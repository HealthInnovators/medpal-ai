package com.healhouts.doctor.adaptor;/*
package com.healhouts.doctor.adaptor;

import android.app.AlertDialog;
import android.app.ProgressDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.provider.Settings;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentManager;
import android.support.v4.app.FragmentPagerAdapter;
import android.util.Log;

import com.healhouts.doctor.R;
import com.healhouts.doctor.common.CommonUtil;
import com.healhouts.doctor.common.ConnectionDetector;
import com.healhouts.doctor.common.ServiceHandler;
import com.healhouts.doctor.fragment.AboutMe;
import com.healhouts.doctor.fragment.EducationSpecailization;
import com.healhouts.doctor.fragment.PractiseLocation;
import com.healhouts.doctor.fragment.WhatYouKnowFor;
import com.healhouts.doctor.fragment.YourPaymentHistory;

import org.json.JSONArray;
import org.json.JSONObject;

import java.net.URISyntaxException;

*/
/**
 * Created by samsung on 18-06-2015.
 *//*

public class ViewPagerProfileSettingsAdapter extends FragmentPagerAdapter {

    private static final String TAG = "AboutMe";
    ProgressDialog pDialog;
    AlertDialog.Builder builder;
    JSONObject jsonObj;
    private Context context;
    Boolean isInternetPresent = false;
    ConnectionDetector cd;
    JSONArray jsonArray;
    SharedPreferences userSharedPreferences;
    String doctorCustomerId;
    String doctorEmail;
    JSONObject jsonObject;
    String jsonStr = "";
    String url = "http://healthouts.com/appDoctorAllDetails?";
    */
/* This will store the Titles of the Tab which are going to be passed when the ViewPagerAdapter is going to be created *//*

    CharSequence Titles[];
    */
/* This will store the number of Tabs which will be passed when the ViewPagerAdapter will be created*//*

    int NumOfTabs;
    public ViewPagerProfileSettingsAdapter(FragmentManager fm, CharSequence mTitles[], int noOfTabs, Context context) {
        super(fm);
        this.Titles = mTitles;
        this.NumOfTabs = noOfTabs;
        this.context = context;

        cd = new ConnectionDetector(context);
        isInternetPresent = cd.isConnectingToInternet();
        userSharedPreferences = context.getSharedPreferences(context.getString(R.string.cPreferences), Context.MODE_PRIVATE);
        doctorCustomerId = userSharedPreferences.getString(context.getString(R.string.customerId), null);
        doctorEmail = userSharedPreferences.getString(context.getResources().getString(R.string.customerEmail), null);
        getDoctorDetials();
    }

    @Override
    public Fragment getItem(int position) {
//        switch (position){
//            case 0:
//                PublicQuestionsFragment tab1 = new PublicQuestionsFragment();
//                return tab1;
//                break;
//            case 1:
//                AskQuestionsFragment tab2 = new AskQuestionsFragment();
//                return tab2;
//                break;
//            case 2:
//                YourFreeQuestionsFragment tab3 = new YourFreeQuestionsFragment();
//                return tab3;
//                break;
//            default:
//                PublicQuestionsFragment tab = new PublicQuestionsFragment();
//                return tab;
//                break;
//        }
        Bundle bundle = new Bundle();
        bundle.putString("jsonStr",jsonStr);
        if (position == 0) {
            AboutMe tab1 = new AboutMe();
            tab1.setArguments(bundle);
            return tab1;
        } else if (position == 1) {
            EducationSpecailization tab2 = new EducationSpecailization();
            tab2.setArguments(bundle);
            return tab2;
        } else if(position==2){
            PractiseLocation tab3=new PractiseLocation();
            tab3.setArguments(bundle);
            return  tab3;
        }else if(   position==3){
            WhatYouKnowFor tab4=new WhatYouKnowFor();
            tab4.setArguments(bundle);
            return  tab4;
        }else{
            YourPaymentHistory tab5=new YourPaymentHistory();
            return tab5;
        }
    }

    // This method return the titles for the Tabs in the Tab Strip
    public CharSequence getPageTitle(int position) {
        return Titles[position];
    }
    @Override
    public int getCount() {
        return NumOfTabs;
    }


    private void getDoctorDetials() {

        ServiceHandler sh = new ServiceHandler();

        String str = "";
        str = str + url;

        try {

            String queryStr = new CommonUtil().ConvertToUrlString(str + "CID=" + doctorCustomerId + "&cEmail=" + doctorEmail);
            Log.d(TAG, "Query string  is" + queryStr);

            if (isInternetPresent) {

                jsonStr = sh.makeServiceCall(queryStr, ServiceHandler.GET);
                try {

                    jsonObject = new JSONObject(jsonStr);


                } catch (Throwable t) {
                    Log.e("My App", "Could not parse malformed JSON: \"" + jsonStr + "\"");
                }

            } else {
                new Thread(new Runnable() {
                    public void run() {
                        final AlertDialog.Builder builder = new AlertDialog.Builder(context);
                        builder.setTitle("Connection failure");
                        builder.setMessage("Please check your network connection and try again");
                        builder.setIcon(R.drawable.warn)
                                .setPositiveButton("cancel", new DialogInterface.OnClickListener() {
                                    public void onClick(DialogInterface dialog, int id) {
                                        builder.setCancelable(true);
                                    }
                                })
                                .setNegativeButton("Wi-Fi Settings", new DialogInterface.OnClickListener() {
                                    public void onClick(DialogInterface dialog, int id) {
                                        context.startActivity(new Intent(Settings.ACTION_WIFI_SETTINGS));

                                    }
                                });
                        builder.show();

                    }
                });

            }

        } catch (URISyntaxException e1) {
            // TODO Auto-generated catch block
            e1.printStackTrace();
        }

    }

}
*/
