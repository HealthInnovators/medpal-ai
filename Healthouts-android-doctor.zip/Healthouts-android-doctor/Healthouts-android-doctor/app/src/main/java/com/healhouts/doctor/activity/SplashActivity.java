package com.healhouts.doctor.activity;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.app.AlertDialog;

import com.healhouts.doctor.AMS;
import com.healhouts.doctor.LoginActivity;
import com.healhouts.doctor.R;
import com.healhouts.doctor.common.ConnectionDetector;


public class SplashActivity extends Activity {
    Boolean isInternetPresent = false;
    AlertDialog.Builder builder;
    ConnectionDetector cd;
    private Context context;


    // Splash screen timer
    private static int SPLASH_TIME_OUT = 3000;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_splash);

        context = getApplicationContext();
        cd = new ConnectionDetector(context);
        isInternetPresent = cd.isConnectingToInternet();


        new Handler().postDelayed(new Runnable() {

            /*
             * Showing splash screen with a timer. This will be useful when you
             * want to show case your app logo / company
             */

            @Override
            public void run() {

                // This method will be executed once the timer is over
                // Start your app main activity
                if (isInternetPresent) {
                    Intent i = new Intent(SplashActivity.this, LoginActivity.class);
                    startActivity(i);

                    // close this activity
                    finish();
                } else {
                    // Internet connection is not present
                    // Ask user to connect to Internet
                    showAlertDialog(SplashActivity.this, "No Internet Connection",
                            "You don't have internet connection.", false);
                }
            }
        }, SPLASH_TIME_OUT);
    }

    public void showAlertDialog(Context context, String title, String message, Boolean status) {
        AlertDialog alertDialog = new AlertDialog.Builder(context).create();

        // Setting Dialog Title
        alertDialog.setTitle(title);

        // Setting Dialog Message
        alertDialog.setMessage(message);

        // Setting alert dialog icon
        alertDialog.setIcon((status) ? R.drawable.ic_action_accept : R.drawable.ic_action_warning);

        // Setting OK Button
        alertDialog.setButton("OK", new DialogInterface.OnClickListener() {
            public void onClick(DialogInterface dialog, int which) {
            }
        });

        // Showing Alert Message
        alertDialog.show();
    }

}