package com.healhouts.doctor.bean;

/**
 * Created by Venkat Veeravalli on 17-06-2015.
 */
public class FeedItemPaidQuestions {
    private String customerImage;
    private String customerName;
    private String customerAge;
    private String time;
    private String questionSubject;
    private String question;
    private String customerGende;
    private String chatType;
    private String doctorId;
    private String chatId;
    private String customerId;
    private String doctorCustomerId;
    private String doctorEmail;

    public String getDoctorCustomerId() {
        return doctorCustomerId;
    }

    public void setDoctorCustomerId(String doctorCustomerId) {
        this.doctorCustomerId = doctorCustomerId;
    }

    public String getDoctorEmail() {
        return doctorEmail;
    }

    public void setDoctorEmail(String doctorEmail) {
        this.doctorEmail = doctorEmail;
    }

    public String getCustomerHealthFile() {
        return customerHealthFile;
    }

    public void setCustomerHealthFile(String customerHealthFile) {
        this.customerHealthFile = customerHealthFile;
    }

    private String customerHealthFile;

    public String getCustomerImage() {
        return customerImage;
    }

    public void setCustomerImage(String customerImage) {
        this.customerImage = customerImage;
    }

    public String getCustomerName() {
        return customerName;
    }

    public void setCustomerName(String customerName) {
        this.customerName = customerName;
    }

    public String getCustomerAge() {
        return customerAge;
    }

    public void setCustomerAge(String customerAge) {
        this.customerAge = customerAge;
    }

    public String getTime() {
        return time;
    }

    public void setTime(String time) {
        this.time = time;
    }

    public String getCustomerId() {
        return customerId;
    }

    public void setCustomerId(String customerId) {
        this.customerId = customerId;
    }

    public String getQuestionSubject() {
        return questionSubject;
    }

    public void setQuestionSubject(String questionSubject) {
        this.questionSubject = questionSubject;
    }

    public String getCustomerGende() {
        return customerGende;
    }

    public void setCustomerGende(String customerGende) {
        this.customerGende = customerGende;
    }

    public String getQuestion() {
        return question;
    }

    public void setQuestion(String question) {
        this.question = question;
    }

    public String getChatType() {
        return chatType;
    }

    public void setChatType(String chatType) {
        this.chatType = chatType;
    }

    public String getDoctorId() {
        return doctorId;
    }

    public void setDoctorId(String doctorId) {
        this.doctorId = doctorId;
    }

    public String getChatId() {
        return chatId;
    }

    public void setChatId(String chatId) {
        this.chatId = chatId;
    }
}
