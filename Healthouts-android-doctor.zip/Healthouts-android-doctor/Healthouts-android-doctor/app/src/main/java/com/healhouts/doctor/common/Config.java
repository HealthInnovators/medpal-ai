package com.healhouts.doctor.common;

/**
 * Created by Venkat on 27-05-2015.
 */
public class Config {

    public static final String UPDATE_ABOUTME_URL = "http://healthouts.com/appUpdateDoctorProfileInfo";

//public static final String UPDATE_ABOUTME_URL = "http://joslinlive.org/appUpdateDoctorProfileInfo";

}
