package com.healhouts.doctor.adaptor;
import android.content.Context;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;

import com.healhouts.doctor.R;
import com.healhouts.doctor.bean.FeedItemPublicQA;

import java.util.List;

/**
 * Created by samsung on 15-06-2015.
 */
public class MyRecyclerAdapterPublicQA extends RecyclerView.Adapter<MyRecyclerAdapterPublicQA.FeedListRowHolderPublicQA> implements View.OnClickListener {

    String TAG=getClass().getName();
    LinearLayout linearLayout;
    private List<FeedItemPublicQA> feedItemList;
    private Context mContext;
    OnItemClickListener mItemClickListener;
    public MyRecyclerAdapterPublicQA(Context context, List<FeedItemPublicQA> feedItemList) {
        this.feedItemList = feedItemList;
        this.mContext = context;
    }
@Override
    public FeedListRowHolderPublicQA onCreateViewHolder(ViewGroup viewGroup, int viewType) {
        View v = LayoutInflater.from(viewGroup.getContext()).inflate(R.layout.your_public_feed_list, null);
        final Button button;
        button=(Button)v.findViewById(R.id.button);
        button.setOnClickListener(this);


        FeedListRowHolderPublicQA mh = new FeedListRowHolderPublicQA(v);

        return mh;
    }
    public void onBindViewHolder(final FeedListRowHolderPublicQA feedListRowHolder, final int i) {
        final FeedItemPublicQA feedItem = feedItemList.get(i);
        feedItem.getCdob();
        if(!feedItem.getCdob().equals("")) {
            feedListRowHolder.cdob.setText(feedItem.getCdob() + "years");
        }
        feedListRowHolder.cgender.setText(feedItem.getCgender());
        feedListRowHolder.location.setText(feedItem.getLocation());
        feedListRowHolder.time.setText(feedItem.getTime());
        feedListRowHolder.question.setText(feedItem.getQuestion());
    }
    public int getItemCount() {

        return (null != feedItemList ? feedItemList.size() : 0);
    }

    @Override
    public void onClick(View v) {

    }

    public  interface OnItemClickListener{
        public  void onItemClick(View view, int position);
    }
    public void SetOnItemClickListener(final OnItemClickListener mItemClickListener) {
        this.mItemClickListener = mItemClickListener;
    }

    public class FeedListRowHolderPublicQA  extends RecyclerView.ViewHolder implements View.OnClickListener{

        protected TextView question;
        protected TextView cgender;
        protected TextView location;
        protected TextView cdob;
        protected  TextView time;
        protected Button button;

        public FeedListRowHolderPublicQA(View view) {
            super(view);
            this.question = (TextView) view.findViewById(R.id.question);
            this.cgender=(TextView)view.findViewById(R.id.cgender);
            this.location = (TextView) view.findViewById(R.id.location);
            this.cdob = (TextView) view.findViewById(R.id.cdob);
            this.time=(TextView)view.findViewById(R.id.time);
            this.button=(Button)view.findViewById(R.id.button);
            this.button.setOnClickListener(this);
        }

        @Override
        public void onClick(View v) {

            if (mItemClickListener != null) {
                mItemClickListener.onItemClick(v, getPosition());
            }
        }

    }


}
