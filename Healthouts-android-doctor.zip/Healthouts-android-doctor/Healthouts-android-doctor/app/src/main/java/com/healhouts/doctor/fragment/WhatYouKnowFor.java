package com.healhouts.doctor.fragment;

import android.app.AlertDialog;
import android.app.ProgressDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.AsyncTask;
import android.os.Bundle;
import android.os.StrictMode;
import android.provider.Settings;
import android.app.Fragment;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.WindowManager;
import android.view.inputmethod.InputMethodManager;
import android.widget.Button;
import android.widget.EditText;

import com.healhouts.doctor.R;
import com.healhouts.doctor.common.CommonUtil;
import com.healhouts.doctor.common.ConnectionDetector;
import com.healhouts.doctor.common.ServiceHandler;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.net.URISyntaxException;

/**
 * Created by samsung on 18-06-2015.
 */
public class WhatYouKnowFor extends Fragment {
    private static final String TAG = "WhatYouKnowFor";
    ProgressDialog pDialog;
    AlertDialog.Builder builder;
    JSONObject jsonObj;
    private Context context;
    Boolean isInternetPresent = false;
    ConnectionDetector cd;
    JSONArray jsonArray;
    SharedPreferences userSharedPreferences;
    String doctorCustomerId;
    String doctorEmail;
    EditText topic1, topic2, topic3,topic4, topic5;
    String topic1ET, topic2ET, topic3ET,topic4ET, topic5ET;

    Button saveProfile;
    JSONObject jsonObject;
    String jsonStr = "";
    String url = "http://healthouts.com/appDoctorAllDetails?";
    String url2="http://healthouts.com/appSaveKnwonfor?";


//    String url = "http://joslinlive.org/appDoctorAllDetails?";
//    String url2="http://joslinlive.org/appSaveKnwonfor?";

    @Override
    public void onCreate(Bundle savedInstanceState) {
        // TODO Auto-generated method stub
        super.onCreate(savedInstanceState);
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        getActivity().getWindow().setSoftInputMode(
                WindowManager.LayoutParams.SOFT_INPUT_ADJUST_PAN);

        StrictMode.ThreadPolicy policy = new StrictMode.ThreadPolicy.Builder().permitAll().build();
        StrictMode.setThreadPolicy(policy);
        context = getActivity().getApplicationContext();
        cd = new ConnectionDetector(context);
        isInternetPresent = cd.isConnectingToInternet();


        View view = inflater.inflate(R.layout.whatyouknowfor, null);
        userSharedPreferences = this.getActivity().getSharedPreferences(context.getString(R.string.cPreferences), Context.MODE_PRIVATE);
        doctorCustomerId = userSharedPreferences.getString(context.getString(R.string.customerId), null);
        doctorEmail = userSharedPreferences.getString(getActivity().getResources().getString(R.string.customerEmail), null);
        
        topic1 = (EditText) view.findViewById(R.id.topic1);
        topic2 = (EditText) view.findViewById(R.id.topic2);
        topic3 = (EditText) view.findViewById(R.id.topic3);
        topic4 = (EditText) view.findViewById(R.id.topic4);
        topic5 = (EditText) view.findViewById(R.id.topic5);      saveProfile = (Button) view.findViewById(R.id.saveProfile);
        saveProfile.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                new GetData().execute();

            }
        });

       // jsonStr = getArguments().getString("jsonStr");
        getWhatYouKnownFor();



        return view;
    }

    private void getWhatYouKnownFor() {
//        String jsonStr = "";
//        ServiceHandler sh = new ServiceHandler();

        String str = "";
        str = str + url;

        try {

            String queryStr = new CommonUtil().ConvertToUrlString(str + "CID=" + doctorCustomerId + "&cEmail=" + doctorEmail);
            Log.d(TAG, "Query string  is" + queryStr);

            if (isInternetPresent) {

                if(jsonStr.equals("")) {
                    ServiceHandler sh = new ServiceHandler();
                    jsonStr = sh.makeServiceCall(queryStr, ServiceHandler.GET);
                }

                try {

                    jsonObject = new JSONObject(jsonStr);
                    jsonObject.optString("topic1");
                    jsonObject.optString("topic2");
                    jsonObject.optString("topic3");
                    jsonObject.optString("topic4");
                    jsonObject.optString("topic5");

                    topic1.setText(jsonObject.optString("topic1"));
                    topic2.setText(jsonObject.optString("topic2"));
                    topic3.setText(jsonObject.optString("topic3"));
                    topic4.setText(jsonObject.optString("topic4"));
                    topic5.setText(jsonObject.optString("topic5"));


                    Log.d("My App", jsonObject.toString());

                } catch (Throwable t) {
                    Log.e("My App", "Could not parse malformed JSON: \"" + jsonStr + "\"");
                }

            } else {
                getActivity().runOnUiThread(new Runnable() {
                    public void run() {
                        final AlertDialog.Builder builder = new AlertDialog.Builder(getActivity());
                        builder.setTitle("Connection failure");
                        builder.setMessage("Please check your network connection and try again");
                        builder.setIcon(R.drawable.warn)
                                .setPositiveButton("cancel", new DialogInterface.OnClickListener() {
                                    public void onClick(DialogInterface dialog, int id) {
                                        builder.setCancelable(true);
                                    }
                                })
                                .setNegativeButton("Wi-Fi Settings", new DialogInterface.OnClickListener() {
                                    public void onClick(DialogInterface dialog, int id) {
                                        startActivityForResult(new Intent(Settings.ACTION_WIFI_SETTINGS), 0);

                                    }
                                });
                        builder.show();

                    }
                });

            }

        } catch (URISyntaxException e1) {
            // TODO Auto-generated catch block
            e1.printStackTrace();
        }


    }

    private class GetData extends AsyncTask<String,String,String> {
        @Override
        protected String doInBackground(String... params) {
            String jsonStr1 = "";
            ServiceHandler sh = new ServiceHandler();

            topic1ET=topic1.getText().toString();
            topic2ET=topic2.getText().toString();
            topic3ET=topic3.getText().toString();
            topic4ET=topic4.getText().toString();
            topic5ET=topic5.getText().toString();

            String str = "";
            str = str + url2;

            try {

                jsonObj=new JSONObject();
                try {
                    jsonObj.put("topic1",topic1ET);
                    jsonObj.put("topic2",topic2ET);
                    jsonObj.put("topic3",topic3ET);
                    jsonObj.put("topic4",topic4ET );
                    jsonObj.put("topic5",topic5ET);


                } catch (JSONException e) {
                    e.printStackTrace();
                }
                String queryStr1 = new CommonUtil().ConvertToUrlString(str +"CID="+doctorCustomerId+"&cEmail="+doctorEmail+"&JSONObj="+jsonObj);
                Log.d(TAG,"Query string  is"+queryStr1);

                if (isInternetPresent) {

                    jsonStr1 = sh.makeServiceCall(queryStr1, ServiceHandler.POST);

                    String flag="1";
                    Log.d(TAG,"jsonobject after"+jsonObj);
                    try {
                        jsonObj = new JSONObject(jsonStr1);
                        if (jsonObj.getString("status").equals(flag)) {
                            getActivity().runOnUiThread(new Runnable() {
                                public void run() {
                                    builder = new AlertDialog.Builder(getActivity());
                                    builder.setCancelable(true);
                                    try {
                                        builder.setMessage(jsonObj.getString("message"));
                                    } catch (JSONException e) {
                                        e.printStackTrace();
                                    }
                                    builder.setInverseBackgroundForced(true);
                                    builder.setNeutralButton("Ok", new DialogInterface.OnClickListener() {
                                        public void onClick(DialogInterface dialog, int whichButton) {
                                            dialog.dismiss();
                                        }
                                    });

                                    builder.show();
                                }
                            });
                        }
                    } catch (JSONException e) {
                        e.printStackTrace();
                    }
                    System.out.print(jsonObj);



                    try {

                        JSONObject jsonObject=new JSONObject(jsonStr1);
                        Log.d(TAG,"saved datais"+jsonObject);
                    } catch (JSONException e) {
                        e.printStackTrace();
                    }


                } else {
                    getActivity().runOnUiThread(new Runnable() {
                        public void run() {

                            final AlertDialog.Builder builder = new AlertDialog.Builder(getActivity());
                            builder.setTitle("Connection failure");
                            builder.setMessage("Please check your network connection and try again");
                            builder.setIcon(R.drawable.warn)
                                    .setPositiveButton("cancel", new DialogInterface.OnClickListener() {
                                        public void onClick(DialogInterface dialog, int id) {
                                            builder.setCancelable(true);
                                        }
                                    })
                                    .setNegativeButton("Wi-Fi Settings", new DialogInterface.OnClickListener() {
                                        public void onClick(DialogInterface dialog, int id) {
                                            startActivityForResult(new Intent(Settings.ACTION_WIFI_SETTINGS), 0);


                                        }
                                    });
                            builder.show();

                        }
                    });

                }

            } catch (URISyntaxException e1) {
                // TODO Auto-generated catch block
                e1.printStackTrace();
            }


            return null;
        }
    }
}
