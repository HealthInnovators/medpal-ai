package com.healhouts.doctor.fragment;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import com.healhouts.doctor.R;

/**
 * Created by samsung on 16-06-2015.
 */
public class ClinicalCases extends android.support.v4.app.Fragment {
    public void onCreate(Bundle savedInstanceState) {
        // TODO Auto-generated method stub
        super.onCreate(savedInstanceState);
    }


    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {


        View view = inflater.inflate(R.layout.clinicalcases, null);
        return view;


    }
}