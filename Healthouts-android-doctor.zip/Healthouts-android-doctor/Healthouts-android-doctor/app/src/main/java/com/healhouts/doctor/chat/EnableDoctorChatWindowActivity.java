package com.healhouts.doctor.chat;

import android.app.Activity;
import android.app.ProgressDialog;
import android.content.Intent;
import android.database.DataSetObserver;
import android.graphics.Bitmap;
import android.os.Bundle;
import android.os.Environment;
import android.os.Handler;
import android.provider.MediaStore;
import android.util.Log;
import android.view.KeyEvent;
import android.view.View;
import android.widget.AbsListView;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.ListView;

import com.healhouts.doctor.R;

import org.jivesoftware.smack.ConnectionConfiguration;
import org.jivesoftware.smack.PacketListener;
import org.jivesoftware.smack.Roster;
import org.jivesoftware.smack.RosterEntry;
import org.jivesoftware.smack.SmackException;
import org.jivesoftware.smack.XMPPConnection;
import org.jivesoftware.smack.XMPPException;
import org.jivesoftware.smack.filter.MessageTypeFilter;
import org.jivesoftware.smack.filter.PacketFilter;
import org.jivesoftware.smack.packet.Message;
import org.jivesoftware.smack.packet.Packet;
import org.jivesoftware.smack.packet.Presence;
import org.jivesoftware.smack.tcp.XMPPTCPConnection;
import org.jivesoftware.smack.util.StringUtils;
import org.jivesoftware.smackx.filetransfer.FileTransfer;
import org.jivesoftware.smackx.filetransfer.FileTransferListener;
import org.jivesoftware.smackx.filetransfer.FileTransferManager;
import org.jivesoftware.smackx.filetransfer.FileTransferRequest;
import org.jivesoftware.smackx.filetransfer.IncomingFileTransfer;
import org.jivesoftware.smackx.filetransfer.OutgoingFileTransfer;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.OutputStream;
import java.util.Collection;

/**
 * Created by Venkat Veeravalli on 05-03-2015.
 */
public class EnableDoctorChatWindowActivity extends Activity {

    public static final String HOST = "healthouts.com";
    public static final int PORT = 5222;
    public String USERNAME;
    public String PASSWORD;

    private XMPPConnection connection;
//    private ArrayList<String> messages = new ArrayList<String>();
    private Handler mHandler = new Handler();

    private ChatArrayAdapter chatArrayAdapter;

    private EditText recipient;
    private EditText textMessage;
    private ListView listView;

//    private static String cPreferences;
//    private static String customerId;
//    private static String customerName;
//    String doctorCustomerId;
//    String dName;
//    SharedPreferences sharedpreferences;
    private static String server = "healthouts.com";
    private static String name = "healthouts";

    private String customerId;
    private String customerName;
    private String doctorCustId;
    private String doctorName;
    String msgToken;
    String to;
    private boolean side = true;
    static final String TAG = "EnableDoctorChat";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.chatwindow);
        Bundle myBundle = getIntent().getExtras();
        customerId = myBundle.getString("customerId");
        customerName = myBundle.getString("customerName");
        doctorCustId = myBundle.getString("doctorCustId");
        doctorName = myBundle.getString("doctorName");

        USERNAME = "healthouts"+doctorCustId;
        PASSWORD = "healthouts"+doctorCustId;

        to = "healthouts"+customerId+"@"+server;
        recipient = (EditText) this.findViewById(R.id.toET);
        recipient.setText(customerName);
        textMessage = (EditText) this.findViewById(R.id.chatET);
        listView = (ListView) this.findViewById(R.id.listMessages);
//        listview = (ListView) this.findViewById(R.id.listView1);
        chatArrayAdapter = new ChatArrayAdapter(getApplicationContext(), R.layout.activity_chat_singlemessage);
        listView.setAdapter(chatArrayAdapter);
//        setListAdapter();
        textMessage.setOnKeyListener(new View.OnKeyListener() {
            public boolean onKey(View v, int keyCode, KeyEvent event) {
                if ((event.getAction() == KeyEvent.ACTION_DOWN) && (keyCode == KeyEvent.KEYCODE_ENTER)) {
                    return setListAdapter(textMessage.getText().toString(), true);
                }
                return false;
            }
        });

        // Set a listener to send a chat text message
        ImageView send = (ImageView) this.findViewById(R.id.sendBtn);
        send.setOnClickListener(new View.OnClickListener() {
            public void onClick(View view) {
//						String to = recipient.getText().toString();

                String text = textMessage.getText().toString();

                if(text.length() > 0){

                    Log.i("XMPPChatDemoActivity", "Sending text " + text + " to " + to);
                    Message msg = new Message(to, Message.Type.chat);
                    msg.setBody(text);
//                setListAdapter(text);
                    if (connection != null) {
                        try {
                            Log.i("EnableChatActivity", "------>" + connection.getUser());
                            connection.sendPacket(msg);
                        } catch (SmackException.NotConnectedException e) {
                            // TODO Auto-generated catch block
                            e.printStackTrace();
                        } catch (SmackException e) {
                            e.printStackTrace();
                        }

                        setListAdapter(text, true);
                    }
                }else if(text.length() == 0){
                    open();
                }

//                Log.i(TAG, "Sending text " + text + " to " + to);
//                Message msg = new Message(to, Message.Type.chat);
//                msg.setBody(text);
//                if (connection != null) {
//                    try {
//                        Log.i(TAG, "------>"+connection.getUser());
//
//                        //====================file transfer code=======================================================
//
//                        FileTransferManager manager = new FileTransferManager(connection);
//                        OutgoingFileTransfer transfer = manager.createOutgoingFileTransfer(to+"/Smack");
//                        File file =new File("venkat.jpg");
//                        transfer.sendFile(file, "test_file");
//                        while (!transfer.isDone()){
//                            if(transfer.getStatus().equals(FileTransfer.Status.error)) {
//                                System.out.println("ERROR!!! " + transfer.getError());
//                            } else if (transfer.getStatus().equals(FileTransfer.Status.cancelled)
//                                    || transfer.getStatus().equals(FileTransfer.Status.refused)) {
//                                System.out.println("Cancelled!!! " + transfer.getError());
//                            }
//                            try {
//                                Thread.sleep(1000L);
//                            } catch (InterruptedException e) {
//                                e.printStackTrace();
//                            }
//                        }
//                        if(transfer.getStatus().equals(FileTransfer.Status.refused) || transfer.getStatus().equals(FileTransfer.Status.error)
//                                || transfer.getStatus().equals(FileTransfer.Status.cancelled)){
//                            System.out.println("refused cancelled error " + transfer.getError());
//                        } else {
//                            System.out.println("Success");
//                        }
//
//
//
//                        //===============================================================================================
//
////                        connection.sendPacket(msg);
//                    } catch (SmackException.NotConnectedException e) {
//                        // TODO Auto-generated catch block
//                        e.printStackTrace();
//                    } catch (SmackException e) {
//                        e.printStackTrace();
//                    }
////							messages.add(connection.getUser() + ":");
////                    messages.add("Dr."+doctorName+ ":");
////                    messages.add(text);
//                    setListAdapter(text, true);
//                }
            }
        });


        connect();
        listView.setTranscriptMode(AbsListView.TRANSCRIPT_MODE_ALWAYS_SCROLL);
        listView.setAdapter(chatArrayAdapter);

        //to scroll the list view to bottom on data change
        chatArrayAdapter.registerDataSetObserver(new DataSetObserver() {
            @Override
            public void onChanged() {
                super.onChanged();
                listView.setSelection(chatArrayAdapter.getCount() - 1);
            }
        });
    }
    private boolean setListAdapter(String msg, boolean side) {

        chatArrayAdapter.add(new ChatMessage(side, msg));
        textMessage.setText("");


        return true;
    }
//    private void setListAdapter() {
//        ArrayAdapter<String> adapter = new ArrayAdapter<String>(this,
//                R.layout.listitem, messages);
//        listview.setAdapter(adapter);
//    }
    @Override
    protected void onDestroy() {
        super.onDestroy();
        try {
            if (connection != null)
                connection.disconnect();
        } catch (Exception e) {

        }
    }
    public void connect() {

        final ProgressDialog dialog = ProgressDialog.show(this,
                "Connecting...", "Please wait...", false);

        Thread t = new Thread(new Runnable() {

            @Override
            public void run() {
                // Create a connection
                Log.i(TAG, "------>" + HOST);
                ConnectionConfiguration connConfig = new ConnectionConfiguration(HOST, PORT);
                connConfig.setReconnectionAllowed(true);
                connConfig.setDebuggerEnabled(true);
                connConfig.setSecurityMode(ConnectionConfiguration.SecurityMode.disabled);
//				connConfig.setCompressionEnabled(true);
//				connConfig.setSASLAuthenticationEnabled(true);
//	            xmppConnection = new XMPPConnection(configuration);
                XMPPConnection connection = new XMPPTCPConnection(connConfig);

                try {
                    connection.connect();
                    Log.i("XMPPChatDemoActivity",
                            "Connected to " + connection.getHost());
                    Log.i("XMPPChatDemoActivity",
                            "is connected-------> " + connection.isConnected());

                } catch (XMPPException | SmackException | IOException ex) {
                    Log.e("XMPPChatDemoActivity", "Failed to connect to "
                            + connection.getHost());

                    Log.e("XMPPChatDemoActivity", ex.toString());
                    Log.e("tag", "-----" + ((SmackException.ConnectionException) ex).getFailedAddresses());
                    setConnection(null);
                }
                try {
                    // SASLAuthentication.supportSASLMechanism("PLAIN", 0);
                    connection.login(USERNAME, PASSWORD);
                    Log.i(TAG, "Logged in as " + connection.getUser());

                    // Set the status to available
                    Presence presence = new Presence(Presence.Type.available);
                    connection.sendPacket(presence);
                    setConnection(connection);

                    Roster roster = connection.getRoster();
                    Collection<RosterEntry> entries = roster.getEntries();
                    for (RosterEntry entry : entries) {
                        Log.d("XMPPChatDemoActivity",
                                "--------------------------------------");
                        Log.d(TAG, "RosterEntry " + entry);
                        Log.d(TAG,
                                "User: " + entry.getUser());
                        Log.d(TAG,
                                "Name: " + entry.getName());
                        Log.d(TAG,
                                "Status: " + entry.getStatus());
                        Log.d(TAG,
                                "Type: " + entry.getType());
                        Presence entryPresence = roster.getPresence(entry
                                .getUser());

                        Log.d(TAG, "Presence Status: "
                                + entryPresence.getStatus());
                        Log.d(TAG, "Presence Type: "
                                + entryPresence.getType());
                        Presence.Type type = entryPresence.getType();
                        if (type == Presence.Type.available)
                            Log.d(TAG, "Presence AVIALABLE");
                        Log.d(TAG, "Presence : "
                                + entryPresence);

                    }
                } catch (XMPPException | SmackException | IOException ex) {
                    Log.e(TAG, "Failed to log in as "
                            + USERNAME);
                    Log.e(TAG, ex.toString());
                    setConnection(null);
                }

                dialog.dismiss();
            }
        });
        t.start();
        dialog.show();
    }
    /**
     * Called by Settings dialog when a connection is establised with the XMPP
     * server
     *
     * @param connection
     */
    public void setConnection(XMPPConnection connection) {
        this.connection = connection;
        if (connection != null) {

            FileTransferManager manager = new FileTransferManager(connection);
            manager.addFileTransferListener(new FileTransferListener() {
                public void fileTransferRequest(final FileTransferRequest request) {
                    new Thread(){
                        @Override
                        public void run() {
                            IncomingFileTransfer transfer = request.accept();
                            File mf = Environment.getExternalStorageDirectory();
                            File file = new File(mf.getAbsoluteFile()+"/DCIM/Camera/" + transfer.getFileName());
                            try{
                                transfer.recieveFile(file);
                                while(!transfer.isDone()) {
                                    try{
                                        Thread.sleep(1000L);
                                    }catch (Exception e) {
                                        Log.e("", e.getMessage());
                                    }
                                    if(transfer.getStatus().equals(FileTransfer.Status.error)) {
                                        Log.e("ERROR!!! ", transfer.getError() + "");
                                    }
                                    if(transfer.getException() != null) {
                                        transfer.getException().printStackTrace();
                                    }
                                }
                            }catch (Exception e) {
                                Log.e("", e.getMessage());
                            }
                        };
                    }.start();
                }
            });







            // Add a packet listener to get messages sent to us
            PacketFilter filter = new MessageTypeFilter(Message.Type.chat);
            connection.addPacketListener(new PacketListener() {
                @Override
                public void processPacket(Packet packet) {
                    Message message = (Message) packet;
                    if (message.getBody() != null) {
                        String fromName = StringUtils.parseBareAddress(message
                                .getFrom());
//                        Log.i(TAG, "Text Recieved " + message.getBody()
//                                + " from " + fromName );
//						messages.add(fromName + ":");
//                        messages.add(customerName+" :");
//                        messages.add(message.getBody());
                        msgToken = message.getBody();
                        // Add the incoming message to the list view
                        mHandler.post(new Runnable() {
                            public void run() {
                                setListAdapter(msgToken,false);
                            }
                        });
                    }
                }
            }, filter);
        }

    }
    public void open(){
        Intent intent = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
        startActivityForResult(intent,0);
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        Bitmap bp = (Bitmap)data.getExtras().get("data");


        Log.d(TAG, "--------->" + bp.toString());

        sendFile(bp);
//        imgFavorite.setImageBitmap(bp);
    }
    public void sendFile(Bitmap bp) {
        Log.i("XMPPChatDemoActivity", "Sending File  to " + to);
        OutputStream stream = null;
        try {
            stream = new FileOutputStream(Environment.getExternalStorageDirectory().getAbsoluteFile()+"/DCIM/Camera/VENKAT.jpg");
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        }
        bp.compress(Bitmap.CompressFormat.JPEG, 100, stream);
        if (connection != null) {
            try {
                Log.i("EnableChatActivity", "------>" + connection.getUser());


                //====================file transfer code=======================================================

                FileTransferManager manager = new FileTransferManager(connection);
                OutgoingFileTransfer transfer = manager.createOutgoingFileTransfer(to + "/Smack");
                File file = new File(Environment.getExternalStorageDirectory().getAbsoluteFile()+"/DCIM/Camera/VENKAT.jpg");
                transfer.sendFile(file, "test_file");
                Log.e(TAG, "--sending statud--" + transfer.getStatus());
                while (!transfer.isDone()) {
                    if (transfer.getStatus().equals(FileTransfer.Status.error)) {
                        Log.e(TAG, "ERROR!!! " + transfer.getError());
//                        System.out.println("ERROR!!! " + transfer.getError());
                    } else if (transfer.getStatus().equals(FileTransfer.Status.cancelled)
                            || transfer.getStatus().equals(FileTransfer.Status.refused)) {
                        Log.e(TAG, "Cancelled!!! " + transfer.getError());
//                        System.out.println("Cancelled!!! " + transfer.getError());
                    }
                    try {
                        Thread.sleep(1000L);
                    } catch (InterruptedException e) {
                        e.printStackTrace();
                    }
                }
                if (transfer.getStatus().equals(FileTransfer.Status.refused) || transfer.getStatus().equals(FileTransfer.Status.error)
                        || transfer.getStatus().equals(FileTransfer.Status.cancelled)) {
                    Log.e(TAG, "refused cancelled error " + transfer.getError());
//                    System.out.println("refused cancelled error " + transfer.getError());
                } else {
                    Log.i(TAG, "---file transfer success---");
//                    System.out.println("Success");
                }


                //===============================================================================================


            } catch (SmackException.NotConnectedException e) {
                // TODO Auto-generated catch block
                e.printStackTrace();
            } catch (SmackException e) {
                e.printStackTrace();
            }

//            setListAdapter(text, true);
        }
    }


}
