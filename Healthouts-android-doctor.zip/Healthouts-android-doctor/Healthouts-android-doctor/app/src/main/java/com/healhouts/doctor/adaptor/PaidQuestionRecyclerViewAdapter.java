package com.healhouts.doctor.adaptor;

import android.app.AlertDialog;
import android.app.ProgressDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.content.pm.ResolveInfo;
import android.net.Uri;
import android.os.AsyncTask;
import android.os.Bundle;
import android.os.Environment;
import android.support.v7.widget.RecyclerView;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import com.healhouts.doctor.R;
import com.healhouts.doctor.activity.ZoomInZoomOut;
import com.healhouts.doctor.bean.FeedItemPaidQuestions;
import com.healhouts.doctor.common.CommonUtil;
import com.healhouts.doctor.common.ServiceHandler;
import com.squareup.picasso.Picasso;

import org.json.JSONException;
import org.json.JSONObject;

import java.io.File;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.URISyntaxException;
import java.net.URL;
import java.util.List;

/**
 * Created by Venkat Veeravalli on 17-06-2015.
 */
public class PaidQuestionRecyclerViewAdapter extends RecyclerView.Adapter<PaidQuestionRecyclerViewAdapter.FeedItemRowHolderPQ> {

    private static final String TAG = "PaidQuestionRecyclerViewAdapter";
    OnItemClickListener mItemClickListener;
    private List<FeedItemPaidQuestions> feedItemList;

    private Context mContext;
    String answer = "";
    String summay = "";
    ProgressDialog pDialog;
    AlertDialog.Builder builder;

        static String url = "http://healthouts.com/appSendAnswerToPremiumQuestion?";
//    static String url = "http://joslinlive.org/appSendAnswerToPremiumQuestion?";

    public PaidQuestionRecyclerViewAdapter(Context context, List<FeedItemPaidQuestions> feedItemList) {
        this.feedItemList = feedItemList;
        this.mContext = context;
    }

    @Override
    public FeedItemRowHolderPQ onCreateViewHolder(ViewGroup parent, int viewType) {
        View v = LayoutInflater.from(parent.getContext()).inflate(R.layout.paid_question_list, null);
        FeedItemRowHolderPQ rowHolderPQ = new FeedItemRowHolderPQ(v);
        return rowHolderPQ;
    }

    @Override
    public void onBindViewHolder(final FeedItemRowHolderPQ holder, final int position) {
        final FeedItemPaidQuestions feedItem = feedItemList.get(position);
   Picasso.with(mContext).load(new CommonUtil().ConvertToUrlString("http://healthouts.com/img/"+feedItem.getCustomerImage()))
//        Picasso.with(mContext).load(new CommonUtil().ConvertToUrlString("http://joslinlive.org/img/" + feedItem.getCustomerImage()))
                .error(R.drawable.ic_launcher)
                .placeholder(R.drawable.ic_launcher)
                .into(holder.cImageView);
        holder.patientNameView.setText(feedItem.getCustomerName());
        holder.patientGenderView.setText(feedItem.getCustomerGende());
        holder.patientAgeView.setText(feedItem.getCustomerAge());
        holder.questionView.setText(feedItem.getQuestion());
        if (!feedItem.getCustomerHealthFile().equals("")) {
            holder.imageButton.setVisibility(View.VISIBLE);
           /* holder.imageButton.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {

                }
            });*/
        }
        holder.btnSend.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                summay = holder.editTextAnsSummary.getText().toString();
                answer = holder.editTextAnswer.getText().toString();

                if (!summay.equals("") && !answer.equals("")) {
                    sendPremiumAnswer(feedItem, position, holder);
                } else {
                    Toast toast = Toast.makeText(mContext, "Suject and Answer are not empty!", Toast.LENGTH_SHORT);
                    toast.getView().setBackgroundColor(mContext.getResources().getColor(R.color.error_toast));
                    toast.show();
                }
            }
        });

        holder.imageButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Log.d("---", "--- what it means feedItem.getCustomerHealthFile()----" + feedItem.getCustomerHealthFile());

                if (!feedItem.getCustomerHealthFile().equals("")) {

                    Log.d(TAG,"---Healthfile in adapter---"+feedItem.getCustomerHealthFile());
                   String url = "http://healthouts.com/img/" + feedItem.getCustomerHealthFile();
                   // String url = "http://joslinlive.org/img/" + feedItem.getCustomerHealthFile();
                    downloadPdfContent(url, feedItem.getCustomerHealthFile());
                } else {
                    Toast toast = Toast.makeText(mContext, "Sorry Health file not available!", Toast.LENGTH_SHORT);
                    toast.getView().setBackgroundColor(mContext.getResources().getColor(R.color.error_toast));
                    toast.show();
                }
            }
        });
    }

    public void downloadPdfContent(String urlToDownload, String filename) {
        try {
            ProgressDialog pDialog;
            pDialog = new ProgressDialog(mContext);
            pDialog.setTitle("Please wait");
            pDialog.setMessage("processing.... ");
            pDialog.setCancelable(false);
            pDialog.show();

            String fileName = filename;
            String fileExtension = android.webkit.MimeTypeMap.getSingleton().getFileExtensionFromUrl(fileName);
            String fileMimeType = android.webkit.MimeTypeMap.getSingleton().getMimeTypeFromExtension(fileExtension);

            URL url2 = new URL(urlToDownload);
            HttpURLConnection c = (HttpURLConnection) url2.openConnection();
            c.setRequestMethod("GET");
            c.setDoOutput(true);
            c.connect();
            String PATH = Environment.getExternalStorageDirectory() + "/healthouts/";
           // String PATH = Environment.getExternalStorageDirectory() + "/joslin/";
            File f = new File(PATH + fileName);

            if (!f.exists()) {
                File file = new File(PATH);
                /*createDirIfNotExists("healthouts");*/
                createDirIfNotExists("healthouts");
                File outputFile = new File(file, fileName);
                FileOutputStream fos = new FileOutputStream(outputFile);
                InputStream is = c.getInputStream();
                byte[] buffer = new byte[1024];
                int len1 = 0;
                while ((len1 = is.read(buffer)) != -1) {
                    fos.write(buffer, 0, len1);
                }
                fos.close();
                is.close();
                showFile(PATH + fileName, fileMimeType);

            } else {
                //show file
                showFile(PATH + fileName, fileMimeType);
            }
            pDialog.dismiss();

        } catch (Exception e) {
            e.printStackTrace();

        }
    }

    @Override
    public int getItemCount() {

        return (null != feedItemList ? feedItemList.size() : 0);
    }

    public interface OnItemClickListener {
        public void onItemClick(View view, int position);
    }

    public void SetOnItemClickListener(final OnItemClickListener mItemClickListener) {
        this.mItemClickListener = mItemClickListener;
    }

    public class FeedItemRowHolderPQ extends RecyclerView.ViewHolder implements View.OnClickListener {


        public ImageView cImageView;
        public TextView patientNameView;
        public TextView patientGenderView;
        public TextView patientAgeView;
        public TextView questionView;
        public ImageButton imageButton;
        public Button answerNow;
        public LinearLayout paid_innerLL;
        public EditText editTextAnsSummary;
        public EditText editTextAnswer;
        public Button btnSend;
        public Button btnClose;


        public FeedItemRowHolderPQ(View view) {
            super(view);
            this.cImageView = (ImageView) view.findViewById(R.id.cImage);
            this.patientNameView = (TextView) view.findViewById(R.id.text_patient_name);
            this.patientGenderView = (TextView) view.findViewById(R.id.textPatientAge);
            this.patientAgeView = (TextView) view.findViewById(R.id.textPatientAge);
            this.questionView = (TextView) view.findViewById(R.id.textQuestion);
            this.imageButton = (ImageButton) view.findViewById(R.id.imageButton);
            this.answerNow = (Button) view.findViewById(R.id.answerNow);
            this.paid_innerLL = (LinearLayout) view.findViewById(R.id.paid_innerLL);
            this.editTextAnsSummary = (EditText) view.findViewById(R.id.editTextAnsSummary);
            this.editTextAnswer = (EditText) view.findViewById(R.id.editTextAnswer);
            this.btnSend = (Button) view.findViewById(R.id.btnSend);
            this.btnClose = (Button) view.findViewById(R.id.btnClose);
            answerNow.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    paid_innerLL.setVisibility(View.VISIBLE);
                    answerNow.setVisibility(View.INVISIBLE);
                }
            });

            btnClose.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    paid_innerLL.setVisibility(View.GONE);
                    answerNow.setVisibility(View.VISIBLE);
                }
            });
//        view.setOnClickListener(this);


        }


        @Override
        public void onClick(View v) {

            if (mItemClickListener != null) {
                mItemClickListener.onItemClick(v, getPosition());
            }
        }

    }

    public void sendPremiumAnswer(final FeedItemPaidQuestions feedItem, final int position, final FeedItemRowHolderPQ holder) {
        new AsyncTask<Void, Void, JSONObject>() {
            @Override
            protected JSONObject doInBackground(Void... params) {
                JSONObject job = null;
                String jsonStr = "";
                ServiceHandler sh = new ServiceHandler();
//CID=37&cEmail=sheshakanth@seedinvent.com
                String str = "CID=" + feedItem.getDoctorCustomerId() + "&cEmail=" + feedItem.getDoctorEmail() + "&chatId=" + feedItem.getChatId() + "&summary=" + summay + "&details=" + answer;
                str = url + str;
                Log.d("---", "----str----" + str);
                String queryStr = new CommonUtil().ConvertToUrlString(str);
                try {
                    jsonStr = sh.makeServiceCall(queryStr, ServiceHandler.GET);
                    Log.d("---", "-----jsonStr---" + jsonStr);
                    job = new JSONObject(jsonStr);

                } catch (URISyntaxException e) {
                    e.printStackTrace();
                } catch (JSONException e) {
                    e.printStackTrace();
                }
                return job;
            }

            @Override
            protected void onCancelled() {
                super.onCancelled();
            }

            @Override
            protected void onPreExecute() {
                super.onPreExecute();
                pDialog = new ProgressDialog(mContext);
                pDialog.setTitle("Verifying");
                pDialog.setMessage("the Credentials.... ");
                pDialog.setCancelable(false);
                pDialog.show();
                builder = new AlertDialog.Builder(mContext);
            }

            @Override
            protected void onPostExecute(JSONObject job) {
                super.onPostExecute(job);
                if (pDialog.isShowing())
                    pDialog.dismiss();
                if (job != null) {
                    try {
                        if (job.getString("status").equals("1")) {

                            builder.setCancelable(true);
                            builder.setMessage(job.getString("message"));
                            builder.setInverseBackgroundForced(true);

                            builder.setNeutralButton("Ok", new DialogInterface.OnClickListener() {
                                public void onClick(DialogInterface dialog, int whichButton) {
                                    holder.editTextAnsSummary.setText("");
                                    holder.editTextAnswer.setText("");
                                    holder.paid_innerLL.setVisibility(View.GONE);
                                    holder.answerNow.setVisibility(View.VISIBLE);
                                    Log.d("---", "----position-------" + position);
                                    feedItemList.remove(position);
                                    notifyItemRemoved(position);
                                    Log.d("---", "----done-------");
                                    dialog.dismiss();
                                }
                            });
                            builder.show();
                        } else {
                            builder.setCancelable(true);
                            builder.setMessage(job.getString("message"));
                            builder.setInverseBackgroundForced(true);

                            builder.setNeutralButton("Ok", new DialogInterface.OnClickListener() {
                                public void onClick(DialogInterface dialog, int whichButton) {
//                                    mContext.startActivity(AMS.class);

                                    dialog.dismiss();
                                }
                            });
                        }
                    } catch (JSONException e) {
                        e.printStackTrace();
                    }
                }

            }
        }.execute(null, null, null);

    }

    public static boolean createDirIfNotExists(String path) {
        boolean ret = true;

        File file = new File(Environment.getExternalStorageDirectory(), path);
        if (!file.exists()) {
            if (!file.mkdirs()) {
                Log.e("TravellerLog :: ", "Problem creating Image folder");
                ret = false;
            }
        }
        return ret;
    }

    public void showFile(String path, String fileMimeType) {
        //show file
        Log.d("---", "----path---" + path);
        Log.d("---", "----fileMimeType---" + fileMimeType);

        if (fileMimeType.equals("image/jpeg") || fileMimeType.equals("image/png")) {
            Intent intent = new Intent(mContext, ZoomInZoomOut.class);
            Bundle myData = new Bundle();
            myData.putString("imagePath", path);
            intent.putExtras(myData);
            mContext.startActivity(intent);
        } else {
            Intent intent = new Intent();
            intent.setAction(Intent.ACTION_VIEW);
            intent.setData(Uri.parse(path));
            intent.setType(fileMimeType);
            PackageManager pm = mContext.getPackageManager();
            List<ResolveInfo> activities = pm.queryIntentActivities(intent, 0);
            if (activities.size() > 0) {
                mContext.startActivity(intent);
            } else {
                Toast toast = Toast.makeText(mContext, "Sorry some problem in file download!", Toast.LENGTH_LONG);
                toast.getView().setBackgroundColor(mContext.getResources().getColor(R.color.error_toast));
                toast.show();
            }
        }
    }
}
