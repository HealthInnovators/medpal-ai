package com.healhouts.doctor.activity;

import android.app.ActionBar;
import android.app.FragmentTransaction;
import android.content.Intent;
import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.os.Bundle;
import android.support.v7.app.ActionBarActivity;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.widget.ArrayAdapter;

import com.healhouts.doctor.AMS;
import com.healhouts.doctor.R;
import com.healhouts.doctor.fragment.AboutMe;
import com.healhouts.doctor.fragment.EducationSpecailization;
import com.healhouts.doctor.fragment.PractiseLocation;
import com.healhouts.doctor.fragment.WhatYouKnowFor;
import com.healhouts.doctor.fragment.YourPaymentHistory;
@SuppressWarnings("ALL")
public class ProfileSettings extends ActionBarActivity {


    // nav drawer title
    private CharSequence mDrawerTitle;

    // used to store app title
    private CharSequence mTitle;

    // slide menu items
    private String[] navMenuTitles;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        final android.support.v7.app.ActionBar actionBar = getSupportActionBar();
        ColorDrawable colorDrawable = new ColorDrawable(Color.parseColor("#139454"));
        actionBar.setBackgroundDrawable(colorDrawable);
        mTitle = mDrawerTitle = getTitle();
        // load slide menu items
        navMenuTitles = getResources().getStringArray(R.array.nav_drawer_items);
        // Specify that a dropdown list should be displayed in the action bar.
        actionBar.setNavigationMode(ActionBar.NAVIGATION_MODE_LIST);
        // Hide the title
        actionBar.setDisplayShowTitleEnabled(false);
        actionBar.setDisplayUseLogoEnabled(true);

        // Specify a SpinnerAdapter to populate the dropdown list.
        ArrayAdapter<String> spinnerMenu = new ArrayAdapter<String>(
                actionBar.getThemedContext(),
                android.R.layout.simple_list_item_activated_1, getResources()
                .getStringArray(R.array.labelMenu));


        actionBar.setListNavigationCallbacks(

                spinnerMenu,

                // Provide a listener to be called when an item is selected.
                new android.support.v7.app.ActionBar.OnNavigationListener() {
                    @Override
                    public boolean onNavigationItemSelected(int i, long l) {
                        FragmentTransaction tx = getFragmentManager()
                                .beginTransaction();

                        switch (i) {
                            case 0:
                                tx.replace(android.R.id.content, new AboutMe());
                                break;
                            case 1:
                                tx.replace(android.R.id.content, new EducationSpecailization());
                                break;
                            case 2:
                                tx.replace(android.R.id.content, new PractiseLocation());
                                break;
                            case 3:
                                tx.replace(android.R.id.content, new WhatYouKnowFor());
                                break;
                            case 4:
                                tx.replace(android.R.id.content, new YourPaymentHistory());
                                break;
                            default:
                                break;
                        }

                        tx.commit();

                        return true;
                    }
                });
    }


    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        MenuInflater inflater = getMenuInflater();
        inflater.inflate(R.menu.profilesettings, menu);
        return super.onCreateOptionsMenu(menu);
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()) {
            // Respond to the action baru's Up/Home button
            case R.id.action_home:
                Intent docSpecialities = new Intent(this, AMS.class);
                startActivity(docSpecialities);
                break;


        }
        return super.onOptionsItemSelected(item);
    }


    @Override
    public void setTitle(CharSequence title) {
        mTitle = title;
        android.support.v7.app.ActionBar actionBar = getSupportActionBar();
        actionBar.setTitle(mTitle);
    }
}
/*
import android.app.Fragment;
import android.app.FragmentTransaction;
import android.content.Intent;
import android.content.res.Configuration;
import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.os.Bundle;
import android.support.v4.app.ActionBarDrawerToggle;
import android.support.v4.widget.DrawerLayout;
import android.support.v7.app.ActionBarActivity;
import android.text.Html;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ListView;

import com.healhouts.doctor.AMS;
import com.healhouts.doctor.R;
import com.healhouts.doctor.fragment.AboutMe;
import com.healhouts.doctor.fragment.EducationSpecailization;
import com.healhouts.doctor.fragment.PractiseLocation;
import com.healhouts.doctor.fragment.WhatYouKnowFor;
import com.healhouts.doctor.fragment.YourPaymentHistory;

*/
/**
 * Created by samsung on 24-06-2015.
 *//*

public class ProfileSettings extends ActionBarActivity {


    public AboutMe aboutMe;
    public EducationSpecailization educationSpecailization;
    public PractiseLocation practiseLocation;
    public WhatYouKnowFor whatYouKnowFor;
    public YourPaymentHistory yourPaymentHistory;
    public android.app.FragmentManager fragmentManager;
    public FragmentTransaction fragmentTransaction;
    public DrawerLayout drawerlayout;
    public ActionBarDrawerToggle drawertoggle;
    public ListView drawerlist;
    public String[] drawerItems = {"About Me","Education&Specailization", "PractiseLocation","Known Topics","Your Payment History"};

    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.profile_settings);
        final android.support.v7.app.ActionBar actionBar = getSupportActionBar();
        ColorDrawable colorDrawable = new ColorDrawable(Color.parseColor("#81020B"));
        actionBar.setBackgroundDrawable(colorDrawable);
        actionBar.setTitle(Html.fromHtml("<font color='#ffffff'>" + "Profile Settings" + "</font>"));
        actionBar.setDisplayHomeAsUpEnabled(true);
        actionBar.setHomeButtonEnabled(true);
        getSupportActionBar().setDisplayShowHomeEnabled(true);

        drawerlayout = (DrawerLayout) findViewById(R.id.ganzesLayout);
        drawertoggle = new ActionBarDrawerToggle(ProfileSettings.this, drawerlayout, R.drawable.drawer, R.string.open, R.string.close);
        drawerlayout.setDrawerListener(drawertoggle);



        aboutMe = (AboutMe) Fragment.instantiate(this, AboutMe.class.getName(), null);
        educationSpecailization = (EducationSpecailization) Fragment.instantiate(this, EducationSpecailization.class.getName(), null);
        practiseLocation = (PractiseLocation) Fragment.instantiate(this, PractiseLocation.class.getName(), null);
        whatYouKnowFor = (WhatYouKnowFor) Fragment.instantiate(this, WhatYouKnowFor.class.getName(), null);
        yourPaymentHistory = (YourPaymentHistory) Fragment.instantiate(this, YourPaymentHistory.class.getName(), null);


        fragmentManager = getFragmentManager();
        fragmentTransaction = fragmentManager.beginTransaction();
        fragmentTransaction.add(R.id.HauptLayout,aboutMe);
        fragmentTransaction.commit();


        drawerlist = (ListView) findViewById(R.id.drawerliste);
        ArrayAdapter<String> drawerlistadapter = new ArrayAdapter<String>(this, android.R.layout.simple_list_item_1, drawerItems);
        drawerlist.setAdapter(drawerlistadapter);
        drawerlist.setOnItemClickListener(new AdapterView.OnItemClickListener() {


            @Override
            public void onItemClick(AdapterView<?> arg0, View view, int arg2,
                                    long arg3) {

                switch (drawerlist.getPositionForView(view)) {
                    case 0: {

                        fragmentManager = getFragmentManager();
                        fragmentTransaction = fragmentManager.beginTransaction();
                        fragmentTransaction.replace(R.id.HauptLayout, aboutMe);
                        fragmentTransaction.commit();
                        actionBar.setTitle(Html.fromHtml("<font color='#ffffff'>" + drawerItems[0] + "</font>"));
                        getSupportActionBar().setIcon(R.drawable.aboutme);

*/
/*
*//*

                        drawerlayout.closeDrawers();
                        break;
                    }


                    case 1: {
                        fragmentManager = getFragmentManager();
                        fragmentTransaction = fragmentManager.beginTransaction();
                        fragmentTransaction.replace(R.id.HauptLayout, educationSpecailization);
                        fragmentTransaction.commit();
                        actionBar.setTitle(Html.fromHtml("<font color='#ffffff'>" + drawerItems[1] + "</font>"));
                        getSupportActionBar().setIcon(R.drawable.education);
*/
/*
                        getSupportActionBar().setIcon(R.drawable.contactinformation);
*//*

                        drawerlayout.closeDrawers();
                        break;
                    }


                    case 2: {
                        fragmentManager = getFragmentManager();
                        fragmentTransaction = fragmentManager.beginTransaction();
                        fragmentTransaction.replace(R.id.HauptLayout, practiseLocation);
                        fragmentTransaction.commit();
*/
/*
                        getSupportActionBar().setIcon(R.drawable.medication);
*//*

                        actionBar.setTitle(Html.fromHtml("<font color='#ffffff'>" + drawerItems[2] + "</font>"));
                        getSupportActionBar().setIcon(R.drawable.location);
                        drawerlayout.closeDrawers();
                        break;
                    }
                    case 3: {
                        fragmentManager = getFragmentManager();
                        fragmentTransaction = fragmentManager.beginTransaction();
                        fragmentTransaction.replace(R.id.HauptLayout, whatYouKnowFor);
                        fragmentTransaction.commit();
                        actionBar.setTitle(Html.fromHtml("<font color='#ffffff'>" + drawerItems[3] + "</font>"));
                        getSupportActionBar().setIcon(R.drawable.knowntopic);
*/
/*
                        getSupportActionBar().setIcon(R.drawable.allergies);
*//*

                        drawerlayout.closeDrawers();
                        break;
                    }
                    case 4: {
                        fragmentManager = getFragmentManager();
                        fragmentTransaction = fragmentManager.beginTransaction();
                        fragmentTransaction.replace(R.id.HauptLayout, yourPaymentHistory);
                        fragmentTransaction.commit();
                        actionBar.setTitle(Html.fromHtml("<font color='#ffffff'>" + drawerItems[4] + "</font>"));
                        getSupportActionBar().setIcon(R.drawable.paymenthistory);
*/
/*
                        getSupportActionBar().setIcon(R.drawable.symptoms);
*//*

                        drawerlayout.closeDrawers();

                        break;
                    }


                }


            }
        });




    }

    @Override
    public void onConfigurationChanged(Configuration newConfig) {
        drawertoggle.onConfigurationChanged(newConfig);
        super.onConfigurationChanged(newConfig);
    }

    @Override
    protected void onPostCreate(Bundle savedInstanceState) {
        drawertoggle.syncState();
        super.onPostCreate(savedInstanceState);
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.main1, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.




        if (drawertoggle.onOptionsItemSelected(item)) {
            return true;
        }

        switch (item.getItemId()) {


            case R.id.back:

                Intent docSpecialities = new Intent(this, AMS.class);
                startActivity(docSpecialities);

                break;

            default:

        }




        return super.onOptionsItemSelected(item);
    }

}
*/
