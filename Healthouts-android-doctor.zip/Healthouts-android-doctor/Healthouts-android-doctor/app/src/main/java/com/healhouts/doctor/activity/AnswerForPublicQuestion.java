package com.healhouts.doctor.activity;

import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.os.Bundle;
import android.support.v7.app.ActionBarActivity;
import android.text.Html;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.healhouts.doctor.AMS;
import com.healhouts.doctor.R;
import com.healhouts.doctor.common.CommonUtil;
import com.healhouts.doctor.common.ServiceHandler;

import org.json.JSONException;
import org.json.JSONObject;

import java.net.URISyntaxException;

/**
 * Created by samsung on 04-06-2015.
 */

public class AnswerForPublicQuestion extends ActionBarActivity {
    Button submit,cancel;
    EditText summary,answer;
    String questionid,doctorCustomerId,doctorEmail,answer_data,summary_data;
    JSONObject jsonObject;
    String TAG = getClass().getName();
    public String URL = " http://healthouts.com/appSendFreeAnswer?";
//    public String URL = " http://joslinlive.org/appSendFreeAnswer?";
    AlertDialog.Builder builder;
    String flag = "1";
    @Override
    protected void onCreate(Bundle savedInstanceState) {

        // TODO Auto-generated method stub
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_answer);
        android.support.v7.app.ActionBar actionBar = getSupportActionBar();
        ColorDrawable colorDrawable = new ColorDrawable(Color.parseColor("#139454"));
        actionBar.setBackgroundDrawable(colorDrawable);
        actionBar.setTitle(Html.fromHtml("<font color='#ffffff'>" + "Post Answer" + "</font>"));
        actionBar.setDisplayHomeAsUpEnabled(true);
        actionBar.setHomeButtonEnabled(true);

        questionid= getIntent().getExtras().getString("questionId");
        Log.d(TAG,"question id"+questionid);
        doctorEmail = getIntent().getExtras().getString("doctorEmail");
        doctorCustomerId = getIntent().getExtras().getString("doctorCustomerId");
        summary = (EditText) findViewById(R.id.summary);
        answer = (EditText) findViewById(R.id.answer);
        submit=(Button)findViewById(R.id.submit);
        cancel=(Button)findViewById(R.id.cancel);
        cancel.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                finish();
            }
        });
        submit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Toast.makeText(getApplicationContext(), "clicked", Toast.LENGTH_LONG).show();
                summary=(EditText)findViewById(R.id.summary);
                answer=(EditText)findViewById(R.id.answer);
                summary_data=summary.getText().toString();
                answer_data=answer.getText().toString();
                ServiceHandler sh = new ServiceHandler();
                String jsonStr = "";
                String queryStr = null;
                if (answer_data.equals("") || summary_data.equals("")) {
                    {
                        builder = new AlertDialog.Builder(AnswerForPublicQuestion.this);
                        Log.d("","answerdata"+answer_data);
                        Log.d("","summary"+summary_data);
                        builder.setCancelable(true);
                        builder.setMessage("You haven't Provided any Answer to the Question");
                        builder.setInverseBackgroundForced(true);
                        builder.setNeutralButton("Ok", new DialogInterface.OnClickListener() {
                            public void onClick(DialogInterface dialog, int whichButton) {
                                dialog.dismiss();
                            }
                        });

                        builder.show();
                    }

                    }
                else {
                    Log.d(TAG, "" + answer_data);
                    queryStr = new CommonUtil().ConvertToUrlString(URL + "CID=" + doctorCustomerId + "&cEmail=" + doctorEmail + "&questionId=" + questionid + "&summary=" +summary_data+ "&details=" + answer_data);

                    Log.d(TAG, "--" + queryStr);
                    try {
                        jsonStr = sh.makeServiceCall(queryStr, ServiceHandler.POST);
                        Log.d(TAG, "------" + jsonStr);
                        jsonObject = new JSONObject(jsonStr);
                        if (jsonObject.getString("status").equals(flag)) {
                         /*   jsonObject.getString("message");*/

                            builder = new AlertDialog.Builder(AnswerForPublicQuestion.this);
                            builder.setCancelable(true);
                            builder.setMessage(""+   jsonObject.getString("message"));
                            builder.setInverseBackgroundForced(true);
                            builder.setNeutralButton("OK", new DialogInterface.OnClickListener() {
                                public void onClick(DialogInterface dialog, int whichButton) {
                                    Intent i = new Intent(AnswerForPublicQuestion.this,AMS.class);
                                   startActivity(i);
                                }
                            });

                            builder.show();

                        }
                    } catch (URISyntaxException e) {
                        e.printStackTrace();
                    } catch (JSONException e) {
                        e.printStackTrace();
                    }
                }
            }
        });

    }
    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.menu_test, menu);
        return true;
    }
    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()) {
            case android.R.id.home:
                super.onBackPressed();
                break;
            default:
        }
        return super.onOptionsItemSelected(item);
    }
}