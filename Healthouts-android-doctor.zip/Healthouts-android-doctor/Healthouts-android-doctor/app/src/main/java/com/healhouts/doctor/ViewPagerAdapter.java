package com.healhouts.doctor;

import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentManager;
import android.support.v4.app.FragmentStatePagerAdapter;

/**
 * Created by sony on 23/02/2015.
 */
public class ViewPagerAdapter extends FragmentStatePagerAdapter {
/* This will store the Titles of the Tab which are going to be passed when the ViewPagerAdapter is going to be created */
    CharSequence Titles[];
/* This will store the number of Tabs which will be passed when the ViewPagerAdapter will be created*/
    int NumOfTabs;
/* Make a constructor and pass the appropriate values to the constructor*/
    public ViewPagerAdapter(FragmentManager fm,CharSequence mTitles[],int noOfTabs) {
        super(fm);
        this.Titles=mTitles;
        this.NumOfTabs=noOfTabs;
    }

    /*This method will return the Fragment for every new position in the View Pager*/
    @Override
    public Fragment getItem(int position) {
        if(position==0){
            YourAppointments tab1=new YourAppointments();
            return tab1;
        }
        else
        {
            ManageAppointments tab2=new ManageAppointments();
            return tab2;
        }
    }

    // This method return the titles for the Tabs in the Tab Strip

    public CharSequence getPageTitle(int position)
    {
        return Titles[position];
    }

   @Override
    public int getCount() {
        return NumOfTabs;
    }
}
