package com.healhouts.doctor.navigationdrawer;

/**
 * Created by trina on 9/1/2015.
 */

import android.app.DatePickerDialog;
import android.app.Dialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.SharedPreferences;
import android.os.AsyncTask;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.GridView;
import android.widget.ImageButton;

import com.healhouts.doctor.R;
import com.healhouts.doctor.adaptor.DoctorTimingsCustomGrid;
import com.healhouts.doctor.bean.FeedItemDoctorTimings;
import com.healhouts.doctor.common.CommonUtil;
import com.healhouts.doctor.common.ServiceHandler;

import org.json.JSONObject;

import java.util.ArrayList;
import java.util.Calendar;
import java.util.List;

public class Test extends Fragment {
    private String availableUrl = "http://healthouts.com/appDocAvailability";
    //    private String availableUrl = "http://joslinlive.org/appDocAvailability";
    private String doctorId;

    private String doctorCustomerId;
    private String doctorEmail;
    Context context;
    List<FeedItemDoctorTimings> list;
    String availableStr = "";
    View fragmentView;
    SharedPreferences userSharedPreferences;
    EditText editTextDateView;
    /*ImageButton imageButtonDate;
*/
    GridView grid;
    String[] times = {
            "10:00AM", "10:30AM", "11:00AM", "11:30AM", "12:00PM", "12:30PM", "5:00PM", "5:30PM", "6:00PM", "6:30PM", "7:00PM", "7:30PM", "8:00PM", "8:30PM"
    };
    int mYear, mMonth, mDay;
    boolean setDatetoken = false;
    private DatePicker datePicker;
    private Calendar calendar;
    private int year, month, day;
    String strDate;

    public Test() {
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {

        super.onCreate(savedInstanceState);
        context = getActivity().getApplicationContext();
        userSharedPreferences = this.getActivity().getSharedPreferences(context.getString(R.string.cPreferences), Context.MODE_PRIVATE);
        doctorCustomerId = userSharedPreferences.getString(context.getString(R.string.customerId), null);
        doctorEmail = userSharedPreferences.getString(getActivity().getResources().getString(R.string.customerEmail), null);
        doctorId = userSharedPreferences.getString(getActivity().getResources().getString(R.string.doctorIdKey), null);

        getAvailability();
        fragmentView = inflater.inflate(R.layout.doctor_timings_grid, container, false);
//        DoctorTimingsCustomGrid adapter = new DoctorTimingsCustomGrid(getActivity(), web, imageId);
//        grid = (GridView) fragmentView.findViewById(R.id.grid);
//        grid.setAdapter(adapter);
//        grid.setOnItemClickListener(new AdapterView.OnItemClickListener() {
//            @Override
//            public void onItemClick(AdapterView<?> parent, View view,
//                                    int position, long id) {
//                String speciality = (String) hm.get(position + "");
//
//                try {
//                    //Intent intent = new Intent(getActivity(), Test.class);
//                   // Intent intent = new Intent(getActivity(), FeedListActivityDoctors.class);
//                   // Bundle myData = new Bundle();
//                  //  myData.putString("speciality", speciality);
//                    //intent.putExtras(myData);
//                    //startActivity(intent);
//
//                } catch (Exception e) {
//                    // TODO: handle exception
//                    e.printStackTrace();
//                }
//
//                Toast.makeText(getActivity(), "You Clicked at " + web[+position], Toast.LENGTH_SHORT).show();
//            }
//        });
        strDate = new CommonUtil().getCurrntDate();
        editTextDateView = (EditText) fragmentView.findViewById(R.id.editTextDate);
/*
        imageButtonDate = (ImageButton)fragmentView.findViewById(R.id.imageButtonDate);
*/
        editTextDateView.setText(strDate);

        /*imageButtonDate.setOnClickListener(new View.OnClickListener() {
            @Override

            @SuppressWarnings("deprecation")
            public void onClick(View v) {
                getActivity().showDialog(999);
                setDatetoken = false;
                Calendar c = Calendar.getInstance();
                mYear = c.get(Calendar.YEAR);
                mMonth = c.get(Calendar.MONTH);
                mDay = c.get(Calendar.DAY_OF_MONTH);

                DatePickerDialog dpd = new DatePickerDialog(getActivity(),new DatePickerDialog.OnDateSetListener() {

                    @Override
                    public void onDateSet(DatePicker view, int year,
                                          int monthOfYear, int dayOfMonth) {
                        strDate = new StringBuilder().append(year).append("-").append(monthOfYear + 1).append("-").append(dayOfMonth).toString();
                        if(setDatetoken){

//                                    getAvailableTaimings();
                            getAvailability();
                            editTextDateView.setText(strDate);
                        }

                    }
                }, mYear, mMonth, mDay);
                dpd.setCanceledOnTouchOutside(false);
                dpd.setCancelable(true);
                dpd.setButton(DialogInterface.BUTTON_POSITIVE,"Done",new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        setDatetoken =true;
                        dialog.dismiss();
                    }
                });
                dpd.setButton(DialogInterface.BUTTON_NEGATIVE,"Cancel",new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        dialog.dismiss();
                    }
                });
                dpd.setOnDismissListener(new DialogInterface.OnDismissListener() {
                    @Override
                    public void onDismiss(DialogInterface dialog) {

                    }
                });
                dpd.show();

            }
        });
        */
        return fragmentView;
    }

    @SuppressWarnings("deprecation")
    public void setDate(View fragmentView) {
        getActivity().showDialog(999);
        /*Toast.makeText(this, "Clicked Now", Toast.LENGTH_LONG).show();*/
        setDatetoken = false;
        Calendar c = Calendar.getInstance();
        mYear = c.get(Calendar.YEAR);
        mMonth = c.get(Calendar.MONTH);
        mDay = c.get(Calendar.DAY_OF_MONTH);


        DatePickerDialog.OnDateSetListener myDateListener = new DatePickerDialog.OnDateSetListener() {
            @Override
            public void onDateSet(DatePicker arg0, int arg1, int arg2, int arg3) {
                // TODO Auto-generated method stub
                // arg1 = year
                // arg2 = month
                // arg3 = day
                showDate(arg1, arg2 + 1, arg3);

            }
        };

    }

    protected Dialog onCreateDialog(int id) {
        // TODO Auto-generated method stub
        if (id == 999) {
            return new DatePickerDialog(getActivity(), myDateListener, year, month, day);
        }

        return null;
    }

    private DatePickerDialog.OnDateSetListener myDateListener = new DatePickerDialog.OnDateSetListener() {
        @Override
        public void onDateSet(DatePicker arg0, int arg1, int arg2, int arg3) {
            // TODO Auto-generated method stub
            // arg1 = year
            // arg2 = month
            // arg3 = day
            showDate(arg1, arg2 + 1, arg3);
        }
    };

    private void showDate(int year, int month, int day) {
        strDate = new StringBuilder().append(year).append("-").append(month).append("-").append(day).toString();
        setDatetoken = true;
        if (setDatetoken) {
            getAvailability();
        }
/*
        Toast.makeText(getApplicationContext(),"selected date is"+strDate,Toast.LENGTH_SHORT).show();
*/

    }


    public void getAvailability() {
//        doctorId = "10";
//        strDate =new CommonUtil().getCurrntDate();

        new AsyncTask<Void, Void, List<FeedItemDoctorTimings>>() {

            @Override
            protected List<FeedItemDoctorTimings> doInBackground(Void... params) {
                try {
//                    doctorCustomerId = "37";
//                    doctorEmail="sheshakanth@seedinvent.com";
                    String strUrl = availableUrl + "?doctorId="
                            + doctorId + "&strDate=" + strDate;
                    Log.d("---", "--->" + strUrl);
                    ServiceHandler sh = new ServiceHandler();
                    availableStr = sh.makeServiceCall(strUrl, ServiceHandler.GET);
                    if (!availableStr.equals("")) {
                        list = new ArrayList<FeedItemDoctorTimings>();
                        JSONObject json = new JSONObject(availableStr);
                        for (int i = 1; i <= 14; i++) {
                            FeedItemDoctorTimings feedItem = new FeedItemDoctorTimings();
                            feedItem.setDoctorTimeId(json.getString("doctorTimeId"));
                            feedItem.setAppointmentDate(json.getString("date"));
                            feedItem.setAvailability(json.getBoolean("tp" + i));
                            feedItem.setPeriod(i);
                            feedItem.setDoctorId(doctorId);
                            feedItem.setPeriodTime(times[i - 1]);
                            feedItem.setDoctorCustomerId(doctorCustomerId);
                            feedItem.setDoctorEmail(doctorEmail);
                            if (feedItem.isAvailability())
                                feedItem.setImageId(R.drawable.date3);
                            else
                                feedItem.setImageId(R.drawable.date7);
                            list.add(feedItem);
                        }

                    }


                } catch (Exception e) {
                    // TODO: handle exception
                    e.printStackTrace();
                }
                return list;
            }

            @Override
            protected void onPostExecute(List<FeedItemDoctorTimings> feedItemDoctorTimingses) {
                super.onPostExecute(feedItemDoctorTimingses);
                DoctorTimingsCustomGrid adapter = new DoctorTimingsCustomGrid(context, feedItemDoctorTimingses);
                grid = (GridView) fragmentView.findViewById(R.id.grid);
                grid.setAdapter(adapter);
            }
        }.execute(null, null, null);
    }
}
