package com.healhouts.doctor.adaptor;

import android.content.Context;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import com.healhouts.doctor.R;
import com.healhouts.doctor.bean.FeedItemDoctorAppointments;

import java.util.List;

/**
 * Created by Venkat Veeravalli on 13-06-2015.
 */
public class RecyclerAdapterDoctorAppointments extends RecyclerView.Adapter<RecyclerAdapterDoctorAppointments.FeedItemRowHolder> {
    private static final String TAG = "MyRecyclerAdapterDoctor";
    private List<FeedItemDoctorAppointments> feedItemList;
    private Context mContext;
    OnItemClickListener mItemClickListener;
    public RecyclerAdapterDoctorAppointments(Context context, List<FeedItemDoctorAppointments> feedItemList) {
        this.feedItemList = feedItemList;
        this.mContext = context;
    }
    @Override
    public FeedItemRowHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.appointments_layout, null);
        FeedItemRowHolder rowHolder = new FeedItemRowHolder(view);
        return rowHolder;
    }

    @Override
    public void onBindViewHolder(FeedItemRowHolder holder, int position) {
        FeedItemDoctorAppointments feedItem = feedItemList.get(position);
        holder.booked_city.setText(feedItem.getCustomerCity());
        holder.booking_date.setText(feedItem.getAppointmentDate());
        holder.booking_time.setText(feedItem.getAppointmentTime());
        holder.patientName.setText(feedItem.getCustomerName());
        holder.patient_email.setText((feedItem.getCustomerPhone()!= null)?feedItem.getCustomerPhone():feedItem.getCustomerEmail());
    }

    @Override
    public int getItemCount() {

            return (null != feedItemList ? feedItemList.size() : 0);
    }
    public  interface OnItemClickListener{
        public  void onItemClick(View view, int position);



    }
    public void SetOnItemClickListener(final OnItemClickListener mItemClickListener) {
        this.mItemClickListener = mItemClickListener;
    }
    public class FeedItemRowHolder extends RecyclerView.ViewHolder implements View.OnClickListener {
        protected TextView booked_city;
        protected TextView patient_email;
        protected TextView booking_time;
        protected TextView booking_date;
        protected TextView patientName;
        public FeedItemRowHolder(View view) {
            super(view);
            this.booked_city = (TextView) view.findViewById(R.id.booked_city);
            this.patient_email = (TextView) view.findViewById(R.id.patient_email);
            this.booking_time = (TextView) view.findViewById(R.id.booking_time);
            this.patientName = (TextView) view.findViewById(R.id.patientName);
            this.booking_date = (TextView) view.findViewById(R.id.booking_date);
            view.setOnClickListener(this);
        }
        @Override
        public void onClick(View v) {
            if (mItemClickListener != null) {
                mItemClickListener.onItemClick(v, getPosition());

            }
        }
    }
}
