package com.healhouts.doctor.navigationdrawer;

import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.support.v4.view.ViewPager;
import android.support.v7.app.ActionBarActivity;
import android.support.v7.widget.Toolbar;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import com.healhouts.doctor.*;

public class ViewPagerActivity extends Fragment {

    //Declaring the Views and the Variables

    private Toolbar toolbar;
    private ViewPager pager;
    private ViewPagerAdapter adapter;
    private com.healhouts.doctor.SlidingTabLayout tabs;
    CharSequence Titles[]={"APPOINTMENTS","SET AVAILABILITY"};
    int NumofTabs=2;


    @Override
    public View onCreateView(LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View v=inflater.inflate(R.layout.activity_main,container,false);
       // toolbar = (Toolbar) v.findViewById(R.id.tool_bar);
        ActionBarActivity activity = (ActionBarActivity) getActivity();
        // Creating The Toolbar and setting it as the Toolbar for the activity
       // activity.setSupportActionBar(toolbar);

        // Creating The ViewPagerAdapter and Passing Fragment Manager, Titles fot the Tabs and Number Of Tabs.
        adapter =  new ViewPagerAdapter(activity.getSupportFragmentManager(),Titles,NumofTabs);


        // Assigning ViewPager View and setting the adapter
        pager = (ViewPager) v.findViewById(R.id.pager);
        pager.setAdapter(adapter);

        // Assiging the Sliding Tab Layout View
        tabs = (com.healhouts.doctor.SlidingTabLayout) v.findViewById(R.id.tabs);
        tabs.setDistributeEvenly(true); // To make the Tabs Fixed set this true, This makes the tabs Space Evenly in Available width

        // Setting Custom Color for the Scroll bar indicator of the Tab View
        tabs.setCustomTabColorizer(new com.healhouts.doctor.SlidingTabLayout.TabColorizer() {
            @Override
            public int getIndicatorColor(int position) {
//                return getResources().getColor(R.color.tabsScrollColor);

                return getResources().getColor(R.color.abc_primary_text_material_dark);

            }
        });

        // Setting the ViewPager For the SlidingTabsLayout
        tabs.setViewPager(pager);


        return v;
    }

}
