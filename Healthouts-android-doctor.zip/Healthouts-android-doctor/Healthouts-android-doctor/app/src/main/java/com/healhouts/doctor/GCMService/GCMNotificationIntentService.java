package com.healhouts.doctor.GCMService;

import android.annotation.SuppressLint;
import android.app.IntentService;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.os.SystemClock;
import android.support.v4.app.NotificationCompat;
import android.util.Log;

import com.google.android.gms.gcm.GoogleCloudMessaging;
import com.healhouts.doctor.R;
import com.healhouts.doctor.chat.EnableDoctorChatWindowActivity;

import org.json.JSONException;
import org.json.JSONObject;

public class GCMNotificationIntentService extends IntentService {

    public static final int NOTIFICATION_ID = 1;
    private NotificationManager mNotificationManager;
    NotificationCompat.Builder builder;

    public GCMNotificationIntentService() {
        super("GcmIntentService");
    }

    public static final String TAG = "GCMNotificationIntentService";

    @SuppressLint("LongLogTag")
    @Override
    protected void onHandleIntent(Intent intent) {
        Bundle extras = intent.getExtras();
        GoogleCloudMessaging gcm = GoogleCloudMessaging.getInstance(this);

        String messageType = gcm.getMessageType(intent);
        Log.i(TAG, "---------->" + messageType);

        if (!extras.isEmpty()) {
            if (GoogleCloudMessaging.MESSAGE_TYPE_SEND_ERROR
                    .equals(messageType)) {
                try {
                    sendNotification("Send error: " + extras.toString());
                } catch (JSONException e) {
                    e.printStackTrace();
                }
            } else if (GoogleCloudMessaging.MESSAGE_TYPE_DELETED
                    .equals(messageType)) {
                try {
                    sendNotification("Deleted messages on server: "
                            + extras.toString());
                } catch (JSONException e) {
                    e.printStackTrace();
                }
            } else if (GoogleCloudMessaging.MESSAGE_TYPE_MESSAGE
                    .equals(messageType)) {

                for (int i = 0; i < 3; i++) {
                    Log.i(TAG,
                            "Working... " + (i + 1) + "/5 @ "
                                    + SystemClock.elapsedRealtime());
                    try {
                        Thread.sleep(5000);
                    } catch (InterruptedException e) {
                    }

                }
                Log.i(TAG, "Completed work @ " + SystemClock.elapsedRealtime());

                try {
//                    sendNotification("Message Received from Google GCM Server: "
//                            + extras.get(Config.MESSAGE_KEY));
                    sendNotification(extras.get(Config.MESSAGE_KEY).toString());

                } catch (JSONException e) {
                    e.printStackTrace();
                }
                Log.i(TAG, "Received: " + extras.toString());
            }
        }
        GcmBroadcastReceiver.completeWakefulIntent(intent);
    }

    @SuppressLint("LongLogTag")
    private void sendNotification(String msg) throws JSONException {
        Log.d(TAG, "Preparing to send notification...: " + msg);
        JSONObject job = new JSONObject(msg);

        Intent intent = new Intent(this, EnableDoctorChatWindowActivity.class);
        Bundle myData = new Bundle();
        myData.putString("customerId", job.getString("customerId"));
        myData.putString("customerName", job.getString("customerName"));
        myData.putString("doctorCustId", job.getString("doctorCustId"));
        myData.putString("doctorName", job.getString("doctorName"));
        intent.putExtras(myData);

        mNotificationManager = (NotificationManager) this
                .getSystemService(Context.NOTIFICATION_SERVICE);

//		PendingIntent contentIntent = PendingIntent.getActivity(this, 0,
//				new Intent(this, MainActivity.class), 0);
        PendingIntent contentIntent = PendingIntent.getActivity(this, 0,
                intent, 0);
        NotificationCompat.Builder mBuilder = new NotificationCompat.Builder(
                this).setSmallIcon(R.drawable.gcm_cloud)
                .setContentTitle("Healthouts")
                .setStyle(new NotificationCompat.BigTextStyle().bigText(job.getString("customerName") + " want to consult you"))
                .setContentText(job.getString("customerName") + " want to consult you");
//                .setAutoCancel(true);

//        .setContentText(msg);
        mBuilder.setContentIntent(contentIntent);
//        mBuilder.addAction(R.drawable.)
        mNotificationManager.notify(NOTIFICATION_ID, mBuilder.build());
        Log.d(TAG, "Notification sent successfully.");

    }
}
