package com.healhouts.doctor.navigationdrawer;

import android.app.AlertDialog;
import android.app.ProgressDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.graphics.DashPathEffect;
import android.graphics.Paint;
import android.os.AsyncTask;
import android.os.Bundle;
import android.provider.Settings;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Toast;

import com.healhouts.doctor.R;
import com.healhouts.doctor.adaptor.PaidQuestionRecyclerViewAdapter;
import com.healhouts.doctor.bean.FeedItemPaidQuestions;
import com.healhouts.doctor.common.CommonUtil;
import com.healhouts.doctor.common.ConnectionDetector;
import com.healhouts.doctor.common.DividerItemDecoration;
import com.healhouts.doctor.common.ServiceHandler;
import com.healhouts.doctor.common.SimpleDividerItemDecoration;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.net.URISyntaxException;
import java.util.ArrayList;
import java.util.List;

/**
 * Created by Venkat Veeravalli on 17-06-2015.
 */
public class PaidQuestionsFragment extends Fragment {
    private static final String TAG = "PaidQuestionsFragment";
    Context context;
    private String doctorId;
    private String doctorCustomerId;
    private String doctorEmail;
    SharedPreferences userSharedPreferences;
    Boolean isInternetPresent = false;
    ConnectionDetector cd;

    JSONArray jsonArray;
    ProgressDialog pDialog;

    private List<FeedItemPaidQuestions> feedItemList = new ArrayList<FeedItemPaidQuestions>();
    private RecyclerView mRecyclerView;
    LinearLayoutManager mLayoutManager;
    PaidQuestionRecyclerViewAdapter adapter;

    static  String URL = "http://healthouts.com/appGetDoctorPaidQuestions?";

//    static  String URL = "http://joslinlive.org/appGetDoctorPaidQuestions?";
//    LinearLayout linearLayout;

    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        super.onCreateView(inflater, container, savedInstanceState);
        context = getActivity().getApplicationContext();

        userSharedPreferences = this.getActivity().getSharedPreferences(context.getString(R.string.cPreferences), Context.MODE_PRIVATE);
        doctorCustomerId = userSharedPreferences.getString(context.getString(R.string.customerId), null);
        doctorEmail = userSharedPreferences.getString(getActivity().getResources().getString(R.string.customerEmail), null);
        doctorId = userSharedPreferences.getString(getActivity().getResources().getString(R.string.doctorIdKey), null);
        cd = new ConnectionDetector(context);
        isInternetPresent = cd.isConnectingToInternet();
        View view =inflater.inflate(R.layout.paid_questions_recycler_list_layout,container,false);

        /* Initialize recycler view */
        mRecyclerView = (RecyclerView) view.findViewById(R.id.paid_question_list);
        mRecyclerView.setHasFixedSize(true);
        mLayoutManager = new LinearLayoutManager(getActivity());
        mRecyclerView.setLayoutManager(mLayoutManager);

        RecyclerView.ItemDecoration itemDecoration =
                new DividerItemDecoration(getActivity(), LinearLayoutManager.VERTICAL);
        mRecyclerView.addItemDecoration(itemDecoration);

//        linearLayout = (LinearLayout)view.findViewById(R.id.paid_innerLL);

        getPaidQuestions();

        return view;
    }
    public void getPaidQuestions(){
        new AsyncTask<Void, Void,List<FeedItemPaidQuestions>>(){
            @Override
            protected List<FeedItemPaidQuestions> doInBackground(Void... params) {
                String jsonStr = "";
                ServiceHandler sh = new ServiceHandler();
//CID=37&cEmail=sheshakanth@seedinvent.com
                String str = "CID="+doctorCustomerId+"&cEmail="+doctorEmail;
                str = URL+str;
                try {
                    String queryStr = new CommonUtil().ConvertToUrlString(str);
                    if (isInternetPresent) {
                        Log.d("---", "---queryStr--" + queryStr);
                        jsonStr = sh.makeServiceCall(queryStr, ServiceHandler.GET);
                    } else {
                        /*As it is a Async Task,we should not  mak use of Toast message Directlywill cause looper exception .
                        So we need to run this on another
                        */
                        getActivity().runOnUiThread(new Runnable() {
                            public void run() {

                                final AlertDialog.Builder builder = new AlertDialog.Builder(getActivity());
                                builder.setTitle("Connection failure");
                                builder.setMessage("Please check your network connection and try again");
                                builder.setIcon(R.drawable.warn)
                                        .setPositiveButton("cancel", new DialogInterface.OnClickListener() {
                                            public void onClick(DialogInterface dialog, int id) {
                                                builder.setCancelable(true);
                                            }
                                        })
                                        .setNegativeButton("Wi-Fi Settings", new DialogInterface.OnClickListener() {
                                            public void onClick(DialogInterface dialog, int id) {
                                                startActivityForResult(new Intent(Settings.ACTION_WIFI_SETTINGS), 0);


                                            }
                                        });
                                builder.show();

                            }
                        });

                    }

                } catch (URISyntaxException e1) {
                    // TODO Auto-generated catch block
                    e1.printStackTrace();
                }
                try {
                    jsonArray = new JSONArray(jsonStr);
                    for (int i = 0; i < jsonArray.length(); i++) {

                        JSONObject jsonobject = jsonArray.getJSONObject(i);
                        FeedItemPaidQuestions item = new FeedItemPaidQuestions();
//                        Log.d("---", "---jsonObject---"+jsonobject.toString());
                        item.setCustomerImage(jsonobject.getString("cImage"));
                        item.setCustomerName(jsonobject.getString("customerName"));
                        item.setCustomerAge(jsonobject.getString("cdob"));
                        item.setTime(jsonobject.getString("time"));
                        item.setQuestionSubject(jsonobject.getString("csubject"));
                        item.setQuestion(jsonobject.getString("cdetails"));
                        item.setCustomerGende(jsonobject.getString("cgender"));
                        item.setChatType(jsonobject.getString("chat-type"));

                        item.setChatId(jsonobject.getString("chatid"));
                        item.setDoctorId(jsonobject.getString("did"));
                        item.setCustomerId(jsonobject.getString("cid"));
                        item.setDoctorCustomerId(doctorCustomerId);
                        item.setDoctorEmail(doctorEmail);
                        if(jsonobject.has("cHealthfile")) {
                            item.setCustomerHealthFile(jsonobject.getString("cHealthfile"));

                            Log.d(TAG,"----Healthfile "+jsonobject.getString("cHealthfile"));
                        }else{
                            item.setCustomerHealthFile("");
                        }


                        feedItemList.add(item);



                    }
                } catch (JSONException e) {
                    e.printStackTrace();
                }
                return feedItemList;
            }

            @Override
            protected void onPreExecute() {
                super.onPreExecute();
                // Showing progress dialog
                pDialog = new ProgressDialog(getActivity(),ProgressDialog.STYLE_SPINNER);
                pDialog.setMessage("Please wait...");
                pDialog.setCancelable(false);

                pDialog.show();
            }

            @Override
            protected void onPostExecute(List<FeedItemPaidQuestions> list) {
                super.onPostExecute(list);

                if (list.size() == 0) {
                    Toast toast = Toast.makeText(getActivity(), "Your questions empty!", Toast.LENGTH_LONG);
                    toast.getView().setBackgroundColor(context.getResources().getColor(R.color.error_toast));
                    toast.show();
                } else {
                    super.onPostExecute(list);

                    adapter = new PaidQuestionRecyclerViewAdapter(getActivity(), feedItemList);
                    mRecyclerView.setAdapter(adapter);
                }
                if (pDialog.isShowing())
                    pDialog.dismiss();


            }
        }.execute(null, null, null);
    }
}
