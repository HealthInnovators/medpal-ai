package com.healhouts.doctor.fragment;

import android.app.AlertDialog;
import android.app.ProgressDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.AsyncTask;
import android.os.Bundle;
import android.os.StrictMode;
import android.provider.Settings;
import android.app.Fragment;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.WindowManager;
import android.view.inputmethod.InputMethodManager;
import android.widget.Button;
import android.widget.EditText;

import com.healhouts.doctor.R;
import com.healhouts.doctor.common.CommonUtil;
import com.healhouts.doctor.common.ConnectionDetector;
import com.healhouts.doctor.common.ServiceHandler;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.net.URISyntaxException;

/**
 * Created by samsung on 18-06-2015.
 */
public class PractiseLocation extends Fragment {

    private static final String TAG = "PractiseLocation";
    ProgressDialog pDialog;
    AlertDialog.Builder builder;
    JSONObject jsonObj;
    private Context context;
    Boolean isInternetPresent = false;
    ConnectionDetector cd;
    JSONArray jsonArray;
    SharedPreferences userSharedPreferences;
    String doctorCustomerId;
    String doctorEmail;
    EditText clinicName, practiceAddress1, practiceAddress2,practiceUrl, city, practicestate, zipcode, contact, fax, experience, price;
    String clinicNameEt, practiceAddress1ET, practiceAddress2ET,practiceUrlET, cityET, practicestateET, zipcodeET, contactET, faxET, experienceET, priceET;

    Button saveProfile;
    JSONObject jsonObject;
    String jsonStr = "";

    String url = "http://healthouts.com/appDoctorAllDetails?";
    String url2="http://healthouts.com/appSavePracticeDetails?";


//    String url = "http://joslinlive.org/appDoctorAllDetails?";
//    String url2="http://joslinlive.org/appSavePracticeDetails?";

    @Override
    public void onCreate(Bundle savedInstanceState) {
        // TODO Auto-generated method stub
        super.onCreate(savedInstanceState);
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        getActivity().getWindow().setSoftInputMode(
                WindowManager.LayoutParams.SOFT_INPUT_ADJUST_PAN);


        StrictMode.ThreadPolicy policy = new StrictMode.ThreadPolicy.Builder().permitAll().build();
        StrictMode.setThreadPolicy(policy);
        context = getActivity().getApplicationContext();
        cd = new ConnectionDetector(context);
        isInternetPresent = cd.isConnectingToInternet();
        View view = inflater.inflate(R.layout.practiselocation, null);
        userSharedPreferences = this.getActivity().getSharedPreferences(context.getString(R.string.cPreferences), Context.MODE_PRIVATE);
        doctorCustomerId = userSharedPreferences.getString(context.getString(R.string.customerId), null);
        doctorEmail = userSharedPreferences.getString(getActivity().getResources().getString(R.string.customerEmail), null);
        clinicName = (EditText) view.findViewById(R.id.clinicName);
        practiceAddress1 = (EditText) view.findViewById(R.id.practiceAddress1);
        practiceAddress2 = (EditText) view.findViewById(R.id.practiceAddress2);
        city = (EditText) view.findViewById(R.id.city);
        practicestate = (EditText) view.findViewById(R.id.practicestate);
        zipcode = (EditText) view.findViewById(R.id.zipcode);
        contact = (EditText) view.findViewById(R.id.contact);
        fax = (EditText) view.findViewById(R.id.fax);
        experience = (EditText) view.findViewById(R.id.experience);
        price = (EditText) view.findViewById(R.id.price);
        practiceUrl=(EditText)view.findViewById(R.id.practiceUrl);
        saveProfile = (Button) view.findViewById(R.id.savechanges_bt);
        saveProfile.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                new GetData().execute();

            }
        });

        getPractiseLocationData();
        return view;
    }

    private void getPractiseLocationData() {
        String jsonStr = "";


        String str = "";
        str = str + url;

        try {

            String queryStr = new CommonUtil().ConvertToUrlString(str + "CID=" + doctorCustomerId + "&cEmail=" + doctorEmail);
            Log.d(TAG, "Query string  is" + queryStr);

            if (isInternetPresent) {

                if(jsonStr.equals("")) {
                    ServiceHandler sh = new ServiceHandler();
                    jsonStr = sh.makeServiceCall(queryStr, ServiceHandler.GET);
                }
                try {

                    jsonObject = new JSONObject(jsonStr);
                    jsonObject.optString("clinicName");
                    jsonObject.optString("practiceAddress1");
                    jsonObject.optString("practiceAddress2");
                    jsonObject.optString("city");
                    jsonObject.optString("practicestate");
                    jsonObject.optString("zipcode");
                    jsonObject.optString("contact");
                    jsonObject.optString("fax");
                    jsonObject.optString("experience");
                    jsonObject.optString("price");
                    /*
                    Log.d(TAG, "" + jsonObject.optString("clinicName"));
                    Log.d(TAG,"1"+jsonObject.optString("practiceAddress1"));
                    Log.d(TAG,"2"+jsonObject.optString("practiceAddress2"));
                    Log.d(TAG,"3"+jsonObject.optString("city"));
                    Log.d(TAG,"4"+jsonObject.optString("practicestate"));
                    Log.d(TAG,"5"+jsonObject.optString("zipcode"));
                    Log.d(TAG,"6"+jsonObject.optString("contact"));
                    Log.d(TAG,"7"+jsonObject.optString("fax"));
                    Log.d(TAG,"8"+jsonObject.optString("experience"));
                    Log.d(TAG,"9"+jsonObject.optString("price"));*/

                    clinicName.setText(jsonObject.optString("clinicName"));
                    practiceAddress1.setText(jsonObject.optString("practiceAddress1"));
                    practiceAddress2.setText(jsonObject.optString("practiceAddress2"));
                    city.setText(jsonObject.optString("city"));
                    practicestate.setText(jsonObject.optString("practicestate"));
                    zipcode.setText(jsonObject.optString("zipcode"));
                    contact.setText(jsonObject.optString("contact"));
                    fax.setText(jsonObject.optString("fax"));
                    experience.setText(jsonObject.optString("experience"));
                    price.setText(jsonObject.optString("price"));
                    practiceUrl.setText(jsonObject.optString("practiceUrl"));


                    Log.d("My App", jsonObject.toString());

                } catch (Throwable t) {
                    Log.e("My App", "Could not parse malformed JSON: \"" + jsonStr + "\"");
                }

            } else {
                getActivity().runOnUiThread(new Runnable() {
                    public void run() {
                        final AlertDialog.Builder builder = new AlertDialog.Builder(getActivity());
                        builder.setTitle("Connection failure");
                        builder.setMessage("Please check your network connection and try again");
                        builder.setIcon(R.drawable.warn)
                                .setPositiveButton("cancel", new DialogInterface.OnClickListener() {
                                    public void onClick(DialogInterface dialog, int id) {
                                        builder.setCancelable(true);
                                    }
                                })
                                .setNegativeButton("Wi-Fi Settings", new DialogInterface.OnClickListener() {
                                    public void onClick(DialogInterface dialog, int id) {
                                        startActivityForResult(new Intent(Settings.ACTION_WIFI_SETTINGS), 0);

                                    }
                                });
                        builder.show();

                    }
                });

            }

        } catch (URISyntaxException e1) {
            // TODO Auto-generated catch block
            e1.printStackTrace();
        }


    }

    private class GetData extends AsyncTask<String,String,String>{
        @Override
        protected String doInBackground(String... params) {
            String jsonStr1 = "";
            ServiceHandler sh = new ServiceHandler();

            clinicNameEt=clinicName.getText().toString();
            practiceAddress1ET=practiceAddress1.getText().toString();
            practiceAddress2ET=practiceAddress2.getText().toString();
            cityET=city.getText().toString();
            practicestateET=practicestate.getText().toString();
            zipcodeET=zipcode.getText().toString();
            contactET=contact.getText().toString();
            faxET=fax.getText().toString();
            experienceET=experience.getText().toString();
            priceET=price.getText().toString();
            practiceUrlET=practiceUrl.getText().toString();

            String str = "";
            str = str + url2;

            try {

                jsonObj=new JSONObject();
                try {
                    jsonObj.put("clinicName",clinicNameEt);
                    jsonObj.put("practiceAddress1",practiceAddress1ET);
                    jsonObj.put("practiceAddress2",practiceAddress2ET);
                    jsonObj.put("city",cityET);
                    jsonObj.put("practicestate",practicestateET);
                    jsonObj.put("zipcode",zipcodeET);
                    jsonObj.put("contact",contactET);
                    jsonObj.put("fax",faxET);
                    jsonObj.put("experience",experienceET);
                    jsonObj.put("price",priceET);
                    jsonObj.put("practiceUrl",practiceUrlET);

                } catch (JSONException e) {
                    e.printStackTrace();
                }
                String queryStr1 = new CommonUtil().ConvertToUrlString(str +"CID="+doctorCustomerId+"&cEmail="+doctorEmail+"&JSONObj="+jsonObj);
                Log.d(TAG,"Query string  is"+queryStr1);

                if (isInternetPresent) {

                    jsonStr1 = sh.makeServiceCall(queryStr1, ServiceHandler.POST);

                    String flag="1";
                    Log.d(TAG,"jsonobject after"+jsonObj);
                    try {
                        jsonObj = new JSONObject(jsonStr1);
                        if (jsonObj.getString("status").equals(flag)) {
                            getActivity().runOnUiThread(new Runnable() {
                                public void run() {
                                    builder = new AlertDialog.Builder(getActivity());
                                    builder.setCancelable(true);
                                    try {
                                        builder.setMessage(jsonObj.getString("message"));
                                    } catch (JSONException e) {
                                        e.printStackTrace();
                                    }
                                    builder.setInverseBackgroundForced(true);
                                    builder.setNeutralButton("Ok", new DialogInterface.OnClickListener() {
                                        public void onClick(DialogInterface dialog, int whichButton) {
                                            dialog.dismiss();
                                        }
                                    });

                                    builder.show();
                                }
                            });
                        }
                    } catch (JSONException e) {
                        e.printStackTrace();
                    }
                    System.out.print(jsonObj);



                    try {

                        JSONObject jsonObject=new JSONObject(jsonStr1);
                        Log.d(TAG,"saved datais"+jsonObject);
                    } catch (JSONException e) {
                        e.printStackTrace();
                    }


                } else {
                    getActivity().runOnUiThread(new Runnable() {
                        public void run() {

                            final AlertDialog.Builder builder = new AlertDialog.Builder(getActivity());
                            builder.setTitle("Connection failure");
                            builder.setMessage("Please check your network connection and try again");
                            builder.setIcon(R.drawable.warn)
                                    .setPositiveButton("cancel", new DialogInterface.OnClickListener() {
                                        public void onClick(DialogInterface dialog, int id) {
                                            builder.setCancelable(true);
                                        }
                                    })
                                    .setNegativeButton("Wi-Fi Settings", new DialogInterface.OnClickListener() {
                                        public void onClick(DialogInterface dialog, int id) {
                                            startActivityForResult(new Intent(Settings.ACTION_WIFI_SETTINGS), 0);


                                        }
                                    });
                            builder.show();

                        }
                    });

                }

            } catch (URISyntaxException e1) {
                // TODO Auto-generated catch block
                e1.printStackTrace();
            }


            return null;
        }
    }
}

