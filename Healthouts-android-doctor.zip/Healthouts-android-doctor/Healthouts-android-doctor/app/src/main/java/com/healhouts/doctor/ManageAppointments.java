package com.healhouts.doctor;

import android.app.DatePickerDialog;
import android.app.Dialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.SharedPreferences;
import android.os.AsyncTask;
import android.os.Bundle;
import android.support.v4.app.DialogFragment;
import android.support.v4.app.Fragment;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.GridView;
import android.widget.ImageButton;

import com.healhouts.doctor.adaptor.DoctorTimingsCustomGrid;
import com.healhouts.doctor.bean.FeedItemDoctorTimings;
import com.healhouts.doctor.common.CommonUtil;
import com.healhouts.doctor.common.ServiceHandler;

import org.json.JSONObject;

import java.util.ArrayList;
import java.util.Calendar;
import java.util.List;


/**
 * A placeholder fragment containing a simple view.
 */
public class ManageAppointments extends Fragment {
    private String availableUrl = "http://healthouts.com/appDocAvailability";
    //    private String availableUrl = "http://joslinlive.org/appDocAvailability";
    private String doctorId;
    private String strDate;
    private String doctorCustomerId;
    private String doctorEmail;
    Context context;
    List<FeedItemDoctorTimings> list;
    String availableStr = "";
    View fragmentView;
    SharedPreferences userSharedPreferences;
    EditText editTextDateView;
    Button imageButtonDate;

    GridView grid;
    String[] times = {
            "10:00AM","10:30AM","11:00AM","11:30AM","12:00PM","12:30PM","5:00PM","5:30PM","6:00PM","6:30PM","7:00PM","7:30PM","8:00PM","8:30PM"
    };
    int mYear,mMonth, mDay;
    boolean setDatetoken = false;

    public ManageAppointments() {
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {

        super.onCreate(savedInstanceState);
        context = getActivity().getApplicationContext();
        userSharedPreferences = this.getActivity().getSharedPreferences(context.getString(R.string.cPreferences), Context.MODE_PRIVATE);
        doctorCustomerId = userSharedPreferences.getString(context.getString(R.string.customerId), null);
        doctorEmail = userSharedPreferences.getString(getActivity().getResources().getString(R.string.customerEmail), null);
        doctorId = userSharedPreferences.getString(getActivity().getResources().getString(R.string.doctorIdKey), null);

        getAvailability();
        fragmentView = inflater.inflate(R.layout.doctor_timings_grid, container, false);
        strDate =new CommonUtil().getCurrntDate();
        editTextDateView = (EditText)fragmentView.findViewById(R.id.editTextDate);
        editTextDateView.setText(strDate);
        imageButtonDate = (Button)fragmentView.findViewById(R.id.imageButtonDate);
        imageButtonDate.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                showDatePicker();
            }
        });

        return fragmentView;
    }

    private void showDatePicker() {
        DatePickerFragment date = new DatePickerFragment();
        /**
         * Set Up Current Date Into dialog
         */
        Calendar calender = Calendar.getInstance();
        Bundle args = new Bundle();
        args.putInt("year", calender.get(Calendar.YEAR));
        args.putInt("month", calender.get(Calendar.MONTH));
        args.putInt("day", calender.get(Calendar.DAY_OF_MONTH));
        date.setArguments(args);
        /**
         * Set Call back to capture selected date
         */
        date.setCallBack(ondate);
        date.show(getFragmentManager(), "Date Picker");
    }
    DatePickerDialog.OnDateSetListener ondate = new DatePickerDialog.OnDateSetListener() {
        @Override
        public void onDateSet(DatePicker view, int year, int monthOfYear,
                              int dayOfMonth) {

            setDatetoken=true;
            if(setDatetoken){

                strDate = new StringBuilder().append(year).append("-").append(monthOfYear + 1).append("-").append(dayOfMonth).toString();


                editTextDateView.setText(strDate);
                getAvailability();
                editTextDateView.setText(strDate);
            }                getAvailability();
        }
    };
    public void getAvailability(){
//        doctorId = "10";
//        strDate =new CommonUtil().getCurrntDate();

        new AsyncTask<Void, Void,List<FeedItemDoctorTimings>>(){

            @Override
            protected List<FeedItemDoctorTimings> doInBackground(Void... params) {
                try {
//                    doctorCustomerId = "37";
//                    doctorEmail="sheshakanth@seedinvent.com";
                    String strUrl = availableUrl + "?doctorId="
                            + doctorId+"&strDate="+strDate;
                    Log.d("---", "--->" + strUrl);
                    ServiceHandler sh = new ServiceHandler();
                    availableStr = sh.makeServiceCall(strUrl, ServiceHandler.GET);
                    if (!availableStr.equals("")) {
                        list = new ArrayList<FeedItemDoctorTimings>();
                        JSONObject json = new JSONObject(availableStr);
                        for(int i=1; i<=14; i++) {
                            FeedItemDoctorTimings feedItem = new FeedItemDoctorTimings();
                            feedItem.setDoctorTimeId(json.getString("doctorTimeId"));
                            feedItem.setAppointmentDate(json.getString("date"));
                            feedItem.setAvailability(json.getBoolean("tp"+i));
                            feedItem.setPeriod(i);
                            feedItem.setDoctorId(doctorId);
                            feedItem.setPeriodTime(times[i-1]);
                            feedItem.setDoctorCustomerId(doctorCustomerId);
                            feedItem.setDoctorEmail(doctorEmail);
                            if(feedItem.isAvailability())
                                feedItem.setImageId(R.drawable.date3);
                            else
                                feedItem.setImageId(R.drawable.date7);
                            list.add(feedItem);
                        }

                    }


                } catch (Exception e) {
                    // TODO: handle exception
                    e.printStackTrace();
                }
                return list;
            }

            @Override
            protected void onPostExecute(List<FeedItemDoctorTimings> feedItemDoctorTimingses) {
                super.onPostExecute(feedItemDoctorTimingses);
                DoctorTimingsCustomGrid adapter = new DoctorTimingsCustomGrid(context, feedItemDoctorTimingses);
                grid = (GridView) fragmentView.findViewById(R.id.grid);
                grid.setAdapter(adapter);
            }
        }.execute(null, null, null);
    }

    public  static class DatePickerFragment extends DialogFragment {
        DatePickerDialog.OnDateSetListener ondateSet;

        public DatePickerFragment() {
        }

        public void setCallBack(DatePickerDialog.OnDateSetListener ondate) {
            ondateSet = ondate;
        }

        private int year, month, day;

        @Override
        public void setArguments(Bundle args) {
            super.setArguments(args);
            year = args.getInt("year");
            month = args.getInt("month");
            day = args.getInt("day");
        }

        @Override
        public Dialog onCreateDialog(Bundle savedInstanceState) {
            return new DatePickerDialog(getActivity(), ondateSet, year, month, day);
        }
    }
}

