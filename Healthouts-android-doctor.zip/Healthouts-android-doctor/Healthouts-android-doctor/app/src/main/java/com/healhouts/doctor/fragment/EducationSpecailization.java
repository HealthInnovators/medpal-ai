package com.healhouts.doctor.fragment;

import android.app.AlertDialog;
import android.app.Fragment;
import android.app.ProgressDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.AsyncTask;
import android.os.Bundle;
import android.os.StrictMode;
import android.provider.Settings;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.WindowManager;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.Toast;

import com.healhouts.doctor.R;
import com.healhouts.doctor.common.CommonUtil;
import com.healhouts.doctor.common.ConnectionDetector;
import com.healhouts.doctor.common.ServiceHandler;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.net.URISyntaxException;
import java.util.Arrays;

public class EducationSpecailization extends Fragment implements AdapterView.OnItemSelectedListener {
    String TAG = getClass().getName();
    String item = "";
    ProgressDialog pDialog;
    AlertDialog.Builder builder;
    JSONObject jsonObj;
    private Context context;
    Boolean isInternetPresent = false;
    ConnectionDetector cd;
    JSONArray jsonArray;
    SharedPreferences userSharedPreferences;
    String doctorCustomerId;
    String doctorEmail;

    Button saveProfile;
    JSONObject jsonObject;
    String jsonStr = "";
    int pos;

    String url = "http://healthouts.com/appDoctorAllDetails?";
    String url2 = "http://healthouts.com/appSaveEducationDetails?";


//    String url = "http://joslinlive.org/appDoctorAllDetails?";
//    String url2="http://joslinlive.org/appSaveEducationDetails?";


    EditText universityName, qualification, doctorLicenceNumber, speciality1, speciality2, speciality3, speciality4, speciality5;
    String universityNameET, qualificationET, doctorLicenceNumberET, speciality1ET, speciality2ET, speciality3ET, speciality4ET, speciality5ET;

    String specialization_ET;


    public Button savechanges;
    Spinner specialization;
    String[] specializations = new String[]{"General Physician", "OB-Gynecologist", "Dermatologist", "Dentist", "ENT", "Eye Doctor", "Cardiologist", "Pediatrician", "Orthopedician", "Cancer Specailist", "Endocrinologist", "General Surgeon", "Psychiartist"};


    @Override
    public void onCreate(Bundle savedInstanceState) {
        // TODO Auto-generated method stub
        super.onCreate(savedInstanceState);
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        getActivity().getWindow().setSoftInputMode(
                WindowManager.LayoutParams.SOFT_INPUT_ADJUST_PAN);


        StrictMode.ThreadPolicy policy = new StrictMode.ThreadPolicy.Builder().permitAll().build();
        StrictMode.setThreadPolicy(policy);
        context = getActivity().getApplicationContext();
        cd = new ConnectionDetector(context);
        isInternetPresent = cd.isConnectingToInternet();


        userSharedPreferences = this.getActivity().getSharedPreferences(context.getString(R.string.cPreferences), Context.MODE_PRIVATE);
        doctorCustomerId = userSharedPreferences.getString(context.getString(R.string.customerId), null);
        doctorEmail = userSharedPreferences.getString(getActivity().getResources().getString(R.string.customerEmail), null);


        View view = inflater.inflate(R.layout.education_specailization, null);
        specialization = (Spinner) view.findViewById(R.id.specialization1);
        savechanges = (Button) view.findViewById(R.id.saveProfile);

        universityName = (EditText) view.findViewById(R.id.universityName);
        qualification = (EditText) view.findViewById(R.id.qualification);
        doctorLicenceNumber = (EditText) view.findViewById(R.id.doctorLicenceNumber);
        speciality1 = (EditText) view.findViewById(R.id.speciality1);
        speciality2 = (EditText) view.findViewById(R.id.speciality2);
        speciality3 = (EditText) view.findViewById(R.id.speciality3);
        speciality4 = (EditText) view.findViewById(R.id.speciality4);
        speciality5 = (EditText) view.findViewById(R.id.speciality5);

        saveProfile = (Button) view.findViewById(R.id.saveProfile);
        saveProfile.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                new GetData().execute();

            }
        });


        ArrayAdapter<String> adapter = new ArrayAdapter<String>(getActivity(), android.R.layout.simple_dropdown_item_1line, specializations);
        specialization.setAdapter(adapter);
        specialization.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> arg0, View arg1,
                                       int arg2, long arg3) {
                item = arg0.getItemAtPosition(arg2).toString();
                pos = arg2;
                Log.d(TAG, "pos is" + pos);
                Toast.makeText(EducationSpecailization.this.getActivity().getBaseContext(),
                        "clicked " + item, Toast.LENGTH_SHORT).show();
            }

            @Override
            public void onNothingSelected(AdapterView<?> arg0) {
            }
        });

        // jsonStr = getArguments().getString("jsonStr");
        getEducationSpecailization();


        return view;
    }

    private void getEducationSpecailization() {
//        String jsonStr = "";
//        ServiceHandler sh = new ServiceHandler();

        String str = "";
        str = str + url;

        try {

            String queryStr = new CommonUtil().ConvertToUrlString(str + "CID=" + doctorCustomerId + "&cEmail=" + doctorEmail);
            Log.d(TAG, "Query string  is" + queryStr);

            if (isInternetPresent) {

                if (jsonStr.equals("")) {
                    ServiceHandler sh = new ServiceHandler();
                    jsonStr = sh.makeServiceCall(queryStr, ServiceHandler.GET);
                }
                try {

                    jsonObject = new JSONObject(jsonStr);
                    jsonObject.optString("universityName");
                    jsonObject.optString("qualification");
                    jsonObject.optString("doctorLicenceNumber");
                    jsonObject.optString("additionalSpecialty");
                    specialization.setSelection(Arrays.asList(specializations).indexOf(jsonObject.optString("specialization")));
                    universityName.setText(jsonObject.optString("universityName"));
                    qualification.setText(jsonObject.optString("qualification"));
                    doctorLicenceNumber.setText(jsonObject.optString("doctorLicenceNumber"));

                    String[] specialities = jsonObject.optString("additionalSpecialty").split(",");
                    Log.d(TAG, "after split" + specialities);

                    for (int i = 0; i < specialities.length; i++) {

                        Log.d(TAG, "getRequiredProducts_Str_Array :" + specialities[i].trim());
                    }

                    speciality1.setText(specialities[0].trim());
                    speciality2.setText(specialities[1].trim());
                    speciality3.setText(specialities[2].trim());
                    speciality4.setText(specialities[3].trim());
                    speciality5.setText(specialities[4].trim());

                } catch (Throwable t) {
                }

            } else {
                getActivity().runOnUiThread(new Runnable() {
                    public void run() {
                        final AlertDialog.Builder builder = new AlertDialog.Builder(getActivity());
                        builder.setTitle("Connection failure");
                        builder.setMessage("Please check your network connection and try again");
                        builder.setIcon(R.drawable.warn)
                                .setPositiveButton("cancel", new DialogInterface.OnClickListener() {
                                    public void onClick(DialogInterface dialog, int id) {
                                        builder.setCancelable(true);
                                    }
                                })
                                .setNegativeButton("Wi-Fi Settings", new DialogInterface.OnClickListener() {
                                    public void onClick(DialogInterface dialog, int id) {
                                        startActivityForResult(new Intent(Settings.ACTION_WIFI_SETTINGS), 0);

                                    }
                                });
                        builder.show();

                    }
                });

            }

        } catch (URISyntaxException e1) {
            // TODO Auto-generated catch block
            e1.printStackTrace();
        }


    }

    @Override
    public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {


    }

    @Override
    public void onNothingSelected(AdapterView<?> parent) {

    }

    private class GetData extends AsyncTask<String, String, String> {


        @Override
        protected String doInBackground(String... params) {
            String jsonStr1 = "";
            ServiceHandler sh = new ServiceHandler();

            universityNameET = universityName.getText().toString();
            qualificationET = qualification.getText().toString();
            doctorLicenceNumberET = doctorLicenceNumber.getText().toString();
            speciality1ET = speciality1.getText().toString();
            speciality2ET = speciality2.getText().toString();
            speciality3ET = speciality3.getText().toString();
            speciality4ET = speciality4.getText().toString();
            speciality5ET = speciality5.getText().toString();
            specialization_ET = item;


            String str = "";
            str = str + url2;

            try {

                jsonObj = new JSONObject();
                try {
                    String[] specialities = {speciality1ET, speciality2ET, speciality3ET, speciality4ET, speciality5ET};
                    String strContent = "";
                    for (int i = 0; i < specialities.length; i++) {
                        if (!specialities[i].equals("")) {
                            strContent = strContent + specialities[i] + ",";
                        }
                    }
                    Log.d("---", "---content---" + strContent);
                    jsonObj.put("universityName", universityNameET);
                    jsonObj.put("doctorQualification", qualificationET);
                    jsonObj.put("doctorLicenceNumber", doctorLicenceNumberET);
                    jsonObj.put("doctorSpecialization", item);
                    jsonObj.put("additionalSpecialty", strContent);


//                    String[] specialities = jsonObject.optString("additionalSpecialty").split(",");
//                    Log.d(TAG, "after split" + specialities);
//                    String content =speciality1ET+","+speciality2ET+","+speciality3ET+","+speciality4ET+","+speciality5ET;


                } catch (JSONException e) {
                    e.printStackTrace();
                }
                String queryStr1 = new CommonUtil().ConvertToUrlString(str + "CID=" + doctorCustomerId + "&cEmail=" + doctorEmail + "&JSONObj=" + jsonObj);
                Log.d(TAG, "Query string  is" + queryStr1);

                if (isInternetPresent) {

                    jsonStr1 = sh.makeServiceCall(queryStr1, ServiceHandler.POST);

                    String flag = "1";
                    Log.d(TAG, "jsonobject after" + jsonObj);
                    try {
                        jsonObj = new JSONObject(jsonStr1);
                        if (jsonObj.getString("status").equals(flag)) {
                            getActivity().runOnUiThread(new Runnable() {
                                public void run() {
                                    builder = new AlertDialog.Builder(getActivity());
                                    builder.setCancelable(true);
                                    try {
                                        builder.setMessage(jsonObj.getString("message"));
                                    } catch (JSONException e) {
                                        e.printStackTrace();
                                    }
                                    builder.setInverseBackgroundForced(true);
                                    builder.setNeutralButton("Ok", new DialogInterface.OnClickListener() {
                                        public void onClick(DialogInterface dialog, int whichButton) {
                                            dialog.dismiss();
                                        }
                                    });

                                    builder.show();
                                }
                            });
                        }
                    } catch (JSONException e) {
                        e.printStackTrace();
                    }
                    System.out.print(jsonObj);


                    try {

                        JSONObject jsonObject = new JSONObject(jsonStr1);
                        Log.d(TAG, "saved datais" + jsonObject);
                    } catch (JSONException e) {
                        e.printStackTrace();
                    }


                } else {
                    getActivity().runOnUiThread(new Runnable() {
                        public void run() {

                            final AlertDialog.Builder builder = new AlertDialog.Builder(getActivity());
                            builder.setTitle("Connection failure");
                            builder.setMessage("Please check your network connection and try again");
                            builder.setIcon(R.drawable.warn)
                                    .setPositiveButton("cancel", new DialogInterface.OnClickListener() {
                                        public void onClick(DialogInterface dialog, int id) {
                                            builder.setCancelable(true);
                                        }
                                    })
                                    .setNegativeButton("Wi-Fi Settings", new DialogInterface.OnClickListener() {
                                        public void onClick(DialogInterface dialog, int id) {
                                            startActivityForResult(new Intent(Settings.ACTION_WIFI_SETTINGS), 0);


                                        }
                                    });
                            builder.show();

                        }
                    });

                }

            } catch (URISyntaxException e1) {
                // TODO Auto-generated catch block
                e1.printStackTrace();
            }


            return null;
        }
    }
}

