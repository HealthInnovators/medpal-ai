package com.healhouts.doctor;


import android.app.AlertDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.AsyncTask;
import android.os.Bundle;
import android.os.StrictMode;
import android.provider.Settings;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentActivity;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Toast;

import com.healhouts.doctor.adaptor.RecyclerAdapterDoctorAppointments;
import com.healhouts.doctor.bean.FeedItemDoctorAppointments;
import com.healhouts.doctor.common.CommonUtil;
import com.healhouts.doctor.common.ConnectionDetector;
import com.healhouts.doctor.common.ServiceHandler;
import com.healhouts.doctor.common.SimpleDividerItemDecoration;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.net.URISyntaxException;
import java.util.ArrayList;
import java.util.List;


/**
 * Created by Venkat Veeravalli on 09-06-2015.
 */
public class YourAppointments extends Fragment {

    private static final String TAG = "YourAppointments";
    private Context context;
    Boolean isInternetPresent = false;
    ConnectionDetector cd;
    SharedPreferences userSharedPreferences;
    JSONArray jsonArray;
    private String customerId;

    private View v;
    private List<FeedItemDoctorAppointments> FeedItemAppList = new ArrayList<FeedItemDoctorAppointments>();
    private RecyclerView mRecyclerView;
    LinearLayoutManager mLayoutManager;
    private RecyclerAdapterDoctorAppointments adapter;
    private boolean loading = true;
    int firstVisibleItem, visibleItemCount, totalItemCount;
    int count = 0;
    int token = 0;
    String doctorCustomerId;
    String doctorEmail;
    String url = "http://healthouts.com/appDocAppointments?";
    //CID=37&cEmail=sheshakanth@seedinvent.com
    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
//        return super.onCreateView(inflater, container, savedInstanceState);
        super.onCreate(savedInstanceState);
        StrictMode.ThreadPolicy policy = new StrictMode.ThreadPolicy.Builder().permitAll().build();
        StrictMode.setThreadPolicy(policy);
        context = getActivity().getApplicationContext();
        cd = new ConnectionDetector(context);
        isInternetPresent = cd.isConnectingToInternet();
        View view = inflater.inflate(R.layout.your_appointment_layout, container,false);

        mRecyclerView = (RecyclerView) view.findViewById(R.id.recycler_view);
        mRecyclerView.setHasFixedSize(true);
        mLayoutManager = new LinearLayoutManager(getActivity());
        mRecyclerView.setLayoutManager(mLayoutManager);
        userSharedPreferences = this.getActivity().getSharedPreferences(context.getString(R.string.cPreferences), Context.MODE_PRIVATE);
        doctorCustomerId = userSharedPreferences.getString(context.getString(R.string.customerId), null);
        doctorEmail = userSharedPreferences.getString(getActivity().getResources().getString(R.string.customerEmail), null);


        v = inflater.inflate(R.layout.activity_booking_history_layout, container, false);

        mRecyclerView.setOnScrollListener(new RecyclerView.OnScrollListener() {
            @Override
            public void onScrolled(RecyclerView recyclerView, int dx, int dy) {
                super.onScrolled(recyclerView, dx, dy);
                visibleItemCount = mRecyclerView.getChildCount();
                totalItemCount = mLayoutManager.getItemCount();
                firstVisibleItem = mLayoutManager.findFirstVisibleItemPosition();
                if (loading) {
                    if ((visibleItemCount + firstVisibleItem) >= totalItemCount) {
                        loading = false;
                        Log.v("...", "Last Item Wow !");
                        count = totalItemCount;

                    }
                }
            }


        });
        yourAppointments();
        return view;
    }
    public void yourAppointments() {

        new AsyncTask<Void, Void, List<FeedItemDoctorAppointments>>() {

            @Override
            protected List<FeedItemDoctorAppointments> doInBackground(Void... params) {
//                ArrayList<HashMap> list = new ArrayList<HashMap>();
                String jsonStr = "";
                ServiceHandler sh = new ServiceHandler();

                String str = "";
                str = str + url;

                try {
                    String queryStr = new CommonUtil().ConvertToUrlString(str + "CID="+doctorCustomerId+"&cEmail="+doctorEmail);
                    if (isInternetPresent) {

                        jsonStr = sh.makeServiceCall(queryStr, ServiceHandler.GET);
                    } else {
                        getActivity().runOnUiThread(new Runnable() {
                            public void run() {
                                final AlertDialog.Builder builder = new AlertDialog.Builder(getActivity());
                                builder.setTitle("Connection failure");
                                builder.setMessage("Please check your network connection and try again");
                                builder.setIcon(R.drawable.warn)
                                        .setPositiveButton("cancel", new DialogInterface.OnClickListener() {
                                            public void onClick(DialogInterface dialog, int id) {
                                                builder.setCancelable(true);
                                            }
                                        })
                                        .setNegativeButton("Wi-Fi Settings", new DialogInterface.OnClickListener() {
                                            public void onClick(DialogInterface dialog, int id) {
                                                startActivityForResult(new Intent(Settings.ACTION_WIFI_SETTINGS), 0);

                                            }
                                        });
                                builder.show();
                            }
                        });
                    }
                } catch (URISyntaxException e1) {
                    // TODO Auto-generated catch block
                    e1.printStackTrace();
                }
                try {
                    jsonArray = new JSONArray(jsonStr);
                    for (int i = 0; i < jsonArray.length(); i++) {
                        JSONObject jsonobject = jsonArray.getJSONObject(i);

                        FeedItemDoctorAppointments item = new FeedItemDoctorAppointments();
                        item.setCustomerName(jsonobject.getString("customerName"));
                        item.setAppointmentDate(jsonobject.getString("appointmentDate"));
                        item.setCustomerEmail(jsonobject.getString("customerEmail"));
                        item.setAppointmentTime(jsonobject.getString("appointmentTime"));
                        if(jsonobject.has("customerCity"))
                        item.setCustomerCity(jsonobject.getString("customerCity"));
                        else
                            item.setCustomerCity(null);
                        if(jsonobject.has("customerPhone"))
                        item.setCustomerPhone(jsonobject.getString("customerPhone"));
                        else item.setCustomerPhone(null);
                        FeedItemAppList.add(item);
                    }
                } catch (JSONException e) {
                    e.printStackTrace();
                }
                return FeedItemAppList;
            }

            private void showAlertDialog(FragmentActivity activity, String s, String s1, boolean b) {
                AlertDialog alertDialog = new AlertDialog.Builder(context).create();
                alertDialog.setTitle("");
                alertDialog.setMessage("");

                alertDialog.setButton("OK", new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface dialog, int which) {
                    }
                });

                alertDialog.show();
            }

            @Override
            protected void onPostExecute(List<FeedItemDoctorAppointments> list) {
                if (list.size() == 0) {
                    Toast.makeText(getActivity(), " questions empty!", Toast.LENGTH_LONG).show();
                } else {
                    super.onPostExecute(list);
                    adapter = new RecyclerAdapterDoctorAppointments(getActivity(), FeedItemAppList);
                    mRecyclerView.addItemDecoration(new SimpleDividerItemDecoration(getResources()));

                    mRecyclerView.setAdapter(adapter);
                    /*adapter.SetOnItemClickListener(new MyRecyclerAdapter.OnItemClickListener() {
                        @Override
                        public void onItemClick(View view, int position) {
                            Log.d("---", "----position---"+position);
                            FeedItemAppointments feedItem = FeedItemAppList.get(position);

                            Intent intent = new Intent(context, AnswersForYourQuestions.class);
                            Bundle myData = new Bundle();
                            myData.putString("ansJsonArray", String.valueOf(feedItem.getAnsArray()));
                            myData.putString("questionId", feedItem.getQuestionId());
                            myData.putString("cImage", feedItem.getcImage());
                            myData.putString("questionBody", feedItem.getQuestionBody());
                            myData.putString("qsDate", feedItem.getQsDate());
                            intent.putExtras(myData);
                            startActivity(intent);
                        }
                    });*/
                }

            }
        }.execute(null, null, null);
    }

    }
