package com.healhouts.doctor.fragment;


/**
 * Created by samsung on 13-03-2015.
 */

import android.app.AlertDialog;
import android.app.ProgressDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.os.AsyncTask;
import android.os.Bundle;
import android.os.StrictMode;
import android.provider.Settings;
import android.app.Fragment;
import android.support.v4.app.FragmentActivity;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;
import android.widget.Toast;

import com.healhouts.doctor.R;
import com.healhouts.doctor.adaptor.MyRecyclerAdapterPaymentHistory;
import com.healhouts.doctor.bean.FeedItemPayment;
import com.healhouts.doctor.common.CommonUtil;
import com.healhouts.doctor.common.ConnectionDetector;
import com.healhouts.doctor.common.DividerItemDecoration;
import com.healhouts.doctor.common.ServiceHandler;
import com.healhouts.doctor.common.SimpleDividerItemDecoration;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.net.URISyntaxException;
import java.util.ArrayList;
import java.util.List;

/**
 * Created by Venkat Veeravalli on 12-05-2015.
 */
public class YourPaymentHistory extends Fragment {
    private static final String TAG ="YourPaymentHistory" ;
    private Context context;
    Boolean isInternetPresent = false;
    ConnectionDetector cd;
    JSONArray jsonArray;
    JSONObject jsonObject;
    private List<FeedItemPayment> feedItemList = new ArrayList<FeedItemPayment>();
    private RecyclerView mRecyclerView;
    LinearLayoutManager mLayoutManager;
    SharedPreferences userSharedPreferences;
    private MyRecyclerAdapterPaymentHistory adapter;
    private boolean loading = true;
    int firstVisibleItem, visibleItemCount, totalItemCount;
    int count =0;
    int token = 0;
    String doctorCustomerId;
    String doctorEmail;
    ProgressDialog pDialog;
    TextView totalAmount;
    String url="http://healthouts.com/appDoctorPayHistory?";
//    String url="http://joslinlive.org/appDoctorPayHistory?";
    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        StrictMode.ThreadPolicy policy = new StrictMode.ThreadPolicy.Builder().permitAll().build();
        StrictMode.setThreadPolicy(policy);
        context = getActivity().getApplicationContext();
        cd = new ConnectionDetector(context);
        isInternetPresent = cd.isConnectingToInternet();

        View fragmentView = inflater.inflate(R.layout.paymenthistory_view, container, false);
        totalAmount=(TextView)fragmentView.findViewById(R.id.totalAmount);

        userSharedPreferences = this.getActivity().getSharedPreferences(context.getString(R.string.cPreferences), Context.MODE_PRIVATE);
        doctorCustomerId = userSharedPreferences.getString(context.getString(R.string.customerId), null);
        doctorEmail = userSharedPreferences.getString(getActivity().getResources().getString(R.string.customerEmail), null);


        mRecyclerView = (RecyclerView) fragmentView.findViewById(R.id.recycler_view);
        mRecyclerView.setHasFixedSize(true);
        mLayoutManager = new LinearLayoutManager(getActivity());
        mRecyclerView.setLayoutManager(mLayoutManager);

        mRecyclerView.setOnScrollListener(new RecyclerView.OnScrollListener() {
            @Override
            public void onScrolled(RecyclerView recyclerView, int dx, int dy) {
                super.onScrolled(recyclerView, dx, dy);
                visibleItemCount = mRecyclerView.getChildCount();
                totalItemCount = mLayoutManager.getItemCount();
                // Log.d("---", "----visibleItemcount---"+visibleItemCount);
                //Log.d("---", "----totalItemcount---"+totalItemCount);
                firstVisibleItem = mLayoutManager.findFirstVisibleItemPosition();
                //Log.d("---", "----firstVisibleItemcount---"+firstVisibleItem);
                //Log.d("---", "----visibleItemCount + firstVisibleItem--"+(visibleItemCount + firstVisibleItem));
               /* if (loading) {
                    if ((visibleItemCount + firstVisibleItem) >= totalItemCount) {
                        loading = false;
                        //      Log.d("---", "-----Last Item Wow -----!");
                        count = totalItemCount;
                        //    Log.d("---","-------------count"+count);
                        getPaymentHistory();
                    }
                }*/
            }

        });
        getPaymentHistory();
        return fragmentView;

    }

    public void getPaymentHistory() {

        new AsyncTask<Void, Void, List<FeedItemPayment>>() {



            @Override
            protected List<FeedItemPayment> doInBackground(Void... params) {
//                ArrayList<HashMap> list = new ArrayList<HashMap>();
                String jsonStr = "";
                ServiceHandler sh = new ServiceHandler();

                String str = "";
                str = str + url;

                try {

                    String queryStr = new CommonUtil().ConvertToUrlString(str+"CID="+doctorCustomerId+"&cEmail="+doctorEmail);
                    Log.d(TAG,"Query string  is"+queryStr);

                    if (isInternetPresent) {

                        jsonStr = sh.makeServiceCall(queryStr, ServiceHandler.GET);
                    } else {
                        getActivity().runOnUiThread(new Runnable() {
                            public void run() {

                                final AlertDialog.Builder builder = new AlertDialog.Builder(getActivity());
                                builder.setTitle("Connection failure");
                                builder.setMessage("Please check your network connection and try again");
                                builder.setIcon(R.drawable.warn)
                                        .setPositiveButton("cancel", new DialogInterface.OnClickListener() {
                                            public void onClick(DialogInterface dialog, int id) {
                                                builder.setCancelable(true);
                                            }
                                        })
                                        .setNegativeButton("Wi-Fi Settings", new DialogInterface.OnClickListener() {
                                            public void onClick(DialogInterface dialog, int id) {
                                                startActivityForResult(new Intent(Settings.ACTION_WIFI_SETTINGS), 0);
                                            }
                                        });
                                builder.show();
                            }
                        });
                    }
                } catch (URISyntaxException e1) {
                    e1.printStackTrace();
                }
                try {
                    jsonArray = new JSONArray(jsonStr);
                    for (int i = 0; i < jsonArray.length()-1; i++) {
                        jsonObject = jsonArray.getJSONObject(i);
                        FeedItemPayment item = new FeedItemPayment();
                        item.setCustomerName(jsonObject.optString("customerName"));
                        item.setPayref(jsonObject.optString("payref"));
                        item.setPayDate(jsonObject.optString("payDate"));
                        item.setConsultationType(jsonObject.optString("consultationType"));
                        item.setConsultationFee(jsonObject.optString("consultationFee"));
                        item.setCurrencyCode(jsonObject.optString("currencyCode"));
                        feedItemList.add(item);
                    }
                } catch (JSONException e) {
                    e.printStackTrace();
                }
                return feedItemList;
            }
            private void showAlertDialog(FragmentActivity activity, String s, String s1, boolean b) {
                AlertDialog alertDialog = new AlertDialog.Builder(context).create();
                alertDialog.setTitle("");
                alertDialog.setMessage("");

                alertDialog.setButton("OK", new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface dialog, int which) {
                    }
                });
                alertDialog.show();
            }

            @Override
            protected void onPostExecute(List<FeedItemPayment> list) {
                if (list.size() == 0) {
                    Toast.makeText(getActivity(), " empty!", Toast.LENGTH_LONG).show();
                } else {
                    super.onPostExecute(list);
                    adapter = new MyRecyclerAdapterPaymentHistory(getActivity(), feedItemList);
                    mRecyclerView.addItemDecoration(new SimpleDividerItemDecoration(getResources()));
                    mRecyclerView.setAdapter(adapter);
/*
                    mLayoutManager.scrollToPositionWithOffset(count, 0);
*/
                    loading = true;
                }
            }
        }.execute(null, null, null);
    }
}