package com.healhouts.doctor.adaptor;

import android.content.Context;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.LinearLayout;
import android.widget.TextView;

import com.healhouts.doctor.R;
import com.healhouts.doctor.bean.FeedItemPayment;

import java.util.List;

/**
 * Created by samsung on 18-06-2015.
 */
public class MyRecyclerAdapterPaymentHistory extends RecyclerView.Adapter<MyRecyclerAdapterPaymentHistory.FeedListRowHolderPaymentHistory> implements View.OnClickListener {

    String TAG=getClass().getName();
    LinearLayout linearLayout;
    private List<FeedItemPayment> feedItemList;
    private Context mContext;
    OnItemClickListener mItemClickListener;
    public MyRecyclerAdapterPaymentHistory(Context context, List<FeedItemPayment> feedItemList) {
        this.feedItemList = feedItemList;
        this.mContext = context;
    }

   /* public MyRecyclerAdapterPublicQA() {

    }*/


    @Override
    public FeedListRowHolderPaymentHistory onCreateViewHolder(ViewGroup viewGroup, int viewType) {
        View v = LayoutInflater.from(viewGroup.getContext()).inflate(R.layout.paymenthistory, null);


        FeedListRowHolderPaymentHistory mh = new FeedListRowHolderPaymentHistory(v);

        return mh;
    }
    public void onBindViewHolder(final FeedListRowHolderPaymentHistory feedListRowHolder, final int i) {
        final FeedItemPayment feedItem = feedItemList.get(i);
        feedListRowHolder.customerName.setText(feedItem.getCustomerName());
        feedListRowHolder.payref.setText(feedItem.getPayref());
        feedListRowHolder.payDate.setText(feedItem.getPayDate());
        feedListRowHolder.consultationType.setText(feedItem.getConsultationType());
        feedListRowHolder.consultationFee.setText(feedItem.getConsultationFee()+feedItem.getCurrencyCode());

    }
    public int getItemCount() {

        return (null != feedItemList ? feedItemList.size() : 0);
    }

    @Override
    public void onClick(View v) {

    }

    public  interface OnItemClickListener{
        public  void onItemClick(View view, int position);
    }
    public void SetOnItemClickListener(final OnItemClickListener mItemClickListener) {
        this.mItemClickListener = mItemClickListener;
    }

    public class FeedListRowHolderPaymentHistory  extends RecyclerView.ViewHolder implements View.OnClickListener{

        protected TextView customerName;
        protected TextView currencyCode;
        protected TextView payref;
        protected TextView payDate;
        protected TextView consultationFee;
        protected  TextView totalAmount;
        protected  TextView consultationType;


        public FeedListRowHolderPaymentHistory(View view) {
            super(view);
            this.customerName = (TextView) view.findViewById(R.id.customerName);
            this.payref = (TextView) view.findViewById(R.id.payref);
            this.payDate = (TextView) view.findViewById(R.id.payDate);
            this.consultationFee=(TextView)view.findViewById(R.id.consultationFee);
            this.totalAmount=(TextView)view.findViewById(R.id.totalAmount);
            this.consultationType=(TextView)view.findViewById(R.id.consultationType);
        }

        @Override
        public void onClick(View v) {

            if (mItemClickListener != null) {
                mItemClickListener.onItemClick(v, getPosition());
            }
        }

    }


}
