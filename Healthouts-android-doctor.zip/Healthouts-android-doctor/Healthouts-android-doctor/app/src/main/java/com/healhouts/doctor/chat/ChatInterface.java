package com.healhouts.doctor.chat;

public interface ChatInterface {
	

//	public boolean createChatAccount(String username, String password)throws Exception;
	public boolean loginToOpenFire(String username, String password)throws Exception;
//	public Vector getOnlineRoster()throws Exception;
//	public void sendMessage(String from,String to,String message);
//	public void setStatus(Type type, String status, int priority,Mode mode);
}
