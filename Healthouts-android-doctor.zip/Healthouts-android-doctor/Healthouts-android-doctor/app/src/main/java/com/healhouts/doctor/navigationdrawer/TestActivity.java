package com.healhouts.doctor.navigationdrawer;

import android.os.Bundle;
import android.support.v7.app.ActionBarActivity;

import com.healhouts.doctor.R;

/**
 * Created by Venkat Veeravalli on 03-06-2015.
 */
public class TestActivity extends ActionBarActivity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.paid_question_list);
    }
}
