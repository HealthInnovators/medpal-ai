package com.healhouts.doctor;

import android.app.AlertDialog;
import android.app.ProgressDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageInfo;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.os.AsyncTask;
import android.os.Bundle;
import android.support.v7.app.ActionBarActivity;
import android.util.Log;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.google.android.gms.gcm.GoogleCloudMessaging;
import com.healhouts.doctor.GCMService.Config;
import com.healhouts.doctor.common.ServiceHandler;

import org.json.JSONException;
import org.json.JSONObject;

import java.io.IOException;
import java.net.URISyntaxException;

//import com.healthouts.GCMService.Config;
//import com.healthouts.chat.ChatServer;

public class LoginActivity extends ActionBarActivity {
    AlertDialog.Builder builder;
    private EditText email = null;
    private EditText password = null;
    private Button login;
    ProgressDialog pDialog;
    //	public String url ="http://healthouts.com/appLogin?";
//    private String url ="http://10.2.192.205:8084/appLogin?";
//    private String updageRegIdUrl ="http://10.2.192.205:8084/updateRegId?";
    private String updageRegIdUrl = "http://healthouts.com/updateRegId?";

    public static final String REG_ID = "regId";
    private static final String APP_VERSION = "appVersion";

    static final String TAG = "LoginActivity";

    SharedPreferences sharedpreferences;
    private static String ctustomerId;
    private static String customerType;
    private static String customerEmail;
    private static String customerPassword;
    private static String customerName;
    private static String doctorIdKey;
    private static String profilepic;
    private static String cPreferences;
    private boolean loginStatus =false;
    private String doctorCustomerId;
    SharedPreferences userSharedPreferences;

//    ChatServer xmppServer = new ChatServer();
    GoogleCloudMessaging gcm;
    Context context;
    String regId;
    private boolean token = false;//this is the status for updating device registration id in server
    Bundle bundle;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        // TODO Auto-generated method stub
        super.onCreate(savedInstanceState);

        userSharedPreferences = this.getSharedPreferences(getString(R.string.cPreferences), Context.MODE_PRIVATE);
        doctorCustomerId = userSharedPreferences.getString(getString(R.string.customerId), null);
        if(userSharedPreferences.getString(getString(R.string.customerId), null) != null){
            loginStatus = true;
            Intent intent = new Intent(this, AMS.class);
            startActivity(intent);
        }
        setContentView(R.layout.login);
        bundle = getIntent().getExtras();
        android.support.v7.app.ActionBar actionBar = getSupportActionBar();
        ColorDrawable colorDrawable = new ColorDrawable(Color.parseColor("#0f9d58"));
        actionBar.setBackgroundDrawable(colorDrawable);
        actionBar.setIcon(R.drawable.ic_launcher);

        actionBar.setDisplayHomeAsUpEnabled(true);
        actionBar.setHomeButtonEnabled(true);
//
        context = getApplicationContext();

//		Toast.makeText(LoginActivity.this, "The email or password that you are entered is incorrect", Toast.LENGTH_LONG).show();
        email = (EditText) findViewById(R.id.edtEmail);
        password = (EditText) findViewById(R.id.edtPassword);
        login = (Button) findViewById(R.id.btnLogin);
        customerPassword = this.getString(R.string.customerPassword);
        customerEmail = this.getString(R.string.customerEmail);
        customerType = this.getString(R.string.customerType);
        ctustomerId = this.getString(R.string.customerId);
        customerName = this.getString(R.string.customerName);
        doctorIdKey = this.getString(R.string.doctorIdKey);
        profilepic = this.getString(R.string.customerImage);
        cPreferences = this.getString(R.string.cPreferences);
        sharedpreferences = getSharedPreferences(cPreferences, Context.MODE_PRIVATE);


    }
public void  home(View view){
    Intent intent=new Intent(this,AMS.class);
    startActivity(intent);
}
    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
//        switch (item.getItemId()) {
//
//            case R.id.txt_doctorHomeTitle:
//                Intent docSpecialities = new Intent(this, AMS.class);
//                startActivity(docSpecialities);
//                break;
//            case R.id.action_search:
//                break;
//
//            case android.R.id.home:
//                super.onBackPressed();
//                break;
//
//
//            default:
//
//        }


        return super.onOptionsItemSelected(item);
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
    }

    public void login(View view) {

        if (email.getText().toString().equals("") || password.getText().toString().equals("")) {
            Toast.makeText(this, "Login details required", Toast.LENGTH_LONG).show();
        } else {
            new CheckAuthendication().execute();
        }
    }

    public void singUp(View view) {
        Toast.makeText(this, "Sign Up", Toast.LENGTH_LONG).show();
        Intent intent = new Intent(this, UserRegistration.class);
        intent.putExtras(bundle);
        startActivity(intent);
    }

    private class CheckAuthendication extends AsyncTask<Void, Void, JSONObject> {

        @Override
        protected void onPreExecute() {
            // TODO Auto-generated method stub
            super.onPreExecute();
            pDialog = new ProgressDialog(LoginActivity.this);
            pDialog.setTitle("Verifying");
            pDialog.setMessage("the Credentials.... ");
            pDialog.setCancelable(false);
            pDialog.show();
            builder = new AlertDialog.Builder(LoginActivity.this);

        }

        @Override
        protected JSONObject doInBackground(Void... arg0) {
            // TODO Auto-generated method stub
            ServiceHandler sh = new ServiceHandler();
            String jsonStr = "";
            JSONObject job = null;
            try {
                Log.d(TAG, "----email--->" + email.getText());
                Log.d(TAG, "----pass---->" + password.getText());
                String url = "http://healthouts.com/appLogin?";
                url = url + "email=" + email.getText().toString() + "&pass=" + password.getText().toString();
                Log.d(TAG, "-----url for authendication---->" + url);
                jsonStr = sh.makeServiceCall(url, ServiceHandler.GET);

            } catch (URISyntaxException e) {
                // TODO Auto-generated catch block
                e.printStackTrace();
                Toast.makeText(context, "Network connection is not good", Toast.LENGTH_LONG).show();
            }
            Log.d(TAG, "response string" + jsonStr);
            if (jsonStr != null) {

                try {
                    job = new JSONObject(jsonStr);
                    Log.i("josn", job.getString("status"));

                    if (job.getString("status").equals("1")) {

                        try {
//                            if (gcm == null) {
//                                gcm = GoogleCloudMessaging.getInstance(context);
//                                Log.i(TAG, "--gcm1--" + gcm);
//                                gcm.unregister();
//                            }
//                            Log.i(TAG, "--gcm2--" + gcm);
//                            regId = gcm.register(Config.GOOGLE_PROJECT_ID);
//                            Log.d(TAG, "registerInBackground - regId: " + regId);
////                            msg = "Device registered, registration ID=" + regId;
//
//                            ServiceHandler sh2 = new ServiceHandler();
//                            updageRegIdUrl = updageRegIdUrl + "regId=" + regId + "&userEmail=" + email.getText();
//                            Log.d(TAG, updageRegIdUrl);
//                            jsonStr = sh2.makeServiceCall(updageRegIdUrl, ServiceHandler.GET);
//                            Log.d(TAG, "--serverResponse--:" + jsonStr);
//                            JSONObject json = new JSONObject(jsonStr);

//                            if (json != null) {
//                                if (json.get("status").equals("1")) {
//                                    storeRegistrationId(context, regId);
                                    Log.i("josn", job.getString("emailId"));
                                    Log.i("josn", job.getString("customerType"));
                                    Log.i("josn", job.getString("customerId"));
                                    Log.i("josn", job.getString("pass"));
                                    SharedPreferences.Editor editor = sharedpreferences.edit();
//						Log.i("Stirng value", customerEmail);
                                    editor.putString(ctustomerId, job.getString("customerId"));
                                    editor.putString(customerEmail, job.getString("emailId"));
                                    editor.putString(customerType, job.getString("customerType"));
                                    editor.putString(customerPassword, job.getString("pass"));
                                    editor.putString(customerName, job.getString("cName"));
                                    editor.putString(doctorIdKey, job.getString("doctorId"));
                                    editor.putString(profilepic,job.optString("cImage"));


                                    editor.commit();
//                                    xmppServer.connect("healthouts" + job.getString("customerId"), "healthouts" + job.getString("customerId"));
//                                }
//                            }

                        }
//                        catch (IOException ex) {
//                            ex.printStackTrace();
//                            job.put("customerType", "NOTVALID");
//                            return job;
//                        } catch (URISyntaxException e) {
//                            e.printStackTrace();
//                            job.put("customerType", "NOTVALID");
//                            return job;
//                        }
                        catch (JSONException e) {
                            e.printStackTrace();
                        }
//                       boolean val =  registerInBackground();


                    } else {
                        job.put("customerType", "NOTVALID");
                        return job;
//                        Toast.makeText(context, "The email or password that you are entered is incorrect", Toast.LENGTH_LONG).show();
                    }

                } catch (JSONException e) {
                    // TODO Auto-generated catch block
                    e.printStackTrace();
                    JSONObject job2 = new JSONObject();
                    try {
                        job2.put("customerType", "NOTVALID");
                    } catch (JSONException e1) {
                        e1.printStackTrace();
                    }

                    return job2;
                } catch (Exception e1) {
                    // TODO Auto-generated catch block
                    e1.printStackTrace();
                }
            }
            return job;
        }

        @Override
        protected void onPostExecute(JSONObject result) {
            // TODO Auto-generated method stub
            super.onPostExecute(result);
            if (pDialog.isShowing())
                pDialog.dismiss();
            Intent intent = null;
            Bundle myData = new Bundle();
            try {
                if (result.getString("customerType").equals("CUSTOMER")) {
                    intent = new Intent(LoginActivity.this, TestActivity.class);
                    //				myData.putString("doctorId", newData.getDoctorId());
//				myData.putString("dName", newData.getdName());
                    intent.putExtras(bundle);
//				startActivityForResult(intent, IPC_ID);
                    startActivity(intent);

                } else if (result.getString("customerType").equals("DOCTOR")) {
                    intent = new Intent(LoginActivity.this, AMS.class);
                    //				myData.putString("doctorId", newData.getDoctorId());
//				myData.putString("dName", newData.getdName());
                    intent.putExtras(myData);
//				startActivityForResult(intent, IPC_ID);
                    startActivity(intent);

                } else if (result.getString("customerType").equals("NOTVALID")) {
                    Log.d(TAG, "Authandication failed try again");
                    Toast.makeText(context, "User is not valid try again", Toast.LENGTH_LONG).show();
                    builder.setCancelable(true);
                    builder.setMessage("Authendication failed");
                    builder.setInverseBackgroundForced(true);

                    builder.setNeutralButton("Ok", new DialogInterface.OnClickListener() {
                        public void onClick(DialogInterface dialog, int whichButton) {
                            dialog.dismiss();
                        }
                    });

                    builder.show();

                }


            } catch (Exception e) {
                // TODO: handle exception
                e.printStackTrace();
            }

            /**
             * Updating parsed JSON data into ListView
             * */


        }


    }

    private boolean registerInBackground() {
        String msg = "";
        String jsonStr = "";
        try {
            if (gcm == null) {
                gcm = GoogleCloudMessaging.getInstance(context);
                gcm.unregister();
            }
            regId = gcm.register(Config.GOOGLE_PROJECT_ID);
            Log.d("RegisterActivity", "registerInBackground - regId: "
                    + regId);
            msg = "Device registered, registration ID=" + regId;

            ServiceHandler sh = new ServiceHandler();
            updageRegIdUrl = updageRegIdUrl + "regId=" + regId + "&userEmail=" + email.getText();
            Log.d(TAG, updageRegIdUrl);
            jsonStr = sh.makeServiceCall(updageRegIdUrl, ServiceHandler.GET);
            Log.d(TAG, "--serverResponse--:" + jsonStr);
            JSONObject json = new JSONObject(jsonStr);

            if (json != null) {
                if (json.get("status").equals("1")) {
                    storeRegistrationId(context, regId);
                    token = true;
                }
            }

        } catch (IOException ex) {
            msg = "Error :" + ex.getMessage();
            Log.d("RegisterActivity", "Error: " + msg);
        } catch (URISyntaxException e) {
            e.printStackTrace();
        } catch (JSONException e) {
            e.printStackTrace();
        }


        return token;
    }

    private static int getAppVersion(Context context) {
        try {
            PackageInfo packageInfo = context.getPackageManager()
                    .getPackageInfo(context.getPackageName(), 0);
            return packageInfo.versionCode;
        } catch (PackageManager.NameNotFoundException e) {
            Log.d("RegisterActivity",
                    "I never expected this! Going down, going down!" + e);
            throw new RuntimeException(e);
        }
    }

    private void storeRegistrationId(Context context, String regId) {
        final SharedPreferences prefs = getSharedPreferences(
                LoginActivity.class.getSimpleName(), Context.MODE_PRIVATE);
        int appVersion = getAppVersion(context);
        Log.i(TAG, "Saving regId on app version " + appVersion);
        SharedPreferences.Editor editor = prefs.edit();
        editor.putString(REG_ID, regId);
        editor.putInt(APP_VERSION, appVersion);
        editor.commit();
    }
}
