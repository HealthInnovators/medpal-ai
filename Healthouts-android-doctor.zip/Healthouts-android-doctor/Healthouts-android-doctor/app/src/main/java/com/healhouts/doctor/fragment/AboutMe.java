package com.healhouts.doctor.fragment;

import android.app.AlertDialog;
import android.app.Fragment;
import android.app.ProgressDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import android.database.Cursor;
import android.graphics.BitmapFactory;
import android.net.Uri;
import android.os.AsyncTask;
import android.os.Bundle;
import android.provider.MediaStore;
import android.provider.Settings;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.Toast;

import com.healhouts.doctor.R;
import com.healhouts.doctor.common.AndroidMultiPartEntity;
import com.healhouts.doctor.common.CommonUtil;
import com.healhouts.doctor.common.Config;
import com.healhouts.doctor.common.ConnectionDetector;
import com.healhouts.doctor.common.ServiceHandler;
import com.squareup.picasso.Picasso;

import org.apache.http.HttpEntity;
import org.apache.http.HttpResponse;
import org.apache.http.client.ClientProtocolException;
import org.apache.http.client.HttpClient;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.entity.mime.content.FileBody;
import org.apache.http.entity.mime.content.StringBody;
import org.apache.http.impl.client.DefaultHttpClient;
import org.apache.http.util.EntityUtils;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.File;
import java.io.IOException;
import java.io.UnsupportedEncodingException;
import java.net.URISyntaxException;

public class AboutMe extends Fragment {
    private static final String TAG = "AboutMe";
    ProgressDialog pDialog;
    AlertDialog.Builder builder;
    JSONObject jsonObj;
    private Context context;
    Boolean isInternetPresent = false;
    ConnectionDetector cd;
    JSONArray jsonArray;
    SharedPreferences userSharedPreferences;
    String doctorCustomerId;
    String doctorEmail;
    EditText nameView,aboutmeView,dobView;
    ImageButton imgButtonView;
    Button updatButton;
    private RadioGroup radioSexGroup;
    private RadioButton radioFemale,radioMale,radioSexButton;
    JSONObject jsonObject;
    private static int RESULT_LOAD_IMAGE = 1;
    String attachmentFile="";
    String jsonStr = "";
//    String url = "http://joslinlive.org/appDoctorAllDetails?";
    String url = "http://healthouts.com/appDoctorAllDetails?";



    @Override
    public void onCreate(Bundle savedInstanceState) {
        getActivity().getWindow().setSoftInputMode(
                WindowManager.LayoutParams.SOFT_INPUT_ADJUST_PAN);

        // TODO Auto-generated method stub
        super.onCreate(savedInstanceState);
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {

        context = getActivity().getApplicationContext();
        cd = new ConnectionDetector(context);
        isInternetPresent = cd.isConnectingToInternet();
        View view = inflater.inflate(R.layout.aboutme,null);

        userSharedPreferences = this.getActivity().getSharedPreferences(context.getString(R.string.cPreferences), Context.MODE_PRIVATE);
        doctorCustomerId = userSharedPreferences.getString(context.getString(R.string.customerId), null);
        doctorEmail = userSharedPreferences.getString(getActivity().getResources().getString(R.string.customerEmail), null);

        nameView = (EditText)view.findViewById(R.id.editTextName);
        aboutmeView = (EditText)view.findViewById(R.id.editTextaboutme);
        dobView = (EditText)view.findViewById(R.id.editTextDOB);
        imgButtonView = (ImageButton)view.findViewById(R.id.profilePic);
        radioSexGroup = (RadioGroup) view.findViewById(R.id.radioSex);
        radioMale = (RadioButton)view.findViewById(R.id.radioMale);
        radioFemale = (RadioButton)view.findViewById(R.id.radioFemale);

        imgButtonView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View arg0) {
                Intent i = new Intent(Intent.ACTION_PICK, MediaStore.Images.Media.EXTERNAL_CONTENT_URI);
                startActivityForResult(i, RESULT_LOAD_IMAGE);
            }
        });

        updatButton = (Button)view.findViewById(R.id.btnSaveAboutme);
        updatButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                saveDoctorDetails();
            }
        });

       // jsonStr = getArguments().getString("jsonStr");

        getDoctorDetials();
        return view;
    }
    @Override
    public void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == RESULT_LOAD_IMAGE  && null != data) {
            Uri selectedImage = data.getData();
            String[] filePathColumn = { MediaStore.Images.Media.DATA };
            Cursor cursor = context.getContentResolver().query(selectedImage,filePathColumn, null, null, null);
            cursor.moveToFirst();
            int columnIndex = cursor.getColumnIndex(filePathColumn[0]);
            attachmentFile = cursor.getString(columnIndex);
            Log.d("---", "----picturePath--"+attachmentFile);
            cursor.close();

            imgButtonView.setImageBitmap(BitmapFactory.decodeFile(attachmentFile));
        }
    }

    @Override
    public void onActivityCreated(Bundle savedInstanceState) {
        // TODO Auto-generated method stub
        super.onActivityCreated(savedInstanceState);
    }

    private void getDoctorDetials() {
//        String jsonStr = "";
//        ServiceHandler sh = new ServiceHandler();

        String str = "";
        str = str + url;

        try {


            String queryStr = new CommonUtil().ConvertToUrlString(str + "CID=" + doctorCustomerId + "&cEmail=" + doctorEmail);
            Log.d(TAG, "Query string  is" + queryStr);

            if (isInternetPresent) {

                if(jsonStr.equals("")) {
                    ServiceHandler sh = new ServiceHandler();
                    jsonStr = sh.makeServiceCall(queryStr, ServiceHandler.GET);
                }
                try {

                    jsonObject = new JSONObject(jsonStr);
                    nameView.setText(jsonObject.optString("name"));
                    aboutmeView.setText(jsonObject.optString("info"));
                    dobView.setText(jsonObject.optString("dob"));
                    if (!jsonObject.optString("imagePath").equals("")) {
//                        Picasso.with(context).load(new CommonUtil().ConvertToUrlString("http://joslinlive.org/img/" + jsonObject.optString("imagePath")))


                        Picasso.with(context).load(new CommonUtil().ConvertToUrlString("http://healthouts.com/img/" + jsonObject.optString("imagePath")))

                                .error(R.drawable.person_image_empty)
                                .placeholder(R.drawable.person_image_empty)
                                .into(imgButtonView);
                    }

                    if (!jsonObject.optString("gender").equals("")) {
                        String gender = jsonObject.optString("gender");
                        if (gender.equalsIgnoreCase("Male")) {
                            radioMale.setSelected(true);
                        } else {
                            radioFemale.setSelected(true);
                        }
                    }


                    Log.d("My App", jsonObject.toString());

                } catch (Throwable t) {
                    Log.e("My App", "Could not parse malformed JSON: \"" + jsonStr + "\"");
                }

            } else {
                getActivity().runOnUiThread(new Runnable() {
                    public void run() {
                        final AlertDialog.Builder builder = new AlertDialog.Builder(getActivity());
                        builder.setTitle("Connection failure");
                        builder.setMessage("Please check your network connection and try again");
                        builder.setIcon(R.drawable.warn)
                                .setPositiveButton("cancel", new DialogInterface.OnClickListener() {
                                    public void onClick(DialogInterface dialog, int id) {
                                        builder.setCancelable(true);
                                    }
                                })
                                .setNegativeButton("Wi-Fi Settings", new DialogInterface.OnClickListener() {
                                    public void onClick(DialogInterface dialog, int id) {
                                        startActivityForResult(new Intent(Settings.ACTION_WIFI_SETTINGS), 0);

                                    }
                                });
                        builder.show();

                    }
                });

            }

        } catch (URISyntaxException e1) {
            // TODO Auto-generated catch block
            e1.printStackTrace();
        }

    }
    public void saveDoctorDetails() {
        new AsyncTask<Void, Integer, String>() {

            @Override
            protected void onPreExecute() {
                super.onPreExecute();
                pDialog = new ProgressDialog(getActivity());
                pDialog.setTitle("Please wait");
                pDialog.setMessage("processing.... ");
                pDialog.setCancelable(false);
                pDialog.show();
                builder = new AlertDialog.Builder(getActivity());
                // setting progress bar to zero

            }

            @Override
            protected String doInBackground(Void... params) {
                return uploadFile();
            }


            private String uploadFile() {

                String responseString = null;

                HttpClient httpclient = new DefaultHttpClient();
                HttpPost httppost = new HttpPost(Config.UPDATE_ABOUTME_URL);
                try {
                    AndroidMultiPartEntity entity = new AndroidMultiPartEntity(
                            new AndroidMultiPartEntity.ProgressListener() {

                                @Override
                                public void transferred(long num) {
//                                    publishProgress((int) ((num / (float) totalSize) * 100));
                                }
                            });
                    if(!attachmentFile.equals("")) {
                        File sourceFile = new File(attachmentFile);

                        // Adding file data to http body
                        entity.addPart("profilepImage", new FileBody(sourceFile));

                    }
                    entity.addPart("CID", new StringBody(doctorCustomerId));
                    entity.addPart("cEmail", new StringBody(doctorEmail));
                    entity.addPart("name", new StringBody(nameView.getText().toString()));
                    entity.addPart("dob", new StringBody(dobView.getText().toString()));
                    entity.addPart("aboutme", new StringBody(aboutmeView.getText().toString()));
                    // get selected radio button from radioGroup
                    int selectedId = radioSexGroup.getCheckedRadioButtonId();

                    // find the radiobutton by returned id
                    if (selectedId == R.id.radioMale)

                        entity.addPart("gender", new StringBody((selectedId == R.id.radioMale) ? "Male" : "Female"));


//                    totalSize = entity.getContentLength();
                    httppost.setEntity(entity);
                    // Making server call
                    HttpResponse response = httpclient.execute(httppost);
                    HttpEntity r_entity = response.getEntity();

                    int statusCode = response.getStatusLine().getStatusCode();
                    if (statusCode == 200) {
                        // Server response
                        responseString = EntityUtils.toString(r_entity);
                    } else {
                        responseString = "Error occurred! Http Status Code: "
                                + statusCode;

                    }
                } catch (UnsupportedEncodingException e) {
                    e.printStackTrace();
                } catch (ClientProtocolException e) {
                    e.printStackTrace();
                } catch (IOException e) {
                    e.printStackTrace();
                }

                return responseString;
            }

            @Override
            protected void onPostExecute(String resultString) {
                super.onPostExecute(resultString);
                if (pDialog.isShowing())
                    pDialog.dismiss();
//                Toast toast = Toast.makeText(context, resultString, Toast.LENGTH_LONG);
//                toast.getView().setBackgroundColor(getResources().getColor(R.color.error_toast));
//                toast.show();
                if (resultString != null && !resultString.equals("")) {
                    try {
                        JSONObject jsonObject = new JSONObject(resultString);
                        if (jsonObject.getString("status").equals("1")) {
//                            Toast toast = Toast.makeText(context, jsonObject.getString("message"), Toast.LENGTH_LONG);
//                            toast.getView().setBackgroundColor(getResources().getColor(R.color.green));
//                            toast.show();
                            builder.setCancelable(true);
                            builder.setMessage(jsonObject.getString("message"));
                            builder.setInverseBackgroundForced(true);
                            builder.setPositiveButton("Done", new DialogInterface.OnClickListener() {
                                @Override
                                public void onClick(DialogInterface dialog, int which) {
//                                    Intent intent = new Intent(context, AMS.class);
//                                    startActivity(intent);
                                    dialog.dismiss();
                                }
                            });
//                            builder.setNeutralButton("Done", new DialogInterface.OnClickListener() {
//                                public void onClick(DialogInterface dialog, int whichButton) {
//                                    dialog.dismiss();
//                                }
//                            });

                            builder.show();

                        } else {
                            Toast toast = Toast.makeText(context, jsonObject.getString("message"), Toast.LENGTH_LONG);
                            toast.getView().setBackgroundColor(getResources().getColor(R.color.error_toast));
                            toast.show();
                        }
                    } catch (JSONException e) {
                        e.printStackTrace();
                    }

                } else {
                    Toast toast = Toast.makeText(context, "Sorry! Due to some problem Message sending failed", Toast.LENGTH_LONG);
                    toast.getView().setBackgroundColor(getResources().getColor(R.color.error_toast));
                    toast.show();
                }
            }

        }.execute();

    }







    }

