package com.healhouts.doctor.bean;

/**
 * Created by Venkat Veeravalli on 15-06-2015.
 */
public class FeedItemDoctorTimings {
    private String doctorTimeId;
    private String appointmentDate;
    private boolean availability;
    private int period;
    private String periodTime;
    private int imageId;
    private String doctorId;
    private String doctorCustomerId;
    private String doctorEmail;

    public String getDoctorEmail() {
        return doctorEmail;
    }

    public void setDoctorEmail(String doctorEmail) {
        this.doctorEmail = doctorEmail;
    }

    public String getDoctorCustomerId() {
        return doctorCustomerId;
    }

    public void setDoctorCustomerId(String doctorCustomerId) {
        this.doctorCustomerId = doctorCustomerId;
    }

    public String getDoctorId() {
        return doctorId;
    }

    public void setDoctorId(String doctorId) {
        this.doctorId = doctorId;
    }

    public int getImageId() {
        return imageId;
    }

    public void setImageId(int imageId) {
        this.imageId = imageId;
    }

    public String getPeriodTime() {
        return periodTime;
    }

    public void setPeriodTime(String periodTime) {
        this.periodTime = periodTime;
    }

    public String getDoctorTimeId() {
        return doctorTimeId;
    }

    public void setDoctorTimeId(String doctorTimeId) {
        this.doctorTimeId = doctorTimeId;
    }

    public String getAppointmentDate() {
        return appointmentDate;
    }

    public void setAppointmentDate(String appointmentDate) {
        this.appointmentDate = appointmentDate;
    }

    public boolean isAvailability() {
        return availability;
    }

    public void setAvailability(boolean availability) {
        this.availability = availability;
    }

    public int getPeriod() {
        return period;
    }

    public void setPeriod(int period) {
        this.period = period;
    }
}
