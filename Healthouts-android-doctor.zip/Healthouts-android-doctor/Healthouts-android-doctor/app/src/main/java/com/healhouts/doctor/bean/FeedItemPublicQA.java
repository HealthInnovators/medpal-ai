package com.healhouts.doctor.bean;

/**
 * Created by samsung on 15-06-2015.
 */
public class FeedItemPublicQA {


    private String cImage;
    private String customerName;
    private String time;
    private String location;
    private String cgender;

    public String getQuestion() {
        return question;
    }

    public void setQuestion(String question) {
        this.question = question;
    }

    private  String question;

    public void setCdob(String cdob) {
        this.cdob = cdob;
    }

    private String cdob;
    private Integer cusotmerId;
    private Integer questionId;
    private Integer count;

    public String getcImage() {
        return cImage;
    }

    public void setcImage(String cImage) {
        this.cImage = cImage;
    }

    public String getTime() {
        return time;
    }

    public void setTime(String time) {
        this.time = time;
    }

    public String getCount() {
        return String.valueOf(count);
    }

    public void setCount(Integer count) {
        this.count = count;
    }

    public Integer getQuestionId() {
        return questionId;
    }

    public void setQuestionId(Integer questionId) {
        this.questionId = questionId;
    }

    public Integer getCusotmerId() {
        return cusotmerId;
    }

    public void setCusotmerId(Integer cusotmerId) {
        this.cusotmerId = cusotmerId;
    }

    public String getCdob() {
        return cdob;
    }



    public String getLocation() {
        return location;
    }

    public void setLocation(String location) {
        this.location = location;
    }

    public String getCgender() {
        return cgender;
    }

    public void setCgender(String cgender) {
        this.cgender = cgender;
    }

    public String getCustomerName() {
        return customerName;
    }

    public void setCustomerName(String customerName) {
        this.customerName = customerName;
    }

}
