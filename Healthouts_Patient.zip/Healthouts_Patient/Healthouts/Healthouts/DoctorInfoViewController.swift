//
//  DoctorInfoViewController.swift
//  Healthouts
//
//  Created by Y.Bharath Kumar Reddy on 28/05/15.
//  Copyright (c) 2015 Y.Bharath Kumar Reddy. All rights reserved.
//

import UIKit



class DoctorInfoViewController: UIViewController,UIPopoverPresentationControllerDelegate,UIPickerViewDelegate,UITextFieldDelegate {

    //outlets from the storyboard
    @IBOutlet weak var dateTextField: UITextField!
    @IBOutlet weak var headerDoctorName: UILabel!
    @IBOutlet weak var contentView: UIView!
    @IBOutlet weak var bioLabel: UILabel!
    @IBOutlet weak var knownForLabel: UILabel!
    @IBOutlet weak var experienceLabel: UILabel!
    @IBOutlet weak var practiceLocationLabel: UILabel!
    @IBOutlet weak var nameLabel: UILabel!
    @IBOutlet weak var qualificationLabel: UILabel!
    @IBOutlet weak var specialityLabel: UILabel!
    @IBOutlet weak var locationLabel: UILabel!
    @IBOutlet weak var doctorImageView: UIImageView!
    @IBOutlet weak var navBarView: UIView!
    
    //required variables
    var datePickerView:UIDatePicker!
    var testCount = 0
    var urlString:String!
    var doctorProfile = NSDictionary()
    var datePickerController:UIPopoverController!
    var selectedDoctorId:String = ""
    var doctorName = ""
    var actInd : UIActivityIndicatorView = UIActivityIndicatorView(frame: CGRectMake(0,0, 50, 50)) as UIActivityIndicatorView
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        //set the input view and input accessory view of the dateTextField
        datePickerView = UIDatePicker(frame: CGRectMake(0, 0, self.view.frame.size.width, 100))
        datePickerView.backgroundColor = UIColor.whiteColor()
        datePickerView.datePickerMode = UIDatePickerMode.Date
        dateTextField.inputView = datePickerView
        dateTextField.delegate = self
        
        var view = UIView(frame: CGRectMake(0, 0, self.view.frame.size.width, 40))
        var doneButton =  UIButton(frame: CGRectMake(self.view.frame.size.width/2, 0, self.view.frame.size.width/2, 40))
        doneButton.setTitle("Done", forState: UIControlState.Normal)
        doneButton.backgroundColor = UIColor.greenColor()
        doneButton.addTarget(self, action: "doneSelected", forControlEvents: UIControlEvents.TouchUpInside)
        view.addSubview(doneButton)
        
        var cancelButton = UIButton(frame: CGRectMake(0, 0, self.view.frame.size.width/2, 40))
        cancelButton.setTitle("Cancel", forState: UIControlState.Normal)
        cancelButton.backgroundColor = UIColor.redColor()
        cancelButton.addTarget(self, action: "cancelSelected", forControlEvents: UIControlEvents.TouchUpInside)
        view.addSubview(cancelButton)
        
        dateTextField.inputAccessoryView = view
        
        
        //run the activity Indicator till the data is received
        actInd.center = self.view.center
        actInd.hidesWhenStopped = true
        actInd.activityIndicatorViewStyle = UIActivityIndicatorViewStyle.White
        actInd.backgroundColor = UIColor.blackColor()
        view.addSubview(actInd)
        actInd.startAnimating()
       
        
        //set the navigation bar view properties
        navBarView.layer.shadowColor = UIColor.blackColor().CGColor
        navBarView.layer.shadowOffset = CGSizeMake(0.5, 0.5)
        navBarView.layer.shadowRadius = 3.0
        navBarView.layer.shadowOpacity = 1.0
        
        //add the left and right constraints for the scroll view
        var leftConstraint = NSLayoutConstraint(item: self.contentView, attribute: NSLayoutAttribute.Leading, relatedBy: NSLayoutRelation.Equal, toItem: self.view, attribute: NSLayoutAttribute.Left, multiplier: 1, constant: 8)
        self.view.addConstraint(leftConstraint)
        
        var rightConstraint = NSLayoutConstraint(item: self.contentView, attribute: NSLayoutAttribute.Trailing, relatedBy: NSLayoutRelation.Equal, toItem: self.view, attribute: NSLayoutAttribute.Right, multiplier: 1, constant: -8)
        self.view.addConstraint(rightConstraint)
        
        //any other initialisation
        self.doctorImageView.layer.cornerRadius = 40
        self.doctorImageView.layer.masksToBounds = true
        self.headerDoctorName.text = doctorName
            
        //get the info of the doctor
        getData()
      
        // Do any additional setup after loading the view.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    //set todays date on editing begin
    func textFieldShouldBeginEditing(textField: UITextField) -> Bool {
        datePickerView.setDate(NSDate(), animated: true)
        return true
    }
    
    
    func getData(){
        //call the SRWebclient witht he url and data
        SRWebClient.POST("http://healthouts.com/appDocProf?")
            .data(["doctorId" : selectedDoctorId])
            .send({ (response, status) -> Void in
                
                self.actInd.stopAnimating()
                var err: NSError?
                var data = (response as! String).dataUsingEncoding(NSUTF8StringEncoding, allowLossyConversion: true)

                if let jsonResult = NSJSONSerialization.JSONObjectWithData(data!, options: NSJSONReadingOptions.MutableContainers, error: &err) as? NSDictionary {
                    dispatch_async(dispatch_get_main_queue(), {
                        
                        self.actInd.stopAnimating()
                        self.doctorProfile = jsonResult["profileDetails"] as! NSDictionary
                        self.bioLabel.text = self.doctorProfile["info"] as? String
                        self.experienceLabel.text = (self.doctorProfile["experience"]?.stringValue)! + " years of experience"
                        self.nameLabel.text = self.doctorProfile["name"] as? String
                        self.qualificationLabel.text = self.doctorProfile["qualification"] as? String
                        self.specialityLabel.text = self.doctorProfile["specialization"] as? String
                        self.locationLabel.text = self.doctorProfile["city"] as? String
                        self.setImage()
                        
                        var topics = ""
                        var i = 1
                        while(self.doctorProfile["topic\(i)"] != nil){
                            var topic = self.doctorProfile["topic\(i)"] as! String
                            if(self.doctorProfile["topic\(i+1)"] != nil){
                                topics = topics + "\(topic)\n"
                            }else{
                                topics = topics + "\(topic)"
                                break
                            }
                            i++
                        }
                        self.knownForLabel.text = topics
                        var places = ""
                        var j = 1
                        while(self.doctorProfile["practiceAddress\(j)"] != nil){
                            var place = self.doctorProfile["practiceAddress\(j)"] as! String
                            if(self.doctorProfile["practiceAddress\(j+1)"] != nil){
                                places = places + "\(place)\n"
                            }else{
                                places = places + "\(place)"
                            }
                            j++
                        }
                        self.practiceLocationLabel.text = places
                        
                        
                    })
                }else{
                    self.addAlert(err!.localizedDescription)
                }
                
            }, failure: { (error) -> Void in
                self.actInd.stopAnimating()
                self.addAlert(error.localizedDescription)
            })

    }

    //function to add alert
    func addAlert(message:String){
        var alert = UIAlertController(title: "Alert", message: message, preferredStyle: UIAlertControllerStyle.Alert)
        alert.addAction(UIAlertAction(title: "ok", style: UIAlertActionStyle.Default, handler: nil))
        self.presentViewController(alert, animated: true, completion: nil)
    }

    
    //set the doctor image
    func setImage(){
        self.doctorImageView.image = UIImage(named: "doctoricon")
        if let image = doctorProfile.objectForKey("imagePath") as? String{
            var imgPath = image.stringByReplacingOccurrencesOfString(" ", withString: "%20") as String
            var imgUrl = NSURL(string: imgPath)
            
                SDWebImageDownloader.sharedDownloader().downloadImageWithURL(imgUrl, options: nil, progress: { (receivedSize:Int, expectedSize:Int) -> Void in
                    
                    }) { (image, data, error, finished) -> Void in
                        if(error != nil){
                            self.doctorImageView.image = UIImage(named: "doctoricon")
                        }else{
                            self.doctorImageView.image = image
                        }
                }
        }else{
            self.doctorImageView.image = UIImage(named: "doctoricon")
        }
    }
    
    //handle the back button press
    @IBAction func backButtonPressed(sender: AnyObject) {
        self.navigationController?.popViewControllerAnimated(true)
    }

    @IBAction func bookNowPressed(sender: AnyObject) {
        
        
    }
    
    //handle the buttons in the appointment date selection
    func doneSelected(){
        dateTextField.resignFirstResponder()
        self.performSegueWithIdentifier("AvailableTimings", sender: self)
    }
    
    func cancelSelected(){
        dateTextField.resignFirstResponder()
    }
    
    //go to home
    @IBAction func homeButtonPressed(sender: AnyObject) {
        var destViewController = self.storyboard?.instantiateInitialViewController() as! RootViewController
        self.presentViewController(destViewController, animated: true, completion: nil)
    }
    
    //pass the data corresponding to the segue
    override func prepareForSegue(segue: UIStoryboardSegue, sender: AnyObject?) {
        if(segue.identifier == "AskPaidQuestion"){
            var destViewController = segue.destinationViewController as! AskPaidQuestionViewController
            destViewController.doctorName = self.doctorName
            destViewController.speciality = self.specialityLabel.text!
            destViewController.doctorImage = self.doctorImageView.image!
            destViewController.doctorId = selectedDoctorId
        }else if(segue.identifier == "NormalLogin"){
            testCount = 1
            var destViewController = segue.destinationViewController as! LoginViewController
            destViewController.normalLogin = true
        }else{
            var destViewController = segue.destinationViewController as! AvailableTimingsViewController
            destViewController.doctorProfile = self.doctorProfile
            destViewController.selectedDoctorId = self.selectedDoctorId
            destViewController.date = datePickerView.date
        }
    }
    
    //ask paid question is pressed
    //check if user is logged in or not
    //if logged in go to AskPaidQuestionViewController
    //else take to LoginViewController
    @IBAction func askPaidQuestionPressed(sender: AnyObject) {
        dispatch_async(dispatch_get_main_queue(), {
            if(NSUserDefaults.standardUserDefaults().boolForKey("isLoggedIn")){
                self.performSegueWithIdentifier("AskPaidQuestion", sender: self)
            }else{
                self.performSegueWithIdentifier("NormalLogin", sender: self)
            }
        })
    }
    

    override func viewWillAppear(animated: Bool) {
        if(testCount == 1){
        if(NSUserDefaults.standardUserDefaults().boolForKey("isLoggedIn")){
            performSegueWithIdentifier("AskPaidQuestion", sender: self)
        }
            testCount = 0
        }
    }
    
}
