//
//  SpecialityCollectionViewCell.swift
//  Healthouts
//
//  Created by Y.Bharath Kumar Reddy on 28/05/15.
//  Copyright (c) 2015 Y.Bharath Kumar Reddy. All rights reserved.
//

import UIKit

class SpecialityCollectionViewCell: UICollectionViewCell {
    
    @IBOutlet weak var specialityImageView: UIImageView!
    @IBOutlet weak var specialityName: UILabel!
}
