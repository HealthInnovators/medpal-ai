//
//  MedicationRelatedTableViewCell.swift
//  Healthouts
//
//  Created by Y.Bharath Kumar Reddy on 16/07/15.
//  Copyright (c) 2015 Y.Bharath Kumar Reddy. All rights reserved.
//

import UIKit

protocol MedicationServicesDelegate{
    func updateMedication(button:UIButton)
    func DeleteMedication(button:UIButton)
}


class MedicationRelatedTableViewCell: UITableViewCell,SSRadioButtonControllerDelegate {

    @IBOutlet weak var containerView: UIView!
    @IBOutlet weak var typeLabel: UILabel!
    @IBOutlet weak var typeNameLabel: UILabel!
    @IBOutlet weak var notesLabel: UILabel!
    @IBOutlet weak var notesInfoLabel: UILabel!
    @IBOutlet weak var conditionLabel: UILabel!
    @IBOutlet weak var updateButton: UIButton!
    @IBOutlet weak var deleteButton: UIButton!
    
   
    var delegate:MedicationServicesDelegate?
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
        
    }

    @IBAction func updateButtonPressed(sender: AnyObject) {
        self.delegate?.updateMedication(sender as! UIButton)
    }
    
    @IBAction func deleteButtonPressed(sender: AnyObject) {
        self.delegate?.DeleteMedication(sender as! UIButton)
    }
    
    override func setSelected(selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }

}
