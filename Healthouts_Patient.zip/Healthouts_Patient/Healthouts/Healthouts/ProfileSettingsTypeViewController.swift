//
//  ProfileSettingsTypeViewController.swift
//  Healthouts
//
//  Created by Y.Bharath Kumar Reddy on 15/07/15.
//  Copyright (c) 2015 Y.Bharath Kumar Reddy. All rights reserved.
//

import UIKit

class ProfileSettingsTypeViewController: UIViewController,UITableViewDelegate,UITableViewDataSource {

    //outlets from the storyboard
    @IBOutlet weak var tableView: UITableView!
    
    //required variables
    var types = ["About Me","Contact Information","Medications","Allergies","Symptoms & Conditions","Procedures","Immunization","Health Files","Payment History"]
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    //populate the tableview
    func tableView(tableView: UITableView, cellForRowAtIndexPath indexPath: NSIndexPath) -> UITableViewCell {
        var identifier = "ProfileSettingsType"
        var cell = tableView.dequeueReusableCellWithIdentifier(identifier) as! UITableViewCell
        
        cell.textLabel?.text = types[indexPath.row]
        return cell
    }

    //number of rows in the tableview
    func tableView(tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return types.count
    }
    
    //header name
    func tableView(tableView: UITableView, titleForHeaderInSection section: Int) -> String? {
        return "Settings"
    }
    
    //handle selections in the table view
    //Do the following for each selection
    //1.initialise the identifier variable with the corresponding identifier
    //2.instantiate view controller with that identifier
    //3.present the view controller
    func tableView(tableView: UITableView, didSelectRowAtIndexPath indexPath: NSIndexPath) {
        tableView.deselectRowAtIndexPath(indexPath, animated: true)
        var identifier = ""
        switch indexPath.row{
        case 0:
            identifier = "About Me"
        case 1:
            identifier = "Contact Information"
        case 2:
            identifier = "Medication"
        case 3:
            identifier = "Allergy"
        case 4:
            identifier = "Symptom"
        case 5:
            identifier = "Procedure"
        case 6:
            identifier = "Immunization"
        case 7:
            identifier = "Health Files"
        case 8:
            identifier = "Payment History"
        default:
            identifier = ""
        }
        if(identifier != ""){
            
            var destViewController = self.storyboard?.instantiateViewControllerWithIdentifier(identifier) as! UIViewController
            self.navigationController?.pushViewController(destViewController, animated: true)
            
        }
    }
    
    //show the menu on pressing the button
    @IBAction func showMenu(sender: AnyObject) {
        self.view.endEditing(true)
        self.frostedViewController.view.endEditing(true)
        self.frostedViewController.presentMenuViewController()
    }

}
