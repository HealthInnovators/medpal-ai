//
//  AboutUsViewController.swift
//  Healthouts
//
//  Created by Y.Bharath Kumar Reddy on 01/06/15.
//  Copyright (c) 2015 Y.Bharath Kumar Reddy. All rights reserved.
//

import UIKit

class AboutUsViewController: UIViewController {

    //outlets from storyboard
    @IBOutlet weak var aboutUsLabel: UILabel!
    @IBOutlet weak var scrollView: UIScrollView!
    @IBOutlet weak var navBarView: UIView!
    @IBOutlet weak var contentView: UIView!
    
    var aboutUs = "We belive in connecting people to the best medical experts so that anyone around the world has the access to take better healthcare decisions effortlessly. Healthouts is a healthcare company that partners with the best medical experts in the world to offer instant health chats advice online for anyone.\nOur technology enables medical experts to reach millions of clients around the world.We envision a future where everyone has access to a better health that has so far been with infrastructure challenges.We aim to empower people with health."
    override func viewDidLoad() {
        super.viewDidLoad()
        self.view.addGestureRecognizer(UIPanGestureRecognizer(target: self, action: "panGestureRecognized:"))
        
        //set the navbar view properties
        navBarView.layer.shadowColor = UIColor.blackColor().CGColor
        navBarView.layer.shadowOffset = CGSizeMake(0.5, 0.5)
        navBarView.layer.shadowRadius = 3.0
        navBarView.layer.shadowOpacity = 1.0
        
        //set the constraints for the content view
        var leftConstraint = NSLayoutConstraint(item: self.contentView, attribute: NSLayoutAttribute.Leading, relatedBy: NSLayoutRelation.Equal, toItem: self.view, attribute: NSLayoutAttribute.Left, multiplier: 1, constant: 0)
        self.view.addConstraint(leftConstraint)
        
        var rightConstraint = NSLayoutConstraint(item: self.contentView, attribute: NSLayoutAttribute.Trailing, relatedBy: NSLayoutRelation.Equal, toItem: self.view, attribute: NSLayoutAttribute.Right, multiplier: 1, constant: 0)
        self.view.addConstraint(rightConstraint)
        
        aboutUsLabel.text  = aboutUs
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    //show menu on pressing the menu button
    @IBAction func showMenu(sender: AnyObject) {
        self.view.endEditing(true)
        self.frostedViewController.view.endEditing(true)
        self.frostedViewController.presentMenuViewController()
    }
    
    func panGestureRecognized(sender:UIPanGestureRecognizer){
        var vel = sender.velocityInView(self.view)
        if(vel.x > 0){
        self.view.endEditing(true)
        self.frostedViewController.view.endEditing(true)
        self.frostedViewController.presentMenuViewController()
        }
    }
  
    @IBAction func openhealthouts(sender: AnyObject) {
    }
    
    @IBAction func sendMail(sender: AnyObject) {
    }
    
    @IBAction func callMobile(sender: AnyObject) {
    }
}
