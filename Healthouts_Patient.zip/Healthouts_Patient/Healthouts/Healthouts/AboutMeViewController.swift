//
//  AboutMeViewController.swift
//  Healthouts
//
//  Created by Y.Bharath Kumar Reddy on 15/07/15.
//  Copyright (c) 2015 Y.Bharath Kumar Reddy. All rights reserved.
//

import UIKit

class AboutMeViewController: UIViewController,UITextFieldDelegate,UITextViewDelegate,UIPickerViewDataSource,UIPickerViewDelegate,UIImagePickerControllerDelegate,UINavigationControllerDelegate {
    
    //outlets from the storyboard
    @IBOutlet weak var navBarView: UIView!
    @IBOutlet weak var imgSelectionButton: UIButton!
    @IBOutlet weak var userImageView: UIImageView!
    @IBOutlet weak var contentView: UIView!
    @IBOutlet weak var scrollView: UIScrollView!
    @IBOutlet weak var nameTextField: UITextField!
    @IBOutlet weak var dobTextField: UITextField!
    @IBOutlet weak var cityTextField: UITextField!
    @IBOutlet weak var zipTextField: UITextField!
    @IBOutlet weak var aboutTextView: UITextView!
    @IBOutlet weak var genderTextField: UITextField!
    @IBOutlet weak var bloodGroupTextField: UITextField!
    
    //required variables
    var datePickerView:UIDatePicker!
    var imagePicker = UIImagePickerController()
    var bloodGroups = ["O+","A+","B+","AB+","O-","A-","B-","AB-"]
    var bloodGroupPicker:UIPickerView!
    var genderView:UIView!
    var selectedTextView:UITextView!
    var selectedTextField:UITextField!
    var actInd : UIActivityIndicatorView = UIActivityIndicatorView(frame: CGRectMake(0,0, 50, 50)) as UIActivityIndicatorView
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        //set the delegates
        nameTextField.delegate = self
        dobTextField.delegate = self
        cityTextField.delegate = self
        zipTextField.delegate = self
        aboutTextView.delegate = self
        genderTextField.delegate = self
        bloodGroupTextField.delegate = self
        
        //create a gender view
        //and add a male and female button to the view
        genderView = UIView(frame: CGRectMake(0, 0, self.view.frame.size.width, 100))
        var maleButton = UIButton(frame: CGRectMake(self.view.frame.width/2 - 45, 10, 90, 30))
        maleButton.setTitle("Male", forState: UIControlState.Normal)
        maleButton.backgroundColor = UIColor.blackColor()
        maleButton.setTitleColor(UIColor.whiteColor(), forState: UIControlState.Normal)
        maleButton.layer.cornerRadius = 5
        maleButton.addTarget(self, action: "maleSelected", forControlEvents: UIControlEvents.TouchUpInside)
        genderView.addSubview(maleButton)
        
        var femaleButton = UIButton(frame: CGRectMake(self.view.frame.width/2 - 45, 60, 90, 30))
        femaleButton.setTitle("Female", forState: UIControlState.Normal)
        femaleButton.backgroundColor = UIColor.blackColor()
        femaleButton.setTitleColor(UIColor.whiteColor(), forState: UIControlState.Normal)
        femaleButton.layer.cornerRadius = 5
        femaleButton.addTarget(self, action: "femaleSelected", forControlEvents: UIControlEvents.TouchUpInside)
        genderView.addSubview(femaleButton)
        
        //make the gender view the inputView of the genderTextField
        genderTextField.inputView = genderView
        
        //create a UIPicker for the blood groups
        //and add it as the inputView of the bloodGroupTextField
        bloodGroupPicker = UIPickerView(frame: CGRectMake(0, 0, self.view.frame.size.width, 100))
        bloodGroupPicker.delegate = self
        bloodGroupTextField.inputView = bloodGroupPicker
        
        //make a view with a done button 
        //and add it as the input accessory view of the bloodGroupTextField
        var view = UIView(frame: CGRectMake(0, 0, self.view.frame.size.width, 40))
        var doneButton =  UIButton(frame: CGRectMake(0, 0, self.view.frame.size.width, 40))
        doneButton.setTitle("Done", forState: UIControlState.Normal)
        doneButton.backgroundColor = UIColor.greenColor()
        doneButton.addTarget(self, action: "doneSelected", forControlEvents: UIControlEvents.TouchUpInside)
        view.addSubview(doneButton)
        
        bloodGroupTextField.inputAccessoryView = view
        
        //set the properties to make the user image circular
        userImageView.layer.cornerRadius = 65
        userImageView.layer.masksToBounds = true
        
        //set the navigationbar view properties
        navBarView.layer.shadowColor = UIColor.blackColor().CGColor
        navBarView.layer.shadowOffset = CGSizeMake(0.5, 0.5)
        navBarView.layer.shadowRadius = 3.0
        navBarView.layer.shadowOpacity = 1.0
        
        //set the constraints of the scroll view
        var leftConstraint = NSLayoutConstraint(item: self.contentView, attribute: NSLayoutAttribute.Leading, relatedBy: NSLayoutRelation.Equal, toItem: self.view, attribute: NSLayoutAttribute.Left, multiplier: 1, constant: 0)
        self.view.addConstraint(leftConstraint)
        
        var rightConstraint = NSLayoutConstraint(item: self.contentView, attribute: NSLayoutAttribute.Trailing, relatedBy: NSLayoutRelation.Equal, toItem: self.view, attribute: NSLayoutAttribute.Right, multiplier: 1, constant: 0)
        self.view.addConstraint(rightConstraint)
        
        //add the keyboard notifications
        NSNotificationCenter.defaultCenter().addObserver(self, selector: "keyboardWillBeShown:", name: UIKeyboardWillShowNotification, object: nil)
        NSNotificationCenter.defaultCenter().addObserver(self, selector: "keyboardWillBeHidden:", name: UIKeyboardWillHideNotification, object: nil)
        
        
        //set the input view of date text field
        datePickerView = UIDatePicker(frame: CGRectMake(0, 0, self.view.frame.size.width, 100))
        datePickerView.backgroundColor = UIColor.whiteColor()
        datePickerView.datePickerMode = UIDatePickerMode.Date
        dobTextField.inputView = datePickerView
        dobTextField.delegate = self
        
        view = UIView(frame: CGRectMake(0, 0, self.view.frame.size.width, 40))
        var done =  UIButton(frame: CGRectMake(0, 0, self.view.frame.size.width, 40))
        doneButton.setTitle("Done", forState: UIControlState.Normal)
        doneButton.backgroundColor = UIColor.greenColor()
        doneButton.addTarget(self, action: "dateSelected", forControlEvents: UIControlEvents.TouchUpInside)
        view.addSubview(doneButton)
        
        dobTextField.inputAccessoryView = view
        
        
        self.contentView.backgroundColor = UIColor.clearColor()
        imgSelectionButton.setTitle("", forState: UIControlState.Normal)
        
        getData()
        
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    //get the data and populate the fields
    func getData(){
        //start the activity indicator
        actInd.center = CGPointMake(self.view.center.x, self.view.center.y - 64)
        actInd.hidesWhenStopped = true
        actInd.activityIndicatorViewStyle = UIActivityIndicatorViewStyle.White
        actInd.backgroundColor = UIColor.blackColor()
        actInd.layer.cornerRadius = 5
        view.addSubview(actInd)
        actInd.startAnimating()
        
        //prepare the parameters to be sent with the url
        var userInfo = NSUserDefaults.standardUserDefaults().objectForKey("userInfo") as? NSDictionary
        var customerId = userInfo?.objectForKey("id") as! Int
        var customerEmail = userInfo?.objectForKey("email") as! String
        
        //call the SRWebClient with the parameters and the url
        SRWebClient.POST("http://healthouts.com/appCustomerBasicDetails?")
            .data(["CId":customerId,"CEmail":customerEmail])
            .send({ (response:AnyObject!, status:Int) -> Void in
                
                self.actInd.stopAnimating()
                var err: NSError?
                var data = (response as! String).dataUsingEncoding(NSUTF8StringEncoding, allowLossyConversion: true)
                
                if let jsonResult = NSJSONSerialization.JSONObjectWithData(data!, options: NSJSONReadingOptions.MutableContainers, error: &err) as? NSMutableDictionary {
                    dispatch_async(dispatch_get_main_queue(), {
                        
                        self.nameTextField.text = jsonResult.objectForKey("name") as? String
                        self.dobTextField.text = jsonResult.objectForKey("dob") as? String
                        self.cityTextField.text = jsonResult.objectForKey("location") as? String
                        self.zipTextField.text = jsonResult.objectForKey("zipcode") as? String
                        self.genderTextField.text = jsonResult.objectForKey("gender") as? String
                        self.bloodGroupTextField.text = jsonResult.objectForKey("bloodGroup") as? String
                        self.aboutTextView.text = jsonResult.objectForKey("info") as? String
                        var imgPath = jsonResult.objectForKey("imagePath") as? String
                        if imgPath != nil{
                            self.setImage(imgPath!)
                        }
                        
                    })
                }else{
                        self.addAlert(err!.localizedDescription)
                }
                
                
            }, failure: { (error) -> Void in
                dispatch_async(dispatch_get_main_queue(), {
                    
                    self.actInd.stopAnimating()
                    self.addAlert(error.localizedDescription)
                        
                        
                })
                    
            })
    }
    
    //function to add alert
    func addAlert(message:String){
        var alert = UIAlertController(title: "Alert", message: message, preferredStyle: UIAlertControllerStyle.Alert)
        alert.addAction(UIAlertAction(title: "ok", style: UIAlertActionStyle.Default, handler: nil))
        self.presentViewController(alert, animated: true, completion: nil)
    }

    //use the SDWebImageDownloader to set the user image
    func setImage(imgPath:String){
        var imagePath = "http://healthouts.com/img/" + imgPath.stringByReplacingOccurrencesOfString(" ", withString: "%20") as String
        var imgUrl = NSURL(string: imagePath)
        
        SDWebImageDownloader.sharedDownloader().downloadImageWithURL(imgUrl, options: nil, progress: { (receivedSize:Int, expectedSize:Int) -> Void in
                
                }) { (image, data, error, finished) -> Void in
                    if(error != nil){
                        self.userImageView.image = UIImage(named: "dummydp")
                    }else{
                        self.userImageView.image = image
                    }
            }
        
    }


    //open the UIImagePickerController once the image is pressed
    @IBAction func selectImagePressed(sender: AnyObject) {
        
        self.imagePicker.sourceType = UIImagePickerControllerSourceType.SavedPhotosAlbum;
        self.imagePicker.allowsEditing = false
        self.imagePicker.delegate = self
        self.presentViewController(self.imagePicker, animated: true) { () -> Void in
            
        }
        
    }
    
    
    //call the save service url
    @IBAction func saveButtonPressed(sender: AnyObject) {
        //resign the first responders
        if(selectedTextField != nil){
            selectedTextField.resignFirstResponder()
        }
        if(selectedTextView != nil){
            selectedTextView.resignFirstResponder()
        }
        
        //start the activity indicator
        actInd.center = CGPointMake(self.view.center.x, self.view.center.y - 64)
        actInd.hidesWhenStopped = true
        actInd.activityIndicatorViewStyle = UIActivityIndicatorViewStyle.White
        actInd.backgroundColor = UIColor.blackColor()
        actInd.layer.cornerRadius = 5
        view.addSubview(actInd)
        actInd.startAnimating()
        
        //prepare the parameters to be sent with the url
        var userInfo = NSUserDefaults.standardUserDefaults().objectForKey("userInfo")?.mutableCopy()
        var customerId = userInfo?.objectForKey("id") as! Int
        var customerEmail = userInfo?.objectForKey("email") as! String
        
        var parameters = [:]
        if(userImageView.image == UIImage(named: "dummydp")){
            parameters = ["CId":customerId,"CEmail":customerEmail,"cName":nameTextField.text,"gender":genderTextField.text,"dob":dobTextField.text,"city":cityTextField.text,"zipcode":zipTextField.text,"info":aboutTextView.text,"bloodGroup":bloodGroupTextField.text]
        }else{
            var imageData = NetData(jpegImage: userImageView.image!, compressionQuanlity: 1.0, filename: "myFile")
            parameters = ["CId":customerId,"CEmail":customerEmail,"cName":nameTextField.text,"gender":genderTextField.text,"dob":dobTextField.text,"city":cityTextField.text,"zipcode":zipTextField.text,"info":aboutTextView.text,"bloodGroup":bloodGroupTextField.text,"profilepImage":imageData]
        }
        
        //Use Net to send the image and the data
        let net = Net()
        net.POST("http://healthouts.com/appUpdateCustomerAboutme?", params: parameters, successHandler: { (response) -> () in
            dispatch_async(dispatch_get_main_queue(), {
                self.actInd.stopAnimating()
                let result = response.jsonDict(error: nil)
                if(result != nil){
                    if let status = result?.objectForKey("status") as? String{
                        if status == "1"{
                            if let imgPath = result?.objectForKey("profileImgPath") as? String{
                                userInfo?.setValue(imgPath, forKey: "image")
                            }
                            if let name = result?.objectForKey("cNmae") as? String{
                                userInfo?.setValue(name, forKey: "name")
                            }
                            NSUserDefaults.standardUserDefaults().setObject(userInfo, forKey: "userInfo")
                            self.addAlert("Details updated successfully")
                        }else{
                            self.addAlert("Oops!! Details could not be updated")
                        }
                    }
                
                }else{
                    self.addAlert("Oops!! Details could not be updated")
                }
            })
        }) { (error) -> () in
            dispatch_async(dispatch_get_main_queue(), {
                self.actInd.stopAnimating()
                self.addAlert(error.localizedDescription)
            })
        }
        
    }
    
    //textfield and textview delegate methods
    func textFieldShouldBeginEditing(textField: UITextField) -> Bool {
        self.selectedTextField = textField
        return true
    }
    
    func textViewShouldBeginEditing(textView: UITextView) -> Bool {
        self.selectedTextView = textView
        return true
    }
    
    func textFieldShouldReturn(textField: UITextField) -> Bool {
        textField.resignFirstResponder()
        return true
    }
    
    //add the keyboard notifications
    func keyboardWillBeHidden(notification:NSNotification){
        var contentInsets = UIEdgeInsetsZero
        self.scrollView.contentInset = contentInsets
        self.scrollView.scrollIndicatorInsets = contentInsets
    }
    
    func keyboardWillBeShown(notification:NSNotification){
        
        if let userInfo = notification.userInfo {
            if let keyboardSize = (userInfo[UIKeyboardFrameBeginUserInfoKey] as? NSValue)?.CGRectValue() {
                //self.bottomConstraint.constant = -keyboardSize.height
                var contentInsets = UIEdgeInsetsMake(0, 0, keyboardSize.height, 0)
                self.scrollView.contentInset = contentInsets
                self.scrollView.scrollIndicatorInsets = contentInsets
                var rect = self.contentView.frame
                rect.size.height -= keyboardSize.height
                if (!aboutTextView.isFirstResponder() && !CGRectContainsPoint(rect, self.selectedTextField.frame.origin)) {
                    var scrollPoint = CGPointMake(0.0, self.selectedTextField.frame.origin.y - (keyboardSize.height - self.selectedTextField.frame.size.height))
                    self.scrollView.setContentOffset(scrollPoint, animated: false)
                }
                if(aboutTextView.isFirstResponder() && !CGRectContainsPoint(rect, self.aboutTextView.frame.origin)){
                    var scrollPoint = CGPointMake(0.0, self.aboutTextView.frame.origin.y - (keyboardSize.height - self.aboutTextView.frame.size.height))
                    self.scrollView.setContentOffset(scrollPoint, animated: false)
                }
            }
        }
    }
    
    
    //bloog group picker view delegate and data scource methods
    func pickerView(pickerView: UIPickerView, numberOfRowsInComponent component: Int) -> Int {
        return bloodGroups.count
    }
    
    func pickerView(pickerView: UIPickerView, titleForRow row: Int, forComponent component: Int) -> String! {
        return bloodGroups[row]
    }
    
    func numberOfComponentsInPickerView(pickerView: UIPickerView) -> Int{
        return 1
    }
    
    func pickerView(pickerView: UIPickerView, didSelectRow row: Int, inComponent component: Int) {
        self.bloodGroupTextField.text = bloodGroups[row]
    }
    
    //handle the buttons in the blood group selection
    func doneSelected(){
        bloodGroupTextField.resignFirstResponder()
    }
    
    //handle the buttons in the gender selection
    func maleSelected(){
        self.genderTextField.text = "Male"
        genderTextField.resignFirstResponder()
    }
    
    func femaleSelected(){
        self.genderTextField.text = "Female"
        genderTextField.resignFirstResponder()
    }
    
    //handle back button clicks
    @IBAction func backButtonPressed(sender: AnyObject) {
        self.navigationController?.popViewControllerAnimated(true)
    }
    
    //image picker controller delegate methods
    func imagePickerController(picker: UIImagePickerController, didFinishPickingImage image: UIImage!, editingInfo: [NSObject : AnyObject]!) {
        
        self.dismissViewControllerAnimated(true, completion: { () -> Void in
            self.userImageView.image = image
        })
        
    }
    
    func imagePickerControllerDidCancel(picker: UIImagePickerController) {
        self.dismissViewControllerAnimated(true, completion: { () -> Void in
            
        })
    }
    
    //handle the buttons in the appointment date selection
    func dateSelected(){
        dobTextField.resignFirstResponder()
        var dateFormatter = NSDateFormatter()
        dateFormatter.dateFormat = "yyyy-MM-dd"
        var dateString = dateFormatter.stringFromDate(datePickerView.date)
        dobTextField.text = dateString
    }
}
