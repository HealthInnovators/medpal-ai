//
//  MyPaidQuestionAnsweredTableViewCell.swift
//  Healthouts
//
//  Created by Y.Bharath Kumar Reddy on 11/06/15.
//  Copyright (c) 2015 Y.Bharath Kumar Reddy. All rights reserved.
//

import UIKit

protocol PaidQuestionAnsweredCellDelegate{
    func showAttachment(attachmentName:String)
    func sendReview(button:UIButton)
}

class MyPaidQuestionAnsweredTableViewCell: UITableViewCell {

    @IBOutlet weak var sendReviewButton: UIButton!
    @IBOutlet weak var userImageView: UIImageView!
    @IBOutlet weak var userNameLabel: UILabel!
    @IBOutlet weak var questionSubjectLabel: UILabel!
    @IBOutlet weak var questionBodyLabel: UILabel!
    @IBOutlet weak var attachmentsButton: UIButton!
    
    @IBOutlet weak var containerView: UIView!
    @IBOutlet weak var doctorImageView: UIImageView!
    @IBOutlet weak var doctorNameLabel: UILabel!
    @IBOutlet weak var answerSubjectLabel: UILabel!
    @IBOutlet weak var answerBodyLabel: UILabel!
    
    
    var delegate:PaidQuestionAnsweredCellDelegate?
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }

    @IBAction func attachmentButtonPressed(sender: AnyObject) {
        self.delegate?.showAttachment((sender as! UIButton).titleForState(UIControlState.Normal)!)
    }
    
    @IBAction func sendReviewPressed(sender: AnyObject) {
        
        self.delegate?.sendReview(sender as! UIButton)
    }
    
}
