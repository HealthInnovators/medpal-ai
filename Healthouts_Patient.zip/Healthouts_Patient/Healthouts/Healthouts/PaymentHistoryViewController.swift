//
//  PaymentHistoryViewController.swift
//  Healthouts
//
//  Created by Y.Bharath Kumar Reddy on 15/07/15.
//  Copyright (c) 2015 Y.Bharath Kumar Reddy. All rights reserved.
//

import UIKit

class PaymentHistoryViewController: UIViewController,UITableViewDelegate,UITableViewDataSource {

    //outlets from the tableview
    @IBOutlet weak var tableView: UITableView!
    
    //required variables
    var tableData = []
    var actInd : UIActivityIndicatorView = UIActivityIndicatorView(frame: CGRectMake(0,0, 50, 50)) as UIActivityIndicatorView
    var myMutableString = NSMutableAttributedString()
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        //register the custom cell to the tableview
        var nib1 = UINib(nibName: "PaymentHistoryTableViewCell", bundle: nil)
        tableView.registerNib(nib1, forCellReuseIdentifier: "PaymentHistoryCell")
        
        //call the getData function
        getData()
        
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    

    //function that calls the payment services url
    func getData(){
        
        //start the activity indicator
        actInd.center = CGPointMake(self.view.center.x, self.view.center.y - 64)
        actInd.hidesWhenStopped = true
        actInd.activityIndicatorViewStyle = UIActivityIndicatorViewStyle.White
        actInd.backgroundColor = UIColor.blackColor()
        actInd.layer.cornerRadius = 5
        view.addSubview(actInd)
        actInd.startAnimating()
        
        //prepare the parameters to be sent with the url
        var userInfo = NSUserDefaults.standardUserDefaults().objectForKey("userInfo") as? NSDictionary
        var customerId = userInfo?.objectForKey("id") as! Int
        var customerEmail = userInfo?.objectForKey("email") as! String
        
        //call the SRWebClient with the url and parameters
        SRWebClient.POST("http://healthouts.com/appYourPayHistory?")
            .data(["CId":customerId,"CEmail":customerEmail])
            .send({ (response:AnyObject!, status:Int) -> Void in
                
                self.actInd.stopAnimating()
                var err: NSError?
                var data = (response as! String).dataUsingEncoding(NSUTF8StringEncoding, allowLossyConversion: true)
                
                if let jsonResult = NSJSONSerialization.JSONObjectWithData(data!, options: NSJSONReadingOptions.MutableContainers, error: &err) as? NSMutableArray {
                    dispatch_async(dispatch_get_main_queue(), {
                        
                        self.tableData = jsonResult
                        self.tableView.hidden = false
                        self.tableView.reloadData()
                        
                    })
                    
                }else{
                    self.addAlert(err!.localizedDescription)
                }
                
            }, failure: { (error) -> Void in
                dispatch_async(dispatch_get_main_queue(), {
                        
                    self.actInd.stopAnimating()
                    self.addAlert(error.localizedDescription)
                        
                })
            })
    }
    
    //number of rows in the tableview
    func tableView(tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return tableData.count
    }
    
    //populate the tableview
    func tableView(tableView: UITableView, cellForRowAtIndexPath indexPath: NSIndexPath) -> UITableViewCell {
        
        var identifier = "PaymentHistoryCell"
        var cell  = tableView.dequeueReusableCellWithIdentifier(identifier) as! PaymentHistoryTableViewCell
        
        var questionData:NSDictionary = tableData[indexPath.row] as! NSDictionary
        
        cell.selectionStyle = UITableViewCellSelectionStyle.None
        cell.containerView.layer.cornerRadius = 10
        
        //initialise the labels in the cell
        var text = "Transaction Id : " +  (questionData.objectForKey("payref") as! String)
        myMutableString = NSMutableAttributedString(string: text, attributes: [NSFontAttributeName : UIFont(name: "HelveticaNeue", size: 15)!])
        myMutableString.addAttribute(NSFontAttributeName, value: UIFont(name: "HelveticaNeue-Bold", size: 15)!, range: NSRange(location: 0, length: 16))
        cell.idLabel.attributedText = myMutableString
        
        
        text = "Name : " +  (questionData.objectForKey("doctoName") as! String)
        myMutableString = NSMutableAttributedString(string: text, attributes: [NSFontAttributeName : UIFont(name: "HelveticaNeue", size: 15)!])
        myMutableString.addAttribute(NSFontAttributeName, value: UIFont(name: "HelveticaNeue-Bold", size: 15)!, range: NSRange(location: 0, length: 5))
        cell.nameLabel.attributedText = myMutableString
        
        
        var fee = questionData.objectForKey("consultationFee") as! CGFloat
        var feestring = "\(fee)"
        var currency = questionData.objectForKey("currencyCode") as! String
        text = "Fee : " + feestring + " " + currency
        myMutableString = NSMutableAttributedString(string: text, attributes: [NSFontAttributeName : UIFont(name: "HelveticaNeue", size: 15)!])
        myMutableString.addAttribute(NSFontAttributeName, value: UIFont(name: "HelveticaNeue-Bold", size: 15)!, range: NSRange(location: 0, length: 4))
        cell.feeLabel.attributedText = myMutableString
        
        
        text = "Date : " +  (questionData.objectForKey("payDate") as! String)
        myMutableString = NSMutableAttributedString(string: text, attributes: [NSFontAttributeName : UIFont(name: "HelveticaNeue", size: 15)!])
        myMutableString.addAttribute(NSFontAttributeName, value: UIFont(name: "HelveticaNeue-Bold", size: 15)!, range: NSRange(location: 0, length: 5))
        cell.dateLabel.attributedText = myMutableString
        
        
        if let type = questionData.objectForKey("consultationType") as? String{
            text = "Type : " +  type
            myMutableString = NSMutableAttributedString(string: text, attributes: [NSFontAttributeName : UIFont(name: "HelveticaNeue", size: 15)!])
            myMutableString.addAttribute(NSFontAttributeName, value: UIFont(name: "HelveticaNeue-Bold", size: 15)!, range: NSRange(location: 0, length: 5))
            cell.typeLabel.attributedText = myMutableString
        }
        
        return cell
    }
    
    //dismiss the view controller
    @IBAction func backButtonPressed(sender: AnyObject) {
        self.navigationController?.popViewControllerAnimated(true)
    }
    
    //function to add alert
    func addAlert(message:String){
        var alert = UIAlertController(title: "Alert", message: message, preferredStyle: UIAlertControllerStyle.Alert)
        alert.addAction(UIAlertAction(title: "ok", style: UIAlertActionStyle.Default, handler: nil))
        self.presentViewController(alert, animated: true, completion: nil)
    }
    

}
