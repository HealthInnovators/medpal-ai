//
//  DoctorsListViewController.swift
//  Healthouts
//
//  Created by Y.Bharath Kumar Reddy on 27/05/15.
//  Copyright (c) 2015 Y.Bharath Kumar Reddy. All rights reserved.
//

import UIKit

class DoctorsListViewController: UIViewController,UITableViewDelegate,UITableViewDataSource,SAMenuDropDownDelegate {

    //outlets from the storyboard
    @IBOutlet weak var navBarView: UIView!
    @IBOutlet weak var tableView: UITableView!
    @IBOutlet weak var specialityLabel: UILabel!
    @IBOutlet weak var locationButton: UIButton!
    @IBOutlet weak var priceButton: UIButton!

    //required variables
    var cities = NSMutableArray()
    var prices = NSMutableArray()
    var cityNames = ["All","Hyderabad","Chennai","Mumbai"]
    var priceValues = ["Price Heigh to Low","Price Low to Heigh","popularity","Price Free"]
    var selectedCategory:String!
    var selectedDoctorId = ""
    var urlString:String!
    var tableData:NSArray! = []
    var imageCache = [String:UIImage]()
    var actInd : UIActivityIndicatorView = UIActivityIndicatorView(frame: CGRectMake(0,0, 50, 50)) as UIActivityIndicatorView
    var selectedDoctorName = ""
    var locationMenuDropDown:SAMenuDropDown!
    var priceMenuDropDown:SAMenuDropDown!
    var isNew = true
    var selectedIndex:NSIndexPath = NSIndexPath()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        //initialise the location drop down menu with the source button,items etc
        locationMenuDropDown = SAMenuDropDown(source: locationButton, itemNames: cityNames, itemImagesName: nil, itemSubtitles: nil)
        locationMenuDropDown.delegate = self
        
        //initialise the price dropdown menu
        priceMenuDropDown = SAMenuDropDown(source: priceButton, itemNames: priceValues, itemImagesName: nil, itemSubtitles: nil)
        priceMenuDropDown.delegate = self
        
        //set the navigation bar properties like shadow etc
        navBarView.layer.shadowColor = UIColor.blackColor().CGColor
        navBarView.layer.shadowOffset = CGSizeMake(0.5, 0.5)
        navBarView.layer.shadowRadius = 3.0
        navBarView.layer.shadowOpacity = 1.0
        
        self.tabBarController?.tabBar.hidden = true
       
        //register the custom DoctorsTableViewCell
        var nib = UINib(nibName: "DoctorsTableViewCell", bundle: nil)
        tableView.registerNib(nib, forCellReuseIdentifier: "DoctorCell")
    
        specialityLabel.text = selectedCategory
        if(tableData.count == 0){
            tableView.hidden = true
        }
        
        //run the activity indicator till you get the data
        actInd.center = self.view.center
        actInd.hidesWhenStopped = true
        actInd.activityIndicatorViewStyle = UIActivityIndicatorViewStyle.White
        actInd.backgroundColor = UIColor.blackColor()
        actInd.layer.cornerRadius = 5
        view.addSubview(actInd)
        actInd.startAnimating()
        
        getData()
        
    }


    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    //function to get the data
    func getData(){
        
        //prepare the parameters
        var selectedCity = locationButton.titleLabel?.text!
        var selectedPrice = priceButton.titleLabel?.text!
        
        //Call the SRWebclient with the url and parameters
        SRWebClient.POST("http://healthouts.com/appDocFilterList?")
            .data(["sp" : selectedCategory,"sortby" : selectedPrice!,"location" : selectedCity!])
            .send({ (response, status) -> Void in
                
                self.actInd.stopAnimating()
                var err: NSError?
                var data = (response as! String).dataUsingEncoding(NSUTF8StringEncoding, allowLossyConversion: true)
                
                if let jsonResult = NSJSONSerialization.JSONObjectWithData(data!, options: NSJSONReadingOptions.MutableContainers, error: &err) as? NSArray {
                    dispatch_async(dispatch_get_main_queue(), {
                        
                        self.actInd.stopAnimating()
                        if(!self.isNew){
                            var text = "Filters Applied"
                            self.showTextOverlay(text)
                            var timer = NSTimer.scheduledTimerWithTimeInterval(1, target: self, selector: Selector("removeOverlay"), userInfo: nil, repeats: false)
                        }
                        self.tableData = jsonResult
                        
                        if(self.tableData.count != 0){
                            
                            self.tableView.hidden = false
                            self.tableView!.reloadData()
                            self.isNew = false
                            
                        }else{
                            
                            self.tableView.reloadData()
                            self.tableView.hidden = true
                            if(self.isNew){
                                self.isNew = false
                                var alert = UIAlertController(title: "information", message: "Healthouts don't have any doctors for this kind of speciality, kindly explore later.", preferredStyle: UIAlertControllerStyle.Alert)
                                alert.addAction(UIAlertAction(title: "ok", style: UIAlertActionStyle.Default, handler: nil))
                                self.presentViewController(alert, animated: true, completion: nil)
                                
                            }
                        }
                       
                        
                    })
                }else{
                    self.addAlert(err!.localizedDescription)
                }
            }, failure: { (error) -> Void in
                self.actInd.stopAnimating()
                self.addAlert(error.localizedDescription)
            })

    }

    func addAlert(message:String){
        var alert = UIAlertController(title: "Alert", message: message, preferredStyle: UIAlertControllerStyle.Alert)
        alert.addAction(UIAlertAction(title: "ok", style: UIAlertActionStyle.Default, handler: nil))
        self.presentViewController(alert, animated: true, completion: nil)
    }
    
   
    //populate the tableView
    func tableView(tableView: UITableView, cellForRowAtIndexPath indexPath: NSIndexPath) -> UITableViewCell {
        var identifier = "DoctorCell"
        var cell:DoctorsTableViewCell  = tableView.dequeueReusableCellWithIdentifier(identifier) as! DoctorsTableViewCell
        var doctorInfo:NSDictionary = tableData[indexPath.row] as! NSDictionary
        //cell.selectionStyle = UITableViewCellSelectionStyle.None
        cell.doctorNameLabel.text = doctorInfo.objectForKey("dName") as? String
        cell.doctorLocationLabel.text = doctorInfo.objectForKey("location") as? String
        cell.doctorSpecialityLabel.text = doctorInfo.objectForKey("speciality") as? String
        cell.doctorImageView.layer.cornerRadius = 33
        cell.doctorImageView.layer.masksToBounds = true
        
        cell.doctorImageView.image = UIImage(named: "doctoricon")
        if let image = doctorInfo.objectForKey("imgPath") as? String{
            var imgPath = image.stringByReplacingOccurrencesOfString(" ", withString: "%20") as String
            var imgUrl = NSURL(string: imgPath)
            if let img = imageCache[imgPath]{
                cell.doctorImageView.image = img
            }else{
                SDWebImageDownloader.sharedDownloader().downloadImageWithURL(imgUrl, options: nil, progress: { (receivedSize:Int, expectedSize:Int) -> Void in
                    
                    }) { (image, data, error, finished) -> Void in
                        if(error != nil){
                            cell.doctorImageView.image = UIImage(named: "doctoricon")
                        }else{
                            
                            cell.doctorImageView.image = image
                            self.imageCache[imgPath] = image
                        }
                }
            }
        }else{
            cell.doctorImageView.image = UIImage(named: "doctoricon")
        }
        
        
        return cell
    }
    
    //number of rows in the tableView
    func tableView(tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return tableData.count
    }
    
    //height of each row
    func tableView(tableView: UITableView, heightForRowAtIndexPath indexPath: NSIndexPath) -> CGFloat {
        return 80
    }
    
    //handle the selections in the tableview
    func tableView(tableView: UITableView, didSelectRowAtIndexPath indexPath: NSIndexPath) {
        var selectedDoctor = tableData[indexPath.row] as! NSDictionary
        selectedDoctorId = (selectedDoctor["doctorId"]?.stringValue)!
        selectedDoctorName = selectedDoctor["dName"] as! String
        self.tableView.deselectRowAtIndexPath(indexPath, animated: false)
        self.performSegueWithIdentifier("DoctorInfo", sender: self)
    }

    //handle back button press
    @IBAction func backButtonPressed(sender: AnyObject) {
        self.navigationController?.popViewControllerAnimated(true)
    }
    
    //pass the data before performing the segue
    override func prepareForSegue(segue: UIStoryboardSegue, sender: AnyObject?) {
        var destViewController = segue.destinationViewController as! DoctorInfoViewController
        destViewController.selectedDoctorId = self.selectedDoctorId
        destViewController.doctorName = self.selectedDoctorName
    }

    //filter data function
    @IBAction func filterData(sender: AnyObject) {
        getData()
    }
    
    //handle the location drop down opening
    @IBAction func showLocationDropdown(sender: AnyObject) {
        if(!priceMenuDropDown.isMenuExpanded){
            locationMenuDropDown.showSADropDownMenuWithAnimation(kSAMenuDropAnimationDirectionBottom)
            self.tableView.userInteractionEnabled = false
        }else{
            priceMenuDropDown.hideSADropDownMenu()
            self.tableView.userInteractionEnabled = true
        }
    }
    
   //handle the price drop down opening
    @IBAction func showPriceDropdown(sender: AnyObject) {
        if(!locationMenuDropDown.isMenuExpanded){
            priceMenuDropDown.showSADropDownMenuWithAnimation(kSAMenuDropAnimationDirectionBottom)
            self.tableView.userInteractionEnabled = false
        }else{
            locationMenuDropDown.hideSADropDownMenu()
            self.tableView.userInteractionEnabled = true
        }
    }
    
    //handle touches to dismiss the opened dropdowns
    override func touchesBegan(touches: Set<NSObject>, withEvent event: UIEvent) {
        if(locationMenuDropDown.isMenuExpanded){
            locationMenuDropDown.hideSADropDownMenu()
        }else if(priceMenuDropDown.isMenuExpanded){
            priceMenuDropDown.hideSADropDownMenu()
        }
        self.tableView.userInteractionEnabled = true
    }
    
    func saDropMenu(menuSender: SAMenuDropDown!, didClickedAtIndex buttonIndex: Int) {
        self.tableView.userInteractionEnabled = true
    }
    
    func removeOverlay(){
        self.removeAllOverlays()
    }
    
    override func viewWillAppear(animated: Bool) {
        super.viewWillAppear(true)
        
    }

}
