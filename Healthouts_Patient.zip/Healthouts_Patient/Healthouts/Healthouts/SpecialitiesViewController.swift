//
//  SpecialitiesViewController.swift
//  Healthouts
//
//  Created by Y.Bharath Kumar Reddy on 27/05/15.
//  Copyright (c) 2015 Y.Bharath Kumar Reddy. All rights reserved.
//

import UIKit

class SpecialitiesViewController: UIViewController,UICollectionViewDelegate,UICollectionViewDataSource,UICollectionViewDelegateFlowLayout {

    //outlets from the storyboard
    @IBOutlet weak var collectionView: UICollectionView!
    @IBOutlet weak var navBarView: UIView!
    
    //required variables
    var specialitiesArray = ["General Physician","OB-Gynecologist","Dermatologist","Dentist","ENT","Eye Doctor","Cardiologist","Pediatrician","Orthopedician","Cancer Specialist","Endocrinologist","General Surgeon","Psychiatrist"]
    var selectedCategory = ""

    
    override func viewDidLoad() {
        super.viewDidLoad()

        //set the navigation bar view properties like shadow etc
        navBarView.layer.shadowColor = UIColor.blackColor().CGColor
        navBarView.layer.shadowOffset = CGSizeMake(0.5, 0.5)
        navBarView.layer.shadowRadius = 3.0
        navBarView.layer.shadowOpacity = 1.0
        
        //register the custom cell for the speciality view
        var nib = UINib(nibName: "SpecialityCollectionViewCell", bundle: nil)
        collectionView.registerNib(nib, forCellWithReuseIdentifier: "SpecialityCell")
        
        //add gesture recognizer to open the side menu
        self.view.addGestureRecognizer(UIPanGestureRecognizer(target: self, action: "panGestureRecognized:"))

    }
    
    //handle gesture to open the side menu
    func panGestureRecognized(sender:UIPanGestureRecognizer){
        var vel = sender.velocityInView(self.view)
        if(vel.x > 0){
            self.view.endEditing(true)
            self.frostedViewController.view.endEditing(true)
            self.frostedViewController.presentMenuViewController()
        }
    }
    
    override func viewWillAppear(animated: Bool) {
        super.viewWillAppear(true)
        self.tabBarController?.tabBar.hidden = false
    }

    override func viewWillDisappear(animated: Bool) {
        super.viewWillDisappear(true)
        
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    //show the side menu on pressing the button
    @IBAction func showMenu(sender: AnyObject) {
        self.view.endEditing(true)
        self.frostedViewController.view.endEditing(true)
        self.frostedViewController.presentMenuViewController()
    }

    //number of specialities in the collection view
    func collectionView(collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        return specialitiesArray.count
    }
    
    //populate each cell in the collection view
    func collectionView(collectionView: UICollectionView, cellForItemAtIndexPath indexPath: NSIndexPath) -> UICollectionViewCell {
        var identifier = "SpecialityCell"
        var cell = collectionView.dequeueReusableCellWithReuseIdentifier(identifier, forIndexPath: indexPath) as! SpecialityCollectionViewCell
        cell.specialityName.text = specialitiesArray[indexPath.row]
        cell.specialityName.sizeToFit()
        return cell
    }
    
    //collectionview delegate methods impolemented
    func collectionView(collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, insetForSectionAtIndex section: Int) -> UIEdgeInsets {
        return UIEdgeInsetsMake(0,0,0,0)
    }
    
    func collectionView(collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, minimumInteritemSpacingForSectionAtIndex section: Int) -> CGFloat {
        return 0
    }
    
    func collectionView(collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, minimumLineSpacingForSectionAtIndex section: Int) -> CGFloat {
        return 0
    }
    
    func collectionView(collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, sizeForItemAtIndexPath indexPath: NSIndexPath) -> CGSize {
        var screenRect = UIScreen.mainScreen().bounds
        var screenWidth = screenRect.size.width
        return CGSizeMake(screenWidth/3 - 3,70)
    }
    
    
    //handle selections in the tableview
    func collectionView(collectionView: UICollectionView, didSelectItemAtIndexPath indexPath: NSIndexPath) {
        self.selectedCategory = specialitiesArray[indexPath.row]
        self.performSegueWithIdentifier("DoctorsList", sender: self)
    }
    
    //pass the required variables before the segue is performed
    override func prepareForSegue(segue: UIStoryboardSegue, sender: AnyObject?) {
        self.tabBarController?.tabBar.hidden = true
        var destViewController = segue.destinationViewController as! DoctorsListViewController
        destViewController.selectedCategory = self.selectedCategory
        
    }

}
