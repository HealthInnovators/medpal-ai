//
//  BookingSuccessViewController.swift
//  Healthouts
//
//  Created by Y.Bharath Kumar Reddy on 31/05/15.
//  Copyright (c) 2015 Y.Bharath Kumar Reddy. All rights reserved.
//

import UIKit

class BookingSuccessViewController: UIViewController {

    //outlets from storyboard
    @IBOutlet weak var navBarView: UIView!
    
    override func viewDidLoad() {
        super.viewDidLoad()

        //set the navbar view properties
        navBarView.layer.shadowColor = UIColor.blackColor().CGColor
        navBarView.layer.shadowOffset = CGSizeMake(0.5, 0.5)
        navBarView.layer.shadowRadius = 3.0
        navBarView.layer.shadowOpacity = 1.0
        
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    

    //jump to home on pressing ok
    @IBAction func okButtonPressed(sender: AnyObject) {
        var destViewController = self.storyboard?.instantiateInitialViewController() as! RootViewController
        self.presentViewController(destViewController, animated: true, completion: nil)
 
    }

}
