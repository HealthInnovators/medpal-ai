//
//  HealthFilesViewController.swift
//  Healthouts
//
//  Created by Y.Bharath Kumar Reddy on 17/07/15.
//  Copyright (c) 2015 Y.Bharath Kumar Reddy. All rights reserved.
//

import UIKit

class HealthFilesViewController: UIViewController,UITableViewDelegate,UITableViewDataSource,UIImagePickerControllerDelegate,UINavigationControllerDelegate {

    //outlets from the storyboard
    @IBOutlet weak var addButton: UIButton!
    @IBOutlet weak var tableView: UITableView!
    
    //required variables
    var imagePicker = UIImagePickerController()
    var actInd : UIActivityIndicatorView = UIActivityIndicatorView(frame: CGRectMake(0,0, 50, 50)) as UIActivityIndicatorView
    var tableData = []
    var selectedFile = ""
    
    override func viewDidLoad() {
        super.viewDidLoad()
        addButton.layer.cornerRadius = 5
        
        //call the getHealthFiles func
        getHealthFiles()
        
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    //handle add button click
    @IBAction func addButtonPressed(sender: AnyObject) {
        //instantiate the AlertController
        let optionMenu = UIAlertController(title: nil, message: "Choose Option", preferredStyle: UIAlertControllerStyle.ActionSheet)
        
        //make an action to open the UIImage picker controller
        let selectImageAction = UIAlertAction(title: "Choose Image", style: .Default, handler: {
            (alert: UIAlertAction!) -> Void in
            if UIImagePickerController.isSourceTypeAvailable(UIImagePickerControllerSourceType.SavedPhotosAlbum){
                
                self.imagePicker.sourceType = UIImagePickerControllerSourceType.SavedPhotosAlbum;
                self.imagePicker.allowsEditing = false
                self.imagePicker.delegate = self
                self.presentViewController(self.imagePicker, animated: true) { () -> Void in
                    
                }
                
            }
        })
        
        //make an option to select the files downloaded
        /*
        let selectFileAction = UIAlertAction(title: "Take Photo", style: .Default, handler: {
            (alert: UIAlertAction!) -> Void in
            self.imagePicker.sourceType = UIImagePickerControllerSourceType.Camera;
            self.imagePicker.allowsEditing = false
            
        })*/
        
        //make a cancel action to dismiss the alertcontroller
        let cancelAction = UIAlertAction(title: "Cancel", style: .Cancel, handler: {
            (alert: UIAlertAction!) -> Void in
            
        })
        
        
        //add the above actions to the the AlertController
        optionMenu.addAction(selectImageAction)
        //optionMenu.addAction(selectFileAction)
        optionMenu.addAction(cancelAction)
        
        //present the AlertController
        self.presentViewController(optionMenu, animated: true, completion: nil)
    }

    //call the get health files url
    func getHealthFiles(){
        
        //start the indicator
        actInd.center = CGPointMake(self.view.center.x, self.view.center.y - 64)
        actInd.hidesWhenStopped = true
        actInd.activityIndicatorViewStyle = UIActivityIndicatorViewStyle.White
        actInd.backgroundColor = UIColor.blackColor()
        actInd.layer.cornerRadius = 5
        view.addSubview(actInd)
        actInd.startAnimating()
        
        //prepare the parameters to be sent
        var userInfo = NSUserDefaults.standardUserDefaults().objectForKey("userInfo") as? NSDictionary
        var customerId = userInfo?.objectForKey("id") as! Int
        var customerEmail = userInfo?.objectForKey("email") as! String
        
        //call the SRWebclient with the url and parameters
        //and handle the success or failure accordingly
        SRWebClient.POST("http://healthouts.com/appGetHealthFiles?")
            .data(["CId":customerId,"CEmail":customerEmail])
            .send({ (response:AnyObject!, status:Int) -> Void in
                
                self.actInd.stopAnimating()
                var err: NSError?
                var data = (response as! String).dataUsingEncoding(NSUTF8StringEncoding, allowLossyConversion: true)
                
                if let jsonResult = NSJSONSerialization.JSONObjectWithData(data!, options: NSJSONReadingOptions.MutableContainers, error: &err) as? NSMutableArray {
                    dispatch_async(dispatch_get_main_queue(), {

                        self.tableData = jsonResult
                        self.tableView.hidden = false
                        self.tableView.reloadData()
                        
                    })
                    
                }else{
                    self.addAlert((err?.localizedDescription)!)
                }
                
                
            }, failure: { (error) -> Void in
                dispatch_async(dispatch_get_main_queue(), {
                        
                    self.actInd.stopAnimating()
                    self.addAlert(error.localizedDescription)
                        
                    
                })
                    
            })
    }
    
    
    //function to add alert
    func addAlert(message:String){
        var alert = UIAlertController(title: "Alert", message: message, preferredStyle: UIAlertControllerStyle.Alert)
        alert.addAction(UIAlertAction(title: "ok", style: UIAlertActionStyle.Default, handler: nil))
        self.presentViewController(alert, animated: true, completion: nil)
    }
    
    //populate the tableview with fine name in each cell
    func tableView(tableView: UITableView, cellForRowAtIndexPath indexPath: NSIndexPath) -> UITableViewCell {
        var identifier = "HealthFileCell"
        var cell = tableView.dequeueReusableCellWithIdentifier(identifier) as! UITableViewCell
        
        var healthFileData = tableData[indexPath.row] as? NSDictionary
        cell.textLabel?.text = healthFileData!.objectForKey("healthfilepath") as? String
        
        return cell
    }
    
    //number of rows in the table view
    func tableView(tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return tableData.count
    }
    
    //return true an we allow editing the table view cell i.e deleting the health file
    func tableView(tableView: UITableView, canEditRowAtIndexPath indexPath: NSIndexPath) -> Bool {
        return true
    }

    //callng the delete function
    func tableView(tableView: UITableView, commitEditingStyle editingStyle: UITableViewCellEditingStyle, forRowAtIndexPath indexPath: NSIndexPath) {
        if (editingStyle == UITableViewCellEditingStyle.Delete) {
            //call the delete function
            deleteHealthFile(indexPath)
        }
    }
    
    //function to delete the health file
    func deleteHealthFile(selectedIndex:NSIndexPath){
         //start the indicator
        actInd.center = CGPointMake(self.view.center.x, self.view.center.y - 64)
        actInd.hidesWhenStopped = true
        actInd.activityIndicatorViewStyle = UIActivityIndicatorViewStyle.White
        actInd.backgroundColor = UIColor.blackColor()
        actInd.layer.cornerRadius = 5
        view.addSubview(actInd)
        actInd.startAnimating()
        
        //prepare the parameters to be sent
        var userInfo = NSUserDefaults.standardUserDefaults().objectForKey("userInfo") as? NSDictionary
        var customerId = userInfo?.objectForKey("id") as! Int
        var customerEmail = userInfo?.objectForKey("email") as! String
        var id = tableData[selectedIndex.row].objectForKey("heathfileid") as! Int
       
        //call the SRWebclient with the url and parameters
        //and handle the success or failure accordingly
        SRWebClient.POST("http://healthouts.com/appDeleteHealthFile?")
            .data(["CId":customerId,"CEmail":customerEmail,"healthFileId":id])
            .send({ (response:AnyObject!, status:Int) -> Void in
                
                self.actInd.stopAnimating()
                var err: NSError?
                var data = (response as! String).dataUsingEncoding(NSUTF8StringEncoding, allowLossyConversion: true)
                
                if let jsonResult = NSJSONSerialization.JSONObjectWithData(data!, options: NSJSONReadingOptions.MutableContainers, error: &err) as? NSMutableArray {
                    dispatch_async(dispatch_get_main_queue(), {
                        
                        self.tableData = jsonResult
                        self.tableView.hidden = false
                        self.tableView.reloadData()
                        
                    })
                    
                }else{
                    self.addAlert((err?.localizedDescription)!)
                }
                
                
            }, failure: { (error) -> Void in
                dispatch_async(dispatch_get_main_queue(), {
                        
                    self.actInd.stopAnimating()
                    self.addAlert(error.localizedDescription)
                        
                        
                })
                    
            })
    }
    
    //back button clicked
    @IBAction func backButtonPressed(sender: AnyObject) {
        self.navigationController?.popViewControllerAnimated(true)
    }
    
    //UIImagePickerController delegate methods
    
    //If Image is selected,call the saveHealthFiles function with the selected image
    func imagePickerController(picker: UIImagePickerController, didFinishPickingImage image: UIImage!, editingInfo: [NSObject : AnyObject]!) {
    
        self.dismissViewControllerAnimated(true, completion: { () -> Void in
            self.saveHealthFile(image)
        })
        
    }
    
    //If cancel is pressed,just dismiss the controller
    func imagePickerControllerDidCancel(picker: UIImagePickerController) {
        self.dismissViewControllerAnimated(true, completion: { () -> Void in
            
        })
    }
    
    
    //function to save the health file
    func saveHealthFile(image:UIImage){
        var text = "please wait...\nuploading file..."
        self.showWaitOverlayWithText(text)
        
        //perpare the parameters to be sent
        var userInfo = NSUserDefaults.standardUserDefaults().objectForKey("userInfo") as? NSDictionary
        var customerId = userInfo?.objectForKey("id") as! Int
        var customerEmail = userInfo?.objectForKey("email") as! String
        var imageData = NetData(jpegImage: image, compressionQuanlity: 1.0, filename: "myFile")
        var parameters = ["CId":customerId,"CEmail":customerEmail,"healthFile":imageData]
        
        let net = Net()
        net.POST("http://healthouts.com/appAddHealthFiles?", params: parameters, successHandler: { (response) -> () in
            dispatch_async(dispatch_get_main_queue(), {
            
                self.removeAllOverlays()
                
                let result = response.jsonArr(error: nil)
                
                if(result != nil){
                    
                    self.tableData = result!
                    self.tableView.reloadData()
                    
                }else{
                    
                    self.addAlert("Could not upload the file")
                    
                }
            })
        }) { (error) -> () in
            dispatch_async(dispatch_get_main_queue(), {
                self.removeAllOverlays()
                self.addAlert(error.localizedDescription)
            })
        }
        
    }
    
    //handle selections in the tableview cell
    //save the image represented by that cell to the documents directory
    //and load the image in a webview controller by performing the segue
    func tableView(tableView: UITableView, didSelectRowAtIndexPath indexPath: NSIndexPath) {
       
        tableView.deselectRowAtIndexPath(indexPath, animated: true)
        var fileData = self.tableData[indexPath.row] as! NSDictionary
        var filePath = fileData.objectForKey("healthfilepath") as? String
        self.selectedFile = filePath!
        self.saveImage(self.selectedFile)
        self.performSegueWithIdentifier("showFile", sender: self)
        
    }
    
    //pass the parameters before performing the segue
    override func prepareForSegue(segue: UIStoryboardSegue, sender: AnyObject?) {
        if(segue.identifier == "showFile"){
            var destViewController = segue.destinationViewController as! ShowAttachmentViewController
            destViewController.attachmentName = self.selectedFile
        }
    }
    
    //function to save the image to the documents directory
    func saveImage(fileName:String){
        
        var imgPath = "http://healthouts.com/img/\(fileName)"
        var imgUrl = NSURL(string: imgPath)
        
        //use the SDWebImageDownloader
        SDWebImageDownloader.sharedDownloader().downloadImageWithURL(imgUrl, options: nil, progress: { (receivedSize:Int, expectedSize:Int) -> Void in
            
            }) { (image, data, error, finished) -> Void in
                if(error != nil){
                   
                }else{
                    
                    //if the image is downloaded successfully
                    //save it to the documents directory
                    
                    let fileManager = NSFileManager.defaultManager()
                    var paths = NSSearchPathForDirectoriesInDomains(.DocumentDirectory, .UserDomainMask, true)[0] as! String
                    var filePathToWrite = "\(paths)/\(fileName)"
                    var imageData: NSData = UIImagePNGRepresentation(image)
                    
                    fileManager.createFileAtPath(filePathToWrite, contents: imageData, attributes: nil)
                }
        }
    }
    
}
