//
//  AnswersViewController.swift
//  Healthouts
//
//  Created by Y.Bharath Kumar Reddy on 09/06/15.
//  Copyright (c) 2015 Y.Bharath Kumar Reddy. All rights reserved.
//

import UIKit

class AnswersViewController: UIViewController,UITableViewDelegate,UITableViewDataSource {

    //outlets
    @IBOutlet weak var tableView: UITableView!
    @IBOutlet weak var questionLabel: UILabel!
    
    //required variables
    var questionInfo = NSDictionary()
    var answerInfo = NSArray()
    var imageCache = [String:UIImage]()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        questionLabel.text = questionInfo.objectForKey("questionBody") as? String
        
        //register the custom cell
        var nib = UINib(nibName: "AnswerTableViewCell", bundle: nil)
        tableView.registerNib(nib, forCellReuseIdentifier: "AnswerCell")
        
        //set table view properties
        if(answerInfo.count == 0){
            self.tableView.hidden = true
        }
        self.tableView.rowHeight = UITableViewAutomaticDimension
        self.tableView.estimatedRowHeight = 80;
        self.tableView.reloadData()
        
        self.tabBarController?.tabBar.hidden = true
    }

    override func viewWillAppear(animated: Bool) {
        super.viewWillAppear(true)
        
    }
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    @IBAction func backButtonPressed(sender: AnyObject) {
        self.navigationController?.popViewControllerAnimated(true)
    }

    
    //number of rows
    func tableView(tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
       return answerInfo.count
    }
    
    //populate the table view
    func tableView(tableView: UITableView, cellForRowAtIndexPath indexPath: NSIndexPath) -> UITableViewCell {
        var identifier = "AnswerCell"
        var cell:AnswerTableViewCell  = tableView.dequeueReusableCellWithIdentifier(identifier) as! AnswerTableViewCell
        
        cell.containerView.layer.cornerRadius = 5
        cell.containerView.layer.zPosition = 5
        
        cell.doctorImageView.layer.cornerRadius = 27.5
        cell.doctorImageView.layer.masksToBounds = true
        
        var answer = answerInfo[indexPath.row] as! NSDictionary
        cell.answerSubjectLabel.text = answer.objectForKey("answerSubject") as? String
        cell.answerLabel.text = answer.objectForKey("answerBody") as? String
        
        var doctorName = answer.objectForKey("doctorName") as? String
        var staticText = "answered"
        var text = NSMutableAttributedString(string: doctorName! + "  " + staticText)
        text.addAttribute(NSForegroundColorAttributeName, value: UIColor.blackColor(), range: NSMakeRange(text.length-8, 8))
        cell.nameLabel.attributedText = text
        
        cell.doctorImageView.image = UIImage(named: "doctoricon")
        if let image = questionInfo.objectForKey("doctorImage") as? String{
            var imgPath = "http://healthouts.com/img/" + image.stringByReplacingOccurrencesOfString(" ", withString: "%20") as String
            var imgUrl = NSURL(string: imgPath)
            
            if let img = imageCache[imgPath]{
                cell.doctorImageView.image = img
            }else{
                SDWebImageDownloader.sharedDownloader().downloadImageWithURL(imgUrl, options: nil, progress: { (receivedSize:Int, expectedSize:Int) -> Void in
                    
                    }) { (image, data, error, finished) -> Void in
                        if(error != nil){
                            cell.doctorImageView.image = UIImage(named: "doctoricon")
                        }else{
                            cell.doctorImageView.image = image
                            self.imageCache[imgPath] = image
                        }
                }
            }
        }else{
            cell.doctorImageView.image = UIImage(named: "doctoricon")
        }
        
        //cell.setNeedsUpdateConstraints()
        //cell.updateConstraintsIfNeeded()
        
        return cell

    }
    

}
