//
//  MenuViewController.swift
//  Healthouts
//
//  Created by Y.Bharath Kumar Reddy on 28/05/15.
//  Copyright (c) 2015 Y.Bharath Kumar Reddy. All rights reserved.
//

import UIKit

class MenuViewController: UIViewController,UITableViewDelegate,UITableViewDataSource {

    //Outlets from the storyboard
    @IBOutlet weak var profileImageView: UIImageView!
    @IBOutlet weak var nameLabel: UILabel!
    @IBOutlet weak var tableView: UITableView!
    
    //Array to store the menu items
    var menuItems = []
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
    //make the profile Image circular in shape
        profileImageView.layer.cornerRadius = 60
        profileImageView.layer.masksToBounds = true
        
    }

    //Function called everytime the view appears
    override func viewWillAppear(animated: Bool) {
        super.viewWillAppear(true)
        
        //check if user logged in
        //and set the menu items accordingly
        if(NSUserDefaults.standardUserDefaults().boolForKey("isLoggedIn")){
            
            menuItems = ["Find Doctors","Appointments","Free Questions","Paid Questions","Profile Settings","About Us"]
            var userData = NSUserDefaults.standardUserDefaults().objectForKey("userInfo") as! NSDictionary
            
            
            //set the username in the menu
            if let userName = userData["name"] as? String{
                if(userName != ""){
                    nameLabel.text = userData["name"] as? String
                }
            }
            
            //set the image in menu
            if let image = userData.objectForKey("image") as? String{
                
                var imgPath = "http://healthouts.com/img/" + (image as String).stringByReplacingOccurrencesOfString(" ", withString: "%20") as String
                var imgUrl = NSURL(string: imgPath)
                SDWebImageDownloader.sharedDownloader().downloadImageWithURL(imgUrl, options: nil, progress: { (receivedSize:Int, expectedSize:Int) -> Void in
                    
                    }) { (image, data, error, finished) -> Void in
                        if(error != nil){
                            self.profileImageView.image = UIImage(named: "dummydp")
                        }else{
                            self.profileImageView.image = image
                        }
                }
            }
            
        }else{
            menuItems = ["Search/Ask Question","Free Questions","About Us"]
        }
        
        //reload the tableview with the corresponding menu items
        self.tableView.reloadData()
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    
    //populating the tableview
    func tableView(tableView: UITableView, cellForRowAtIndexPath indexPath: NSIndexPath) -> UITableViewCell {
        var cell = tableView.dequeueReusableCellWithIdentifier("SideCell") as! UITableViewCell
        cell.textLabel?.text = menuItems[indexPath.row] as? String
        return cell
    }
    
    //number of rows in the tableview
    func tableView(tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return menuItems.count
    }
    
    //handle selections in the tableview
    func tableView(tableView: UITableView, didSelectRowAtIndexPath indexPath: NSIndexPath) {
        
        //handle different selections corresponding to logged in
        /*
          For each selection do the following
            1.Instantiate the corresponding view controller with its identifier
            2.If required assign a navigation controller to it
            3.now make it or its navigation Controller(if assigned any) the contentViewController of the frostedViewController
            4.Call the self.frostedViewController.hideMenuViewController()
        */
        if(NSUserDefaults.standardUserDefaults().boolForKey("isLoggedIn")){
            
            if(indexPath.row == 0){
                
                var tabBarController = self.storyboard?.instantiateViewControllerWithIdentifier("contentController") as? UITabBarController
                self.frostedViewController.contentViewController = tabBarController
                self.frostedViewController.hideMenuViewController()
                
            }else if(indexPath.row == 1){
                
                var navController = self.storyboard?.instantiateViewControllerWithIdentifier("contentNavigationController") as? UINavigationController
                var destViewController = self.storyboard?.instantiateViewControllerWithIdentifier("MyBookings") as! UIViewController
                navController?.viewControllers = [destViewController]
                self.frostedViewController.contentViewController = navController
                self.frostedViewController.hideMenuViewController()
                
            }else if(indexPath.row == 2){
                
                var destViewController = self.storyboard?.instantiateViewControllerWithIdentifier("Free Questions") as! UITabBarController
                self.frostedViewController.contentViewController = destViewController
                self.frostedViewController.hideMenuViewController()
                
            }else if(indexPath.row == 3){
                
                var navController = self.storyboard?.instantiateViewControllerWithIdentifier("contentNavigationController") as? UINavigationController
                var destViewController = self.storyboard?.instantiateViewControllerWithIdentifier("Paid Questions") as! UIViewController
                navController?.viewControllers = [destViewController]
                self.frostedViewController.contentViewController = navController
                self.frostedViewController.hideMenuViewController()
                
            }else if(indexPath.row == 4){
                var navController = self.storyboard?.instantiateViewControllerWithIdentifier("contentNavigationController") as? UINavigationController
                var destViewController = self.storyboard?.instantiateViewControllerWithIdentifier("Profile Settings") as! UIViewController
                navController?.viewControllers = [destViewController]
                self.frostedViewController.contentViewController = navController
                self.frostedViewController.hideMenuViewController()
            }else if(indexPath.row == 5){
                
                var navController = self.storyboard?.instantiateViewControllerWithIdentifier("contentNavigationController") as? UINavigationController
                var destViewController = self.storyboard?.instantiateViewControllerWithIdentifier("AboutUs") as! UIViewController
                navController?.viewControllers = [destViewController]
                self.frostedViewController.contentViewController = navController
                self.frostedViewController.hideMenuViewController()
                
            }

        }else{
            
            if(indexPath.row == 0){
                
               var tabBarController = self.storyboard?.instantiateViewControllerWithIdentifier("contentController") as? UITabBarController
                self.frostedViewController.contentViewController = tabBarController
                self.frostedViewController.hideMenuViewController()
                
            }else if(indexPath.row == 1){
                
                var navController = self.storyboard?.instantiateViewControllerWithIdentifier("contentNavigationController") as? UINavigationController
                var destViewController = self.storyboard?.instantiateViewControllerWithIdentifier("Free Questions") as! UITabBarController
                navController?.viewControllers = [destViewController]
                self.frostedViewController.contentViewController = navController
                self.frostedViewController.hideMenuViewController()
                
            }else if(indexPath.row == 2){
                
                var navController = self.storyboard?.instantiateViewControllerWithIdentifier("contentNavigationController") as? UINavigationController
                var destViewController = self.storyboard?.instantiateViewControllerWithIdentifier("AboutUs") as! UIViewController
                navController?.viewControllers = [destViewController]
                self.frostedViewController.contentViewController = navController
                self.frostedViewController.hideMenuViewController()
                
            }
        }
    }

}
