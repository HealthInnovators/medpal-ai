//
//  SymptomsTableViewCell.swift
//  Healthouts
//
//  Created by Y.Bharath Kumar Reddy on 16/07/15.
//  Copyright (c) 2015 Y.Bharath Kumar Reddy. All rights reserved.
//

import UIKit
protocol SymptomsServicesDelegate{
    func updateSymptoms(button:UIButton)
    func deleteSymptoms(button:UIButton)
}

class SymptomsTableViewCell: UITableViewCell {

    @IBOutlet weak var containerView: UIView!
    @IBOutlet weak var typeLabel: UILabel!
    @IBOutlet weak var typeNameLabel: UILabel!
    @IBOutlet weak var notesLabel: UILabel!
    @IBOutlet weak var notesInfoLabel: UILabel!
    @IBOutlet weak var conditionLabel: UILabel!
    @IBOutlet weak var updateButton: UIButton!
    @IBOutlet weak var deleteButton: UIButton!
    
    
    var delegate:SymptomsServicesDelegate?
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
        
    }
    
    @IBAction func updateButtonPressed(sender: AnyObject) {
        self.delegate?.updateSymptoms(sender as! UIButton)
    }
    
    @IBAction func deleteButtonPressed(sender: AnyObject) {
        self.delegate?.deleteSymptoms(sender as! UIButton)
    }
    
    override func setSelected(selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)
        
        // Configure the view for the selected state
    }

}
