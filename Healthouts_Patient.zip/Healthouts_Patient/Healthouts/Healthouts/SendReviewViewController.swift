//
//  SendReviewViewController.swift
//  Healthouts
//
//  Created by Y.Bharath Kumar Reddy on 19/06/15.
//  Copyright (c) 2015 Y.Bharath Kumar Reddy. All rights reserved.
//

import UIKit

class SendReviewViewController: UIViewController,UITextViewDelegate,SAMenuDropDownDelegate {

    //outlets
    @IBOutlet weak var ratingButton: UIButton!
    @IBOutlet weak var reviewTextView: UITextView!
    @IBOutlet weak var navBarView: UIView!
    @IBOutlet weak var scrollView: UIScrollView!
    @IBOutlet weak var contentView: UIView!
    
    //required variables
    var passedInfo = [:]
    var actInd : UIActivityIndicatorView = UIActivityIndicatorView(frame: CGRectMake(0,0, 50, 50)) as UIActivityIndicatorView
    var ratings = ["1","2","3","4","5"]
    var ratingDropDown:SAMenuDropDown!
    
    
    override func viewDidLoad() {
        super.viewDidLoad()

        //initialise the rating dropdown
        ratingDropDown = SAMenuDropDown(source: ratingButton, itemNames: ratings, itemImagesName: nil, itemSubtitles: nil)
        ratingDropDown.delegate = self
        
        //set the nav bar view properties
        navBarView.layer.shadowColor = UIColor.blackColor().CGColor
        navBarView.layer.shadowOffset = CGSizeMake(0.5, 0.5)
        navBarView.layer.shadowRadius = 3.0
        navBarView.layer.shadowOpacity = 1.0
        
        //set the content view constraints
        var leftConstraint = NSLayoutConstraint(item: self.contentView, attribute: NSLayoutAttribute.Leading, relatedBy: NSLayoutRelation.Equal, toItem: self.view, attribute: NSLayoutAttribute.Left, multiplier: 1, constant: 0)
        self.view.addConstraint(leftConstraint)
        
        var rightConstraint = NSLayoutConstraint(item: self.contentView, attribute: NSLayoutAttribute.Trailing, relatedBy: NSLayoutRelation.Equal, toItem: self.view, attribute: NSLayoutAttribute.Right, multiplier: 1, constant: 0)
        self.view.addConstraint(rightConstraint)
        
        //set the keyboard notifications
        NSNotificationCenter.defaultCenter().addObserver(self, selector: "keyboardWillBeShown:", name: UIKeyboardWillShowNotification, object: nil)
        NSNotificationCenter.defaultCenter().addObserver(self, selector: "keyboardWillBeHidden:", name: UIKeyboardWillHideNotification, object: nil)
        
        reviewTextView.delegate = self
        // Do any additional setup after loading the view.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    //prepare the send review url
    @IBAction func submitPressed(sender: AnyObject) {
        reviewTextView.resignFirstResponder()
        
        sendReview()
    }

    //call the sendReview service url
    func sendReview(){
        //start the activity indicator
        actInd.center = self.view.center
        actInd.hidesWhenStopped = true
        actInd.activityIndicatorViewStyle = UIActivityIndicatorViewStyle.White
        actInd.backgroundColor = UIColor.blackColor()
        actInd.layer.cornerRadius = 10
        view.addSubview(actInd)
        actInd.startAnimating()
        
        //prepare the data to be sent
        var chatid = passedInfo.valueForKey("chatid")
        var doctorid = passedInfo.valueForKey("did")
        var customerid = passedInfo.valueForKey("cid")
        var feedback = ""
        if(reviewTextView.text != "Enter your review.."){
            feedback = reviewTextView.text
        }
        
        var reviewRating = ratingButton.titleForState(UIControlState.Normal)
        
        //call the SRWebclient with the url and parameters
        SRWebClient.POST("http://healthouts.com/appSendReview?")
            .data(["chatId" : chatid!,"doctorId" : doctorid!,"customerId" : customerid!,"feedback" : feedback,"reviewRating" : reviewRating!])
            .send({ (response, status) -> Void in
                
                self.actInd.stopAnimating()
                var err: NSError?
                var data = (response as! String).dataUsingEncoding(NSUTF8StringEncoding, allowLossyConversion: true)
                
                if let jsonResult = NSJSONSerialization.JSONObjectWithData(data!, options: NSJSONReadingOptions.MutableContainers, error: &err) as? NSDictionary {
                    dispatch_async(dispatch_get_main_queue(), {
                        if(jsonResult["status"] as! String == "1" ){
                            
                            var text = "Your review is successfully posted"
                            self.showTextOverlay(text)
                            var timer = NSTimer.scheduledTimerWithTimeInterval(1, target: self, selector: Selector("removeOverlayAndDismiss"), userInfo: nil, repeats: false)
                            
                        }else{
                            
                            var text = "Your review could not be posted"
                            self.showTextOverlay(text)
                            var timer = NSTimer.scheduledTimerWithTimeInterval(1, target: self, selector: Selector("removeOverlay"), userInfo: nil, repeats: false)
                        }
                    })
                }else{
                    self.addAlert(err!.localizedDescription)
                }
                
            }, failure: { (error) -> Void in
                self.actInd.stopAnimating()
                self.addAlert(error.localizedDescription)
            })
        
    }
    
    //function to add alert
    func addAlert(message:String){
        var alert = UIAlertController(title: "Alert", message: message, preferredStyle: UIAlertControllerStyle.Alert)
        alert.addAction(UIAlertAction(title: "ok", style: UIAlertActionStyle.Default, handler: nil))
        self.presentViewController(alert, animated: true, completion: nil)
    }
    
    //overlay removal methods
    func removeOverlay(){
        self.removeAllOverlays()
        
    }
    
    func removeOverlayAndDismiss(){
        self.removeAllOverlays()
        self.navigationController?.popViewControllerAnimated(true)
    }
    
    //keyboard notification methods
    func keyboardWillBeHidden(notification:NSNotification){
        var contentInsets = UIEdgeInsetsZero
        self.scrollView.contentInset = contentInsets
        self.scrollView.scrollIndicatorInsets = contentInsets
    }
    
    func keyboardWillBeShown(notification:NSNotification){
        if let userInfo = notification.userInfo {
            if let keyboardSize = (userInfo[UIKeyboardFrameBeginUserInfoKey] as? NSValue)?.CGRectValue() {
                var contentInsets = UIEdgeInsetsMake(0, 0, keyboardSize.height, 0)
                self.scrollView.contentInset = contentInsets
                self.scrollView.scrollIndicatorInsets = contentInsets
                var rect = self.contentView.frame
                rect.size.height -= keyboardSize.height
                if (!CGRectContainsPoint(rect, self.reviewTextView.frame.origin) ) {
                    var scrollPoint = CGPointMake(0.0, self.reviewTextView.frame.origin.y - (keyboardSize.height - self.reviewTextView.frame.size.height))
                    self.scrollView.setContentOffset(scrollPoint, animated: false)
                }
            }
        }
        
        
    }

    //textView delegate methods
    func textViewDidBeginEditing(textView: UITextView) {
        
        if(textView.text == "Enter your review.."){
            textView.text = ""
            textView.textColor = UIColor.blackColor()
        }
        
    }
    
    func textViewDidEndEditing(textView: UITextView) {
        if(textView.text == ""){
            textView.text = "Enter your review.."
            textView.textColor = UIColor.lightGrayColor()
        }
        
    }
    
    //show the rating dropdown
    @IBAction func ratingButtonPressed(sender: AnyObject) {
        reviewTextView.resignFirstResponder()
        if(!ratingDropDown.isMenuExpanded){
            self.reviewTextView.resignFirstResponder()
            ratingDropDown.showSADropDownMenuWithAnimation(kSAMenuDropAnimationDirectionBottom)
            
            
        }else{
            ratingDropDown.hideSADropDownMenu()
            
        }
    }
    
    
    func saDropMenu(menuSender: SAMenuDropDown!, didClickedAtIndex buttonIndex: Int) {
        
    }
    
    //handle back button press
    @IBAction func backButtonPressed(sender: AnyObject) {
        reviewTextView.resignFirstResponder()
       self.navigationController?.popViewControllerAnimated(true)
    }

}
