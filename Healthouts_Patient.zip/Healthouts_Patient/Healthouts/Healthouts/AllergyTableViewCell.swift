//
//  AllergyTableViewCell.swift
//  Healthouts
//
//  Created by Y.Bharath Kumar Reddy on 16/07/15.
//  Copyright (c) 2015 Y.Bharath Kumar Reddy. All rights reserved.
//

import UIKit
protocol AllergyServicesDelegate{
    func updateAllergy(button:UIButton)
    func DeleteAllergy(button:UIButton)
}

class AllergyTableViewCell: UITableViewCell {

    @IBOutlet weak var containerView: UIView!
    @IBOutlet weak var typeLabel: UILabel!
    @IBOutlet weak var typeNameLabel: UILabel!
    @IBOutlet weak var notesLabel: UILabel!
    @IBOutlet weak var notesInfoLabel: UILabel!
    @IBOutlet weak var conditionLabel: UILabel!
    @IBOutlet weak var updateButton: UIButton!
    @IBOutlet weak var deleteButton: UIButton!
    
    
    var delegate:AllergyServicesDelegate?
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
        
    }
    
    @IBAction func updateButtonPressed(sender: AnyObject) {
        self.delegate?.updateAllergy(sender as! UIButton)
    }
    
    @IBAction func deleteButtonPressed(sender: AnyObject) {
        self.delegate?.DeleteAllergy(sender as! UIButton)
    }
    
    override func setSelected(selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)
        
        // Configure the view for the selected state
    }

}
