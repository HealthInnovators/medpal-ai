//
//  DoctorSearchViewController.swift
//  Healthouts
//
//  Created by Y.Bharath Kumar Reddy on 27/05/15.
//  Copyright (c) 2015 Y.Bharath Kumar Reddy. All rights reserved.
//

import UIKit

class DoctorSearchViewController: UIViewController,UITextFieldDelegate,UITableViewDataSource,UITableViewDelegate {

    //required outlets from the storyboard
    @IBOutlet weak var tableBottomConstraint: NSLayoutConstraint!
    @IBOutlet weak var navBarView: UIView!
    @IBOutlet weak var searchTextField: UITextField!
    @IBOutlet weak var tableView: UITableView!
    
    //required variables
    var selectedDoctorId:String!
    var task:NSURLSessionDataTask = NSURLSessionDataTask()
    var tableData:NSArray! = []
    var imageCache = [String:UIImage]()
    var selectedDoctorName = ""
    var actInd : UIActivityIndicatorView = UIActivityIndicatorView(frame: CGRectMake(0,0, 50, 50)) as UIActivityIndicatorView
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        //set the navigation bar properties like shadow etc
        navBarView.layer.shadowColor = UIColor.blackColor().CGColor
        navBarView.layer.shadowOffset = CGSizeMake(0.5, 0.5)
        navBarView.layer.shadowRadius = 3.0
        navBarView.layer.shadowOpacity = 1.0
        
        searchTextField.delegate = self
        
        //register the doctor tableviewcell
        var nib = UINib(nibName: "DoctorsTableViewCell", bundle: nil)
        tableView.registerNib(nib, forCellReuseIdentifier: "DoctorCell")
        
        //add gesture recogniser for side menu
        self.view.addGestureRecognizer(UIPanGestureRecognizer(target: self, action: "panGestureRecognized:"))
        if(tableData.count == 0){
            tableView.hidden = true
        }
       
        /*
        //add the keyboard notifications
        NSNotificationCenter.defaultCenter().addObserver(self, selector: "keyboardWillBeShown:", name: UIKeyboardWillShowNotification, object: nil)
        NSNotificationCenter.defaultCenter().addObserver(self, selector: "keyboardWillBeHidden:", name: UIKeyboardWillHideNotification, object: nil)
        */
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    //handle side menu opening on pressing the side menu button
    @IBAction func showMenu(sender: AnyObject) {
        self.view.endEditing(true)
        self.frostedViewController.view.endEditing(true)
        self.frostedViewController.presentMenuViewController()

    }
    
    //gesture recogniser to open the side menu
    func panGestureRecognized(sender:UIPanGestureRecognizer){
        var vel = sender.velocityInView(self.view)
        if(vel.x > 0){
        self.view.endEditing(true)
        self.frostedViewController.view.endEditing(true)
        self.frostedViewController.presentMenuViewController()
        }
        //self.frostedViewController.panGestureRecognized(sender)
    }
    
    
    override func viewWillAppear(animated: Bool) {
        super.viewWillAppear(true)
        //self.tableView.contentOffset = CGPointMake(0, 40);
        self.tabBarController?.tabBar.hidden = false
    }

    
    //check if the text in the search textfield is changed
    //If changed call the selector "UITextFieldTextDidChange:"
    func textFieldDidBeginEditing(textField: UITextField) {
        NSNotificationCenter.defaultCenter().addObserver(self, selector: "UITextFieldTextDidChange:", name: UITextFieldTextDidChangeNotification, object: textField)
    }
    
    //remove the "UITextFieldTextDidChange:" selector when editing is ended
    func textFieldDidEndEditing(textField: UITextField) {
        NSNotificationCenter.defaultCenter().removeObserver(self, name:UITextFieldTextDidChangeNotification, object: textField)
    }
    
    //implement the "UITextFieldTextDidChange:" selector
    //Call the get data function to get the data on changing the string
    @objc func UITextFieldTextDidChange(notification:NSNotification){
        var textField:UITextField = notification.object as! UITextField
        var parameterStr =  textField.text
        getData(parameterStr)
        
    }
    
    
    

    //function to get the data
    func getData(parameterStr:String){
        //run the activity indicator till you get the data
        actInd.center = self.view.center
        actInd.hidesWhenStopped = true
        actInd.activityIndicatorViewStyle = UIActivityIndicatorViewStyle.White
        actInd.backgroundColor = UIColor.blackColor()
        actInd.layer.cornerRadius = 5
        view.addSubview(actInd)
        actInd.startAnimating()
        
        //call the SRwebclient with url and parameters
        SRWebClient.POST("http://healthouts.com/appdocListByName?")
            .data(["str" : parameterStr])
            .send({ (response, status) -> Void in
                
                self.actInd.stopAnimating()
                var err: NSError?
                var data = (response as! String).dataUsingEncoding(NSUTF8StringEncoding, allowLossyConversion: true)
                
                if let jsonResult = NSJSONSerialization.JSONObjectWithData(data!, options: NSJSONReadingOptions.MutableContainers, error: &err) as? NSArray {
                    dispatch_async(dispatch_get_main_queue(), {
                        self.tableData = jsonResult
                        if(self.tableData.count == 0){
                            self.tableView.hidden = true
                        }else{
                            self.tableView.hidden = false
                            self.tableView!.reloadData()
                        }
                    })
                }else{
                    self.addAlert(err!.localizedDescription)
                }
            }, failure: { (error) -> Void in
                self.actInd.stopAnimating()
                self.addAlert(error.localizedDescription)

            })
        
       
    }

    
    func addAlert(message:String){
        var alert = UIAlertController(title: "Alert", message: message, preferredStyle: UIAlertControllerStyle.Alert)
        alert.addAction(UIAlertAction(title: "ok", style: UIAlertActionStyle.Default, handler: nil))
        self.presentViewController(alert, animated: true, completion: nil)
    }
    
    //populate the tableView
    func tableView(tableView: UITableView, cellForRowAtIndexPath indexPath: NSIndexPath) -> UITableViewCell {
        var identifier = "DoctorCell"
        var cell:DoctorsTableViewCell  = tableView.dequeueReusableCellWithIdentifier(identifier) as! DoctorsTableViewCell
        var doctorInfo:NSDictionary = tableData[indexPath.row] as! NSDictionary
        cell.doctorNameLabel.text = doctorInfo.objectForKey("dName") as? String
        cell.doctorLocationLabel.text = doctorInfo.objectForKey("location") as? String
        cell.doctorSpecialityLabel.text = doctorInfo.objectForKey("speciality") as? String
        cell.doctorImageView.layer.cornerRadius = 33
        cell.doctorImageView.layer.masksToBounds = true
        
        cell.doctorImageView.image = UIImage(named: "doctoricon")
        if let image = doctorInfo.objectForKey("imgPath") as? String{
            var imgPath = image.stringByReplacingOccurrencesOfString(" ", withString: "%20") as String
            var imgUrl = NSURL(string: imgPath)
            if let img = imageCache[imgPath]{
                cell.doctorImageView.image = img
            }else{
                SDWebImageDownloader.sharedDownloader().downloadImageWithURL(imgUrl, options: nil, progress: { (receivedSize:Int, expectedSize:Int) -> Void in
                    
                    }) { (image, data, error, finished) -> Void in
                        if(error != nil){
                            cell.doctorImageView.image = UIImage(named: "doctoricon")
                        }else{
                            
                            cell.doctorImageView.image = image
                            self.imageCache[imgPath] = image
                        }
                }
            }
        }else{
            cell.doctorImageView.image = UIImage(named: "doctoricon")
        }
        
        return cell
    }
    
    //number of rows in the tableview
    func tableView(tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return tableData.count
    }
    
    //height of each cell
    func tableView(tableView: UITableView, heightForRowAtIndexPath indexPath: NSIndexPath) -> CGFloat {
        return 80
    }
    
    //handle selections on the tableview
    //perform segues to the doctor Info viewcontroller
    func tableView(tableView: UITableView, didSelectRowAtIndexPath indexPath: NSIndexPath) {
        var selectedDoctor = tableData[indexPath.row] as! NSDictionary
        selectedDoctorId = (selectedDoctor["doctorId"]?.stringValue)!
        selectedDoctorName = selectedDoctor["dName"] as! String
        self.tableView.deselectRowAtIndexPath(indexPath, animated: true)
        self.performSegueWithIdentifier("DoctorInfo", sender: self)
    }

    //pass the required variables before performing the segue
    override func prepareForSegue(segue: UIStoryboardSegue, sender: AnyObject?) {
        self.tabBarController?.tabBar.hidden = true
        var destViewController = segue.destinationViewController as! DoctorInfoViewController
        destViewController.selectedDoctorId = self.selectedDoctorId
        destViewController.doctorName = self.selectedDoctorName
    }

    //resign the keyboard on pressing return
    func textFieldShouldReturn(textField: UITextField) -> Bool {
        textField.resignFirstResponder()
        return true
    }
    
    
    override func viewWillDisappear(animated: Bool) {
        super.viewWillDisappear(true)
        searchTextField.resignFirstResponder()
        NSNotificationCenter.defaultCenter().removeObserver(self)
        
    }
    
    /*
    //keyboard notification seletors
    //these are called when the keyboard is about to be shown and when it is about to be removed
    //these are used to adjust the scrollview accordingly
    func keyboardWillBeHidden(notification:NSNotification){
        tableData = []
        tableBottomConstraint.constant = 0
    }
    
    func keyboardWillBeShown(notification:NSNotification){
        if let userInfo = notification.userInfo {
            if let keyboardSize = (userInfo[UIKeyboardFrameBeginUserInfoKey] as? NSValue)?.CGRectValue() {
                //self.bottomConstraint.constant = -keyboardSize.height
                tableBottomConstraint.constant = keyboardSize.height - 50
            }
        }
    }
*/

    
}
