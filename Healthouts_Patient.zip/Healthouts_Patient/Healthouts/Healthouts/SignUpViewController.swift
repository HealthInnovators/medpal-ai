//
//  SignUpViewController.swift
//  Healthouts
//
//  Created by Y.Bharath Kumar Reddy on 29/05/15.
//  Copyright (c) 2015 Y.Bharath Kumar Reddy. All rights reserved.
//

import UIKit

protocol dismissViewDelegate{
    func dismissView()
}

class SignUpViewController: UIViewController,UITextFieldDelegate {

    //outlets from storyboard
    @IBOutlet weak var contentView: UIView!
    @IBOutlet weak var scrollView: UIScrollView!
    @IBOutlet weak var navBarView: UIView!
    @IBOutlet weak var usernameTextField: UITextField!
    @IBOutlet weak var emailTextField: UITextField!
    @IBOutlet weak var passwordTextField: UITextField!
    @IBOutlet weak var mobileTextField: UITextField!
    
    //required variables
    var delegate:dismissViewDelegate?
    var selectedTextField:UITextField!
    var normalSignup = false
    var doctorId:String!
    var selectedDate:String!
    var timeslot:String!
    var doctorTimeId:String!
    var userInfo:NSMutableDictionary = NSMutableDictionary()
    var actInd : UIActivityIndicatorView = UIActivityIndicatorView(frame: CGRectMake(0,0, 50, 50)) as UIActivityIndicatorView
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        //set the navigationBarView properties
        navBarView.layer.shadowColor = UIColor.blackColor().CGColor
        navBarView.layer.shadowOffset = CGSizeMake(0.5, 0.5)
        navBarView.layer.shadowRadius = 3.0
        navBarView.layer.shadowOpacity = 1.0
        
        //add tps recogniser
        var tapBackground = UITapGestureRecognizer(target: self, action: "tapBackground")
        self.view.addGestureRecognizer(tapBackground)
        
        //set the constraints of the scroll view
        var leftConstraint = NSLayoutConstraint(item: self.contentView, attribute: NSLayoutAttribute.Leading, relatedBy: NSLayoutRelation.Equal, toItem: self.view, attribute: NSLayoutAttribute.Left, multiplier: 1, constant: 0)
        self.view.addConstraint(leftConstraint)
        
        var rightConstraint = NSLayoutConstraint(item: self.contentView, attribute: NSLayoutAttribute.Trailing, relatedBy: NSLayoutRelation.Equal, toItem: self.view, attribute: NSLayoutAttribute.Right, multiplier: 1, constant: 0)
        self.view.addConstraint(rightConstraint)
        
        //add the keyboard notifications
        NSNotificationCenter.defaultCenter().addObserver(self, selector: "keyboardWillBeShown:", name: UIKeyboardWillShowNotification, object: nil)
        NSNotificationCenter.defaultCenter().addObserver(self, selector: "keyboardWillBeHidden:", name: UIKeyboardWillHideNotification, object: nil)

        //set the delegates
        usernameTextField.delegate = self
        emailTextField.delegate = self
        passwordTextField.delegate = self
        mobileTextField.delegate = self
        
        // Do any additional setup after loading the view.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    //handle back button press
    @IBAction func backButtonPressed(sender: AnyObject) {
         self.navigationController?.popViewControllerAnimated(true)
    }

    //sign up button is pressed
    @IBAction func signUpButtonPressed(sender: AnyObject) {
        if(selectedTextField != nil){
            selectedTextField.resignFirstResponder()
        }
        
        //if this is a login with booking
        if(!normalSignup){
        var text = "Please fill in\nall the fields"
        if(usernameTextField.text == "" || passwordTextField.text == "" || usernameTextField.text == "" || mobileTextField.text == ""){
            self.showTextOverlay(text)
            var timer = NSTimer.scheduledTimerWithTimeInterval(2, target: self, selector: Selector("removeOverlay"), userInfo: nil, repeats: false)
        }else{
            //start the activity indicator
            actInd.center = self.view.center
            actInd.hidesWhenStopped = true
            actInd.activityIndicatorViewStyle = UIActivityIndicatorViewStyle.White
            actInd.backgroundColor = UIColor.blackColor()
            actInd.layer.cornerRadius = 5
            view.addSubview(actInd)
            actInd.startAnimating()
            
            //call the SRWebClient with the url and parameters
            SRWebClient.POST("http://healthouts.com/appUserSignupBooking?")
                .data(["email" : emailTextField.text,"pass":passwordTextField.text,"name":usernameTextField.text,"mNo":mobileTextField.text,"doctorId" : doctorId,"availableDate" : selectedDate,"timePeriod" : timeslot,"doctorTimeId" : doctorTimeId])
                .send({ (response, status) -> Void in
                    
                    self.actInd.stopAnimating()
                    var err: NSError?
                    var data = (response as! String).dataUsingEncoding(NSUTF8StringEncoding, allowLossyConversion: true)
                    
                    if let jsonResult = NSJSONSerialization.JSONObjectWithData(data!, options: NSJSONReadingOptions.MutableContainers, error: &err) as? NSDictionary {
                        dispatch_async(dispatch_get_main_queue(), {
                            
                            if((jsonResult["status"] as! String) == "1"){

                                self.userInfo["email"] = jsonResult["emailId"] as! String
                                self.userInfo["pass"] = jsonResult["pass"]
                                self.userInfo["type"] = jsonResult["customerType"]
                                self.userInfo["id"] = jsonResult["customerId"]
                                self.userInfo["name"] = jsonResult["cName"]
                                
                                NSUserDefaults.standardUserDefaults().setObject(self.userInfo, forKey: "userInfo")
                                NSUserDefaults.standardUserDefaults().setBool(true, forKey: "isLoggedIn")
                                self.performSegueWithIdentifier("BookingSuccess", sender: self)
                                
                                
                                
                            }else{
                                if((jsonResult["bookingStatus"] as! String) == "registrationFail"){
                                    var text = "Sign up was not successful.\nPlease try again"
                                    self.showTextOverlay(text)
                                    var timer = NSTimer.scheduledTimerWithTimeInterval(2, target: self, selector: Selector("removeOverlay"), userInfo: nil, repeats: false)
                                    
                                }
                            }
                            
                        })
                    }else{
                        self.addAlert(err!.localizedDescription)
                    }
            
                }, failure: { (error) -> Void in
                    self.actInd.stopAnimating()
                    self.addAlert(error.localizedDescription)
                })
            
            }
        }else{
            performNormalSignup()
        }
    }
    
    
    //normal sign up without registration
    func performNormalSignup(){
        var text = "Please fill in\nall the fields"
        if(usernameTextField.text == "" || passwordTextField.text == "" || usernameTextField.text == "" || mobileTextField.text == ""){
            self.showTextOverlay(text)
            var timer = NSTimer.scheduledTimerWithTimeInterval(2, target: self, selector: Selector("removeOverlay"), userInfo: nil, repeats: false)
        }else{
            //start the activity indicator
            actInd.center = self.view.center
            actInd.hidesWhenStopped = true
            actInd.activityIndicatorViewStyle = UIActivityIndicatorViewStyle.White
            actInd.backgroundColor = UIColor.blackColor()
            actInd.layer.cornerRadius = 5
            view.addSubview(actInd)
            actInd.startAnimating()
            
            //call the SRWebClient with the url and parameters
            SRWebClient.POST("http://healthouts.com/appUserSignup?")
                .data(["email" : emailTextField.text,"pass" : passwordTextField.text,"name" : usernameTextField.text,"mNo":mobileTextField.text])
                .send({ (response, status) -> Void in
                    
                    self.actInd.stopAnimating()
                    var err: NSError?
                    var data = (response as! String).dataUsingEncoding(NSUTF8StringEncoding, allowLossyConversion: true)
                    
                    if let jsonResult = NSJSONSerialization.JSONObjectWithData(data!, options: NSJSONReadingOptions.MutableContainers, error: &err) as? NSDictionary {
                        dispatch_async(dispatch_get_main_queue(), {
                            
                            if((jsonResult["status"] as! String) == "1"){
                                
                                self.userInfo["email"] = jsonResult["emailId"] as! String
                                self.userInfo["pass"] = jsonResult["pass"]
                                self.userInfo["type"] = jsonResult["customerType"]
                                self.userInfo["id"] = jsonResult["customerId"]
                                self.userInfo["name"] = jsonResult["cName"]
                                
                                NSUserDefaults.standardUserDefaults().setObject(self.userInfo, forKey: "userInfo")
                                NSUserDefaults.standardUserDefaults().setBool(true, forKey: "isLoggedIn")
                                self.delegate?.dismissView()
                                
                                
                            }else{
                                
                                var text = "Sign up was not successful.\nPlease try again"
                                self.showTextOverlay(text)
                                var timer = NSTimer.scheduledTimerWithTimeInterval(2, target: self, selector: Selector("removeOverlay"), userInfo: nil, repeats: false)
                                
                                
                            }
                            
                        })
                    }else{
                        self.addAlert(err!.localizedDescription)
                    }
                    
                }, failure: { (error) -> Void in
                    self.actInd.stopAnimating()
                    self.addAlert(error.localizedDescription)
                })
            
        }
    }
    
    //function to add alert
    func addAlert(message:String){
        var alert = UIAlertController(title: "Alert", message: message, preferredStyle: UIAlertControllerStyle.Alert)
        alert.addAction(UIAlertAction(title: "ok", style: UIAlertActionStyle.Default, handler: nil))
        self.presentViewController(alert, animated: true, completion: nil)
    }
    
    override func viewWillDisappear(animated: Bool) {
        super.viewWillDisappear(true)
        NSNotificationCenter.defaultCenter().removeObserver(self)
    }
    
    //keyboard notification seletors
    //these are called when the keyboard is about to be shown and when it is about to be removed
    //these are used to adjust the scrollview accordingly
    func keyboardWillBeHidden(notification:NSNotification){
        var contentInsets = UIEdgeInsetsZero
        self.scrollView.contentInset = contentInsets
        self.scrollView.scrollIndicatorInsets = contentInsets
    }
    
    func keyboardWillBeShown(notification:NSNotification){
        if let userInfo = notification.userInfo {
            if let keyboardSize = (userInfo[UIKeyboardFrameBeginUserInfoKey] as? NSValue)?.CGRectValue() {
                var contentInsets = UIEdgeInsetsMake(0, 0, keyboardSize.height, 0)
                self.scrollView.contentInset = contentInsets
                self.scrollView.scrollIndicatorInsets = contentInsets
                var rect = self.contentView.frame
                rect.size.height -= keyboardSize.height
                if (!CGRectContainsPoint(rect, self.emailTextField.frame.origin)) {
                    var scrollPoint = CGPointMake(0.0, self.emailTextField.frame.origin.y - (keyboardSize.height - self.emailTextField.frame.size.height))
                    self.scrollView.setContentOffset(scrollPoint, animated: false)
                }
            }
        }
        
        
    }


    func removeOverlay(){
        self.removeAllOverlays()
    }
    
    //resign first responder on pressing the return key
    func textFieldShouldReturn(textField: UITextField) -> Bool {
        textField.resignFirstResponder()
        return true
    }
    
    func textFieldShouldBeginEditing(textField: UITextField) -> Bool {
        selectedTextField = textField
        return true
    }
    
    //go to login screen
    @IBAction func loginButtonPressed(sender: AnyObject) {
         self.navigationController?.popViewControllerAnimated(true)
    }
    
    //tap received
    func tapBackground(){
        if(mobileTextField.isFirstResponder()){
            mobileTextField.resignFirstResponder()
        }
    }
    

}
