//
//  AskFreeQuestionViewController.swift
//  Healthouts
//
//  Created by Y.Bharath Kumar Reddy on 07/06/15.
//  Copyright (c) 2015 Y.Bharath Kumar Reddy. All rights reserved.
//

import UIKit

class AskFreeQuestionViewController: UIViewController,UITextViewDelegate,UIAlertViewDelegate {

    //outlets
    @IBOutlet weak var navBarView: UIView!
    @IBOutlet weak var textViewHeightConstraint: NSLayoutConstraint!
    @IBOutlet weak var characterCountLabel: UILabel!
    @IBOutlet weak var sendButton: UIButton!
    @IBOutlet weak var questionTextView: UITextView!
    
    //required variables
    var keyboardShowing = false
    var characterCount = 0
    var username = ""
    var password = ""
    var userInfo:NSMutableDictionary = NSMutableDictionary()
    var actInd : UIActivityIndicatorView = UIActivityIndicatorView(frame: CGRectMake(0,0, 50, 50)) as UIActivityIndicatorView
    var isCompressed = false
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        navBarView.layer.shadowColor = UIColor.blackColor().CGColor
        navBarView.layer.shadowOffset = CGSizeMake(0.5, 0.5)
        navBarView.layer.shadowRadius = 3.0
        navBarView.layer.shadowOpacity = 1.0
        
        
        self.view.addGestureRecognizer(UIPanGestureRecognizer(target: self, action: "panGestureRecognized:"))
        
        
        questionTextView.delegate = self
        questionTextView.textColor = UIColor.lightGrayColor()
        questionTextView.layer.borderColor = UIColor(red: 0, green: 147/255, blue: 59/255, alpha: 0.86).CGColor
        questionTextView.layer.borderWidth = 1
        questionTextView.layer.cornerRadius = 5
        
        sendButton.layer.cornerRadius = 5
        sendButton.layer.borderWidth = 1
        sendButton.layer.borderColor = UIColor(red: 0, green: 147/255, blue: 59/255, alpha: 0.86).CGColor
        
        
        NSNotificationCenter.defaultCenter().addObserver(self, selector: "keyboardWasShown:", name: UIKeyboardWillShowNotification, object: nil)
        NSNotificationCenter.defaultCenter().addObserver(self, selector: "keyboardWillBeHidden:", name: UIKeyboardWillHideNotification, object: nil)
        
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    func removeOverlay(){
        self.removeAllOverlays()
    }

    func panGestureRecognized(sender:UIPanGestureRecognizer){
        var vel = sender.velocityInView(self.view)
        if(vel.x > 0){
            self.view.endEditing(true)
            self.frostedViewController.view.endEditing(true)
            self.frostedViewController.presentMenuViewController()
        }
    }
    
    //send the question
    @IBAction func sendButtonPressed(sender: AnyObject) {
        
        if(characterCount == 0 || self.questionTextView.text == "Enter your brief question.Its anonymous and free"){
            var text = "Your question cannot be empty"
            var timer = NSTimer.scheduledTimerWithTimeInterval(1, target: self, selector: Selector("removeOverlay"), userInfo: nil, repeats: false)
            self.showTextOverlay(text)
        }else if(characterCount < 20){
            var text = "Question has to be more than 20 character"
            var timer = NSTimer.scheduledTimerWithTimeInterval(1, target: self, selector: Selector("removeOverlay"), userInfo: nil, repeats: false)
            self.showTextOverlay(text)
        }else{
            questionTextView.resignFirstResponder()
            
            //if logged in send the question
            //else show login
            if(NSUserDefaults.standardUserDefaults().boolForKey("isLoggedIn")){
                self.askQuestion()
            }else{
                
                //show login alert
                questionTextView.resignFirstResponder()
                var alertController = UIAlertController(title: "Login", message: "Enter your email and password", preferredStyle: UIAlertControllerStyle.Alert)
                alertController.addTextFieldWithConfigurationHandler({ (textField:UITextField!) -> Void in
                    textField.placeholder = "email"
                    textField.addTarget(self, action: "alertTextFieldDidChange:", forControlEvents: UIControlEvents.EditingChanged)
                })
                alertController.addTextFieldWithConfigurationHandler({ (textField:UITextField!) -> Void in
                    textField.placeholder = "password"
                    textField.secureTextEntry = true
                    textField.addTarget(self, action: "alertTextFieldDidChange:", forControlEvents: UIControlEvents.EditingChanged)
                })
                
                var loginAction = UIAlertAction(title: "Login", style: UIAlertActionStyle.Default, handler: { (action:UIAlertAction!) -> Void in
                    var email = (alertController.textFields?.first! as! UITextField).text
                    var password = (alertController.textFields?.last! as! UITextField).text
                    var question = self.questionTextView.text
                    var parameters = ["message" : question,"email" : email,"pass" : password]
                    
                    self.loginAndAsk(parameters)
                })
                loginAction.enabled = false
                
                var cancelAction = UIAlertAction(title: "Cancel", style: UIAlertActionStyle.Default, handler: { (action:UIAlertAction!) -> Void in
                    
                })

                alertController.addAction(cancelAction)
                alertController.addAction(loginAction)
                
                self.presentViewController(alertController, animated: true, completion: { () -> Void in
                    
                })
            }

        
        }
    }
    
    //track changes in the alert text field
    func alertTextFieldDidChange(sender:UITextField!){
        var alertController = self.presentedViewController as! UIAlertController

        if((alertController.textFields?.first as! UITextField).text != "" && (alertController.textFields?.last as! UITextField).text != ""){
              (alertController.actions.last as! UIAlertAction).enabled = true
        }else{
                (alertController.actions.last as! UIAlertAction).enabled = false
        }
        
    }
    
    
    //call the ask question service
    func askQuestion(){
        //start the activity indicator
        actInd.center = self.view.center
        actInd.hidesWhenStopped = true
        actInd.activityIndicatorViewStyle = UIActivityIndicatorViewStyle.White
        actInd.backgroundColor = UIColor.blackColor()
        actInd.layer.cornerRadius = 10
        view.addSubview(actInd)
        actInd.startAnimating()
        
        //prepare the data to be sent
        var userData = NSUserDefaults.standardUserDefaults().objectForKey("userInfo") as! NSDictionary
        var customerId = userData["id"]
        var customerEmail = userData["email"]
        var question = self.questionTextView.text
        
        //call the SRWebclient with the url and parameters
        SRWebClient.POST("http://healthouts.com/appfreeMessage?")
            .data(["message" : question,"CId" : customerId!,"CEmail" : customerEmail!])
            .send({ (response, status) -> Void in
                
                self.actInd.stopAnimating()
                var err: NSError?
                var data = (response as! String).dataUsingEncoding(NSUTF8StringEncoding, allowLossyConversion: true)
                
                if let jsonResult = NSJSONSerialization.JSONObjectWithData(data!, options: NSJSONReadingOptions.MutableContainers, error: &err) as? NSDictionary {
                    
                    dispatch_async(dispatch_get_main_queue(), {
                        
                        if((jsonResult["STATUS"] as! String) == "1"){
                            var text = jsonResult["RESULT"] as! String
                            self.showTextOverlay(text)
                            var timer = NSTimer.scheduledTimerWithTimeInterval(2, target: self, selector: Selector("removeOverlay"), userInfo: nil, repeats: false)
                            
                            self.questionTextView.text = "Enter your brief question.Its anonymous and free"
                            self.questionTextView.textColor = UIColor.lightGrayColor()
                        }else{
                            
                            var text = jsonResult["RESULT"] as! String
                            self.showTextOverlay(text)
                            var timer = NSTimer.scheduledTimerWithTimeInterval(2, target: self, selector: Selector("removeOverlay"), userInfo: nil, repeats: false)
                            
                        }
                        
                    })
                    
                }else{
                    self.addAlert(err!.localizedDescription)
                }

            }, failure: { (error) -> Void in
                self.actInd.stopAnimating()
                self.addAlert(error.localizedDescription)
            })
        
        

    }
    
    //function to add alert
    func addAlert(message:String){
        var alert = UIAlertController(title: "Alert", message: message, preferredStyle: UIAlertControllerStyle.Alert)
        alert.addAction(UIAlertAction(title: "ok", style: UIAlertActionStyle.Default, handler: nil))
        self.presentViewController(alert, animated: true, completion: nil)
    }
    
    //once the user logs in through the alert login
    //this function is called to login and ask question simultaneously
    func loginAndAsk(parameters:NSDictionary){
        //start the activity indicator
        actInd.center = self.view.center
        actInd.hidesWhenStopped = true
        actInd.activityIndicatorViewStyle = UIActivityIndicatorViewStyle.White
        actInd.backgroundColor = UIColor.blackColor()
        actInd.layer.cornerRadius = 10
        view.addSubview(actInd)
        actInd.startAnimating()
        
        //call the SRWebclient with the url and parameters
        SRWebClient.POST("http://healthouts.com/appLoginwithAskQs?")
            .data(["message" : parameters["message"]!,"email" : parameters["email"]!,"pass" : parameters["pass"]!])
            .send({ (response, status) -> Void in
                self.actInd.stopAnimating()
                var err: NSError?
                var data = (response as! String).dataUsingEncoding(NSUTF8StringEncoding, allowLossyConversion: true)
                
                if let jsonResult = NSJSONSerialization.JSONObjectWithData(data!, options: NSJSONReadingOptions.MutableContainers, error: &err) as? NSDictionary {
                    
                    dispatch_async(dispatch_get_main_queue(), {
                        
                        if((jsonResult["status"] as! String) == "1"){
                            self.questionTextView.text = "Enter your brief question.Its anonymous and free"
                            self.questionTextView.textColor = UIColor.lightGrayColor()
                            
                            var text = jsonResult["RESULT"] as! String
                            self.showTextOverlay(text)
                            var timer = NSTimer.scheduledTimerWithTimeInterval(2, target: self, selector: Selector("removeOverlay"), userInfo: nil, repeats: false)
                            
                            self.userInfo["email"] = jsonResult["emailId"] as! String
                            self.userInfo["pass"] = jsonResult["pass"]
                            self.userInfo["type"] = jsonResult["customerType"]
                            self.userInfo["id"] = jsonResult["customerId"]
                            self.userInfo["name"] = ""
                            self.userInfo["image"] = jsonResult["cImage"]
                            
                            NSUserDefaults.standardUserDefaults().setObject(self.userInfo, forKey: "userInfo")
                            NSUserDefaults.standardUserDefaults().setBool(true, forKey: "isLoggedIn")
                            
                            
                        }else{
                            
                            var text = jsonResult["RESULT"] as! String
                            self.showTextOverlay(text)
                            var timer = NSTimer.scheduledTimerWithTimeInterval(2, target: self, selector: Selector("removeOverlay"), userInfo: nil, repeats: false)
                            
                        }
                        
                    })
                    
                }else{
                    self.addAlert(err!.localizedDescription)
                }
                
            }, failure: { (error) -> Void in
                self.actInd.stopAnimating()
                self.addAlert(error.localizedDescription)
            })

    }
    
    //decrease the size of question textview when the keyboard is shown
    func keyboardWasShown(notification:NSNotification){
        if let userInfo = notification.userInfo {
            if let keyboardSize = (userInfo[UIKeyboardFrameBeginUserInfoKey] as? NSValue)?.CGRectValue() {
                
                if(sendButton.frame.origin.y + sendButton.frame.size.height - (self.view.frame.size.height - keyboardSize.size.height) > -1){
                    //println(296 - keyboardSize.size.height)
                    var height = self.questionTextView.frame.size.height - 40
                    self.textViewHeightConstraint.constant = height
                    isCompressed = true
                }
                // ...
            } else {
                // no UIKeyboardFrameBeginUserInfoKey entry in userInfo
            }
        } else {
            // no userInfo dictionary in notification
        }
    }
    
    func keyboardWillBeHidden(notification:NSNotification){
        if(isCompressed){
            var height = self.questionTextView.frame.size.height + 40
            self.textViewHeightConstraint.constant = height
        }
    }
    
    //detect touches to resign the textfield
    override func touchesBegan(touches: Set<NSObject>, withEvent event: UIEvent) {
        questionTextView.resignFirstResponder()
    }
    
    //textfield delegate methods
    func textViewDidBeginEditing(textView: UITextView) {
        if(textView.text == "Enter your brief question.Its anonymous and free"){
            textView.text = ""
            textView.textColor = UIColor.blackColor()
        }
        
    }

    func textViewDidEndEditing(textView: UITextView) {
        if(textView.text == ""){
            textView.text = "Enter your brief question.Its anonymous and free"
            textView.textColor = UIColor.lightGrayColor()
        }
       
    }
    
    //function to limit the character count
    func textViewDidChange(textView: UITextView) {
        characterCount = textView.text.lengthOfBytesUsingEncoding(NSUTF8StringEncoding)
        characterCountLabel.text = "\(150 - characterCount) characters remaining."
    }
    
    func textView(textView: UITextView, shouldChangeTextInRange range: NSRange, replacementText text: String) -> Bool {
        if(textView.text.lengthOfBytesUsingEncoding(NSUTF8StringEncoding) - range.length + text.lengthOfBytesUsingEncoding(NSUTF8StringEncoding) > 150){
            return false
        }
        return true
    }
    
    //show menu
    @IBAction func showMenu(sender: AnyObject) {
        self.view.endEditing(true)
        self.frostedViewController.view.endEditing(true)
        self.frostedViewController.presentMenuViewController()
    }

}
