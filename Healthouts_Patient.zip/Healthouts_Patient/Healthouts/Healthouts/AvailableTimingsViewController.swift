//
//  AvailableTimingsViewController.swift
//  Healthouts
//
//  Created by Y.Bharath Kumar Reddy on 30/05/15.
//  Copyright (c) 2015 Y.Bharath Kumar Reddy. All rights reserved.
//

import UIKit



class AvailableTimingsViewController: UIViewController,UICollectionViewDataSource,UICollectionViewDelegate {

    //outlets from the storyboard
    @IBOutlet weak var cityLabel: UILabel!
    @IBOutlet weak var specialityLabel: UILabel!
    @IBOutlet weak var nameLabel: UILabel!
    @IBOutlet weak var collectionView: UICollectionView!
    @IBOutlet weak var navBarView: UIView!
    
    //required variables
    var doctorProfile:NSDictionary!
    var selectedDoctorId:String!
    var data:NSDictionary = [:]
    var date:NSDate!
    var dateString:String!
    var selectedslot:Int!
    var timingsArray = ["10:00","10:30","11:00","11:30","12:00","12:30","05:00","05:30","06:00","06:30","07:00","07:30","08:00","08:30"]
    var actInd : UIActivityIndicatorView = UIActivityIndicatorView(frame: CGRectMake(0,0, 50, 50)) as UIActivityIndicatorView
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        collectionView.backgroundColor = UIColor.clearColor()
        
        //set the navigation bar properties
        navBarView.layer.shadowColor = UIColor.blackColor().CGColor
        navBarView.layer.shadowOffset = CGSizeMake(0.5, 0.5)
        navBarView.layer.shadowRadius = 3.0
        navBarView.layer.shadowOpacity = 1.0
        
        //register the Timings cell
        var nib = UINib(nibName: "TimingsCollectionViewCell", bundle: nil)
        collectionView.registerNib(nib, forCellWithReuseIdentifier: "TimingsCell")
        
        
        //other initialisations
        if let city = doctorProfile["city"] as? String{
            self.cityLabel.text = city
        }else{
            self.cityLabel.text = ""
        }
        
        if let specialization = doctorProfile["specialization"] as? String{
            self.specialityLabel.text = specialization
        }else{
            self.specialityLabel.text = ""
        }
        
        if let name = doctorProfile["name"] as? String{
            self.nameLabel.text = name
        }else{
            self.nameLabel.text = ""
        }
        
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    override func viewWillAppear(animated: Bool) {
        super.viewWillAppear(true)
        
        getData()
    }
   
 
    //get the data
    func getData(){
        //start the activity indicator
        actInd.center = self.view.center
        actInd.hidesWhenStopped = true
        actInd.activityIndicatorViewStyle = UIActivityIndicatorViewStyle.White
        actInd.backgroundColor = UIColor.blackColor()
        actInd.layer.cornerRadius = 5
        view.addSubview(actInd)
        actInd.startAnimating()
        
        var doctorId = selectedDoctorId
        var dateformatter = NSDateFormatter()
        dateformatter.dateFormat = "yyyy-MM-dd"
        dateString = dateformatter.stringFromDate(date)
        
        //call the SRWebclient with the url and parameters
        SRWebClient.POST("http://healthouts.com/appDocAvailability?")
            .data(["doctorId" : doctorId,"strDate" : dateString])
            .send({ (response, status) -> Void in
                
                self.actInd.stopAnimating()
                var err: NSError?
                var data = (response as! String).dataUsingEncoding(NSUTF8StringEncoding, allowLossyConversion: true)
                
                if let jsonResult = NSJSONSerialization.JSONObjectWithData(data!, options: NSJSONReadingOptions.MutableContainers, error: &err) as? NSDictionary {
                    
                        dispatch_async(dispatch_get_main_queue(), {
                            self.data = jsonResult
                            self.collectionView.reloadData()
                        })
                    
                }else{
                    self.addAlert(err!.localizedDescription)
                }
                
            }, failure: { (error) -> Void in
                self.actInd.stopAnimating()
                self.addAlert(error.localizedDescription)
            })

    }

    //function to add alert
    func addAlert(message:String){
        var alert = UIAlertController(title: "Alert", message: message, preferredStyle: UIAlertControllerStyle.Alert)
        alert.addAction(UIAlertAction(title: "ok", style: UIAlertActionStyle.Default, handler: nil))
        self.presentViewController(alert, animated: true, completion: nil)
    }
    
    //number of items
    func collectionView(collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        return timingsArray.count
    }
    
    //populate the collection view
    func collectionView(collectionView: UICollectionView, cellForItemAtIndexPath indexPath: NSIndexPath) -> UICollectionViewCell {
        var identifier = "TimingsCell"
        var cell = collectionView.dequeueReusableCellWithReuseIdentifier(identifier, forIndexPath: indexPath) as! TimingsCollectionViewCell
        cell.timeLabel.textColor = UIColor.whiteColor()
        cell.stateLabel.textColor = UIColor.whiteColor()
        cell.timeLabel.text = timingsArray[indexPath.row] as? String
        if(indexPath.row < 4){
            cell.stateLabel.text = "AM"
        }else{
            cell.stateLabel.text = "PM"
        }
        
        var timeslot = "tp" + "\(indexPath.row + 1)"
        if let bool = data["\(timeslot)"]{
            if((bool) as! NSObject == 1){
                cell.backgroundColor = UIColor.greenColor()
            }else{
                cell.backgroundColor = UIColor(red: 204/255, green: 204/255, blue: 204/255, alpha: 0.1)
            }
        }
        return cell
    }
    
    //handle selections in the collectionView
    func collectionView(collectionView: UICollectionView, didSelectItemAtIndexPath indexPath: NSIndexPath) {
        var timeslot = "tp" + "\(indexPath.row + 1)"
        if let bool = data["\(timeslot)"]{
            if((bool) as! NSObject == 1){
                selectedslot = indexPath.row + 1
         
                if(NSUserDefaults.standardUserDefaults().boolForKey("isLoggedIn")){
                    self.performSegueWithIdentifier("BookingConfirmation", sender: self)
                }else{
                   self.performSegueWithIdentifier("Login", sender: self)
                }
            }else{
                var text = "Not Available"
                self.showTextOverlay(text)
                var timer = NSTimer.scheduledTimerWithTimeInterval(2, target: self, selector: Selector("removeOverlay"), userInfo: nil, repeats: false)
            }
        }
    }
    
    //pass the data before performing segue
    override func prepareForSegue(segue: UIStoryboardSegue, sender: AnyObject?) {
        if(segue.identifier == "Login"){
            
            var destViewController = segue.destinationViewController as! LoginViewController
            destViewController.doctorTimeId = data["doctorTimeId"]?.stringValue
            destViewController.selectedDate = data["date"] as! String
            destViewController.doctorId = self.selectedDoctorId
            destViewController.timeslot = (selectedslot as NSNumber).stringValue
            
        }else if(segue.identifier == "BookingConfirmation"){
            
            var destViewController = segue.destinationViewController as! BookingConfirmationViewController
            destViewController.doctorTimeId = data["doctorTimeId"]?.stringValue
            destViewController.selectedDate = data["date"] as! String
            destViewController.doctorId = self.selectedDoctorId
            destViewController.timeslot = (selectedslot as NSNumber).stringValue
            if let name = doctorProfile["name"] as? String{
                destViewController.doctorName = name
            }else{
                destViewController.doctorName = ""
            }
            
            if let specialization = doctorProfile["specialization"] as? String{
                 destViewController.specialization = specialization
            }else{
                destViewController.specialization = ""
            }
            
            if let city = doctorProfile["city"] as? String{
                destViewController.city = city
            }else{
                destViewController.city = ""
            }
            
            if let imgPath = doctorProfile["imagePath"] as? String{
                destViewController.imagePath = imgPath
            }else{
                destViewController.imagePath = ""
            }
            
        }
    }
    
    //handle back button press
    @IBAction func backButtonPressed(sender: AnyObject) {
         self.navigationController?.popViewControllerAnimated(true)
    }
    
    //go to home
    @IBAction func homeButtonPressed(sender: AnyObject) {
        
        var destViewController = self.storyboard?.instantiateInitialViewController() as! RootViewController
        self.presentViewController(destViewController, animated: true, completion: nil)
    }
    
    
    func removeOverlay(){
        self.removeAllOverlays()
    }
    
    
    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepareForSegue(segue: UIStoryboardSegue, sender: AnyObject?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}
