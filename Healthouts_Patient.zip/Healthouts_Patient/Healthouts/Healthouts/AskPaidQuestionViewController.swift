//
//  AskPaidQuestionViewController.swift
//  Healthouts
//
//  Created by Y.Bharath Kumar Reddy on 10/06/15.
//  Copyright (c) 2015 Y.Bharath Kumar Reddy. All rights reserved.
//

import UIKit
import MobileCoreServices

class AskPaidQuestionViewController: UIViewController,UITextViewDelegate,UITextFieldDelegate,UIImagePickerControllerDelegate,UINavigationControllerDelegate {

    //outlets
    @IBOutlet weak var contentView: UIView!
    @IBOutlet weak var scrollView: UIScrollView!
    @IBOutlet weak var doctorImageView: UIImageView!
    @IBOutlet weak var nameLabel: UILabel!
    @IBOutlet weak var specialityLabel: UILabel!
    @IBOutlet weak var subjectTextField: UITextField!
    @IBOutlet weak var progressView: UIProgressView!
    @IBOutlet weak var doctorProfileView: UIView!
    @IBOutlet weak var messageTextView: UITextView!
    @IBOutlet weak var selectedFileNameLabel: UILabel!
    
    //required variables
    var chosenImage:UIImage?
    var actInd : UIActivityIndicatorView = UIActivityIndicatorView(frame: CGRectMake(0,0, 50, 50)) as UIActivityIndicatorView
    var doctorName = ""
    var speciality = ""
    var doctorImage = UIImage()
    var doctorId = ""
    var imagePicker = UIImagePickerController()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        imagePicker.delegate = self
    
        //set constraints for the content view
        var leftConstraint = NSLayoutConstraint(item: self.contentView, attribute: NSLayoutAttribute.Leading, relatedBy: NSLayoutRelation.Equal, toItem: self.view, attribute: NSLayoutAttribute.Left, multiplier: 1, constant: 0)
        self.view.addConstraint(leftConstraint)
        
        var rightConstraint = NSLayoutConstraint(item: self.contentView, attribute: NSLayoutAttribute.Trailing, relatedBy: NSLayoutRelation.Equal, toItem: self.view, attribute: NSLayoutAttribute.Right, multiplier: 1, constant: 0)
        self.view.addConstraint(rightConstraint)
        
        
        //add keyboard notifications
        NSNotificationCenter.defaultCenter().addObserver(self, selector: "keyboardWillBeShown:", name: UIKeyboardWillShowNotification, object: nil)
        NSNotificationCenter.defaultCenter().addObserver(self, selector: "keyboardWillBeHidden:", name: UIKeyboardWillHideNotification, object: nil)
        
        
        //initialise other variables
        nameLabel.text = doctorName
        specialityLabel.text = speciality
        doctorImageView.image = doctorImage
        
        subjectTextField.delegate = self
        messageTextView.delegate = self
        
        messageTextView.textColor = UIColor.lightGrayColor()
        messageTextView.layer.borderColor = UIColor.lightGrayColor().CGColor
        messageTextView.layer.borderWidth = 0.5
        messageTextView.layer.cornerRadius = 5
        
        doctorProfileView.layer.cornerRadius = 5
        
        doctorImageView.layer.cornerRadius = 50
        doctorImageView.layer.masksToBounds = true
        
        //add tap recogniser
        var tapGestureRecogniser = UITapGestureRecognizer(target: self, action: "tapReceived:")
        self.view.addGestureRecognizer(tapGestureRecogniser)
 
        
        // Do any additional setup after loading the view.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    
    //resign first responder on tap
    func tapReceived(tapGestureRecogniser:UITapGestureRecognizer){
            subjectTextField.resignFirstResponder()
            messageTextView.resignFirstResponder()
    }
    
    //choose file from images
    @IBAction func chooseFileButtonpressed(sender: AnyObject) {
        
        
        let optionMenu = UIAlertController(title: nil, message: "Choose Option", preferredStyle: UIAlertControllerStyle.ActionSheet)
        
        let selectImageAction = UIAlertAction(title: "Choose Image", style: .Default, handler: {
            (alert: UIAlertAction!) -> Void in
            if UIImagePickerController.isSourceTypeAvailable(UIImagePickerControllerSourceType.SavedPhotosAlbum){
                self.imagePicker.sourceType = UIImagePickerControllerSourceType.SavedPhotosAlbum;
                self.imagePicker.allowsEditing = false
                self.presentViewController(self.imagePicker, animated: true, completion: nil)
            }
        })
        
        /*
        let selectFileAction = UIAlertAction(title: "Choose File", style: .Default, handler: {
            (alert: UIAlertAction!) -> Void in
            var documentsPath = NSSearchPathForDirectoriesInDomains(NSSearchPathDirectory.DocumentDirectory, NSSearchPathDomainMask.UserDomainMask, true)[0] as! String
            var error:NSError!
            var files = NSFileManager.defaultManager().contentsOfDirectoryAtPath(documentsPath, error: nil)
        })
        */
        
        let cancelAction = UIAlertAction(title: "Cancel", style: .Cancel, handler: {
            (alert: UIAlertAction!) -> Void in
            
        })
        
        optionMenu.addAction(selectImageAction)
        //optionMenu.addAction(selectFileAction)
        optionMenu.addAction(cancelAction)
        
        self.presentViewController(optionMenu, animated: true, completion: nil)
  
    }
    
    //image picker delegate method
    //called after image is selected
    func imagePickerController(picker: UIImagePickerController, didFinishPickingImage image: UIImage!, editingInfo: [NSObject : AnyObject]!) {
        chosenImage = image
        selectedFileNameLabel.text = "file selected"
        self.dismissViewControllerAnimated(true, completion: { () -> Void in
            
        })
        
    }
    
    //image picker delegate method
    //called when cancel is pressed
    func imagePickerControllerDidCancel(picker: UIImagePickerController) {
        self.dismissViewControllerAnimated(true, completion: { () -> Void in
            
        })
    }
    
    //call the paid question service url
    @IBAction func sendButtonPressed(sender: AnyObject) {
        
        
        if(subjectTextField.text == "" || messageTextView.text == "Message"){
            var alert = UIAlertController(title: "Alert", message: "Fill in both the fields", preferredStyle: UIAlertControllerStyle.Alert)
            alert.addAction(UIAlertAction(title: "ok", style: UIAlertActionStyle.Default, handler: nil))
            self.presentViewController(alert, animated: true, completion: nil)
            return
        }
        
        //start the activity indicator
        actInd.center = self.view.center
        actInd.hidesWhenStopped = true
        actInd.activityIndicatorViewStyle = UIActivityIndicatorViewStyle.White
        actInd.backgroundColor = UIColor.blackColor()
        actInd.layer.cornerRadius = 10
        view.addSubview(actInd)
        actInd.startAnimating()
        
        //prepare the data to be sent
        var userData = NSUserDefaults.standardUserDefaults().objectForKey("userInfo") as! NSDictionary
        var customerId = String((userData["id"]! as! Int))
        var customerEmail = userData["email"] as! String
        var subject = self.subjectTextField.text as String
        var message = messageTextView.text as String
        
        //check if image is selected or not
        //and proceed accordingly
        if(chosenImage != nil){
            
            var imageData = UIImageJPEGRepresentation(chosenImage,1.0)
            
            //call the SRWebclient with the url and parameters
            SRWebClient.POST("http://healthouts.com/appsendPaidMessageToDoctor?")
                .data(imageData, fieldName: "healthFile", data: ["CID":customerId,"cEmail":customerEmail,"doctorId":doctorId,"qSubject":subject,"qMessage":message])
                .send({ (response:AnyObject!, status:Int) -> Void in
            
                    self.actInd.stopAnimating()
                    var err: NSError?
                    var data = (response as! String).dataUsingEncoding(NSUTF8StringEncoding, allowLossyConversion: true)
                    if let jsonResult = NSJSONSerialization.JSONObjectWithData(data!, options: NSJSONReadingOptions.MutableContainers, error: &err) as? NSDictionary {
                        dispatch_async(dispatch_get_main_queue(), {
                            if(jsonResult["status"] as! String == "1"){
                                self.subjectTextField.text = ""
                                self.messageTextView.text = "Message"
                            
                                var text = jsonResult["message"] as! String
                                self.showTextOverlay(text)
                                var timer = NSTimer.scheduledTimerWithTimeInterval(2, target: self, selector: Selector("removeOverlay"), userInfo: nil, repeats: false)
                    
                            }else{
                                var text = "Your question could not be sent"
                                self.showTextOverlay(text)
                                var timer = NSTimer.scheduledTimerWithTimeInterval(2, target: self, selector: Selector("removeOverlay"), userInfo: nil, repeats: false)
                            }
                        })
                    }else{
                        self.addAlert(err!.localizedDescription)
                    }
                }, failure: { (error) -> Void in
                    var text = error.localizedDescription
                    self.showTextOverlay(text)
                    var timer = NSTimer.scheduledTimerWithTimeInterval(2, target: self, selector: Selector("removeOverlay"), userInfo: nil, repeats: false)
                })
        }else{
            
            //call the SRWebclient with the url and parameters
            SRWebClient.POST("http://healthouts.com/appsendPaidMessageToDoctor?")
            .data(["CID":customerId,"cEmail":customerEmail,"doctorId":doctorId,"qSubject":subject,"qMessage":message])
            .send({ (response:AnyObject!, status:Int) -> Void in
                self.actInd.stopAnimating()
                var err: NSError?
                var data = (response as! String).dataUsingEncoding(NSUTF8StringEncoding, allowLossyConversion: true)
                if let jsonResult = NSJSONSerialization.JSONObjectWithData(data!, options: NSJSONReadingOptions.MutableContainers, error: &err) as? NSDictionary {
                    dispatch_async(dispatch_get_main_queue(), {
                        if(jsonResult["status"] as! String == "1"){
                            var text = jsonResult["message"] as! String
                            self.showTextOverlay(text)
                            var timer = NSTimer.scheduledTimerWithTimeInterval(2, target: self, selector: Selector("removeOverlay"), userInfo: nil, repeats: false)
                        
                        }else{
                            var text = "Your question could not be sent"
                            self.showTextOverlay(text)
                            var timer = NSTimer.scheduledTimerWithTimeInterval(2, target: self, selector: Selector("removeOverlay"), userInfo: nil, repeats: false)
                        }
                    })
                }else{
                    self.addAlert(err!.localizedDescription)
                }
            }, failure: { (error) -> Void in
                var text = error.localizedDescription
                self.showTextOverlay(text)
                var timer = NSTimer.scheduledTimerWithTimeInterval(2, target: self, selector: Selector("removeOverlay"), userInfo: nil, repeats: false)
            })
        }
    }
    
    //function to add alert
    func addAlert(message:String){
        var alert = UIAlertController(title: "Alert", message: message, preferredStyle: UIAlertControllerStyle.Alert)
        alert.addAction(UIAlertAction(title: "ok", style: UIAlertActionStyle.Default, handler: nil))
        self.presentViewController(alert, animated: true, completion: nil)
    }
    
    func removeOverlay(){
        self.removeAllOverlays()
        
    }
 
    //keyboard notification seletors
    //these are called when the keyboard is about to be shown and when it is about to be removed
    //these are used to adjust the scrollview accordingly
    func keyboardWillBeHidden(notification:NSNotification){
        var contentInsets = UIEdgeInsetsZero
        self.scrollView.contentInset = contentInsets
        self.scrollView.scrollIndicatorInsets = contentInsets
    }
    
    func keyboardWillBeShown(notification:NSNotification){
        if let userInfo = notification.userInfo {
            if let keyboardSize = (userInfo[UIKeyboardFrameBeginUserInfoKey] as? NSValue)?.CGRectValue() {
                var contentInsets = UIEdgeInsetsMake(0, 0, keyboardSize.height, 0)
                self.scrollView.contentInset = contentInsets
                self.scrollView.scrollIndicatorInsets = contentInsets
                var rect = self.contentView.frame
                rect.size.height -= keyboardSize.height
                if (!CGRectContainsPoint(rect, self.subjectTextField.frame.origin) && self.subjectTextField.isFirstResponder()) {
                    var scrollPoint = CGPointMake(0.0, self.subjectTextField.frame.origin.y - (keyboardSize.height - self.subjectTextField.frame.size.height))
                    self.scrollView.setContentOffset(scrollPoint, animated: false)
                }else{
            
                    var scrollPoint = CGPointMake(0.0, self.messageTextView.frame.origin.y - (keyboardSize.height - self.messageTextView.frame.size.height))
                    self.scrollView.setContentOffset(scrollPoint, animated: false)
                }
            }
        }
        
        
    }
    
    //go to home
    @IBAction func homeButtonPressed(sender: AnyObject) {
        
        self.navigationController?.popToRootViewControllerAnimated(true)
        /*var destViewController = self.storyboard?.instantiateInitialViewController() as! RootViewController
        self.presentViewController(destViewController, animated: true, completion: nil)*/
    }
    
    //textfield delegate methods
    func textFieldShouldReturn(textField: UITextField) -> Bool {
        if(textField.isFirstResponder()){
            textField.resignFirstResponder()
        }
        return true
    }
    
    func textViewDidBeginEditing(textView: UITextView) {
        
        if(textView.text == "Message"){
            textView.text = ""
            textView.textColor = UIColor.blackColor()
        }
        
    }
    
    func textViewDidEndEditing(textView: UITextView) {
        if(textView.text == ""){
            textView.text = "Message"
            textView.textColor = UIColor.lightGrayColor()
        }
        
    }
    
    
    //handle back button press
    @IBAction func backButtonPressed(sender: AnyObject) {
         self.navigationController?.popViewControllerAnimated(true)
    }

}


