//
//  MyQuestionsViewController.swift
//  Healthouts
//
//  Created by Y.Bharath Kumar Reddy on 09/06/15.
//  Copyright (c) 2015 Y.Bharath Kumar Reddy. All rights reserved.
//

import UIKit

class MyQuestionsViewController: UIViewController,UITableViewDataSource,UITableViewDelegate {
    
    //required variables
    var tableData:NSMutableArray = []
    var actInd : UIActivityIndicatorView = UIActivityIndicatorView(frame: CGRectMake(0,0, 50, 50)) as UIActivityIndicatorView
    var imageCache = [String:UIImage]()
    var selectedIndex = NSIndexPath()
    var isPresentedFromDismissed = false
    var myRowHeightEstimateCache = [String:CGFloat]()
    
    //outlets
    @IBOutlet weak var tableView: UITableView!
    @IBOutlet weak var navBarView: UIView!
 
    override func viewDidLoad() {
        super.viewDidLoad()
        //set navbar properties
        navBarView.layer.shadowColor = UIColor.blackColor().CGColor
        navBarView.layer.shadowOffset = CGSizeMake(0.5, 0.5)
        navBarView.layer.shadowRadius = 3.0
        navBarView.layer.shadowOpacity = 1.0
        
        self.view.addGestureRecognizer(UIPanGestureRecognizer(target: self, action: "panGestureRecognized:"))
        
        //register the custom cell
        var nib = UINib(nibName: "MyQuestionsTableViewCell", bundle: nil)
        tableView.registerNib(nib, forCellReuseIdentifier: "MyQuestionsCell")
        
        self.tableView.hidden = true
        // Do any additional setup after loading the view.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    
    func panGestureRecognized(sender:UIPanGestureRecognizer){
        //if(sender.state == UIPanGestureRecognizerdirection)
        var vel = sender.velocityInView(self.view)
        if(vel.x > 0){
            self.view.endEditing(true)
            self.frostedViewController.view.endEditing(true)
            self.frostedViewController.presentMenuViewController()
        }
        //self.frostedViewController.panGestureRecognized(sender)
    }
    
    
    override func viewWillAppear(animated: Bool) {
        super.viewWillAppear(true)
        self.tabBarController?.tabBar.hidden = false
        if(!isPresentedFromDismissed){
        if(NSUserDefaults.standardUserDefaults().boolForKey("isLoggedIn")){
            getData()
        }else{
            var text = "Please login to view your questions"
            self.showTextOverlay(text)
            var timer = NSTimer.scheduledTimerWithTimeInterval(2, target: self, selector: Selector("removeOverlay"), userInfo: nil, repeats: false)
        }
        }else{
            isPresentedFromDismissed = false
        }
    }
    
    
    //get the data
    func getData(){
        //start the activity indicator
        actInd.center = self.view.center
        actInd.hidesWhenStopped = true
        actInd.activityIndicatorViewStyle = UIActivityIndicatorViewStyle.White
        actInd.backgroundColor = UIColor.blackColor()
        actInd.layer.cornerRadius = 10
        view.addSubview(actInd)
        actInd.startAnimating()
        
        //prepare the data to be sent
        var userData = NSUserDefaults.standardUserDefaults().objectForKey("userInfo") as! NSDictionary
        var userEmail = userData["email"] as? String
        var userId = userData["id"]
        
        //call the SRWebclient with the url and parameters
        SRWebClient.POST("http://healthouts.com/appGetYourFreeQs?")
            .data(["CId" : userId!,"CEmail" : userEmail!])
            .send({ (response, status) -> Void in
                
                self.actInd.stopAnimating()
                var err: NSError?
                var data = (response as! String).dataUsingEncoding(NSUTF8StringEncoding, allowLossyConversion: true)
                
                if let jsonResult = NSJSONSerialization.JSONObjectWithData(data!, options: NSJSONReadingOptions.MutableContainers, error: &err) as? NSMutableArray {
                    
                        dispatch_async(dispatch_get_main_queue(), {
                            
                            self.tableData.removeAllObjects()
                            self.tableData = jsonResult
                            
                            if(self.tableData.count != 0){
                                
                                self.tableView.hidden = false
                                self.tableView.reloadData()
                                
                            }else{
                                self.tableView.hidden = true
                                self.tableView.reloadData()
                                var text = "You have not asked any questions"
                                self.showTextOverlay(text)
                                var timer = NSTimer.scheduledTimerWithTimeInterval(2, target: self, selector: Selector("removeOverlay"), userInfo: nil, repeats: false)
                            }
                            
                        })
                    
                    }else{
                        self.addAlert(err!.localizedDescription)
                    }
                
            }, failure: { (error) -> Void in
                self.actInd.stopAnimating()
                self.addAlert(error.localizedDescription)
            })

    }
    
    //function to add alert
    func addAlert(message:String){
        var alert = UIAlertController(title: "Alert", message: message, preferredStyle: UIAlertControllerStyle.Alert)
        alert.addAction(UIAlertAction(title: "ok", style: UIAlertActionStyle.Default, handler: nil))
        self.presentViewController(alert, animated: true, completion: nil)
    }
    
    //populate the tableview
    func tableView(tableView: UITableView, cellForRowAtIndexPath indexPath: NSIndexPath) -> UITableViewCell {
        var identifier = "MyQuestionsCell"
        var cell:MyQuestionsTableViewCell  = tableView.dequeueReusableCellWithIdentifier(identifier) as! MyQuestionsTableViewCell
        cell.selectionStyle = UITableViewCellSelectionStyle.None
        
        cell.containerView.layer.cornerRadius = 5
        cell.containerView.layer.zPosition = 5
        
        cell.userImageView.layer.cornerRadius = 27.5
        cell.userImageView.layer.masksToBounds = true
        
        var questionData:NSMutableArray = tableData[indexPath.row] as! NSMutableArray
        var questionInfo:NSDictionary = questionData[0] as! NSDictionary
        
        cell.dateLabel.text = questionInfo.objectForKey("qsDate") as? String
        cell.questionLabel.text = questionInfo.objectForKey("questionBody") as? String
        
        if let image = questionInfo.objectForKey("cImage") as? String{
            var imgPath = "http://healthouts.com/img/" + image.stringByReplacingOccurrencesOfString(" ", withString: "%20") as String
            var imgUrl = NSURL(string: imgPath)
            
            if let img = imageCache[imgPath]{
                cell.userImageView.image = img
            }else{
                SDWebImageDownloader.sharedDownloader().downloadImageWithURL(imgUrl, options: nil, progress: { (receivedSize:Int, expectedSize:Int) -> Void in
                    
                    }) { (image, data, error, finished) -> Void in
                        if(error != nil){
                            cell.userImageView.image = UIImage(named: "dummydp")
                        }else{
                            cell.userImageView.image = image
                            self.imageCache[imgPath] = image
                        }
                }
            }
        }else{
            cell.userImageView.image = UIImage(named: "dummydp")
        }
            
        //cell.setNeedsUpdateConstraints()
        //cell.updateConstraintsIfNeeded()
        
        return cell

    }

    //number of rows in the tableview
    func tableView(tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return tableData.count
    }
    
    func removeOverlay(){
        self.removeAllOverlays()
    }
    
    //show side menu
    @IBAction func showMenu(sender: AnyObject) {
        self.view.endEditing(true)
        self.frostedViewController.view.endEditing(true)
        self.frostedViewController.presentMenuViewController()
    }
    
    //handle selections in tableview
    func tableView(tableView: UITableView, didSelectRowAtIndexPath indexPath: NSIndexPath) {
        selectedIndex = indexPath
        dispatch_async(dispatch_get_main_queue(),{
            self.performSegueWithIdentifier("ShowAnswer", sender: self)
        })
    }
    
    //pass data
    override func prepareForSegue(segue: UIStoryboardSegue, sender: AnyObject?) {
        var destViewController = segue.destinationViewController as! AnswersViewController
        var questionData:NSMutableArray = tableData[selectedIndex.row] as! NSMutableArray
        var questionInfo:NSDictionary = questionData[0] as! NSDictionary
        destViewController.questionInfo = questionInfo
        
        var answerInfo = questionData[1] as! NSArray
        destViewController.answerInfo = answerInfo
    }
    
    //unwind segue
    @IBAction func answerDismissed(segue:UIStoryboardSegue){
        isPresentedFromDismissed = true
    }
    
    
    //row height cache for the tableview
    func tableView(tableView: UITableView, didEndDisplayingCell cell: UITableViewCell, forRowAtIndexPath indexPath: NSIndexPath) {
        myRowHeightEstimateCache["\(indexPath.row)"] = CGRectGetHeight(cell.frame)
    }
    
    //estimated height for the row
    func tableView(tableView: UITableView, estimatedHeightForRowAtIndexPath indexPath: NSIndexPath) -> CGFloat {
        if let height = myRowHeightEstimateCache["\(indexPath.row)"]
        {
            return height
        }
        else
        {
            return 100
        }
    }
    
    //height for the row
    func tableView(tableView: UITableView, heightForRowAtIndexPath indexPath: NSIndexPath) -> CGFloat {
        return UITableViewAutomaticDimension
    }
    

}
