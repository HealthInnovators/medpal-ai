//
//  ImmunizationTableViewCell.swift
//  Healthouts
//
//  Created by Y.Bharath Kumar Reddy on 16/07/15.
//  Copyright (c) 2015 Y.Bharath Kumar Reddy. All rights reserved.
//

import UIKit

protocol ImmunizationServicesDelegate{
    func updateImmunization(button:UIButton)
    func deleteImmunization(button:UIButton)
}

class ImmunizationTableViewCell: UITableViewCell {

    @IBOutlet weak var containerView: UIView!
    @IBOutlet weak var typeLabel: UILabel!
    @IBOutlet weak var typeNameLabel: UILabel!
    @IBOutlet weak var notesLabel: UILabel!
    @IBOutlet weak var notesInfoLabel: UILabel!
    @IBOutlet weak var dateLabel: UILabel!
    @IBOutlet weak var updateButton: UIButton!
    @IBOutlet weak var deleteButton: UIButton!
    
    
    var delegate:ImmunizationServicesDelegate?
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
        
    }
    
    @IBAction func updateButtonPressed(sender: AnyObject) {
        self.delegate?.updateImmunization(sender as! UIButton)
    }
    
    @IBAction func deleteButtonPressed(sender: AnyObject) {
        self.delegate?.deleteImmunization(sender as! UIButton)
    }
    
    override func setSelected(selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)
        
        // Configure the view for the selected state
    }

}
