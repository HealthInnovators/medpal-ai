//
//  MyPaidQuestionsViewController.swift
//  Healthouts
//
//  Created by Y.Bharath Kumar Reddy on 11/06/15.
//  Copyright (c) 2015 Y.Bharath Kumar Reddy. All rights reserved.
//

import UIKit


class MyPaidQuestionsViewController: UIViewController,UITableViewDelegate,UITableViewDataSource,PaidQuestionCellDelegate,PaidQuestionAnsweredCellDelegate {

    //outlets
    @IBOutlet weak var tableView: UITableView!
    @IBOutlet weak var navBarView: UIView!
    
    //required variables
    var infoToReviewController = [:]
    var tableData:NSMutableArray = []
    var actInd : UIActivityIndicatorView = UIActivityIndicatorView(frame: CGRectMake(0,0, 50, 50)) as UIActivityIndicatorView
    //var isPresentedFromDismissed = false
    var imageCache = [String:UIImage]()
    var selectedAttachmentName = ""
    var myRowHeightEstimateCache = [String:CGFloat]()
    var selectedIndex = NSIndexPath()
    
    override func viewDidLoad() {
        super.viewDidLoad()

        //set the nav bar view properties
        navBarView.layer.shadowColor = UIColor.blackColor().CGColor
        navBarView.layer.shadowOffset = CGSizeMake(0.5, 0.5)
        navBarView.layer.shadowRadius = 3.0
        navBarView.layer.shadowOpacity = 1.0
        
        self.view.addGestureRecognizer(UIPanGestureRecognizer(target: self, action: "panGestureRecognized:"))
        
        //register the custom cells to the table view
        var nib1 = UINib(nibName: "MyPaidQuestionTableViewCell", bundle: nil)
        tableView.registerNib(nib1, forCellReuseIdentifier: "PaidQuestionCell")
        
        var nib2 = UINib(nibName: "MyPaidQuestionAnsweredTableViewCell", bundle: nil)
        tableView.registerNib(nib2, forCellReuseIdentifier: "PaidQuestionAnsweredCell")
        
        self.tableView.hidden = true
        self.tableView.rowHeight = UITableViewAutomaticDimension
        self.tableView.estimatedRowHeight = 300;
        // Do any additional setup after loading the view.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    override func viewWillAppear(animated: Bool) {
        super.viewWillAppear(true)
        //if(!isPresentedFromDismissed){
            
            if(NSUserDefaults.standardUserDefaults().boolForKey("isLoggedIn")){
                getData()
            }else{
                var text = "Please login to view your questions"
                self.showTextOverlay(text)
                var timer = NSTimer.scheduledTimerWithTimeInterval(2, target: self, selector: Selector("removeOverlay"), userInfo: nil, repeats: false)
            }
       // }else{
         //   isPresentedFromDismissed = false
        //}
    }

    //call the GetPaidQuestions service url
    func getData(){
        
        //start the activity indicator
        actInd.center = self.view.center
        actInd.hidesWhenStopped = true
        actInd.activityIndicatorViewStyle = UIActivityIndicatorViewStyle.White
        actInd.backgroundColor = UIColor.blackColor()
        actInd.layer.cornerRadius = 10
        view.addSubview(actInd)
        actInd.startAnimating()
        
        //prepare the data to be sent
        var userData = NSUserDefaults.standardUserDefaults().objectForKey("userInfo") as! NSDictionary
        var userEmail = userData["email"] as? String
        var userId = userData["id"] as? Int
        
        //call the SRWebclient with the url and parameters
        SRWebClient.POST("http://healthouts.com/appGetUserPaidHistory?")
            .data(["CID" : userId!,"cEmail" : userEmail!])
            .send({ (response, status) -> Void in
                self.actInd.stopAnimating()
                var err: NSError?
                var data = (response as! String).dataUsingEncoding(NSUTF8StringEncoding, allowLossyConversion: true)
                
                if let jsonResult = NSJSONSerialization.JSONObjectWithData(data!, options: NSJSONReadingOptions.MutableContainers, error: &err) as? NSMutableArray {
                    dispatch_async(dispatch_get_main_queue(), {
                        self.tableData.removeAllObjects()
                        self.tableData = jsonResult
                        
                        if(self.tableData.count != 0){
                            self.removeChatType()
                            self.tableView.hidden = false
                            self.tableView.reloadData()
                            
                        }else{
                            self.tableView.hidden = true
                            self.tableView.reloadData()
                            var text = "You have not asked any questions"
                            self.showTextOverlay(text)
                            var timer = NSTimer.scheduledTimerWithTimeInterval(2, target: self, selector: Selector("removeOverlay"), userInfo: nil, repeats: false)
                        }
                    })
                }else{
                    self.addAlert(err!.localizedDescription)
                }
                
            }, failure: { (error) -> Void in
                self.actInd.stopAnimating()
                self.addAlert(error.localizedDescription)
            })
        
    }
    
    //function to add alert
    func addAlert(message:String){
        var alert = UIAlertController(title: "Alert", message: message, preferredStyle: UIAlertControllerStyle.Alert)
        alert.addAction(UIAlertAction(title: "ok", style: UIAlertActionStyle.Default, handler: nil))
        self.presentViewController(alert, animated: true, completion: nil)
    }
    
    //number of rows
    func tableView(tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return tableData.count - 1
    }
    
    
    //populate the tableview
    //there are 2 custom cells here
    //one is just the question i.e unanswered question
    //the other is answered question
    func tableView(tableView: UITableView, cellForRowAtIndexPath indexPath: NSIndexPath) -> UITableViewCell {
        var questionData:NSDictionary = tableData[indexPath.row] as! NSDictionary
        
        if(questionData.objectForKey("chatType") as! String == "question"){
            var identifier = "PaidQuestionCell"
            var cell  = tableView.dequeueReusableCellWithIdentifier(identifier) as! MyPaidQuestionTableViewCell
            cell.selectionStyle = UITableViewCellSelectionStyle.None
            
            cell.userNameLabel.text = questionData.objectForKey("cutomerName") as? String
            cell.questionSubjectLabel.text = questionData.objectForKey("csubject") as? String
            cell.questionBodyLabel.text = questionData.objectForKey("cdetails") as? String
            if(questionData.objectForKey("healthFile") as! String != ""){
                cell.attachmentsButton.setTitle(questionData.objectForKey("healthFile") as? String, forState: UIControlState.Normal)
            }
            cell.containerView.layer.cornerRadius = 5
            cell.containerView.layer.zPosition = 5
            
            cell.userImageView.layer.cornerRadius = 30
            cell.userImageView.layer.masksToBounds = true
            
            if let image = questionData.objectForKey("customerImg") as? String{
                var imgPath = "http://healthouts.com/img/" + (image as String).stringByReplacingOccurrencesOfString(" ", withString: "%20") as String
                var imgUrl = NSURL(string: imgPath)
                if let img = imageCache[imgPath]{
                    cell.userImageView.image = img
                }else{
                    SDWebImageDownloader.sharedDownloader().downloadImageWithURL(imgUrl, options: nil, progress: { (receivedSize:Int, expectedSize:Int) -> Void in
                        
                        }) { (image, data, error, finished) -> Void in
                            if(error != nil){
                                cell.userImageView.image = UIImage(named: "dummydp")
                            }else{
                                
                                cell.userImageView.image = image
                                self.imageCache[imgPath] = image
                            }
                    }
                }
            }else{
                cell.userImageView.image = UIImage(named: "dummydp")
            }
            
            cell.delegate = self
            
            return cell
    
        }else{
            
            var identifier = "PaidQuestionAnsweredCell"
            var cell  = tableView.dequeueReusableCellWithIdentifier(identifier) as! MyPaidQuestionAnsweredTableViewCell
            cell.selectionStyle = UITableViewCellSelectionStyle.None
            
            cell.containerView.layer.cornerRadius = 5
            cell.containerView.layer.zPosition = 5
            
            cell.userImageView.layer.cornerRadius = 30
            cell.userImageView.layer.masksToBounds = true
            
            cell.sendReviewButton.layer.cornerRadius = 5
            if(questionData.objectForKey("reviewStatus") as! Bool == true){
                cell.sendReviewButton.hidden = true
            }else{
                cell.sendReviewButton.hidden = false
            }
            cell.doctorImageView.layer.cornerRadius = 30
            cell.doctorImageView.layer.masksToBounds = true
            cell.userNameLabel.text = questionData.objectForKey("cutomerName") as? String
            cell.questionSubjectLabel.text = questionData.objectForKey("csubject") as? String
            cell.questionBodyLabel.text = questionData.objectForKey("cdetails") as? String
            if(questionData.objectForKey("healthFile") as! String != ""){
                cell.attachmentsButton.setTitle(questionData.objectForKey("healthFile") as? String, forState: UIControlState.Normal)
            }
            
            cell.doctorNameLabel.text = questionData.objectForKey("dname") as? String
            
            cell.answerSubjectLabel.text = questionData.objectForKey("doctorSubject") as? String
            cell.answerBodyLabel.text = questionData.objectForKey("doctorAnswer") as? String
            
            if let image = questionData.objectForKey("dImgPath") as? String{
                var imgPath = "http://healthouts.com/img/" + (image as String).stringByReplacingOccurrencesOfString(" ", withString: "%20") as String
                var imgUrl = NSURL(string: imgPath)
                if let img = imageCache[imgPath]{
                    cell.doctorImageView.image = img
                }else{
                    SDWebImageDownloader.sharedDownloader().downloadImageWithURL(imgUrl, options: nil, progress: { (receivedSize:Int, expectedSize:Int) -> Void in
                        
                        }) { (image, data, error, finished) -> Void in
                            if(error != nil){
                                cell.doctorImageView.image = UIImage(named: "doctoricon")
                            }else{
                                
                                cell.doctorImageView.image = image
                                self.imageCache[imgPath] = image
                            }
                    }
                }
            }else{
                cell.doctorImageView.image = UIImage(named: "doctoricon")
            }

            
            if let image = questionData.objectForKey("customerImg") as? String{
                var imgPath = "http://healthouts.com/img/" + (image as String).stringByReplacingOccurrencesOfString(" ", withString: "%20") as String
                var imgUrl = NSURL(string: imgPath)
                if let img = imageCache[imgPath]{
                    cell.userImageView.image = img
                }else{
                    SDWebImageDownloader.sharedDownloader().downloadImageWithURL(imgUrl, options: nil, progress: { (receivedSize:Int, expectedSize:Int) -> Void in
                        
                        }) { (image, data, error, finished) -> Void in
                            if(error != nil){
                                cell.userImageView.image = UIImage(named: "dummydp")
                            }else{
                                
                                cell.userImageView.image = image
                                self.imageCache[imgPath] = image
                            }
                    }
                }
            }else{
                cell.userImageView.image = UIImage(named: "dummydp")
            }

            
            
            cell.delegate = self

            return cell
        }
       
    }
    
    
    //remove the objects with chat type = "chat"
    func removeChatType(){
        var i = 0
        var processedData = NSMutableArray()
        for(i=0;i<tableData.count - 1;i++){
            var questionData = tableData[i] as! NSDictionary
            if(questionData.objectForKey("chatType") as! String != "chat"){
                processedData.addObject(questionData)
            }
        }
        processedData.addObject(tableData[tableData.count - 1])
        tableData.removeAllObjects()
        tableData = processedData
    }
    
    
    

    
    //called when show attachment button is pressed
    func showAttachment(attachmentName:String) {
        if(attachmentName == "No Attachments"){
            
        }else{
           
            self.saveImage(attachmentName)
            self.selectedAttachmentName = attachmentName
            performSegueWithIdentifier("ShowAttachment", sender: self)
            
        }
        
    }
    
    //send review pressed
    func sendReview(button:UIButton) {
        var buttonFrame = button.convertRect(button.bounds, toView: self.tableView)
        var indexPath = self.tableView.indexPathForRowAtPoint(buttonFrame.origin)
        selectedIndex = indexPath!
        infoToReviewController = tableData[indexPath!.row] as! NSDictionary
        //isPresentedFromDismissed = true
        self.performSegueWithIdentifier("SendReview", sender: self)
    }
    
    //pass the variables
    override func prepareForSegue(segue: UIStoryboardSegue, sender: AnyObject?) {
        if(segue.identifier == "ShowAttachment"){
            var destViewController = segue.destinationViewController as! ShowAttachmentViewController
            destViewController.attachmentName = self.selectedAttachmentName
        }else{
            var destViewController = segue.destinationViewController as! SendReviewViewController
            destViewController.passedInfo = infoToReviewController
        }
    }
    
    //show the menu
    @IBAction func showMenu(sender: AnyObject) {
        self.view.endEditing(true)
        self.frostedViewController.view.endEditing(true)
        self.frostedViewController.presentMenuViewController()
    }
    
    
    func panGestureRecognized(sender:UIPanGestureRecognizer){
        var vel = sender.velocityInView(self.view)
        if(vel.x > 0){
            self.view.endEditing(true)
            self.frostedViewController.view.endEditing(true)
            self.frostedViewController.presentMenuViewController()
        }
        
    }
    

    //row height cache for the tableview
    func tableView(tableView: UITableView, didEndDisplayingCell cell: UITableViewCell, forRowAtIndexPath indexPath: NSIndexPath) {
        myRowHeightEstimateCache["\(indexPath.row)"] = CGRectGetHeight(cell.frame)
    }
    
    //estimated height for the row
    func tableView(tableView: UITableView, estimatedHeightForRowAtIndexPath indexPath: NSIndexPath) -> CGFloat {
        if let height = myRowHeightEstimateCache["\(indexPath.row)"]
        {
            return height
        }
        else
        {
            return 300
        }
    }
    
    //height for the row
    func tableView(tableView: UITableView, heightForRowAtIndexPath indexPath: NSIndexPath) -> CGFloat {
        return UITableViewAutomaticDimension
    }
    
    func saveImage (image: UIImage, path: String ) -> Bool{
        
        //let pngImageData = UIImagePNGRepresentation(image)
        let jpegImageData = UIImageJPEGRepresentation(image, 1.0)   // if you want to save as JPEG
        let result = jpegImageData.writeToFile(path, atomically: true)
        
        return result
        
    }
    
    // Get the documents Directory
    
    func documentsDirectory() -> String {
        let documentsFolderPath = NSSearchPathForDirectoriesInDomains(NSSearchPathDirectory.DocumentDirectory, NSSearchPathDomainMask.UserDomainMask, true)[0] as! String
        return documentsFolderPath
    }
    // Get path for a file in the directory
    
    func fileInDocumentsDirectory(filename: String) -> String {
        return documentsDirectory().stringByAppendingPathComponent(filename)
    }
    
    //function to save the image to the documents directory
    func saveImage(fileName:String){
        var imgPath = "http://healthouts.com/img/\(fileName)"
        var imgUrl = NSURL(string: imgPath)
        
        SDWebImageDownloader.sharedDownloader().downloadImageWithURL(imgUrl, options: nil, progress: { (receivedSize:Int, expectedSize:Int) -> Void in
            
            }) { (image, data, error, finished) -> Void in
                if(error != nil){
                    
                }else{
                    let fileManager = NSFileManager.defaultManager()
                    
                    var paths = NSSearchPathForDirectoriesInDomains(.DocumentDirectory, .UserDomainMask, true)[0] as! String
                    
                    var filePathToWrite = "\(paths)/\(fileName)"
                    
                    var imageData: NSData = UIImagePNGRepresentation(image)
                    
                    fileManager.createFileAtPath(filePathToWrite, contents: imageData, attributes: nil)
                }
        }
    }
    
}
