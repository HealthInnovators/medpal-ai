//
//  MyBookingsViewController.swift
//  Healthouts
//
//  Created by Y.Bharath Kumar Reddy on 01/06/15.
//  Copyright (c) 2015 Y.Bharath Kumar Reddy. All rights reserved.
//

import UIKit

class MyBookingsViewController: UIViewController,UITableViewDelegate,UITableViewDataSource {

    //outlets
    @IBOutlet weak var navBarView: UIView!
    @IBOutlet weak var textView: UITextView!
    @IBOutlet weak var tableView: UITableView!
    
    //required variables
    var tableData = []
    var actInd : UIActivityIndicatorView = UIActivityIndicatorView(frame: CGRectMake(0,0, 50, 50)) as UIActivityIndicatorView
    
    override func viewDidLoad() {
        super.viewDidLoad()

        //set nav bar view properties
        navBarView.layer.shadowColor = UIColor.blackColor().CGColor
        navBarView.layer.shadowOffset = CGSizeMake(0.5, 0.5)
        navBarView.layer.shadowRadius = 3.0
        navBarView.layer.shadowOpacity = 1.0
        
        //start the activity indicator
        actInd.center = self.view.center
        actInd.hidesWhenStopped = true
        actInd.activityIndicatorViewStyle = UIActivityIndicatorViewStyle.White
        actInd.backgroundColor = UIColor.blackColor()
        actInd.layer.cornerRadius = 5
        view.addSubview(actInd)
        actInd.startAnimating()

        //register the custom cell
        var nib = UINib(nibName: "MyBookingsTableViewCell", bundle: nil)
        tableView.registerNib(nib, forCellReuseIdentifier: "MyBookingsCell")
        self.tableView.hidden = true
        
        
        self.view.addGestureRecognizer(UIPanGestureRecognizer(target: self, action: "panGestureRecognized:"))
        getData()
        
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    func panGestureRecognized(sender:UIPanGestureRecognizer){
        var vel = sender.velocityInView(self.view)
        if(vel.x > 0){
        self.view.endEditing(true)
        self.frostedViewController.view.endEditing(true)
        self.frostedViewController.presentMenuViewController()
        }
        //self.frostedViewController.panGestureRecognized(sender)
    }

    //number of rows
    func tableView(tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return tableData.count
    }
    
    //populate the tableView
    func tableView(tableView: UITableView, cellForRowAtIndexPath indexPath: NSIndexPath) -> UITableViewCell {
        
        let cell = tableView.dequeueReusableCellWithIdentifier("MyBookingsCell", forIndexPath: indexPath) as! MyBookingsTableViewCell
        var booking = tableData[indexPath.row] as! NSDictionary
        cell.nameLabel.text = booking["doctorName"] as! String
        cell.cityLabel.text = booking["doctorCity"] as! String
        cell.specializationLabel.text = booking["doctorSpecialty"] as! String
        var date = booking["appointmentDate"] as! String
        var time = booking["appointmentTime"] as! String
        cell.dateTimeLabel.text = date + " " + time
        return cell
    }
    
    //call the getAppointments sevice url
    func getData(){
        if(NSUserDefaults.standardUserDefaults().boolForKey("isLoggedIn")){
            //prepare the data to be sent
            var userData = NSUserDefaults.standardUserDefaults().objectForKey("userInfo") as! NSDictionary
            var customerId = userData["id"]
            
            //call the SRWebclient with the url and parameters
            SRWebClient.POST("http://healthouts.com/appBookedAppointments?")
                .data(["customerId" : customerId!])
                .send({ (response, status) -> Void in
                    self.actInd.stopAnimating()
                    var err: NSError?
                    var data = (response as! String).dataUsingEncoding(NSUTF8StringEncoding, allowLossyConversion: true)
                    
                    if let jsonResult = NSJSONSerialization.JSONObjectWithData(data!, options: NSJSONReadingOptions.MutableContainers, error: &err) as? NSArray {
                        dispatch_async(dispatch_get_main_queue(), {
                            self.tableData = jsonResult
                            if(self.tableData.count != 0){
                                self.tableView.hidden = false
                                self.tableView!.reloadData()
                            }else{
                                self.textView.text = "There are no Appointments"
                            }
                        })
                    }else{
                        self.addAlert(err!.localizedDescription)
                    }
                    
                }, failure: { (error) -> Void in
                    self.actInd.stopAnimating()
                    self.addAlert(error.localizedDescription)
                })
            
            
        }
        
    }
    
    //function to add alert
    func addAlert(message:String){
        var alert = UIAlertController(title: "Alert", message: message, preferredStyle: UIAlertControllerStyle.Alert)
        alert.addAction(UIAlertAction(title: "ok", style: UIAlertActionStyle.Default, handler: nil))
        self.presentViewController(alert, animated: true, completion: nil)
    }
    
    //height of the tableview cell
    func tableView(tableView: UITableView, heightForRowAtIndexPath indexPath: NSIndexPath) -> CGFloat {
        return 131
    }

    //show the side menu
    @IBAction func showMenu(sender: AnyObject) {
        self.view.endEditing(true)
        self.frostedViewController.view.endEditing(true)
        self.frostedViewController.presentMenuViewController()
    }

}
