//
//  LoginViewController.swift
//  Healthouts
//
//  Created by Y.Bharath Kumar Reddy on 29/05/15.
//  Copyright (c) 2015 Y.Bharath Kumar Reddy. All rights reserved.
//

import UIKit




class LoginViewController: UIViewController,UITextFieldDelegate,dismissViewDelegate {

   //outlets from the storyboard
    @IBOutlet weak var contentView: UIView!
    @IBOutlet weak var scrollView: UIScrollView!
    @IBOutlet weak var loginView: UIView!
    @IBOutlet weak var navBarView: UIView!
    @IBOutlet weak var passwordTextField: UITextField!
    @IBOutlet weak var usernameTextField: UITextField!
    
    //required variables
    var selectedTextField:UITextField!
    var loginSuccessful = false
    var normalLogin = false
    var doctorId:String!
    var selectedDate:String!
    var timeslot:String!
    var doctorTimeId:String!
    var userInfo:NSMutableDictionary = NSMutableDictionary()
    var displace:CGFloat!
    var actInd : UIActivityIndicatorView = UIActivityIndicatorView(frame: CGRectMake(0,0, 50, 50)) as UIActivityIndicatorView
    
    override func viewDidLoad() {
        super.viewDidLoad()

        //set the navigationbar view properties
        navBarView.layer.shadowColor = UIColor.blackColor().CGColor
        navBarView.layer.shadowOffset = CGSizeMake(0.5, 0.5)
        navBarView.layer.shadowRadius = 3.0
        navBarView.layer.shadowOpacity = 1.0
        
        //set the constraints of the scroll view
        var leftConstraint = NSLayoutConstraint(item: self.contentView, attribute: NSLayoutAttribute.Leading, relatedBy: NSLayoutRelation.Equal, toItem: self.view, attribute: NSLayoutAttribute.Left, multiplier: 1, constant: 0)
        self.view.addConstraint(leftConstraint)
        
        var rightConstraint = NSLayoutConstraint(item: self.contentView, attribute: NSLayoutAttribute.Trailing, relatedBy: NSLayoutRelation.Equal, toItem: self.view, attribute: NSLayoutAttribute.Right, multiplier: 1, constant: 0)
        self.view.addConstraint(rightConstraint)

        //add the keyboard notifications
        NSNotificationCenter.defaultCenter().addObserver(self, selector: "keyboardWillBeShown:", name: UIKeyboardWillShowNotification, object: nil)
        NSNotificationCenter.defaultCenter().addObserver(self, selector: "keyboardWillBeHidden:", name: UIKeyboardWillHideNotification, object: nil)
        
        //set the delegates
        passwordTextField.delegate = self
        usernameTextField.delegate = self
        
        
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
        
    //handle login button
    @IBAction func loginPressed(sender: AnyObject) {
        if(selectedTextField  != nil){
            selectedTextField.resignFirstResponder()
        }
        
        //if this is a login with booking
        if(!normalLogin){
            var text = "Please fill in all the fields"
            if(usernameTextField.text == ""){
                self.showTextOverlay(text)
                var timer = NSTimer.scheduledTimerWithTimeInterval(2, target: self, selector: Selector("removeOverlay"), userInfo: nil, repeats: false)
            }else if(passwordTextField.text == ""){
                self.showTextOverlay(text)
                var timer = NSTimer.scheduledTimerWithTimeInterval(2, target: self, selector: Selector("removeOverlay"), userInfo: nil, repeats: false)
            }else{
            
                //start the activity indicator
                actInd.center = self.view.center
                actInd.hidesWhenStopped = true
                actInd.activityIndicatorViewStyle = UIActivityIndicatorViewStyle.White
                actInd.backgroundColor = UIColor.blackColor()
                actInd.layer.cornerRadius = 5
                view.addSubview(actInd)
                actInd.startAnimating()
            
                //call the SRWebClient with the url and parameters
                SRWebClient.POST("http://healthouts.com/appLoginwithbooking?")
                    .data(["email" : usernameTextField.text,"pass":passwordTextField.text,"doctorId" : doctorId,"availableDate" : selectedDate,"timePeriod" : timeslot,"doctorTimeId" : doctorTimeId])
                    .send({ (response, status) -> Void in
                        
                        self.actInd.stopAnimating()
                        var err: NSError?
                        var data = (response as! String).dataUsingEncoding(NSUTF8StringEncoding, allowLossyConversion: true)
                        
                        if let jsonResult = NSJSONSerialization.JSONObjectWithData(data!, options: NSJSONReadingOptions.MutableContainers, error: &err) as? NSDictionary {
                            dispatch_async(dispatch_get_main_queue(), {
                                
                                if((jsonResult["status"] as! String) == "1"){
                                    
                                    self.userInfo["email"] = jsonResult["emailId"] as! String
                                    self.userInfo["pass"] = jsonResult["pass"]
                                    self.userInfo["type"] = jsonResult["customerType"]
                                    self.userInfo["id"] = jsonResult["customerId"]
                                    self.userInfo["name"] = jsonResult["cName"]
                                    self.userInfo["image"] = jsonResult["cImage"]
                                    NSUserDefaults.standardUserDefaults().setObject(self.userInfo, forKey: "userInfo")
                                    NSUserDefaults.standardUserDefaults().setBool(true, forKey: "isLoggedIn")
                                    self.performSegueWithIdentifier("BookingSuccess", sender: self)
                                    
                                }else{
                                    if((jsonResult["bookingStatus"] as! String) == "loginFail"){
                                        var text = "Your username or password is\nincorrect.Please try again"
                                        self.showTextOverlay(text)
                                        var timer = NSTimer.scheduledTimerWithTimeInterval(2, target: self, selector: Selector("removeOverlay"), userInfo: nil, repeats: false)
                                        
                                    }
                                }
                                
                            })
                        }else{
                            self.addAlert(err!.localizedDescription)
                        }
                        
                        }, failure: { (error) -> Void in
                            self.actInd.stopAnimating()
                            self.addAlert(error.localizedDescription)
                    })
                
                
               
            }
        }else{
            performNormalLogin()
        }
    }
    
    
    //this  is normal login with out booking
    func performNormalLogin(){
        var text = "Please fill in all the fields"
        if(usernameTextField.text == ""){
            self.showTextOverlay(text)
            var timer = NSTimer.scheduledTimerWithTimeInterval(2, target: self, selector: Selector("removeOverlay"), userInfo: nil, repeats: false)
        }else if(passwordTextField.text == ""){
            self.showTextOverlay(text)
            var timer = NSTimer.scheduledTimerWithTimeInterval(2, target: self, selector: Selector("removeOverlay"), userInfo: nil, repeats: false)
        }else{
            //start the activity indicator
            actInd.center = self.view.center
            actInd.hidesWhenStopped = true
            actInd.activityIndicatorViewStyle = UIActivityIndicatorViewStyle.White
            actInd.backgroundColor = UIColor.blackColor()
            actInd.layer.cornerRadius = 5
            view.addSubview(actInd)
            actInd.startAnimating()
            
            //call the SRWebClient with the url and parameters
            SRWebClient.POST("http://healthouts.com/appLogin?")
                .data(["email" : usernameTextField.text , "pass" : passwordTextField.text])
                .send({ (response, status) -> Void in
                    
                    self.actInd.stopAnimating()
                    var err: NSError?
                    var data = (response as! String).dataUsingEncoding(NSUTF8StringEncoding, allowLossyConversion: true)
                    
                    if let jsonResult = NSJSONSerialization.JSONObjectWithData(data!, options: NSJSONReadingOptions.MutableContainers, error: &err) as? NSDictionary {
                        dispatch_async(dispatch_get_main_queue(), {
                            
                            if((jsonResult["status"] as! String) == "1"){
                                
                                self.userInfo["email"] = jsonResult["emailId"] as! String
                                self.userInfo["pass"] = jsonResult["pass"]
                                self.userInfo["type"] = jsonResult["customerType"]
                                self.userInfo["id"] = jsonResult["customerId"]
                                self.userInfo["name"] = jsonResult["cName"]
                                self.userInfo["image"] = jsonResult["cImage"]
                                NSUserDefaults.standardUserDefaults().setObject(self.userInfo, forKey: "userInfo")
                                var info = NSUserDefaults.standardUserDefaults().objectForKey("userInfo")
                                NSUserDefaults.standardUserDefaults().setBool(true, forKey: "isLoggedIn")
                                 self.navigationController?.popViewControllerAnimated(false)
                            }else{
                                var text = "Your username or password is \nincorrect.Please try again"
                                self.showTextOverlay(text)
                                var timer = NSTimer.scheduledTimerWithTimeInterval(2, target: self, selector: Selector("removeOverlay"), userInfo: nil, repeats: false)
                            }
                            
                        })
                    }else{
                        self.addAlert(err!.localizedDescription)
                    }
                    
                }, failure: { (error) -> Void in
                    self.actInd.stopAnimating()
                    self.addAlert(error.localizedDescription)
                })
            
        }
    }
    
    //function to add alert
    func addAlert(message:String){
        var alert = UIAlertController(title: "Alert", message: message, preferredStyle: UIAlertControllerStyle.Alert)
        alert.addAction(UIAlertAction(title: "ok", style: UIAlertActionStyle.Default, handler: nil))
        self.presentViewController(alert, animated: true, completion: nil)
    }
    
    func removeOverlay(){
        self.removeAllOverlays()
    }

    //handle back button press
    @IBAction func backButtonPressed(sender: AnyObject) {
        //self.navigationController?.popViewControllerAnimated(true)
        
        self.navigationController?.popViewControllerAnimated(true)
    }

    //pass the data before performing the segue
    override func prepareForSegue(segue: UIStoryboardSegue, sender: AnyObject?) {
        if(segue.identifier == "SignUp"){
            var destViewController = segue.destinationViewController as! SignUpViewController
            destViewController.doctorId = self.doctorId
            destViewController.doctorTimeId = self.doctorTimeId
            destViewController.selectedDate = self.selectedDate
            destViewController.timeslot = self.timeslot
            destViewController.delegate = self
            if(normalLogin){
                destViewController.normalSignup = true
            }
        }
    }
    
    override func viewWillDisappear(animated: Bool) {
        super.viewWillDisappear(true)
        NSNotificationCenter.defaultCenter().removeObserver(self)
    }
    
    //keyboard notification seletors
    //these are called when the keyboard is about to be shown and when it is about to be removed
    //these are used to adjust the scrollview accordingly
    func keyboardWillBeHidden(notification:NSNotification){
        var contentInsets = UIEdgeInsetsZero
        self.scrollView.contentInset = contentInsets
        self.scrollView.scrollIndicatorInsets = contentInsets
    }
    
    func keyboardWillBeShown(notification:NSNotification){
        if let userInfo = notification.userInfo {
            if let keyboardSize = (userInfo[UIKeyboardFrameBeginUserInfoKey] as? NSValue)?.CGRectValue() {
                //self.bottomConstraint.constant = -keyboardSize.height
                var contentInsets = UIEdgeInsetsMake(0, 0, keyboardSize.height, 0)
                self.scrollView.contentInset = contentInsets
                self.scrollView.scrollIndicatorInsets = contentInsets
                var rect = self.contentView.frame
                rect.size.height -= keyboardSize.height
                if (!CGRectContainsPoint(rect, self.usernameTextField.frame.origin)) {
                    var scrollPoint = CGPointMake(0.0, self.usernameTextField.frame.origin.y - (keyboardSize.height - self.usernameTextField.frame.size.height))
                    self.scrollView.setContentOffset(scrollPoint, animated: false)
                }
            }
        }
    }
    
    //resign first responder on pressing the return key
    func textFieldShouldReturn(textField: UITextField) -> Bool {
        textField.resignFirstResponder()
        return true
    }
    
    func textFieldShouldBeginEditing(textField: UITextField) -> Bool {
        selectedTextField = textField
        return true
    }

    //go to home
    @IBAction func homeButtonPressed(sender: AnyObject) {
        var destViewController = self.storyboard?.instantiateInitialViewController() as! RootViewController
        self.presentViewController(destViewController, animated: true, completion: nil)
    }
    
    //dismissView delegate method
    func dismissView() {
        
        var count = self.navigationController?.viewControllers.count
        var destViewController = self.navigationController?.viewControllers[count!-3] as! UIViewController
         self.navigationController?.popToViewController(destViewController, animated: true)
       
        
        
    }
    

}
