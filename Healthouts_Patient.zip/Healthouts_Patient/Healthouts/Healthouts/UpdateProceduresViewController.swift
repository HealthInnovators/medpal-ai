//
//  UpdateProceduresViewController.swift
//  Healthouts
//
//  Created by Y.Bharath Kumar Reddy on 16/07/15.
//  Copyright (c) 2015 Y.Bharath Kumar Reddy. All rights reserved.
//

import UIKit

class UpdateProceduresViewController: UIViewController,UITextFieldDelegate,UITextViewDelegate {

    //outlets from the storyboard
    @IBOutlet weak var navBarView: UIView!
    @IBOutlet weak var scrollView: UIScrollView!
    @IBOutlet weak var contentView: UIView!
    @IBOutlet weak var procedureName: UITextField!
    @IBOutlet weak var Notes: UITextView!
    @IBOutlet weak var dateTextField: UITextField!
    
    //required variables
    var selectedTextField = UITextField()
    var selectedTextView = UITextView()
    var selectedIndex = 0
    var editProcedure = false
    var passedInfo = [:]
    var actInd : UIActivityIndicatorView = UIActivityIndicatorView(frame: CGRectMake(0,0, 50, 50)) as UIActivityIndicatorView
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        //if in editing mode, populate the appropriate fields with the passed Data
        if(editProcedure){
            self.procedureName.text = passedInfo.objectForKey("procedureName") as? String
            self.Notes.text = passedInfo.objectForKey("notes") as? String
            self.dateTextField.text = passedInfo.objectForKey("performedDate") as? String
            
        }else{
            procedureName.userInteractionEnabled = true
        }
        
        //set the properties of the notes text view
        Notes.layer.borderColor = UIColor(red: 0, green: 147/255, blue: 59/255, alpha: 0.86).CGColor
        Notes.layer.borderWidth = 1
        Notes.layer.cornerRadius = 5
        
        //set the delegates
        Notes.delegate = self
        procedureName.delegate = self
        dateTextField.delegate = self
        
        //set the constraints of the scroll view
        var leftConstraint = NSLayoutConstraint(item: self.contentView, attribute: NSLayoutAttribute.Leading, relatedBy: NSLayoutRelation.Equal, toItem: self.view, attribute: NSLayoutAttribute.Left, multiplier: 1, constant: 0)
        self.view.addConstraint(leftConstraint)
        
        var rightConstraint = NSLayoutConstraint(item: self.contentView, attribute: NSLayoutAttribute.Trailing, relatedBy: NSLayoutRelation.Equal, toItem: self.view, attribute: NSLayoutAttribute.Right, multiplier: 1, constant: 0)
        self.view.addConstraint(rightConstraint)
        
        //add the keyboard notifications
        NSNotificationCenter.defaultCenter().addObserver(self, selector: "keyboardWillBeShown:", name: UIKeyboardWillShowNotification, object: nil)
        NSNotificationCenter.defaultCenter().addObserver(self, selector: "keyboardWillBeHidden:", name: UIKeyboardWillHideNotification, object: nil)
        // Do any additional setup after loading the view.
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    //keyboard notification methods
    func keyboardWillBeHidden(notification:NSNotification){
        var contentInsets = UIEdgeInsetsZero
        self.scrollView.contentInset = contentInsets
        self.scrollView.scrollIndicatorInsets = contentInsets
    }
    
    func keyboardWillBeShown(notification:NSNotification){
        
        if let userInfo = notification.userInfo {
            if let keyboardSize = (userInfo[UIKeyboardFrameBeginUserInfoKey] as? NSValue)?.CGRectValue() {
                //self.bottomConstraint.constant = -keyboardSize.height
                var contentInsets = UIEdgeInsetsMake(0, 0, keyboardSize.height, 0)
                self.scrollView.contentInset = contentInsets
                self.scrollView.scrollIndicatorInsets = contentInsets
                var rect = self.contentView.frame
                rect.size.height -= keyboardSize.height
                if (selectedTextField.isFirstResponder() && !CGRectContainsPoint(rect, self.selectedTextField.frame.origin)) {
                    var scrollPoint = CGPointMake(0.0, self.selectedTextField.frame.origin.y - (keyboardSize.height - self.selectedTextField.frame.size.height))
                    self.scrollView.setContentOffset(scrollPoint, animated: false)
                }else if (!CGRectContainsPoint(rect, self.selectedTextView.frame.origin)){
                    var scrollPoint = CGPointMake(0.0, self.selectedTextView.frame.origin.y - (keyboardSize.height - self.selectedTextView.frame.size.height))
                    self.scrollView.setContentOffset(scrollPoint, animated: false)
                }
            }
        }
    }
    
    //textfields and textview delegate methods
    func textFieldShouldReturn(textField: UITextField) -> Bool {
        textField.resignFirstResponder()
        return true
    }
    
    func textFieldShouldBeginEditing(textField: UITextField) -> Bool {
        self.selectedTextField = textField
        return true
    }
    
    func textViewShouldBeginEditing(textView: UITextView) -> Bool {
        self.selectedTextView = textView
        return true
    }
    
    //back button pressed
    @IBAction func backButtonPressed(sender: AnyObject) {
        self.navigationController?.popViewControllerAnimated(true)
    }
    
    //save button is pressed
    @IBAction func saveButtonPressed(sender: AnyObject) {
        
        //resign the first responders
        selectedTextView.resignFirstResponder()
        selectedTextField.resignFirstResponder()
        
        //input validation
        if(procedureName.text == "" && Notes.text == ""){
            self.addAlert("Fill in atleast one of the fields")
        }else{
            
            //start the activity indiactor
            actInd.center = CGPointMake(self.view.center.x, self.view.center.y - 64)
            actInd.hidesWhenStopped = true
            actInd.activityIndicatorViewStyle = UIActivityIndicatorViewStyle.White
            actInd.backgroundColor = UIColor.blackColor()
            actInd.layer.cornerRadius = 5
            view.addSubview(actInd)
            actInd.startAnimating()
            
            //prepare the parameters to be sent
            var userInfo = NSUserDefaults.standardUserDefaults().objectForKey("userInfo")
            var customerId = userInfo?.objectForKey("id") as! Int
            var customerEmail = userInfo?.objectForKey("email") as! String
            
            //if editing mode,call the update service url using SRWebClient
            if(editProcedure){
                var id = passedInfo.objectForKey("procedureId") as! Int
                SRWebClient.POST("http://healthouts.com/appUpdateProcedure?")
                    .data(["CId":customerId,"CEmail":customerEmail,"procedureId":id,"notes":Notes.text,"performedDate":dateTextField.text])
                    .send({ (response:AnyObject!, status:Int) -> Void in
                        self.actInd.stopAnimating()
                        var err: NSError?
                        var data = (response as! String).dataUsingEncoding(NSUTF8StringEncoding, allowLossyConversion: true)
                        if let jsonResult = NSJSONSerialization.JSONObjectWithData(data!, options: NSJSONReadingOptions.MutableContainers, error: &err) as? NSMutableArray {
                            dispatch_async(dispatch_get_main_queue(), {
                                var count = self.navigationController?.viewControllers.count
                                var destViewController = self.navigationController?.viewControllers[count!-2] as! ProceduresViewController
                                destViewController.tableData = jsonResult
                                self.navigationController?.popViewControllerAnimated(true)
                            })
                            
                        }else{
                            self.addAlert((err?.localizedDescription)!)
                        }
                        
                        }, failure: { (error) -> Void in
                            dispatch_async(dispatch_get_main_queue(), {
                                self.actInd.stopAnimating()
                                self.addAlert(error.localizedDescription)
                                
                                
                            })
                    })
                
            }else{
                //if not call the save service url using SRWebClient
                SRWebClient.POST("http://healthouts.com/appSaveProcedure?")
                    .data(["CId":customerId,"CEmail":customerEmail,"procedureName":procedureName.text,"notes":Notes.text,"performedDate":dateTextField.text])
                    .send({ (response:AnyObject!, status:Int) -> Void in
                        self.actInd.stopAnimating()
                        var err: NSError?
                        var data = (response as! String).dataUsingEncoding(NSUTF8StringEncoding, allowLossyConversion: true)
                        if let jsonResult = NSJSONSerialization.JSONObjectWithData(data!, options: NSJSONReadingOptions.MutableContainers, error: &err) as? NSMutableArray {
                            dispatch_async(dispatch_get_main_queue(), {
                                var count = self.navigationController?.viewControllers.count
                                var destViewController = self.navigationController?.viewControllers[count!-2] as! ProceduresViewController
                                destViewController.tableData = jsonResult
                                self.navigationController?.popViewControllerAnimated(true)
                            })
                            
                        }else{
                            self.addAlert((err?.localizedDescription)!)
                        }
                        }, failure: { (error) -> Void in
                            dispatch_async(dispatch_get_main_queue(), {
                                self.actInd.stopAnimating()
                                self.addAlert(error.localizedDescription)
                                
                                
                            })
                    })
            }
        }
    }
    
    //function to add alert
    func addAlert(message:String){
        var alert = UIAlertController(title: "Alert", message: message, preferredStyle: UIAlertControllerStyle.Alert)
        alert.addAction(UIAlertAction(title: "ok", style: UIAlertActionStyle.Default, handler: nil))
        self.presentViewController(alert, animated: true, completion: nil)
    }

}
