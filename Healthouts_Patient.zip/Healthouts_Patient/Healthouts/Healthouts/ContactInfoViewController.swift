//
//  ContactInfoViewController.swift
//  Healthouts
//
//  Created by Y.Bharath Kumar Reddy on 15/07/15.
//  Copyright (c) 2015 Y.Bharath Kumar Reddy. All rights reserved.
//

import UIKit

class ContactInfoViewController: UIViewController,UITextFieldDelegate {

    //outlets from the storyboard
    @IBOutlet weak var eStateTextField: UITextField!
    @IBOutlet weak var eZipTextField: UITextField!
    @IBOutlet weak var eCityTextField: UITextField!
    @IBOutlet weak var eStreetAddress2TextField: UITextField!
    @IBOutlet weak var eStreetAddress1TextField: UITextField!
    @IBOutlet weak var ePhoneTextField: UITextField!
    @IBOutlet weak var relationTextField: UITextField!
    @IBOutlet weak var eContactNameTextField: UITextField!
    @IBOutlet weak var phoneTextField: UITextField!
    @IBOutlet weak var zipTextField: UITextField!
    @IBOutlet weak var cityTextField: UITextField!
    @IBOutlet weak var stateTextField: UITextField!
    @IBOutlet weak var streetAddress2: UITextField!
    @IBOutlet weak var streetAddress1: UITextField!
    @IBOutlet weak var navBarView: UIView!
    @IBOutlet weak var scrollView: UIScrollView!
    @IBOutlet weak var contentView: UIView!
    
    //required variables
    var selectedTextField:UITextField!
    var actInd : UIActivityIndicatorView = UIActivityIndicatorView(frame: CGRectMake(0,0, 50, 50)) as UIActivityIndicatorView
    
    override func viewDidLoad() {
        super.viewDidLoad()

        //set the delegates
        eStateTextField.delegate = self
        eZipTextField.delegate = self
        eCityTextField.delegate = self
        eStreetAddress2TextField.delegate = self
        eStreetAddress1TextField.delegate = self
        ePhoneTextField.delegate = self
        relationTextField.delegate = self
        eContactNameTextField.delegate = self
        phoneTextField.delegate = self
        zipTextField.delegate = self
        cityTextField.delegate = self
        stateTextField.delegate = self
        streetAddress2.delegate = self
        streetAddress1.delegate = self
        
        
        //set the navigationbar view properties
        navBarView.layer.shadowColor = UIColor.blackColor().CGColor
        navBarView.layer.shadowOffset = CGSizeMake(0.5, 0.5)
        navBarView.layer.shadowRadius = 3.0
        navBarView.layer.shadowOpacity = 1.0
        
        //set the constraints of the scroll view
        var leftConstraint = NSLayoutConstraint(item: self.contentView, attribute: NSLayoutAttribute.Leading, relatedBy: NSLayoutRelation.Equal, toItem: self.view, attribute: NSLayoutAttribute.Left, multiplier: 1, constant: 0)
        self.view.addConstraint(leftConstraint)
        
        var rightConstraint = NSLayoutConstraint(item: self.contentView, attribute: NSLayoutAttribute.Trailing, relatedBy: NSLayoutRelation.Equal, toItem: self.view, attribute: NSLayoutAttribute.Right, multiplier: 1, constant: 0)
        self.view.addConstraint(rightConstraint)
        
        //add the keyboard notifications
        NSNotificationCenter.defaultCenter().addObserver(self, selector: "keyboardWillBeShown:", name: UIKeyboardWillShowNotification, object: nil)
        NSNotificationCenter.defaultCenter().addObserver(self, selector: "keyboardWillBeHidden:", name: UIKeyboardWillHideNotification, object: nil)
        
        self.contentView.backgroundColor = UIColor.clearColor()
        getData()
        
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    //function to get the data and populate the fields
    func getData(){
        
        //start the activity indicator
        actInd.center = CGPointMake(self.view.center.x, self.view.center.y - 64)
        actInd.hidesWhenStopped = true
        actInd.activityIndicatorViewStyle = UIActivityIndicatorViewStyle.White
        actInd.backgroundColor = UIColor.blackColor()
        actInd.layer.cornerRadius = 5
        view.addSubview(actInd)
        actInd.startAnimating()
        
        //prepare the parameters to be sent
        var userInfo = NSUserDefaults.standardUserDefaults().objectForKey("userInfo") as? NSDictionary
        var customerId = userInfo?.objectForKey("id") as! Int
        var customerEmail = userInfo?.objectForKey("email") as! String
        
        //call the SRebClient with the url and parameters
        SRWebClient.POST("http://healthouts.com/appCustomerBasicDetails?")
            .data(["CId":customerId,"CEmail":customerEmail])
            .send({ (response:AnyObject!, status:Int) -> Void in
                
                self.actInd.stopAnimating()
                var err: NSError?
                var data = (response as! String).dataUsingEncoding(NSUTF8StringEncoding, allowLossyConversion: true)
                
                if let jsonResult = NSJSONSerialization.JSONObjectWithData(data!, options: NSJSONReadingOptions.MutableContainers, error: &err) as? NSMutableDictionary {
                    dispatch_async(dispatch_get_main_queue(), {
                        
                        self.streetAddress1.text = jsonResult.objectForKey("cStreetAddress1") as? String
                        self.streetAddress2.text = jsonResult.objectForKey("cStreetAddress2") as? String
                        self.cityTextField.text = jsonResult.objectForKey("cCity") as? String
                        self.zipTextField.text = jsonResult.objectForKey("cZipcode") as? String
                        self.stateTextField.text = jsonResult.objectForKey("cState") as? String
                        self.phoneTextField.text = jsonResult.objectForKey("cPhone") as? String
                        self.eContactNameTextField.text = jsonResult.objectForKey("emergencyContactName") as? String
                        self.eStreetAddress1TextField.text = jsonResult.objectForKey("eStreetAddress1") as? String
                        self.eStreetAddress2TextField.text = jsonResult.objectForKey("eStreetAddress2") as? String
                        self.relationTextField.text = jsonResult.objectForKey("eRelationship") as? String
                        self.ePhoneTextField.text = jsonResult.objectForKey("ePhone") as? String
                        self.eStateTextField.text = jsonResult.objectForKey("eState") as? String
                        self.eCityTextField.text = jsonResult.objectForKey("eCity") as? String
                        self.eZipTextField.text = jsonResult.objectForKey("eZipcode") as? String
                        
                    })
                    
                }else{
                    self.addAlert(err!.localizedDescription)
                }
                
                
            }, failure: { (error) -> Void in
                dispatch_async(dispatch_get_main_queue(), {
                        
                    self.actInd.stopAnimating()
                    self.addAlert(error.localizedDescription)
                    
                })
                    
            })
    }

    //function to ad alert
    func addAlert(message:String){
        var alert = UIAlertController(title: "Alert", message: message, preferredStyle: UIAlertControllerStyle.Alert)
        alert.addAction(UIAlertAction(title: "ok", style: UIAlertActionStyle.Default, handler: nil))
        self.presentViewController(alert, animated: true, completion: nil)
    }
    
    //function to save the data
    @IBAction func saveButtonPressed(sender: AnyObject) {
        //resign the responders
        if(selectedTextField != nil){
            selectedTextField.resignFirstResponder()
        }
        
        //start the activity indicator
        actInd.center = CGPointMake(self.view.center.x, self.view.center.y - 64)
        actInd.hidesWhenStopped = true
        actInd.activityIndicatorViewStyle = UIActivityIndicatorViewStyle.White
        actInd.backgroundColor = UIColor.blackColor()
        actInd.layer.cornerRadius = 5
        view.addSubview(actInd)
        actInd.startAnimating()
        
        //prepare the parameters to be sent with the url
        var userInfo = NSUserDefaults.standardUserDefaults().objectForKey("userInfo") as? NSDictionary
        var customerId = userInfo?.objectForKey("id") as! Int
        var customerEmail = userInfo?.objectForKey("email") as! String
        
        //call the SRWebclient with the parameters and the url
        SRWebClient.POST("http://healthouts.com/appSaveContactInfo?")
            .data(["CId":customerId,"CEmail":customerEmail,"contactInfoDetails":["cStreetAddress1":streetAddress1.text,"cStreetAddress2":streetAddress2.text,"cCity":cityTextField.text,"cState":stateTextField.text,"cZipcode":zipTextField.text,"cPhone":phoneTextField.text,"emergencyContactName":eContactNameTextField.text,"eRelationship":relationTextField.text,"ePhone":ePhoneTextField.text,"eStreetAddress1":eStreetAddress1TextField.text,"eStreetAddress2":eStreetAddress2TextField.text,"eCity":eCityTextField.text,"eZipcode":eZipTextField.text,"eState":eStateTextField.text]])
            .send({ (response:AnyObject!, status:Int) -> Void in
                
                self.actInd.stopAnimating()
                var err: NSError?
                var data = (response as! String).dataUsingEncoding(NSUTF8StringEncoding, allowLossyConversion: true)
                
                if let jsonResult = NSJSONSerialization.JSONObjectWithData(data!, options: NSJSONReadingOptions.MutableContainers, error: &err) as? NSDictionary {
                    dispatch_async(dispatch_get_main_queue(), {
                    
                        self.addAlert(jsonResult["message"] as! String)
                    
                    })
                }else{
                    self.addAlert((err?.localizedDescription)!)
                }
                
        }, failure: { (error) -> Void in
            dispatch_async(dispatch_get_main_queue(), {
                
                self.actInd.stopAnimating()
                self.addAlert(error.localizedDescription)
                
            })
        })
    }
    
    //textfield delegate methods
    func textFieldShouldBeginEditing(textField: UITextField) -> Bool {
        self.selectedTextField = textField
        return true
    }
    
    func textFieldShouldReturn(textField: UITextField) -> Bool {
        textField.resignFirstResponder()
        return true
    }
    
    //keyboard notification methods
    func keyboardWillBeHidden(notification:NSNotification){
        var contentInsets = UIEdgeInsetsZero
        self.scrollView.contentInset = contentInsets
        self.scrollView.scrollIndicatorInsets = contentInsets
    }
    
    func keyboardWillBeShown(notification:NSNotification){
        if let userInfo = notification.userInfo {
            if let keyboardSize = (userInfo[UIKeyboardFrameBeginUserInfoKey] as? NSValue)?.CGRectValue() {
                //self.bottomConstraint.constant = -keyboardSize.height
                var contentInsets = UIEdgeInsetsMake(0, 0, keyboardSize.height, 0)
                self.scrollView.contentInset = contentInsets
                self.scrollView.scrollIndicatorInsets = contentInsets
                var rect = self.contentView.frame
                rect.size.height -= keyboardSize.height
                if (!CGRectContainsPoint(rect, self.selectedTextField.frame.origin)) {
                    var scrollPoint = CGPointMake(0.0, self.selectedTextField.frame.origin.y - (keyboardSize.height - self.selectedTextField.frame.size.height))
                    self.scrollView.setContentOffset(scrollPoint, animated: false)
                }
            }
        }
    }
    
    //back button pressed
    @IBAction func backButtonPressed(sender: AnyObject) {
        self.navigationController?.popViewControllerAnimated(true)
    }
}
