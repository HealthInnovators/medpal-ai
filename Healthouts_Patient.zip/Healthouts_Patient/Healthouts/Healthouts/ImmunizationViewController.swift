//
//  ImmunizationViewController.swift
//  Healthouts
//
//  Created by Y.Bharath Kumar Reddy on 16/07/15.
//  Copyright (c) 2015 Y.Bharath Kumar Reddy. All rights reserved.
//

import UIKit

class ImmunizationViewController: UIViewController,ImmunizationServicesDelegate {

    //outlets from the storyboard
    @IBOutlet weak var navBarView: UIView!
    @IBOutlet weak var tableView: UITableView!
    @IBOutlet weak var addButton: UIButton!
    
    //required variables
    var myRowHeightEstimateCache = [String:CGFloat]()
    var tableData = []
    var selectedIndex = 0
    var actInd : UIActivityIndicatorView = UIActivityIndicatorView(frame: CGRectMake(0,0, 50, 50)) as UIActivityIndicatorView
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        addButton.layer.cornerRadius = 5
        
        //set the navigationbar view properties
        navBarView.layer.shadowColor = UIColor.blackColor().CGColor
        navBarView.layer.shadowOffset = CGSizeMake(0.5, 0.5)
        navBarView.layer.shadowRadius = 3.0
        navBarView.layer.shadowOpacity = 1.0
        
        //register the custom cell
        var nib = UINib(nibName: "ImmunizationTableViewCell", bundle: nil)
        tableView.registerNib(nib, forCellReuseIdentifier: "ImmunizationCell")
        
        self.tableView.hidden = true
        getData()
        
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    override func viewWillAppear(animated: Bool) {
        super.viewWillAppear(true)
        tableView.reloadData()
    }
    
    //get the data
    func getData(){
        
        //start the activity indicator
        actInd.center = CGPointMake(self.view.center.x, self.view.center.y - 64)
        actInd.hidesWhenStopped = true
        actInd.activityIndicatorViewStyle = UIActivityIndicatorViewStyle.White
        actInd.backgroundColor = UIColor.blackColor()
        actInd.layer.cornerRadius = 5
        view.addSubview(actInd)
        actInd.startAnimating()
        
        //prepare the parameters to be sent
        var userInfo = NSUserDefaults.standardUserDefaults().objectForKey("userInfo") as? NSDictionary
        var customerId = userInfo?.objectForKey("id") as! Int
        var customerEmail = userInfo?.objectForKey("email") as! String
        
        //call the SRWebClient with url and parameters
        SRWebClient.POST("http://healthouts.com/appGetImmunizations?")
            .data(["CId":customerId,"CEmail":customerEmail])
            .send({ (response:AnyObject!, status:Int) -> Void in
                
                self.actInd.stopAnimating()
                var err: NSError?
                var data = (response as! String).dataUsingEncoding(NSUTF8StringEncoding, allowLossyConversion: true)
                
                if let jsonResult = NSJSONSerialization.JSONObjectWithData(data!, options: NSJSONReadingOptions.MutableContainers, error: &err) as? NSMutableArray {
                    dispatch_async(dispatch_get_main_queue(), {
                        
                        self.tableData = jsonResult
                        self.tableView.hidden = false
                        self.tableView.reloadData()
                        
                    })
                    
                }else{
                    self.addAlert((err?.localizedDescription)!)
                }
                
            }, failure: { (error) -> Void in
                dispatch_async(dispatch_get_main_queue(), {
                        
                    self.actInd.stopAnimating()
                    self.addAlert(error.localizedDescription)
                        
                })
            })
    }
    
    //add alert
    func addAlert(message:String){
        var alert = UIAlertController(title: "Alert", message: message, preferredStyle: UIAlertControllerStyle.Alert)
        alert.addAction(UIAlertAction(title: "ok", style: UIAlertActionStyle.Default, handler: nil))
        self.presentViewController(alert, animated: true, completion: nil)
    }
    
    //populate the tableview
    func tableView(tableView: UITableView, cellForRowAtIndexPath indexPath: NSIndexPath) -> UITableViewCell {
        var identifier = "ImmunizationCell"
        var cell:ImmunizationTableViewCell  = tableView.dequeueReusableCellWithIdentifier(identifier) as! ImmunizationTableViewCell
        
        cell.containerView.layer.cornerRadius = 5
        cell.containerView.layer.zPosition = 5
        
        var immunizationData = tableData[indexPath.row] as! NSDictionary
        
        cell.typeNameLabel.text = immunizationData.objectForKey("immunization") as? String
        cell.notesInfoLabel.text = immunizationData.objectForKey("notes") as? String
        cell.dateLabel.text = immunizationData.objectForKey("immunizationDate") as? String
        
        cell.updateButton.layer.cornerRadius = 5
        cell.deleteButton.layer.cornerRadius = 5
        
        cell.delegate = self
        return cell
    }
    
    //number of rows in the table view
    func tableView(tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return tableData.count
    }
    
    //row height cache for the tableview
    func tableView(tableView: UITableView, didEndDisplayingCell cell: UITableViewCell, forRowAtIndexPath indexPath: NSIndexPath) {
        myRowHeightEstimateCache["\(indexPath.row)"] = CGRectGetHeight(cell.frame)
    }
    
    //estimated height for the row
    func tableView(tableView: UITableView, estimatedHeightForRowAtIndexPath indexPath: NSIndexPath) -> CGFloat {
        if let height = myRowHeightEstimateCache["\(indexPath.row)"]
        {
            return height
        }
        else
        {
            return 300
        }
    }
    
    //height for the row
    func tableView(tableView: UITableView, heightForRowAtIndexPath indexPath: NSIndexPath) -> CGFloat {
        return UITableViewAutomaticDimension
    }
    
    //pass the data before performing the segue
    override func prepareForSegue(segue: UIStoryboardSegue, sender: AnyObject?) {
        if(segue.identifier == "EditImmunization"){
            //if we are in editing mode
            //mahe the editImmunization as true in the destViewController
            var destViewController = segue.destinationViewController as! UpdateImmunizationViewController
            destViewController.editImmunization = true
            destViewController.selectedIndex = self.selectedIndex
            destViewController.passedInfo = tableData[selectedIndex] as! NSDictionary
            
        }else{
            
        }
    }
    
    //function to update
    //set the selected Index variable
    //and perform the segue with identifier "EditImmunization"
    func updateImmunization(button: UIButton) {
        var buttonFrame = button.convertRect(button.bounds, toView: self.tableView)
        var indexPath = self.tableView.indexPathForRowAtPoint(buttonFrame.origin)
        selectedIndex = indexPath!.row
        self.performSegueWithIdentifier("EditImmunization", sender: self)
    }
    
    //function to delete
    func deleteImmunization(button: UIButton) {
        
        //start the activity indicator
        actInd.center = CGPointMake(self.view.center.x, self.view.center.y - 64)
        actInd.hidesWhenStopped = true
        actInd.activityIndicatorViewStyle = UIActivityIndicatorViewStyle.White
        actInd.backgroundColor = UIColor.blackColor()
        actInd.layer.cornerRadius = 5
        view.addSubview(actInd)
        actInd.startAnimating()
        
        //prepare the parameters to be sent
        var buttonFrame = button.convertRect(button.bounds, toView: self.tableView)
        var indexPath = self.tableView.indexPathForRowAtPoint(buttonFrame.origin)
        selectedIndex = indexPath!.row
        
        var userInfo = NSUserDefaults.standardUserDefaults().objectForKey("userInfo") as? NSDictionary
        var customerId = userInfo?.objectForKey("id") as! Int
        var customerEmail = userInfo?.objectForKey("email") as! String
        
        var immunizationData = tableData[selectedIndex] as? NSDictionary
        var id = immunizationData!.objectForKey("immunizationId") as! Int
        
        //call the SRWebClient with the url and parameters
        SRWebClient.POST("http://healthouts.com/appDeleteImmunizations?")
            .data(["CId":customerId,"CEmail":customerEmail,"immunizationId":id])
            .send({ (response:AnyObject!, status:Int) -> Void in
                
                self.actInd.stopAnimating()
                var err: NSError?
                var data = (response as! String).dataUsingEncoding(NSUTF8StringEncoding, allowLossyConversion: true)
                
                if let jsonResult = NSJSONSerialization.JSONObjectWithData(data!, options: NSJSONReadingOptions.MutableContainers, error: &err) as? NSMutableArray {
                    dispatch_async(dispatch_get_main_queue(), {
                        self.tableData = jsonResult
                        self.tableView.hidden = false
                        self.tableView.reloadData()
                        
                    })
                    
                }else{
                    self.addAlert((err?.localizedDescription)!)
                }
                
            }, failure: { (error) -> Void in
                dispatch_async(dispatch_get_main_queue(), {
                    
                    self.actInd.stopAnimating()
                    self.addAlert(error.localizedDescription)
                        
                })
            })
    }
    
    //back button is presed
    @IBAction func backButtonPressed(sender: AnyObject) {
        self.navigationController?.popViewControllerAnimated(true)
    }

}
