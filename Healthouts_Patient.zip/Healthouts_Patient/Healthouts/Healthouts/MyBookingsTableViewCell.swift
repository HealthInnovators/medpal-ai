//
//  MyBookingsTableViewCell.swift
//  Healthouts
//
//  Created by Y.Bharath Kumar Reddy on 01/06/15.
//  Copyright (c) 2015 Y.Bharath Kumar Reddy. All rights reserved.
//

import UIKit

class MyBookingsTableViewCell: UITableViewCell {

 
    
    @IBOutlet weak var bgView: UIView!
    @IBOutlet weak var dateTimeLabel: UILabel!
    @IBOutlet weak var cityLabel: UILabel!
    @IBOutlet weak var specializationLabel: UILabel!
    @IBOutlet weak var nameLabel: UILabel!
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }

}
