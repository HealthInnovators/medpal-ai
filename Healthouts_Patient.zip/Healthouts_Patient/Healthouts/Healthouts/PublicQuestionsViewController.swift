//
//  PublicQuestionsViewController.swift
//  Healthouts
//
//  Created by Y.Bharath Kumar Reddy on 06/06/15.
//  Copyright (c) 2015 Y.Bharath Kumar Reddy. All rights reserved.
//

import UIKit

class PublicQuestionsViewController: UIViewController,UITableViewDelegate,UITableViewDataSource {

    //outlets from the story board
    @IBOutlet weak var navBarView: UIView!
    @IBOutlet weak var tableView: UITableView!
    
    //required variables
    var tableData:NSMutableArray = []
    var count = 0
    var myRowHeightEstimateCache = [String:CGFloat]()
    var actInd : UIActivityIndicatorView = UIActivityIndicatorView(frame: CGRectMake(0,0, 50, 50)) as UIActivityIndicatorView
    var imageCache = [String:UIImage]()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        //set the nav bar view properties
        navBarView.layer.shadowColor = UIColor.blackColor().CGColor
        navBarView.layer.shadowOffset = CGSizeMake(0.5, 0.5)
        navBarView.layer.shadowRadius = 3.0
        navBarView.layer.shadowOpacity = 1.0
        
        self.view.addGestureRecognizer(UIPanGestureRecognizer(target: self, action: "panGestureRecognized:"))
        
        //register the custom cell
        var nib = UINib(nibName: "PublicQuestionsTableViewCell", bundle: nil)
        tableView.registerNib(nib, forCellReuseIdentifier: "PublicQuestionsCell")
        
        self.tableView.hidden = true
        
        //get the data
        getData()
        
        

        // Do any additional setup after loading the view.
    }


    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    func panGestureRecognized(sender:UIPanGestureRecognizer){
        var vel = sender.velocityInView(self.view)
        if(vel.x > 0){
            self.view.endEditing(true)
            self.frostedViewController.view.endEditing(true)
            self.frostedViewController.presentMenuViewController()
        }
    }
    
    override func viewWillAppear(animated: Bool) {
        super.viewWillAppear(true)
        
        
    }
    
    //get the data
    func getData(){
        //start the activity indicator
        actInd.center = self.view.center
        actInd.hidesWhenStopped = true
        actInd.activityIndicatorViewStyle = UIActivityIndicatorViewStyle.White
        actInd.backgroundColor = UIColor.blackColor()
        actInd.layer.cornerRadius = 10
        view.addSubview(actInd)
        actInd.startAnimating()
        
        //call the Net with the url and parameters
        var net = Net()
        net.POST("http://healthouts.com/appWithOutLoginFeed?", params: ["count":count], successHandler: { (responseData) -> () in
            dispatch_async(dispatch_get_main_queue(), {
                
            self.actInd.stopAnimating()
            var str = NSString(data: responseData.data, encoding: NSISOLatin1StringEncoding)
            var data = str?.dataUsingEncoding(NSUTF8StringEncoding, allowLossyConversion: true)
            var err:NSError?
            if let jsonResult = NSJSONSerialization.JSONObjectWithData(data!, options: nil, error: &err) as? NSArray {
                   
                    dispatch_async(dispatch_get_main_queue(), {

                            self.actInd.stopAnimating()
                            self.tableData.addObjectsFromArray(jsonResult as [AnyObject])
                            self.tableView.hidden = false
                            self.tableView.reloadData()
                            
                    })
                        
                    
            }else{
                    
                        dispatch_async(dispatch_get_main_queue(), {
                            self.addAlert(err!.localizedDescription)
                            
                        })
                        
            }
            })
        })
            { (error) -> () in
            dispatch_async(dispatch_get_main_queue(), {
                self.actInd.stopAnimating()
                self.addAlert(error.localizedDescription)
            })
        }

        
     
    }


    //add alert
    func addAlert(message:String){
        var alert = UIAlertController(title: "Alert", message: message, preferredStyle: UIAlertControllerStyle.Alert)
        alert.addAction(UIAlertAction(title: "ok", style: UIAlertActionStyle.Default, handler: nil))
        self.presentViewController(alert, animated: true, completion: nil)
    }
    
    //populate the tableview
    func tableView(tableView: UITableView, cellForRowAtIndexPath indexPath: NSIndexPath) -> UITableViewCell {
       
        var identifier = "PublicQuestionsCell"
        var cell:PublicQuestionsTableViewCell  = tableView.dequeueReusableCellWithIdentifier(identifier) as! PublicQuestionsTableViewCell
       
        cell.containerView.layer.cornerRadius = 5
        cell.containerView.layer.zPosition = 5
        
        var questionInfo:NSDictionary = tableData[indexPath.row] as! NSDictionary
        
        cell.questionLabel.text = questionInfo.objectForKey("questionBody") as? String
        cell.answerSubjectLabel.text = questionInfo.objectForKey("answerSubject") as? String
        cell.answerLabel.text = questionInfo.objectForKey("answerBody") as? String
        cell.doctorImageView.layer.cornerRadius = 25
        cell.doctorImageView.layer.masksToBounds = true
        
        var doctorName = questionInfo.objectForKey("doctorName") as? String
        var staticText = "answered"
        var text = NSMutableAttributedString(string: doctorName! + "  " + staticText)
        text.addAttribute(NSForegroundColorAttributeName, value: UIColor.blackColor(), range: NSMakeRange(text.length-8, 8))
        cell.doctorNameLabel.attributedText = text
        
        cell.doctorImageView.image = UIImage(named: "doctoricon")
        if let image = questionInfo.objectForKey("doctorImage") as? String{
            
            var imgPath = "http://healthouts.com/img/" + image.stringByReplacingOccurrencesOfString(" ", withString: "%20") as String
            var imgUrl = NSURL(string: imgPath)
            
            if let img = imageCache[imgPath]{
                cell.doctorImageView.image = img
            }else{
                SDWebImageDownloader.sharedDownloader().downloadImageWithURL(imgUrl, options: nil, progress: { (receivedSize:Int, expectedSize:Int) -> Void in
                
                    }) { (image, data, error, finished) -> Void in
                        if(error != nil){
                            cell.doctorImageView.image = UIImage(named: "doctoricon")
                        }else{
                            cell.doctorImageView.image = image
                            self.imageCache[imgPath] = image
                        }
                }
            }
        }else{
            cell.doctorImageView.image = UIImage(named: "doctoricon")
        }
        
        
        self.count = questionInfo.objectForKey("count") as! Int
        if(indexPath.row == self.tableData.count-1){
            if(self.count != -1){
                getData()
            }
        }
        
        //cell.setNeedsUpdateConstraints()
        //cell.updateConstraintsIfNeeded()
        
        return cell

    }
    
    //number of rows
    func tableView(tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return tableData.count
    }
    
    //row height cache for the tableview
    func tableView(tableView: UITableView, didEndDisplayingCell cell: UITableViewCell, forRowAtIndexPath indexPath: NSIndexPath) {
        myRowHeightEstimateCache["\(indexPath.row)"] = CGRectGetHeight(cell.frame)
    }
    
    //estimated height for the row
    func tableView(tableView: UITableView, estimatedHeightForRowAtIndexPath indexPath: NSIndexPath) -> CGFloat {
        if let height = myRowHeightEstimateCache["\(indexPath.row)"]
        {
            return height
        }
        else
        {
            return 100
        }
    }
    
    //height for the row
    func tableView(tableView: UITableView, heightForRowAtIndexPath indexPath: NSIndexPath) -> CGFloat {
        return UITableViewAutomaticDimension
    }
    
    //show menu
    @IBAction func showMenu(sender: AnyObject) {
        self.view.endEditing(true)
        self.frostedViewController.view.endEditing(true)
        self.frostedViewController.presentMenuViewController()
        
    }

}
