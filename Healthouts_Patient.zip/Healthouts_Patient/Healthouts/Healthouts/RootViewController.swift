//
//  RootViewController.swift
//  Healthouts
//
//  Created by Y.Bharath Kumar Reddy on 27/05/15.
//  Copyright (c) 2015 Y.Bharath Kumar Reddy. All rights reserved.
//

import UIKit

//This is the container view controller that takes care of sidemenu
class RootViewController: REFrostedViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
    }

    
    override func awakeFromNib() {
        //this is the initial view controller that will be shown once the app is launched
        //Its identifier is set to "contentController" in the storyboard
        self.contentViewController = self.storyboard?.instantiateViewControllerWithIdentifier("contentController") as? UITabBarController
        
        //Here the menu view controller is instantiated 
        //the menu view controller is given the identifier "menuController" in the storyboard
        self.menuViewController = self.storyboard?.instantiateViewControllerWithIdentifier("menuController") as? UIViewController
        
        //set the size of the side menu
        self.limitMenuViewSize  = true
        self.menuViewSize = CGSizeMake(275, UIScreen.mainScreen().bounds.size.height)
    }
    
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    

   

}
