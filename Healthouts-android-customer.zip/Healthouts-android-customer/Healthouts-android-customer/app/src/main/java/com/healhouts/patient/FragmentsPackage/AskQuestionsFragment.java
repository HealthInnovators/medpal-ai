package com.healhouts.patient.FragmentsPackage;

import android.app.AlertDialog;
import android.app.ProgressDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.os.AsyncTask;
import android.os.Bundle;
import android.provider.Settings;
import android.support.v4.app.Fragment;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.inputmethod.InputMethodManager;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.healhouts.patient.Activities.DoctorHomeActivity;
import com.healhouts.patient.R;
import com.healhouts.patient.common.CommonUtil;
import com.healhouts.patient.common.ConnectionDetector;

import org.json.JSONException;
import org.json.JSONObject;

import java.net.URISyntaxException;

/**
 * Created by Venkat Veeravalli on 13-05-2015.
 */
public class AskQuestionsFragment extends Fragment {
    public static String TAG = "AskQuestionsFragment";
    Button btnSendQs;
    EditText editTextQestion;
    EditText edtEmailAlert;
    EditText edtPasswordAlert;
    private Context context;
    Boolean isInternetPresent = false;
    ConnectionDetector cd;
    ProgressDialog pDialog;
    AlertDialog.Builder builder;

    SharedPreferences userSharedPreferences;
    private String customerId;
    private  String customerEmail;
    private boolean loginStatus = false;
    private View v;

    AlertDialog dialog;

/*
    String url = "http://healthouts.com/appfreeMessage?message=";
    String loginUrl = "http://healthouts.com/appLoginwithAskQs?";
*/

    String url = "http://joslinlive.org/appfreeMessage?message=";
    String loginUrl = "http://joslinlive.org/appLoginwithAskQs?";

    CommonUtil cu;
    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        View fragmentView = inflater.inflate(R.layout.fragment4, container, false);
        context = getActivity().getApplicationContext();
        cd = new ConnectionDetector(context);
        isInternetPresent = cd.isConnectingToInternet();
        cu = new CommonUtil();

        userSharedPreferences = this.getActivity().getSharedPreferences(context.getString(R.string.cPreferences), Context.MODE_PRIVATE);
        Log.d("---", "--userSharedPreferenc--" + userSharedPreferences);
        if (userSharedPreferences.getString(context.getString(R.string.customerId), null) != null) {
            customerId = userSharedPreferences.getString(context.getString(R.string.customerId), null);
            customerEmail = userSharedPreferences.getString(context.getResources().getString(R.string.customerEmail),null);
            loginStatus = true;
        }
        InputMethodManager imm = (InputMethodManager)getActivity().getSystemService(Context.INPUT_METHOD_SERVICE);

        editTextQestion = (EditText)fragmentView.findViewById(R.id.editTextQestion);

        imm.hideSoftInputFromWindow(editTextQestion.getWindowToken(), 0);
        btnSendQs = (Button)fragmentView.findViewById(R.id.btnSendQs);
        btnSendQs.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String msg = editTextQestion.getText().toString();
                if(msg.length() == 0){
                    Toast toast = Toast.makeText(context,"Frist enter your question", Toast.LENGTH_LONG);
                    toast.getView().setBackgroundColor(Color.parseColor("#139454"));
                    toast.show();
                }else if (msg.length() < 20 ){
                    Toast toast = Toast.makeText(context, "Your question must be more than 20 charactors", Toast.LENGTH_LONG);
                    toast.getView().setBackgroundColor(Color.parseColor("#139454"));
                    toast.show();
                }else{
                    sendFreeQuestion();
                }
            }
        });


        return fragmentView;
    }
    public void sendFreeQuestion() {


        if(loginStatus){
            sendFreeQuestionWithoutLogin();
        }else{
            showLoginAlert();
        }




    }
    public void sendFreeQuestionWithoutLogin(){
        new AsyncTask<Void, Void, String>() {


            @Override
            protected void onPreExecute() {
                super.onPreExecute();
                /*pDialog = new ProgressDialog(getActivity());
                pDialog.setTitle("Please wait...");
                pDialog.setCancelable(true);
                pDialog.show();*/
                builder = new AlertDialog.Builder(getActivity());
            }

            @Override
            protected String doInBackground(Void... params) {

                String jsonStr = "";
                ServiceHandler sh = new ServiceHandler();

                String str = "";
                str = str + url;


                Log.d("----", "---isInternetPresent---" + isInternetPresent);
                try {
                    String queryStr = new CommonUtil().ConvertToUrlString(str + editTextQestion.getText().toString()+"&CId="+customerId+"&CEmail="+customerEmail);
                    if (isInternetPresent) {

                        jsonStr = sh.makeServiceCall(queryStr, ServiceHandler.GET);
                    } else {
                        /*As it is a Async Task,we should not  mak use of Toast message Directlywill cause looper exception .
                        So we need to run this on another
                        */
                        getActivity().runOnUiThread(new Runnable() {
                            public void run() {

                                final AlertDialog.Builder builder = new AlertDialog.Builder(getActivity());
                                builder.setTitle("Connection failure");
                                builder.setMessage("Please check your netwAlork connection and try again");
                                builder.setIcon(R.drawable.warn)
                                        .setPositiveButton("cancel", new DialogInterface.OnClickListener() {
                                            public void onClick(DialogInterface dialog, int id) {
                                                builder.setCancelable(true);
                                            }
                                        })
                                        .setNegativeButton("Wi-Fi Settings", new DialogInterface.OnClickListener() {
                                            public void onClick(DialogInterface dialog, int id) {
                                                startActivityForResult(new Intent(Settings.ACTION_WIFI_SETTINGS), 0);


                                            }
                                        });
                                builder.show();

                            }
                        });

                    }

                } catch (URISyntaxException e1) {
                    // TODO Auto-generated catch block
                    e1.printStackTrace();
                }
                return jsonStr;
            }

            @Override
            protected void onPostExecute(String s) {
                super.onPostExecute(s);
                /*if (pDialog.isShowing())
                    pDialog.dismiss();*/
                try {
                    JSONObject job = new JSONObject(s);
                    String status = job.getString("STATUS");
                    String result = job.getString("RESULT");
                    switch (status){
                        case "1":
                            editTextQestion.setText("");
                            builder.setCancelable(true);
                            builder.setMessage(result);
                            builder.setInverseBackgroundForced(true);

                            builder.setNeutralButton("Ok", new DialogInterface.OnClickListener() {
                                public void onClick(DialogInterface dialog, int whichButton) {
                                    dialog.dismiss();
                                }
                            });

                            builder.show();
                            break;
                        case "0":
                            builder.setCancelable(true);
                            builder.setMessage(result);
                            builder.setInverseBackgroundForced(true);

                            builder.setNeutralButton("Ok", new DialogInterface.OnClickListener() {
                                public void onClick(DialogInterface dialog, int whichButton) {
                                    dialog.dismiss();
                                }
                            });

                            builder.show();

                    }

                } catch (JSONException e) {
                    e.printStackTrace();
                }


            }
        }.execute(null, null, null);
    }
    public void showLoginAlert(){
        LayoutInflater factory = LayoutInflater.from(getActivity());
        final View loginView = factory.inflate(R.layout.login2, null);
        edtEmailAlert = (EditText)loginView.findViewById(R.id.edtEmailAlert);
        edtPasswordAlert = (EditText)loginView.findViewById(R.id.edtPasswordAlert);

        final AlertDialog.Builder alert = new AlertDialog.Builder(getActivity());

        alert
                .setTitle("You need to Login first")
                .setView(loginView)
                .setPositiveButton("Login",
                        null)
                .setNegativeButton("Cancel",
                        new DialogInterface.OnClickListener() {
                            public void onClick(DialogInterface dialog,
                                                int whichButton) {

                            }
                        });

//        alert.show();
        dialog = alert.create();
        dialog.show();
//Overriding the handler immediately after show is probably a better approach than OnShowListener as described below
        dialog.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener(new View.OnClickListener()
        {
            @Override
            public void onClick(View v)
            {
                        Log.i(TAG,"---Login Email---"+edtEmailAlert.getText().toString());
                        Log.i(TAG,"---Login password---"+edtEmailAlert.getText().toString());
                if (edtEmailAlert.getText().toString().equals("") || edtEmailAlert.getText().toString().equals("")) {
                    Toast toast = Toast.makeText(getActivity(), "Login details required", Toast.LENGTH_LONG);
                    toast.getView().setBackgroundColor(Color.parseColor("#ff7373"));
                    toast.show();
                } else {
                    checkAuthendication();
                }


            }
        });



    }

    public void checkAuthendication(){

        new AsyncTask<Void, Void,JSONObject>(){
            @Override
            protected JSONObject doInBackground(Void... params) {
                JSONObject jsonObject = null;
                ServiceHandler sh = new ServiceHandler();
                String jsonStr = "";
                String urlStr = "";
                urlStr = urlStr + loginUrl+"email=" + edtEmailAlert.getText().toString() + "&pass=" + edtPasswordAlert.getText().toString()+"&message="+editTextQestion.getText().toString();
                try {
                    jsonStr = sh.makeServiceCall(cu.ConvertToUrlString(urlStr),ServiceHandler.GET);
                } catch (URISyntaxException e) {
                    e.printStackTrace();
                }
                Log.d(TAG, "response string" + jsonStr);
                if(!jsonStr.equals("")){
                    try{
                        jsonObject = new JSONObject(jsonStr);
                        if(jsonObject.getString("status").equals("1")){
                            Log.d("---","---jsonObject---"+jsonObject.toString());
//                            jsonObject.put("emailId", edtEmailAlert.getText().toString());
                            cu.registerGCMandSaveSession(jsonObject,context,userSharedPreferences);
                        }
                    }catch (Exception e){
                        e.printStackTrace();
                    }
                }
                return jsonObject;
            }

            @Override
            protected void onPreExecute() {
                super.onPreExecute();

                pDialog = new ProgressDialog(getActivity());
                pDialog.setMessage("Please wait..");
                pDialog.setCancelable(false);
                pDialog.show();
                builder = new AlertDialog.Builder(getActivity());
            }

            @Override
            protected void onPostExecute(JSONObject result) {
                super.onPostExecute(result);
                if(pDialog.isShowing())
                    pDialog.dismiss();
                dialog.dismiss();//dismiss the alert
                Intent intent = null;
                Bundle myData = new Bundle();
                try {
                    if (result.getString("customerType").equals("CUSTOMER")) {

                        editTextQestion.setText("");// Clear question text area
                        builder.setCancelable(true);
                        builder.setMessage(result.getString("RESULT"));

                        builder.setInverseBackgroundForced(true);

                        builder.setNeutralButton("Ok", new DialogInterface.OnClickListener() {
                            public void onClick(DialogInterface dialog, int whichButton) {
                                dialog.dismiss();
                            }
                        });

                        builder.show();

                    } else if (result.getString("customerType").equals("DOCTOR")) {
                        intent = new Intent(getActivity(), DoctorHomeActivity.class);
                        //				myData.putString("doctorId", newData.getDoctorId());
//				myData.putString("dName", newData.getdName());
                        intent.putExtras(myData);
//				startActivityForResult(intent, IPC_ID);
                        startActivity(intent);

                    } else if (result.getString("customerType").equals("NOTVALID")) {
                        if (result.getString("askFreeQsStatus").equals("askQuestionFail")) {



                            builder.setCancelable(true);
                            builder.setMessage(result.getString("RESULT"));

                            builder.setInverseBackgroundForced(true);

                            builder.setNeutralButton("Ok", new DialogInterface.OnClickListener() {
                                public void onClick(DialogInterface dialog, int whichButton) {
                                    dialog.dismiss();
                                }
                            });

                            builder.show();

                        } else if (result.getString("askFreeQsStatus").equals("loginFail")) {

                            builder.setCancelable(true);
                            builder.setMessage(result.getString("RESULT"));
                            builder.setInverseBackgroundForced(true);

                            builder.setNeutralButton("Ok", new DialogInterface.OnClickListener() {
                                public void onClick(DialogInterface dialog, int whichButton) {
                                    dialog.dismiss();
                                }
                            });

                            builder.show();
                        }
//                        Log.d(TAG, "Authandication failed try again");
//                        Toast.makeText(context, "User is not valid try again", Toast.LENGTH_LONG).show();


                    }


                } catch (Exception e) {
                    // TODO: handle exception
                    e.printStackTrace();
                }
            }
        }.execute();
    }




    }
