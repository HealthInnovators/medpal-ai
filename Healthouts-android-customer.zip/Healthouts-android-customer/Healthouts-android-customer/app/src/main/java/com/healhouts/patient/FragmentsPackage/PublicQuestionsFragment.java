package com.healhouts.patient.FragmentsPackage;

import android.app.ProgressDialog;
import android.content.Context;
import android.os.Bundle;
import android.os.StrictMode;
import android.support.v4.app.Fragment;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;

import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.VolleyLog;
import com.android.volley.toolbox.JsonArrayRequest;
import com.android.volley.toolbox.Volley;
import com.healhouts.patient.Activities.SimpleDividerItemDecoration;
import com.healhouts.patient.Adapters.PublicFeedRecyclerAdapter;
import com.healhouts.patient.Beanclasses.FeedItem;
import com.healhouts.patient.Beanclasses.FeedItemAppointments;
import com.healhouts.patient.R;
import com.healhouts.patient.Volley.AppController;
import com.healhouts.patient.common.ConnectionDetector;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by Venkat Veeravalli on 12-05-2015.
 */
public class PublicQuestionsFragment extends Fragment {
    private static final String TAG = PublicQuestionsFragment.class.getName();
    //    ListView lv1;
    private Context context;
    Boolean isInternetPresent = false;
    ConnectionDetector cd;
    JSONArray jsonArray;
    //    PublicFeedAdapter adapter;
    private List<FeedItem> feedItemList = new ArrayList<FeedItem>();
    private RecyclerView mRecyclerView;
    LinearLayoutManager mLayoutManager;


    private PublicFeedRecyclerAdapter adapter;
    private boolean loading = true;
    int firstVisibleItem, visibleItemCount, totalItemCount;
    int count =0;
    int token = 0;
    ProgressDialog pDialog;

   // String url = "http://healthouts.com/appWithOutLoginFeed?count=";
 String url = "http://joslinlive.org/appWithOutLoginFeed?count=";

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        StrictMode.ThreadPolicy policy = new StrictMode.ThreadPolicy.Builder().permitAll().build();
        StrictMode.setThreadPolicy(policy);
        context = getActivity().getApplicationContext();
        cd = new ConnectionDetector(context);
        isInternetPresent = cd.isConnectingToInternet();

        View fragmentView = inflater.inflate(R.layout.public_feed_list_layout, container, false);

        mRecyclerView = (RecyclerView) fragmentView.findViewById(R.id.public_feed_list);
        mRecyclerView.setHasFixedSize(true);
        mLayoutManager = new LinearLayoutManager(getActivity());
        mRecyclerView.setLayoutManager(mLayoutManager);
        mRecyclerView.setOnScrollListener(new RecyclerView.OnScrollListener() {
            @Override
            public void onScrolled(RecyclerView recyclerView, int dx, int dy) {
                super.onScrolled(recyclerView, dx, dy);
                visibleItemCount = mRecyclerView.getChildCount();
                totalItemCount = mLayoutManager.getItemCount();
                firstVisibleItem = mLayoutManager.findFirstVisibleItemPosition();
                if (loading) {
                    if ((visibleItemCount + firstVisibleItem) >= totalItemCount) {
                        loading = false;
                        pDialog = new ProgressDialog(getActivity(), Window.FEATURE_NO_TITLE);
                        pDialog.setMessage("Please wait...");
                        pDialog.setCancelable(false);

                        Log.v("...", "Last Item Wow !");
                        count = totalItemCount;
                        mRecyclerView.scrollToPosition(totalItemCount);
                        mRecyclerView.smoothScrollToPosition(totalItemCount);
                        mLayoutManager.scrollToPositionWithOffset(5, 10);
                        getPublicFeed();
                    }
                }
            }


        });

        getPublicFeed();
        Volley.newRequestQueue(context);
        return fragmentView;

    }

    public void getPublicFeed() {

        final ProgressDialog pDialog = new ProgressDialog(getActivity());
        pDialog.setMessage("Loading...");
        pDialog.show();
        FeedItemAppointments item = new FeedItemAppointments();


        JsonArrayRequest req = new JsonArrayRequest(url+count,
                new Response.Listener<JSONArray>() {
                    @Override
                    public void onResponse(JSONArray response) {
                        for (int i = 0; i < response.length(); i++) {
                            JSONObject jsonobject = null;
                            FeedItem item = new FeedItem();
                            try {
                                jsonobject = response.getJSONObject(i);
                                item.setDoctorId(jsonobject.getString("doctorId"));
                                item.setDoctorName(jsonobject.getString("doctorName"));
                                item.setDoctorImage(jsonobject.getString("doctorImage"));
                                item.setDoctorcity(jsonobject.getString("doctorcity"));
                                item.setFeedCount(jsonobject.getString("count"));
                                item.setCustomerId(jsonobject.getString("customerId"));
                                item.setQuestionBody(jsonobject.getString("questionBody"));
                                item.setAnswerId(jsonobject.getString("answerId"));
                                item.setAnswerSubject(jsonobject.getString("answerSubject"));
                                item.setAnswerBody(jsonobject.optString("answerBody").replace("@_@","\n"));
                                //*item.setAnswerBody((jsonobject.getString("answerBody") != null)?jsonobject.getString("answerBody") :"");*//*
                                item.setAnsTime(jsonobject.optString("ansTime"));
                                feedItemList.add(item);


                            } catch (JSONException e) {
                                e.printStackTrace();
                            }

                            feedItemList.add(item);

                            adapter = new PublicFeedRecyclerAdapter(getActivity(), feedItemList);
                            mRecyclerView.addItemDecoration(new SimpleDividerItemDecoration(getResources()));
                            mRecyclerView.setAdapter(adapter);
                            mLayoutManager.scrollToPositionWithOffset(count, 0);
                            loading=true;
                        }
                        pDialog.hide();
                    }
                }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                VolleyLog.d(TAG, "Error: " + error.getMessage());
                pDialog.hide();
            }
        });

        AppController.getInstance(context.getApplicationContext()).addToRequestQueue(req);

        /*new AsyncTask<Void, Void, List<FeedItem>>() {

            @Override
            protected void onPreExecute() {
                super.onPreExecute();

                pDialog = new ProgressDialog(getActivity(), Window.FEATURE_NO_TITLE);
                pDialog.setCancelable(false);
                pDialog.show();

            }

            @Override
            protected List<FeedItem> doInBackground(Void... params) {
                String jsonStr = "";
                ServiceHandler sh = new ServiceHandler();

                String str = "";
                str = str + url;

                try {
                    String queryStr = new CommonUtil().ConvertToUrlString(str + count);
                    Log.d(TAG,"querystr "+queryStr);
                    if (isInternetPresent) {

                        jsonStr = sh.makeServiceCall(queryStr, ServiceHandler.GET);
                    } else {

                        getActivity().runOnUiThread(new Runnable() {
                            public void run() {

                                final AlertDialog.Builder builder = new AlertDialog.Builder(getActivity());
                                builder.setTitle("Connection failure");
                                builder.setMessage("Please check your network connection and try again");
                                builder.setIcon(R.drawable.warn)
                                        .setPositiveButton("cancel", new DialogInterface.OnClickListener() {
                                            public void onClick(DialogInterface dialog, int id) {
                                                builder.setCancelable(true);
                                            }
                                        })
                                        .setNegativeButton("Wi-Fi Settings", new DialogInterface.OnClickListener() {
                                            public void onClick(DialogInterface dialog, int id) {
                                                startActivityForResult(new Intent(Settings.ACTION_WIFI_SETTINGS), 0);


                                            }
                                        });
                                builder.show();

                            }
                        });

                    }

                } catch (URISyntaxException e1) {
                    // TODO Auto-generated catch block
                    e1.printStackTrace();
                }


                try {
                    jsonArray = new JSONArray(jsonStr);
                    for (int i = 0; i < jsonArray.length(); i++) {

                        JSONObject jsonobject = jsonArray.getJSONObject(i);
                        FeedItem item = new FeedItem();
                        Log.d("---", "---jsonObject---"+jsonobject.toString());
                        item.setDoctorId(jsonobject.getString("doctorId"));
                        item.setDoctorName(jsonobject.getString("doctorName"));
                        item.setDoctorImage(jsonobject.getString("doctorImage"));
                        item.setDoctorcity(jsonobject.getString("doctorcity"));
                        item.setFeedCount(jsonobject.getString("count"));
                        item.setCustomerId(jsonobject.getString("customerId"));
                        item.setQuestionBody(jsonobject.getString("questionBody"));
                        item.setAnswerId(jsonobject.getString("answerId"));
                        item.setAnswerSubject(jsonobject.getString("answerSubject"));
                        item.setAnswerBody(jsonobject.optString("answerBody").replace("@_@","\n"));
                        *//*item.setAnswerBody((jsonobject.getString("answerBody") != null)?jsonobject.getString("answerBody") :"");*//*
                        item.setAnsTime(jsonobject.optString("ansTime"));
                        feedItemList.add(item);
                    }
                } catch (JSONException e) {
                    e.printStackTrace();
                }
                return feedItemList;
            }


            private void showAlertDialog(FragmentActivity activity, String s, String s1, boolean b) {
                AlertDialog alertDialog = new AlertDialog.Builder(context).create();
                alertDialog.setTitle("");
                alertDialog.setMessage("");
                alertDialog.setButton("OK", new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface dialog, int which) {
                    }
                });
                alertDialog.show();
            }
            @Override
            protected void onPostExecute(List<FeedItem> list) {
                if (list.size() == 0) {
                    Toast.makeText(getActivity(), "Feed List Empty!", Toast.LENGTH_LONG).show();
                } else {
                    super.onPostExecute(list);

                    adapter = new PublicFeedRecyclerAdapter(getActivity(), feedItemList);
                    mRecyclerView.setAdapter(adapter);
                    mLayoutManager.scrollToPositionWithOffset(count, 0);
                    loading=true;
                }
                if (pDialog.isShowing())
                    pDialog.dismiss();

            }
        }.execute(null, null, null);
*/

    }
}