package com.healhouts.patient.Activities;


import android.app.AlertDialog;
import android.app.ProgressDialog;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.os.StrictMode;
import android.support.v4.app.Fragment;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.VolleyLog;
import com.android.volley.toolbox.JsonArrayRequest;
import com.android.volley.toolbox.Volley;
import com.healhouts.patient.Adapters.AdapterQA;
import com.healhouts.patient.Beanclasses.FeedItemQA;
import com.healhouts.patient.FragmentsPackage.DividerItemDecoration;
import com.healhouts.patient.R;
import com.healhouts.patient.Volley.AppController;
import com.healhouts.patient.common.ConnectionDetector;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by Venkat Veeravalli on 12-05-2015.
 */
public class YourFreeQuestionsFragment extends Fragment {
    private static final String TAG ="YourFreeQuestionsFragment" ;
    private Context context;
    SharedPreferences sharedpreferences;
    ProgressDialog pDialog;
    Boolean isInternetPresent = false;
    ConnectionDetector cd;
    JSONArray jsonArray;
    private List<FeedItemQA> FeedItemQAList = new ArrayList<FeedItemQA>();
    private RecyclerView mRecyclerView;
    LinearLayoutManager mLayoutManager;
    private AdapterQA adapter;
    private boolean loading = true;
    int firstVisibleItem, visibleItemCount, totalItemCount;
    int count =0;
    int token = 0;
    String customerId,customerEmail;
    AlertDialog.Builder builder;
    boolean loginStatus= false;
  //  String url = "http://healthouts.com/appGetYourFreeQs?";
   String url = "http://joslinlive.org/appGetYourFreeQs?";
    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        StrictMode.ThreadPolicy policy = new StrictMode.ThreadPolicy.Builder().permitAll().build();
        StrictMode.setThreadPolicy(policy);
        context = getActivity().getApplicationContext();
        cd = new ConnectionDetector(context);
        isInternetPresent = cd.isConnectingToInternet();
        View fragmentView = inflater.inflate(R.layout.activity_feedsqanda_list, container, false);
        mRecyclerView = (RecyclerView) fragmentView.findViewById(R.id.recycler_view);
        mRecyclerView.setHasFixedSize(true);
        mLayoutManager = new LinearLayoutManager(getActivity());
        RecyclerView.ItemDecoration itemDecoration =
                new DividerItemDecoration(getActivity(), LinearLayoutManager.VERTICAL);
        mRecyclerView.addItemDecoration(itemDecoration);

        mRecyclerView.setLayoutManager(mLayoutManager);


//        mRecyclerView.
        sharedpreferences = context.getSharedPreferences(context.getString(R.string.cPreferences), Context.MODE_PRIVATE);
        customerId = sharedpreferences.getString(context.getString(R.string.customerId), null);
        customerEmail = sharedpreferences.getString(context.getString(R.string.customerEmail),null);

        mRecyclerView.setOnScrollListener(new RecyclerView.OnScrollListener() {
            @Override
            public void onScrolled(RecyclerView recyclerView, int dx, int dy) {
                super.onScrolled(recyclerView, dx, dy);
                visibleItemCount = mRecyclerView.getChildCount();
                totalItemCount = mLayoutManager.getItemCount();
                firstVisibleItem = mLayoutManager.findFirstVisibleItemPosition();
                if (loading) {
                    if ((visibleItemCount + firstVisibleItem) >= totalItemCount) {
                        loading = false;
                        Log.v("...", "Last Item Wow !");
                        count = totalItemCount;

                    }
                }
            }


        });
        yourFeedandAns();
        Volley.newRequestQueue(context);
        return fragmentView;

    }

    private void launchExampleActivity(Class activityClass) {
        Intent intent = new Intent(getActivity(), activityClass);
        startActivity(intent);
    }


    public void yourFeedandAns() {
        final ProgressDialog pDialog = new ProgressDialog(getActivity());
        pDialog.setMessage("Loading...");
        pDialog.show();

        JsonArrayRequest req = new JsonArrayRequest(url+"CId=" + customerId + "&cEmail=" + customerEmail,
                new Response.Listener<JSONArray>() {
                    @Override
                    public void onResponse(JSONArray response) {
                        JSONObject jsonobject = null;
                        for (int i = 0; i < response.length(); i++) {
                            FeedItemQA item = new FeedItemQA();

                            try {

                                JSONArray jsonArray1 = response.getJSONArray(i);
                                jsonobject = (JSONObject) jsonArray1.get(0);
                                JSONArray jsonArray2 = (JSONArray) jsonArray1.get(1);
                                item.setcImage(jsonobject.optString("cImage"));
                                item.setQuestionBody(jsonobject.optString("questionBody"));
                                item.setQuestionId(jsonobject.optString("questionId"));
                                item.setAnsArray(jsonArray2);
                            } catch (JSONException e) {
                                e.printStackTrace();
                            }
                            FeedItemQAList.add(item);
                            adapter = new AdapterQA(context, FeedItemQAList);
                            mRecyclerView.addItemDecoration(new SimpleDividerItemDecoration(getResources()));
                            mRecyclerView.setAdapter(adapter);
                            adapter.SetOnItemClickListener(new AdapterQA.OnItemClickListener() {
                                @Override
                                public void onItemClick(View view, int position) {
                                    Log.d("---", "----position---"+position);
                                    FeedItemQA feedItem = FeedItemQAList.get(position);
                                    Intent intent = new Intent(context, AnswersForYourQuestions.class);
                                    Bundle myData = new Bundle();
                                    myData.putString("ansJsonArray", String.valueOf(feedItem.getAnsArray()));
                                    myData.putString("questionId", feedItem.getQuestionId());
                                    myData.putString("cImage", feedItem.getcImage());
                                    myData.putString("questionBody", feedItem.getQuestionBody());
                                    myData.putString("qsDate", feedItem.getQsDate());
                                    intent.putExtras(myData);
                                    startActivity(intent);
                                }
                            });
                            mLayoutManager.scrollToPositionWithOffset(count, 0);
                            loading=true;
                        }
                        pDialog.hide();
                    }
                }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                VolleyLog.d(TAG, "Error: " + error.getMessage());
                pDialog.hide();
            }
        });

        AppController.getInstance(context.getApplicationContext()).addToRequestQueue(req);

    }
}