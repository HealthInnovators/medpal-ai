package com.healhouts.patient.Activities;

import android.app.Activity;
import android.os.Bundle;
import android.util.Log;

import com.healhouts.patient.R;

public class TestActivity extends Activity {
    String ansJsonArray;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        // TODO Auto-generated method stub
        super.onCreate(savedInstanceState);
        setContentView(R.layout.public_feed_list);

        ansJsonArray = getIntent().getExtras().getString("ansJsonArray");

        Log.d("---", "----ansJsonArray---"+ansJsonArray);

//        ActionBar bar = getActionBar();
//        bar.setBackgroundDrawable(new ColorDrawable(Color.parseColor("#32c6ff")));
    }
}

/*

    @Override
    protected void onPostExecute(ArrayList result) {


        boolean isInternetPresent= Boolean.parseBoolean(null);
        if(isInternetPresent==true){
            if(result.size()!=0){
                super.onPostExecute(result);
                adapter = new CustomListAdapter(Test.this, result);
                adapter.notifyDataSetChanged();
                lv1.setAdapter(adapter);
                // Dismiss the progress dialog
                if (pDialog.isShowing())
                    pDialog.dismiss();

            }else{
                final AlertDialog.Builder builder = new AlertDialog.Builder(Test.this);

                builder.setTitle("Sorry !!");
                builder.setMessage("Healthouts don't have any doctors for this Speciality,kindly explore later");
                builder.setIcon(R.drawable.ic_report)
                        .setPositiveButton("cancel", new DialogInterface.OnClickListener() {
                            public void onClick(DialogInterface dialog, int id) {
                                builder.setCancelable(true);
                            }
                        });
                builder.show();
                pDialog.dismiss();

            }
        }else{
            if(result.size()!=0){
                super.onPostExecute(result);
                adapter = new CustomListAdapter(Test.this, result);
                adapter.notifyDataSetChanged();
                lv1.setAdapter(adapter);
                // Dismiss the progress dialog
                if (pDialog.isShowing())
                    pDialog.dismiss();

            }else{
                final AlertDialog.Builder builder = new AlertDialog.Builder(Test.this);

                builder.setTitle("Sorry !!");
                builder.setMessage("Healthouts don't have any doctors for this Speciality,kindly explore later");
                builder.setIcon(R.drawable.ic_report)
                        .setPositiveButton("cancel", new DialogInterface.OnClickListener() {
                            public void onClick(DialogInterface dialog, int id) {
                                builder.setCancelable(true);
                            }
                        });
                builder.show();
                pDialog.dismiss();

            }

        }


        if (result.size() != 0 && isInternetPresent==true) {

            super.onPostExecute(result);
            adapter = new CustomListAdapter(Test.this, result);
            adapter.notifyDataSetChanged();
            lv1.setAdapter(adapter);
            // Dismiss the progress dialog
            if (pDialog.isShowing())
                pDialog.dismiss();
        }
        if (result.size() != 0 && isInternetPresent==false) {
            AlertDialog.Builder builder = new AlertDialog.Builder(Test.this);

            builder.setTitle("Sorry!!");
            builder.show();
            pDialog.dismiss();


                */
/*super.onPostExecute(result);
                adapter = new CustomListAdapter(Test.this, result);
                adapter.notifyDataSetChanged();
                lv1.setAdapter(adapter);
                // Dismiss the progress dialog
                if (pDialog.isShowing())
                    pDialog.dismiss();*//*

        }

        if (result.size() == 0 && isInternetPresent==true) {
            final AlertDialog.Builder builder = new AlertDialog.Builder(Test.this);

            builder.setTitle("Sorry !!");
            builder.setMessage("Healthouts don't have any doctors for this Speciality,kindly explore later");
            builder.setIcon(R.drawable.ic_report)
                    .setPositiveButton("cancel", new DialogInterface.OnClickListener() {
                        public void onClick(DialogInterface dialog, int id) {
                            builder.setCancelable(true);
                        }
                    });
            builder.show();
            pDialog.dismiss();


                */
/*super.onPostExecute(result);
                adapter = new CustomListAdapter(Test.this, result);
                adapter.notifyDataSetChanged();
                lv1.setAdapter(adapter);
                // Dismiss the progress dialog
                if (pDialog.isShowing())
                    pDialog.dismiss();*//*

        }


            */
/* else {


                AlertDialog.Builder builder = new AlertDialog.Builder(Test.this);

                builder.setTitle("Sorry!!");
                builder.setMessage("Please Check your connection and try again");
                        builder.setIcon(R.drawable.ic_report)
                        .setPositiveButton("cancel", new DialogInterface.OnClickListener() {
                            public void onClick(DialogInterface dialog, int id) {
                                // FIRE ZE MISSILES!
                            }
                        })
                        .setNegativeButton("Wi-Fi Settings", new DialogInterface.OnClickListener() {
                            public void onClick(DialogInterface dialog, int id) {
                                startActivityForResult(new Intent(Settings.ACTION_WIFI_SETTINGS), 0);

                                // User cancelled the dialog
                            }
                        });
                // Create the AlertDialog object and return it
                builder.show();
                pDialog.dismiss();
            }*//*

    }


}
*/
