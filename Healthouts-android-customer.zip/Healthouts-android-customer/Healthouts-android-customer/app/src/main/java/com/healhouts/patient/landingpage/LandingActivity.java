/*
package com.healhouts.patient.landingpage;

import android.app.AlertDialog;
import android.app.Dialog;
import android.app.ProgressDialog;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageInfo;
import android.content.pm.PackageManager;
import android.graphics.Typeface;
import android.os.AsyncTask;
import android.os.Bundle;
import android.support.v4.view.PagerAdapter;
import android.support.v4.view.ViewPager;
import android.support.v7.app.ActionBarActivity;
import android.text.Html;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.gms.gcm.GoogleCloudMessaging;
import com.healhouts.patient.Activities.AMS;
import com.healhouts.patient.Activities.MainActivity;
import com.healhouts.patient.FragmentsPackage.ServiceHandler;
import com.healhouts.patient.GCMService.Config;
import com.healhouts.patient.R;
import com.healhouts.patient.chat.ChatServer;
import com.healhouts.patient.common.ConnectionDetector;

import org.json.JSONException;
import org.json.JSONObject;

import java.io.IOException;
import java.net.URISyntaxException;
import java.util.ArrayList;

*/
/**
 * Created by samsung on 13-07-2015.
 *//*

public class LandingActivity extends ActionBarActivity implements View.OnClickListener {


    private static final String TAG = "LandingActivity";
    private ViewPager viewPager;
    private MyViewPagerAdapter myViewPagerAdapter;
    private ArrayList<String> listOfItems;


    private LinearLayout dotsLayout;
    private int dotsCount;
    private TextView[] dots;
    EditText editTextQestion;
    EditText edtEmailAlert;
    EditText edtPasswordAlert;
    private Context context;
    Boolean isInternetPresent = false;
    ConnectionDetector cd;
    ProgressDialog pDialog;
    AlertDialog.Builder builder;
    private String updageRegIdUrl = "http://healthouts.com/updateRegId?";
    public static final String REG_ID = "regId";
    private static final String APP_VERSION = "appVersion";
    SharedPreferences userSharedPreferences;
    private String customerId;
    private boolean loginStatus = false;
    private View v;
    Button btnLoginDialog;
    AlertDialog dialog;
    private GoogleCloudMessaging gcm;
    String regId;
    EditText password;
    EditText email;
    SharedPreferences sharedpreferences;
    private static String ctustomerId;
    private static String customerType;
    private static String customerEmail;
    private static String customerPassword;
    private static String customerName;
    private static String customerImage;
    private static String cPreferences;
    ChatServer xmppServer = new ChatServer();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_landing);
        Button skip = (Button) findViewById(R.id.skip);
        btnLoginDialog = (Button) findViewById(R.id.login);
        skip.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(LandingActivity.this, AMS.class);
                startActivity(intent);

            }
        });
        btnLoginDialog.setOnClickListener(this);
        android.support.v7.app.ActionBar actionBar = getSupportActionBar();
        initViews();
        setViewPagerItemsWithAdapter();
        setUiPageViewController();
    }

    @Override
    public void onClick(View v) {
        if (v == btnLoginDialog) {

            // Create Object of Dialog class
            final Dialog login = new Dialog(this);
            // Set GUI of login screen
            login.setContentView(R.layout.login_dialog);
            login.setTitle("Login to Proceed");

            // Init button of login GUI
            Button btnLogin = (Button) login.findViewById(R.id.btnLogin);
            Button btnCancel = (Button) login.findViewById(R.id.btnCancel);
            email = (EditText) login.findViewById(R.id.txtUsername);
            password = (EditText) login.findViewById(R.id.txtPassword);

            // Attached listener for login GUI button
            btnLogin.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    if (email.getText().toString().equals("") || password.getText().toString().equals("")) {
                        Toast.makeText(getApplicationContext(), "Login details required", Toast.LENGTH_LONG).show();
                    } else {
                        new CheckAuthendication().execute();

                    }
                }
            });
            btnCancel.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    login.dismiss();
                }
            });
        login.show();
        }
    }


    private void setUiPageViewController() {
        dotsLayout = (LinearLayout) findViewById(R.id.viewPagerCountDots);
        dotsCount = myViewPagerAdapter.getCount();
        dots = new TextView[dotsCount];

        for (int i = 0; i < dotsCount; i++) {
            dots[i] = new TextView(this);
            dots[i].setText(Html.fromHtml("&#8226"));
            dots[i].setTextSize(30);
            dots[i].setTypeface(null, Typeface.BOLD_ITALIC);
            dots[i].setTextColor(getResources().getColor(android.R.color.white));
            dotsLayout.addView(dots[i]);
        }

        dots[0].setTextColor(getResources().getColor(R.color.app_green));
    }


    private void setViewPagerItemsWithAdapter() {
        myViewPagerAdapter = new MyViewPagerAdapter(listOfItems);
        viewPager.setAdapter(myViewPagerAdapter);
        viewPager.setCurrentItem(0);
        viewPager.setOnPageChangeListener(viewPagerPageChangeListener);
    }

    //	page change listener
    ViewPager.OnPageChangeListener viewPagerPageChangeListener = new ViewPager.OnPageChangeListener() {

        @Override
        public void onPageSelected(int position) {
            for (int i = 0; i < dotsCount; i++) {
                dots[i].setTextColor(getResources().getColor(android.R.color.white));
            }
            dots[position].setTextColor(getResources().getColor(R.color.Tomato));
        }

        @Override
        public void onPageScrolled(int arg0, float arg1, int arg2) {

        }

        @Override
        public void onPageScrollStateChanged(int arg0) {

        }
    };

    private void initViews() {


        viewPager = (ViewPager) findViewById(R.id.viewPager);

        listOfItems = new ArrayList<String>();
        listOfItems.add("Search nearby Doctors");
        listOfItems.add("Booking Appointments made easy");
        listOfItems.add("Check out Public Feed");
        listOfItems.add("Keep Your Questions Private");
        listOfItems.add("Access  Your Profile 24*7 from anywhere");
    }


    //	adapter
    public class MyViewPagerAdapter extends PagerAdapter {

        private LayoutInflater layoutInflater;
        private ArrayList<String> items;

        public MyViewPagerAdapter(ArrayList<String> listOfItems) {
            this.items = listOfItems;
        }

        @Override
        public Object instantiateItem(ViewGroup container, int position) {

            layoutInflater = (LayoutInflater) getApplicationContext().getSystemService(Context.LAYOUT_INFLATER_SERVICE);
            View view = layoutInflater.inflate(R.layout.view_pager_item, container, false);

            TextView tView = (TextView) view.findViewById(R.id.PageNumber);

            tView.setText(listOfItems.get(position).toString());

            ((ViewPager) container).addView(view);

            return view;
        }

        @Override
        public int getCount() {
            return items.size();
        }

        @Override
        public boolean isViewFromObject(View view, Object obj) {
            return view == ((View) obj);
        }


        @Override
        public void destroyItem(ViewGroup container, int position, Object object) {
            View view = (View) object;
            ((ViewPager) container).removeView(view);
        }
    }


    private class CheckAuthendication extends AsyncTask<Void, Void, JSONObject> {

        @Override
        protected void onPreExecute() {
            // TODO Auto-generated method stub
            super.onPreExecute();
            pDialog = new ProgressDialog(LandingActivity.this, R.style.MyTheme);
            pDialog.setMessage("Please wait...");
            pDialog.setCancelable(false);
            pDialog.show();
            builder = new AlertDialog.Builder(LandingActivity.this);

        }

        @Override
        protected JSONObject doInBackground(Void... arg0) {
            // TODO Auto-generated method stub
            ServiceHandler sh = new ServiceHandler();
            String jsonStr = "";
            JSONObject job = null;
            try {
                String url = "http://healthouts.com/appLogin?";
*/
/*
                String url = "http://healthouts.com/appLoginwithbooking?";
*//*

                url = url + "email=" + email.getText().toString() + "&pass=" + password.getText().toString();

                Log.d(TAG, "-----url for authendication---->" + url);
                jsonStr = sh.makeServiceCall(url, ServiceHandler.GET);

            } catch (URISyntaxException e) {
                // TODO Auto-generated catch block
                e.printStackTrace();
                Toast.makeText(context, "Network connection is not good", Toast.LENGTH_LONG).show();
            }
            Log.d(TAG, "response string" + jsonStr);
            if (jsonStr != null) {

                try {
                    job = new JSONObject(jsonStr);
                    Log.i("josn", job.getString("status"));

                    if (job.getString("status").equals("1")) {

                        try {

                            if (gcm == null) {
                                gcm = GoogleCloudMessaging.getInstance(context);
                                Log.i(TAG, "--gcm1--" + gcm);
                                gcm.unregister();
                            }
                            Log.i(TAG, "--gcm2--" + gcm);
                            regId = gcm.register(ServiceCalls.GOOGLE_PROJECT_ID);
                            Log.d(TAG, "registerInBackground - regId: " + regId);
//                            msg = "Device registered, registration ID=" + regId;

                            ServiceHandler sh2 = new ServiceHandler();
                            updageRegIdUrl = updageRegIdUrl + "regId=" + regId + "&userEmail=" + email.getText();
                            Log.d(TAG, updageRegIdUrl);
                            jsonStr = sh2.makeServiceCall(updageRegIdUrl, ServiceHandler.GET);
                            Log.d(TAG, "--serverResponse--:" + jsonStr);
                            JSONObject json = new JSONObject(jsonStr);

                            if (json != null) {
                                if (json.get("status").equals("1")) {
                                    storeRegistrationId(context, regId);
                                    Log.i("josn", job.getString("emailId"));
                                    Log.i("josn", job.getString("customerType"));
                                    Log.i("josn", job.getString("customerId"));
                                    Log.i("josn", job.getString("pass"));
                                    SharedPreferences.Editor editor = sharedpreferences.edit();
//						Log.i("Stirng value", customerEmail);
                                    editor.putString(ctustomerId, job.getString("customerId"));
                                    editor.putString(customerEmail, job.getString("emailId"));
                                    editor.putString(customerType, job.getString("customerType"));
                                    editor.putString(customerPassword, job.getString("pass"));
                                    editor.putString(customerName, job.getString("cName"));
                                    editor.putString(customerImage, job.getString("cImage"));
                                    editor.commit();
                                    xmppServer.connect("healthouts" + job.getString("customerId"), "healthouts" + job.getString("customerId"));
                                }
                            }

                        } catch (IOException ex) {
                            ex.printStackTrace();
                            job.put("customerType", "NOTVALID");
                            return job;
                        } catch (URISyntaxException e) {
                            e.printStackTrace();
                            job.put("customerType", "NOTVALID");
                            return job;
                        } catch (JSONException e) {
                            e.printStackTrace();
                        }
//                       boolean val =  registerInBackground();


                    } else {
                        job.put("customerType", "NOTVALID");
                        job.put("bookingStatus", job.getString("bookingStatus"));
                        return job;
                    }
                } catch (JSONException e) {
                    // TODO Auto-generated catch block
                    e.printStackTrace();
                    JSONObject job2 = new JSONObject();
                    try {
                        job2.put("customerType", "NOTVALID");
                    } catch (JSONException e1) {
                        e1.printStackTrace();
                    }
                    return job2;
                } catch (Exception e1) {
                    e1.printStackTrace();
                }
            }
            return job;
        }

        @Override
        protected void onPostExecute(JSONObject result) {
            // TODO Auto-generated method stub
            super.onPostExecute(result);
            if (pDialog.isShowing())
                pDialog.dismiss();
            Intent intent = null;
            Bundle myData = new Bundle();
            try {
                if (result.getString("customerType").equals("CUSTOMER")) {
                    myData.putString("result", "done");
                    intent = new Intent(LandingActivity.this, AMS.class);
                    intent.putExtras(myData);
                    startActivity(intent);

                } else {
                    Toast.makeText(context, "Please Continue as Guest USer", Toast.LENGTH_SHORT).show();
                }
            } catch (Exception e) {
                // TODO: handle exception
                e.printStackTrace();
            }
        }


    }

    private void storeRegistrationId(Context context, String regId) {
        final SharedPreferences prefs = getSharedPreferences(
                MainActivity.class.getSimpleName(), Context.MODE_PRIVATE);
        int appVersion = getAppVersion(context);
        Log.i(TAG, "Saving regId on app version " + appVersion);
        SharedPreferences.Editor editor = prefs.edit();
        editor.putString(REG_ID, regId);
        editor.putInt(APP_VERSION, appVersion);
        editor.commit();
    }

    private static int getAppVersion(Context context) {
        try {
            PackageInfo packageInfo = context.getPackageManager()
                    .getPackageInfo(context.getPackageName(), 0);
            return packageInfo.versionCode;
        } catch (PackageManager.NameNotFoundException e) {
            Log.d("RegisterActivity",
                    "I never expected this! Going down, going down!" + e);
            throw new RuntimeException(e);
        }
    }
}
*/
