package com.healhouts.patient.Adapters;

import android.support.v4.app.FragmentActivity;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.Filter;
import android.widget.Filterable;
import android.widget.ImageView;
import android.widget.TextView;

import com.healhouts.patient.R;
import com.healhouts.patient.common.CommonUtil;
import com.healhouts.patient.common.ImageDownloaderTask;

import java.util.ArrayList;
import java.util.HashMap;

/**
 * Created by Venkat Veeravalli on 12-05-2015.
 */
public class PublicFeedAdapter extends BaseAdapter implements Filterable {
    private ArrayList<HashMap> listData;
    ArrayList<HashMap> mStringFilterList;

    private LayoutInflater layoutInflater;
    //    ValueFilter valueFilter;
    public static String TAG = "PublicFeedAdapter";
    public PublicFeedAdapter(FragmentActivity context, int public_feed_list_layout, ArrayList list){
        super();
        this.listData = list;
        this.mStringFilterList = list;
        layoutInflater = LayoutInflater.from(context);
    }
    static class ViewHolder {
        ImageView feedDocImg;
        TextView textFeedDocName;
        TextView textAnswered;
        TextView textViewQs;
        TextView textViewAnsHead;
        TextView textViewAnsbody;
    }

    @Override
    public int getCount() {
        return listData.size();
    }

    @Override
    public Object getItem(int position) {
        return listData.get(position);
    }

    @Override
    public long getItemId(int position) {
        return position;
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {

        ViewHolder holder;
        if (convertView == null) {
            convertView = layoutInflater.inflate(R.layout.public_feed_list, null);
            holder = new ViewHolder();
            holder.feedDocImg = (ImageView) convertView.findViewById(R.id.customerImg);
            holder.textFeedDocName = (TextView)convertView.findViewById(R.id.textFeedDocName);
            holder.textAnswered = (TextView)convertView.findViewById(R.id.textAnswered);
            holder.textViewQs = (TextView)convertView.findViewById(R.id.textViewQs);
            holder.textViewAnsHead = (TextView)convertView.findViewById(R.id.textViewAnsHead);
            holder.textViewAnsbody = (TextView)convertView.findViewById(R.id.textViewAnsbody);


            convertView.setTag(holder);
        } else {
            holder = (ViewHolder) convertView.getTag();
        }
        HashMap hm = (HashMap) listData.get(position);
//        holder.feedDocImg
        holder.textFeedDocName.setText(hm.get("doctorName").toString());

        holder.textViewQs.setText(hm.get("questionBody").toString());
        holder.textViewAnsHead.setText(hm.get("answerSubject").toString());
        holder.textViewAnsbody.setText(hm.get("answerBody").toString());
        Log.d("---","---hm.get(\"doctorImage\")--"+hm.get("doctorImage"));
        if (holder.feedDocImg != null) {

            String finalUrlStr = "";

           if(!hm.get("doctorImage").equals("")) {

               

             //  finalUrlStr = new CommonUtil().ConvertToUrlString("http://healthouts.com/img/"+hm.get("doctorImage").toString());
               finalUrlStr = new CommonUtil().ConvertToUrlString("http://joslinlive.org/img/"+hm.get("doctorImage").toString());

               new ImageDownloaderTask(holder.feedDocImg).execute(finalUrlStr);
           }

        }
        return convertView;
    }

    @Override
    public Filter getFilter() {
        return null;
    }
}
