package com.healhouts.patient;

import android.support.v7.widget.RecyclerView;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;

import com.healhouts.patient.Adapters.AdapterQA;


/**
 * Created by Sheshakanth on 21-05-2015.
 */
public class FeedListRowHolderQA  extends RecyclerView.ViewHolder implements View.OnClickListener{

    protected ImageView cImage;
    protected TextView qsDate;
    protected TextView questionBody;
    protected TextView questionId;
    AdapterQA.OnItemClickListener mItemClickListener;


    public FeedListRowHolderQA(View view) {
        super(view);
        this.cImage = (ImageView) view.findViewById(R.id.cImage);
        this.qsDate = (TextView) view.findViewById(R.id.qsDate);
        this.questionBody = (TextView) view.findViewById(R.id.cdetails);
        this.questionId = (TextView) view.findViewById(R.id.questionId);
        view.setOnClickListener(this);
    }

    @Override
    public void onClick(View v) {

        if (mItemClickListener != null) {
            mItemClickListener.onItemClick(v, getPosition());
        }
    }
}
