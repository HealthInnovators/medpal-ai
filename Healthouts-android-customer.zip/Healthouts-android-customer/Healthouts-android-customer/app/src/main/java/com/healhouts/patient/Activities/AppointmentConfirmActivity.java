package com.healhouts.patient.Activities;

import android.app.ProgressDialog;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.os.AsyncTask;
import android.os.Bundle;
import android.support.v7.app.ActionBarActivity;
import android.text.Html;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;

import com.healhouts.patient.Beanclasses.DoctorItems;
import com.healhouts.patient.FragmentsPackage.ServiceHandler;
import com.healhouts.patient.R;
import com.healhouts.patient.common.CommonUtil;
import com.healhouts.patient.common.ServiceCalls;
import com.squareup.picasso.Picasso;

import java.net.URISyntaxException;
import java.util.ArrayList;


public class AppointmentConfirmActivity extends ActionBarActivity {

    String doctorId;
    String dName = "";
    String imgPath = "";
    String speciality = "";
    String location = "";
    String availableDate = "";
    String timePeriod = "";
    String time = "";
    String format = "";
    EditText nameEdit;
    EditText emailEdit;
    String customerEmail;
    String customerName;
    ProgressDialog pDialog;

    //String url = "http://healthouts.com/appConfirmApp";

//String url = "http://joslinlive.org/appConfirmApp";

    String doctorTimeId;
    SharedPreferences userSharedPreferences;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        // TODO Auto-generated method stub
        super.onCreate(savedInstanceState);
        setContentView(R.layout.confirm_appointment_layout);


        //Adding Action bar
        android.support.v7.app.ActionBar actionBar = getSupportActionBar();
        ColorDrawable colorDrawable = new ColorDrawable(Color.parseColor("#993333"));
        actionBar.setBackgroundDrawable(colorDrawable);
        actionBar.setTitle(Html.fromHtml("<font color='#ffffff'>" +  "Appointment Confirm"+ "</font>"));
        actionBar.setDisplayHomeAsUpEnabled(true);
        actionBar.setHomeButtonEnabled(true);

        userSharedPreferences = getSharedPreferences(this.getString(R.string.cPreferences), this.MODE_PRIVATE);
        customerName = userSharedPreferences.getString(this.getString(R.string.customerName), null);
        customerEmail = userSharedPreferences.getString(this.getString(R.string.customerEmail), null);
        Intent myLocalIntent = getIntent();
        Bundle myBundle = myLocalIntent.getExtras();
        doctorId = myBundle.getString("doctorId");
        dName = myBundle.getString("dName");
        imgPath = myBundle.getString("imgPath");
        speciality = myBundle.getString("speciality");
        location = myBundle.getString("location");
        availableDate = myBundle.getString("availableDate");
        timePeriod = myBundle.getString("timePeriod");
        time = myBundle.getString("time");
        format = myBundle.getString("format");
        doctorTimeId = myBundle.getString("doctorTimeId");


        TextView dNameView = (TextView) findViewById(R.id.con_profileName);
        TextView specialityView = (TextView) findViewById(R.id.con_speciality);
        TextView cityView = (TextView) findViewById(R.id.con_city);
        TextView dateView = (TextView) findViewById(R.id.app_date);
        TextView timeView = (TextView) findViewById(R.id.app_time);
        ImageView imgView = (ImageView) findViewById(R.id.con_profileImg);
//        emailEdit = (EditText) findViewById(R.id.edt_email);
//        nameEdit = (EditText) findViewById(R.id.edt_name);

        Button con_btn = (Button) findViewById(R.id.con_btn);
        con_btn.setText("Confirm With "+dName);
        con_btn.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View arg0) {
                // TODO Auto-generated method stub
                new ConfromAppointment().execute();
//                customerEmail = emailEdit.getText().toString();
//                customerName = nameEdit.getText().toString();
//                if (!customerEmail.equals("") && !customerName.equals("")) {
//
//                    new ConfromAppointment().execute();
//                } else {
//                    Toast.makeText(getApplicationContext(), "Please fill all details", Toast.LENGTH_SHORT).show();
//                }
            }
        });


        dNameView.setText(dName);
        specialityView.setText(speciality);
        cityView.setText(location);
        dateView.setText(availableDate);
        timeView.setText(time + " " + format);
        Picasso.with(getApplicationContext()).load(new CommonUtil().ConvertToUrlString(imgPath))
                .error(R.drawable.person_image_empty)
                .placeholder(R.drawable.doctorhealthouts)
                .into(imgView);
         /*new ImageDownloaderTask(imgView).execute(imgPath);*/


    }
    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.doctor_actionitems, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()) {

            case R.id.txt_doctorHomeTitle:
                Intent docSpecialities = new Intent(this, AMS.class);
                startActivity(docSpecialities);
                break;
            case android.R.id.home:
                super.onBackPressed();
                break;


            default:

        }


        return super.onOptionsItemSelected(item);
    }



    private class ConfromAppointment extends AsyncTask<Void, Void, String> {

        @Override
        protected void onPreExecute() {
            super.onPreExecute();
            // Showing progress dialog
            pDialog = new ProgressDialog(AppointmentConfirmActivity.this, R.style.MyTheme);
            pDialog.setMessage("Please wait...");
            pDialog.setCancelable(false);
            pDialog.show();

        }

        @Override
        protected String doInBackground(Void... arg0) {
            ArrayList<DoctorItems> list = new ArrayList<DoctorItems>();
            String result = "";
            // Creating service handler class instance
            ServiceHandler sh = new ServiceHandler();

            // Making a request to url and getting response
            String jsonStr = "";

            try {
                String queryStr = "?email=" + customerEmail + "&customerName=" + customerName + "&doctorId=" + doctorId + "&availableDate=" + availableDate + ""
                        + "&timePeriod=" + timePeriod + "&doctorTimeId=" + doctorTimeId;
                Log.d("log", "---queryString--->" + queryStr);
                jsonStr = sh.makeServiceCall(new CommonUtil().ConvertToUrlString(ServiceCalls.APPOINTMENT_CONFIRM_URL + queryStr), ServiceHandler.GET);
            } catch (URISyntaxException e1) {
                // TODO Auto-generated catch block
                e1.printStackTrace();
            }

            Log.d("Response: ", "> " + jsonStr);

            if (jsonStr != null) {

                result = jsonStr;
            } else {
                Log.e("ServiceHandler", "Couldn't get any data from the url");
            }

            return result;
        }

        @Override
        protected void onPostExecute(String result) {
            super.onPostExecute(result);
            Intent intent = new Intent(AppointmentConfirmActivity.this, AppointmentResultActivity.class);
            Bundle myData = new Bundle();

            if (result.equals("done")) {
                myData.putString("result", "done");
                intent.putExtras(myData);
                startActivity(intent);
            } else {
                myData.putString("result", "fail");
                intent.putExtras(myData);
                startActivity(intent);
            }
            // Dismiss the progress dialog
            if (pDialog.isShowing())
                pDialog.dismiss();
            /**
             * Updating parsed JSON data into ListView
             * */

        }
    }
}
