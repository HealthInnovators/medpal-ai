package com.healhouts.patient.FragmentsPackage;

import android.app.Fragment;
import android.app.ProgressDialog;
import android.content.Context;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.os.StrictMode;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.VolleyLog;
import com.android.volley.toolbox.JsonArrayRequest;
import com.android.volley.toolbox.Volley;
import com.healhouts.patient.Activities.SimpleDividerItemDecoration;
import com.healhouts.patient.Adapters.AdapterPaymentHistory;
import com.healhouts.patient.Beanclasses.FeedItemPayment;
import com.healhouts.patient.R;
import com.healhouts.patient.Volley.AppController;
import com.healhouts.patient.common.ConnectionDetector;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.List;

public class YourPaymentHistory extends Fragment {

	private static final String TAG ="YourPaymentHistory" ;
	private Context context;
	Boolean isInternetPresent = false;
	ConnectionDetector cd;
	JSONArray jsonArray;
	JSONObject jsonObject;
	private List<FeedItemPayment> feedItemList = new ArrayList<FeedItemPayment>();
	private RecyclerView mRecyclerView;
	LinearLayoutManager mLayoutManager;
	SharedPreferences userSharedPreferences;
	private AdapterPaymentHistory adapter;
	private boolean loading = true;
	int firstVisibleItem, visibleItemCount, totalItemCount;
	int count =0;
	int token = 0;
	private String customerId;
	private  String customerEmail;
	ProgressDialog pDialog;
	TextView totalAmount;
	//String url="http://healthouts.com/appYourPayHistory?";
		String url="http://joslinlive.org/appYourPayHistory?";

//	CId=5&CEmail=ven.veeravalli@gmail.com


	@Override
	public void onCreate(Bundle savedInstanceState) {
		// TODO Auto-generated method stub
		super.onCreate(savedInstanceState);
	}

	public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		StrictMode.ThreadPolicy policy = new StrictMode.ThreadPolicy.Builder().permitAll().build();
		StrictMode.setThreadPolicy(policy);
		context = getActivity().getApplicationContext();
		cd = new ConnectionDetector(context);
		isInternetPresent = cd.isConnectingToInternet();

		View fragmentView = inflater.inflate(R.layout.paidhistory_list, container, false);


		userSharedPreferences = this.getActivity().getSharedPreferences(context.getString(R.string.cPreferences), Context.MODE_PRIVATE);
		customerId = userSharedPreferences.getString(context.getString(R.string.customerId), null);
		customerEmail = userSharedPreferences.getString(getActivity().getResources().getString(R.string.customerEmail), null);


		mRecyclerView = (RecyclerView) fragmentView.findViewById(R.id.recycler_view);
		mRecyclerView.setHasFixedSize(true);
		mLayoutManager = new LinearLayoutManager(getActivity());
		mRecyclerView.setLayoutManager(mLayoutManager);
		/*RecyclerView.ItemDecoration itemDecoration =
	 			new DividerItemDecoration(getActivity(), LinearLayoutManager.VERTICAL);
		mRecyclerView.addItemDecoration(itemDecoration);
	*/	getPaymentHistory();
		Volley.newRequestQueue(context);
		return fragmentView;

	}


	public void getPaymentHistory() {
		final ProgressDialog pDialog = new ProgressDialog(getActivity());
		pDialog.setMessage("Loading...");
		pDialog.show();
		FeedItemPayment item = new FeedItemPayment();
		JsonArrayRequest req = new JsonArrayRequest(url+"CId="+customerId+"&CEmail="+customerEmail,
				new Response.Listener<JSONArray>() {
					@Override
					public void onResponse(JSONArray response) {
						for (int i = 0; i < response.length(); i++) {
							JSONObject jsonobject = null;

							FeedItemPayment item = new FeedItemPayment();
							Log.d(TAG, "length is" + response.length());
							try {
								jsonObject = response.getJSONObject(i);
								Log.d(TAG,"at"+i+"th obj is"+jsonObject);
								item.setDoctoName(jsonObject.optString("doctoName"));
								item.setPayref(jsonObject.optString("payref"));
								item.setPayDate(jsonObject.optString("payDate"));
								item.setConsultationType(jsonObject.optString("consultationType"));
								item.setConsultationFee(jsonObject.optString("consultationFee"));
								item.setCurrencyCode(jsonObject.optString("currencyCode"));
							} catch (JSONException e) {
								e.printStackTrace();
							}

							feedItemList.add(item);
							adapter = new AdapterPaymentHistory(getActivity(), feedItemList);
							mRecyclerView.addItemDecoration(new SimpleDividerItemDecoration(getResources()));
							mRecyclerView.setAdapter(adapter);
						}
						pDialog.hide();
					}
				}, new Response.ErrorListener() {
			@Override
			public void onErrorResponse(VolleyError error) {
				VolleyLog.d(TAG, "Error: " + error.getMessage());
				pDialog.hide();
			}
		});
		AppController.getInstance(context.getApplicationContext()).addToRequestQueue(req);

	}
	@Override
	public void onActivityCreated(Bundle savedInstanceState) {
		// TODO Auto-generated method stub
		super.onActivityCreated(savedInstanceState);
	}

}
