package com.healhouts.patient.FragmentsPackage;

import android.app.AlertDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.os.StrictMode;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.healhouts.patient.R;


/**
 * Created by sony on 04/03/2015.
 */
public class Fragment4 extends Fragment implements View.OnClickListener {
    final String TAG = "Fragment4";
    EditText et_question;
    Button button_post;
    SharedPreferences userSharedPreferences;
    private Context context;
    private String customerId;
    private boolean loginStatus = false;
    public String et;

    @Override
    public View onCreateView(LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        StrictMode.ThreadPolicy policy = new StrictMode.ThreadPolicy.Builder().permitAll().build();
        StrictMode.setThreadPolicy(policy);
        context = getActivity().getApplicationContext();


        View v = inflater.inflate(R.layout.fragment4, container, false);

        userSharedPreferences = this.getActivity().getSharedPreferences(context.getString(R.string.cPreferences), Context.MODE_PRIVATE);
        Log.d(TAG, "--userSharedPreferenc--" + userSharedPreferences);
        if (userSharedPreferences.getString(context.getString(R.string.customerId), null) != null) {
            customerId = userSharedPreferences.getString(context.getString(R.string.customerId), null);
            loginStatus = true;
        }
        if (loginStatus) {
            Toast.makeText(getActivity(), "you are logged in", Toast.LENGTH_SHORT).show();
        } else {

            AlertDialog.Builder builder = new AlertDialog.Builder(getActivity());
            builder.setTitle(R.string.login_title +"required");
            builder.setMessage("You need to login before you proceed");
            builder.setIcon(R.drawable.ic_report)
                    .setNegativeButton("Cancel", new DialogInterface.OnClickListener() {
                        public void onClick(DialogInterface dialog, int id) {
                            dialog.dismiss();
                        }
                    });

            builder.show();
        }

        et_question = (EditText) v.findViewById(R.id.editTextQestion);
        String et= et_question.getText().toString();
        button_post = (Button) v.findViewById(R.id.btnSendQs);
        button_post.setOnClickListener(this);


        return v;
    }

    @Override
    public void onClick(View v) {
        switch (v.getId()) {
            case R.id.btnSendQs:{
                if(et==null) {
                    Toast.makeText(getActivity(), "It should not be empty", Toast.LENGTH_SHORT).show();

                }
            }



        }
    }
}

