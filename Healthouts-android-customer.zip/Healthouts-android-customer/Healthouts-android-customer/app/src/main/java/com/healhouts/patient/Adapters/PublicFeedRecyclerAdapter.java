package com.healhouts.patient.Adapters;

import android.content.Context;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import com.healhouts.patient.Beanclasses.FeedItem;
import com.healhouts.patient.R;
import com.healhouts.patient.common.CommonUtil;
import com.squareup.picasso.Picasso;

import java.util.List;

/**
 * Created by Venkat Veeravalli on 19-05-2015.
 */
public class PublicFeedRecyclerAdapter extends RecyclerView.Adapter<PublicFeedRecyclerAdapter.FeedListRowHolder> {


    private List<FeedItem> feedItemList;

    private Context mContext;
    public PublicFeedRecyclerAdapter(Context context, List<FeedItem> feedItemList) {
        this.feedItemList = feedItemList;
        this.mContext = context;
    }

    @Override
    public FeedListRowHolder onCreateViewHolder(ViewGroup viewGroup, int viewType) {
        View v = LayoutInflater.from(viewGroup.getContext()).inflate(R.layout.public_feed_list, null);
        FeedListRowHolder mh = new FeedListRowHolder(v);
        return mh;
    }

    public void onBindViewHolder(FeedListRowHolder feedListRowHolder, int i) {
        FeedItem feedItem = feedItemList.get(i);

//        Log.d("---", "--feedItem.getThumbnail()---" + feedItem.getThumbnail());

    //    Picasso.with(mContext).load(new CommonUtil().ConvertToUrlString("http://healthouts.com/img/"+feedItem.getDoctorImage()))

        Picasso.with(mContext).load(new CommonUtil().ConvertToUrlString("http://joslinlive.org/img/"+feedItem.getDoctorImage()))

                .error(R.drawable.person_image_empty)
                .placeholder(R.drawable.person_image_empty)
                .into(feedListRowHolder.feedDocImg);

        feedListRowHolder.textFeedDocName.setText(feedItem.getDoctorName());
        feedListRowHolder.textViewQs.setText(feedItem.getQuestionBody());
        feedListRowHolder.textViewAnsHead.setText(feedItem.getAnswerSubject());
        feedListRowHolder.textViewAnsbody.setText(feedItem.getAnswerBody());
    }
    @Override
    public int getItemCount() {
        return (null != feedItemList ? feedItemList.size() : 0);

    }

    class FeedListRowHolder extends RecyclerView.ViewHolder {
        protected ImageView feedDocImg;
        protected TextView textFeedDocName;
        protected TextView textAnswered;
        protected TextView textViewQs;
        protected TextView textViewAnsHead;
        protected TextView textViewAnsbody;

        public FeedListRowHolder(View view) {
            super(view);
            this.feedDocImg = (ImageView) view.findViewById(R.id.customerImg);
            this.textFeedDocName = (TextView)view.findViewById(R.id.textFeedDocName);
            this.textAnswered = (TextView)view.findViewById(R.id.textAnswered);
            this.textViewQs = (TextView)view.findViewById(R.id.textViewQs);
            this.textViewAnsHead = (TextView)view.findViewById(R.id.textViewAnsHead);
            this.textViewAnsbody = (TextView)view.findViewById(R.id.textViewAnsbody);
        }

    }
}
