package com.healhouts.patient.FragmentsPackage;

/**
 * Created by trina on 9/24/2015.
 */
public class Const {
//   public static String URL_JSON_ARRAY="http://healthouts.com/appBookedAppointments?";
public static String URL_JSON_ARRAY="http://joslinlive.org/appBookedAppointments?";


}
