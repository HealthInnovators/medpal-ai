package com.healhouts.patient.common;

import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.PorterDuff;
import android.graphics.PorterDuffXfermode;
import android.graphics.Rect;
import android.graphics.RectF;
import android.net.http.AndroidHttpClient;
import android.os.AsyncTask;
import android.util.Log;
import android.widget.ImageView;

import org.apache.http.HttpEntity;
import org.apache.http.HttpResponse;
import org.apache.http.HttpStatus;
import org.apache.http.client.methods.HttpGet;

import java.io.FilterInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.lang.ref.WeakReference;
import java.net.URI;
import java.net.URISyntaxException;

public class ImageDownloaderTask extends AsyncTask<String, Void, Bitmap> {
    private final WeakReference imageViewReference;
    private boolean isTaskCancelled = false;
    public static String TAG = "ImageDownloaderTask";
    public static int maxWidth   =85;
    public static int maxHeight   =85;

    public void cancelTask() {
        isTaskCancelled = true;
    }

    private boolean isTaskCancelled() {
        return isTaskCancelled;
    }

    static Bitmap downloadBitmap(String url) {

        final AndroidHttpClient client = AndroidHttpClient.newInstance("Android");
        HttpGet getRequest = null;
        try {
            Log.d(TAG, "--img Path that sent to server--" + url);
            getRequest = new HttpGet(new URI(url));
            HttpResponse response = client.execute(getRequest);
            final int statusCode = response.getStatusLine().getStatusCode();
            if (statusCode != HttpStatus.SC_OK) {
                Log.w(TAG, "Error " + statusCode
                        + " while retrieving bitmap from " + url);
                return null;
            }

            final HttpEntity entity = response.getEntity();
            if (entity != null) {
                InputStream inputStream = null;
                try {
                    inputStream = entity.getContent();
                    BitmapFactory.Options options = new BitmapFactory.Options();

                    options.inJustDecodeBounds = false;
                    options.inScaled = false;
                    options.inDither = false;
                    options.inPreferredConfig = Bitmap.Config.ARGB_8888;
                    options.inPreferQualityOverSpeed = true;
                    options.inSampleSize=3;
                    Bitmap bitmap = BitmapFactory.decodeStream(new FlushedInputStream(inputStream), null, options);



                    bitmap=ImageHelper.getRoundedCornerBitmap(bitmap,50);
                    int originWidth  = bitmap.getWidth();
                    int originHeight = bitmap.getHeight();

                    if (originWidth < maxWidth && originHeight < maxHeight) {
                        return bitmap;
                    }

                    int width  = originWidth;
                    int height = originHeight;
                    if (originWidth > maxWidth) {
                        width = maxWidth;


                        double i = originWidth * 1.0 / maxWidth;
                        height = (int) Math.floor(originHeight / i);

                        bitmap = Bitmap.createScaledBitmap(bitmap, width, height, false);
                    }

                    if (height > maxHeight) {
                        height = maxHeight;

                        bitmap = Bitmap.createBitmap(bitmap, 0, 0, width, height);
                    }


                    Log.d(TAG,"in Kb"+bitmap.getByteCount()/1024);

                    return bitmap;
                } finally {
                    if (inputStream != null) {
                        inputStream.close();
                    }
                    entity.consumeContent();
                }
            }
        } catch (URISyntaxException u) {
            u.printStackTrace();
        } catch (Exception e) {

            // Could provide a more explicit error message for IOException or
            // IllegalStateException
            getRequest.abort();
            Log.w("ImageDownloader", "Error while retrieving bitmap from " + url);
        } finally {
            if (client != null) {
                client.close();
            }
        }
        return null;
    }


    public ImageDownloaderTask(ImageView imageView) {
        imageViewReference = new WeakReference(imageView);
    }

    @Override
    // Actual download method, run in the task thread
    protected Bitmap doInBackground(String... params) {
        if (isTaskCancelled()) {
            return null;
        }
        // params comes from the execute() call: params[0] is the url.
        return downloadBitmap(params[0]);
    }

    @Override
    // Once the image is downloaded, associates it to the imageView
    protected void onPostExecute(Bitmap bitmap) {
        if (isCancelled()) {
            bitmap = null;
        }

        if (imageViewReference != null) {
            ImageView imageView = (ImageView) imageViewReference.get();
            if (imageView != null) {

                if (bitmap != null) {
                    imageView.setImageBitmap(bitmap);
                }
            }

        }
    }

    public static class ImageHelper {


        public static Bitmap getRoundedCornerBitmap(Bitmap bitmap, int pixels) {

            Bitmap output = Bitmap.createBitmap(bitmap.getWidth(), bitmap
                    .getHeight(), Bitmap.Config.ARGB_8888);
            Canvas canvas = new Canvas(output);

            final int color = 0xff424242;
            final Paint paint = new Paint();
            final Rect rect = new Rect(0, 0, bitmap.getWidth(), bitmap.getHeight());
            final RectF rectF = new RectF(rect);
            final float roundPx = pixels;

            paint.setAntiAlias(true);
            canvas.drawARGB(0, 0, 0, 0);
            paint.setColor(color);
            canvas.drawRoundRect(rectF, roundPx, roundPx, paint);

            paint.setXfermode(new PorterDuffXfermode(PorterDuff.Mode.SRC_IN));
            canvas.drawBitmap(bitmap, rect, rect, paint);

            return output;
        }
    }

    static class FlushedInputStream extends FilterInputStream
    {
        public FlushedInputStream(InputStream inputStream)
        {
            super(inputStream);
        }

        @Override
        public long skip(long n) throws IOException
        {
            long totalBytesSkipped = 0L;
            while(totalBytesSkipped < n)
            {
                long bytesSkipped = in.skip(n - totalBytesSkipped);
                if(bytesSkipped == 0L)
                {
                    int bytes = read();
                    if(bytes < 0)
                    {
                        break; // we reached EOF
                    }
                    else
                    {
                        bytesSkipped = 1; // we read one byte
                    }
                }
                totalBytesSkipped += bytesSkipped;
            }
            return totalBytesSkipped;
        }
    }

}


