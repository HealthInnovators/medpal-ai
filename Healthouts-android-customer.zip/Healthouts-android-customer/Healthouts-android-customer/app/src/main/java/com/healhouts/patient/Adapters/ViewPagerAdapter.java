package com.healhouts.patient.Adapters;

import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentManager;
import android.support.v4.app.FragmentStatePagerAdapter;

import com.healhouts.patient.FragmentsPackage.DoctorsTab;
import com.healhouts.patient.FragmentsPackage.SpecialitiesTab;

/**
 * Created by sony on 23/02/2015.
 */
public class ViewPagerAdapter extends FragmentStatePagerAdapter {
    /* This will store the Titles of the Tab which are going to be passed when the ViewPagerAdapter is going to be created */
    CharSequence Titles[];
    /* This will store the number of Tabs which will be passed when the ViewPagerAdapter will be created*/
    int NumOfTabs;

    /* Make a constructor and pass the appropriate values to the constructor*/
    public ViewPagerAdapter(FragmentManager fm, CharSequence mTitles[], int noOfTabs) {
        super(fm);
        this.Titles = mTitles;
        this.NumOfTabs = noOfTabs;
    }

    /*This method will return the Fragment for every new position in the View Pager*/
    @Override
    public Fragment getItem(int position) {
        if (position == 0) {
            SpecialitiesTab specialitiesTab = new SpecialitiesTab();
            return specialitiesTab;
        } else {
            DoctorsTab doctorsTab = new DoctorsTab();
            return doctorsTab;
        }
    }

    // This method return the titles for the Tabs in the Tab Strip

    public CharSequence getPageTitle(int position) {
        return Titles[position];
    }

    @Override
    public int getCount() {
        return NumOfTabs;
    }
}
