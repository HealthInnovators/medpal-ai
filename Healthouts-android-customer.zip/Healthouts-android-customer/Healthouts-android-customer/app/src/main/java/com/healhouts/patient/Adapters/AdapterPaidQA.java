package com.healhouts.patient.Adapters;

/**
 * Created by samsung on 27-05-2015.
 */

import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.content.pm.ResolveInfo;
import android.net.Uri;
import android.os.Bundle;
import android.os.Environment;
import android.support.v7.widget.RecyclerView;
import android.util.Log;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.PopupWindow;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import com.healhouts.patient.Beanclasses.FeedItemPaidQA;
import com.healhouts.patient.R;
import com.healhouts.patient.common.CommonUtil;
import com.healhouts.patient.common.ZoomInZoomOut;
import com.squareup.picasso.Picasso;

import java.io.BufferedInputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.List;

/**
 * Created by Sheshakanth on 21-05-2015.
 */
public class AdapterPaidQA extends RecyclerView.Adapter<AdapterPaidQA.FeedListRowHolderPaidQA>{
    String TAG=getClass().getName();
    TextView questionId;
    ImageView attatcment;
    TextView healthfile;
    LinearLayout linearLayout;
    private List<FeedItemPaidQA> feedItemList;
    String[] DayOfWeek = {"1", "2","3"};
    FileInputStream in;
    BufferedInputStream buf;
    private Context mContext;
    OnItemClickListener mItemClickListener;
    public AdapterPaidQA(Context context, List<FeedItemPaidQA> feedItemList) {
        this.feedItemList = feedItemList;
        this.mContext = context;
    }

    @Override
    public FeedListRowHolderPaidQA onCreateViewHolder(ViewGroup viewGroup, int viewType) {

        View v = LayoutInflater.from(viewGroup.getContext()).inflate(R.layout.your_paid_feed_list, null);
        final Button reviewButton;
        reviewButton=(Button)v.findViewById(R.id.reviewButton);
        attatcment=(ImageView)v.findViewById(R.id.attatcment);
        healthfile=(TextView)v.findViewById(R.id.healthfile);
        reviewButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                LayoutInflater layoutInflater = (LayoutInflater)mContext.getSystemService(mContext.LAYOUT_INFLATER_SERVICE);
                View popupView = layoutInflater.inflate(R.layout.popup, null);
                final PopupWindow popupWindow = new PopupWindow(
                        popupView, LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT);
                popupWindow.showAtLocation(popupView, Gravity.CENTER, 10, 10);
                Button btnDismiss = (Button)popupView.findViewById(R.id.dismiss);

                Spinner popupSpinner = (Spinner)popupView.findViewById(R.id.popupspinner);

                ArrayAdapter<String> adapter =
                        new ArrayAdapter<String>(mContext,
                                android.R.layout.simple_spinner_item, DayOfWeek);
                adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
                popupSpinner.setAdapter(adapter);

                btnDismiss.setOnClickListener(new Button.OnClickListener(){

                    @Override
                    public void onClick(View v) {
                        popupWindow.dismiss();
                    }});

                popupWindow.showAsDropDown(reviewButton, 50, -30);

            }
        });

        FeedListRowHolderPaidQA mh = new FeedListRowHolderPaidQA(v);

        return mh;
    }
    public static boolean createDirIfNotExists(String path) {
        boolean ret = true;

        File file = new File(Environment.getExternalStorageDirectory(), path);
        if (!file.exists()) {
            if (!file.mkdirs()) {
                Log.e("TravellerLog :: ", "Problem creating Image folder");
                ret = false;
            }
        }
        return ret;
    }
    public void onBindViewHolder(final FeedListRowHolderPaidQA feedListRowHolder, final int i) {
        final FeedItemPaidQA feedItem = feedItemList.get(i);

      //  Picasso.with(mContext).load(new CommonUtil().ConvertToUrlString("http://healthouts.com/img/"+feedItem.getCustomerImg()))

       Picasso.with(mContext).load(new CommonUtil().ConvertToUrlString("http://joslinlive.org/img/"+feedItem.getCustomerImg()))

                .error(R.drawable.ic_launcher)
                .placeholder(R.drawable.ic_launcher)
                .into(feedListRowHolder.customerImg);

        feedListRowHolder.cSubject.setText(feedItem.getCsubject());
        feedListRowHolder.cutomerName.setText(feedItem.getCutomerName());
        feedListRowHolder.cdetails.setText(feedItem.getCdetails());
        feedListRowHolder.healthFile.setText(feedItem.getHealthFile());
        if(feedItem.getHealthFile()!=null && !feedItem.getHealthFile().equals("")){
            feedListRowHolder.healthFile.setText(feedItem.getHealthFile());
            Log.d("------", "--------------------" + feedItem.getHealthFile());
            attatcment.setVisibility(View.VISIBLE);
            healthfile.setVisibility(View.VISIBLE);
            attatcment.setOnClickListener(new View.OnClickListener() {



              //  String url="http://healthouts.com/img/"+feedItem.getHealthFile();
               String url="http://joslinlive.org/img/"+feedItem.getHealthFile();

                @Override
                public void onClick(View v) {
                    Toast toast = Toast.makeText(mContext, "Please Wait..", Toast.LENGTH_LONG);
                    toast.getView().setBackgroundColor(mContext.getResources().getColor(R.color.healthoutstheme));
                    toast.setGravity(Gravity.TOP|Gravity.LEFT, 0, 0);
                    toast.show();

                    Log.d(TAG,"url is"+url);
                    downloadPdfContent(url);



                }

                public void downloadPdfContent(String urlToDownload) {
                    try {

                        String fileName=feedItem.getHealthFile();
                        String fileExtension = android.webkit.MimeTypeMap.getSingleton().getFileExtensionFromUrl(fileName);
                        String fileMimeType = android.webkit.MimeTypeMap.getSingleton().getMimeTypeFromExtension(fileExtension);

                        URL url = new URL(urlToDownload);
                        HttpURLConnection c = (HttpURLConnection) url.openConnection();
                        c.setRequestMethod("GET");
                        c.setDoOutput(true);
                        c.connect();
                     //   String PATH = Environment.getExternalStorageDirectory() + "/healthouts/";
                       String PATH = Environment.getExternalStorageDirectory() + "/joslin/";
                        File f =new  File(PATH+fileName);

                        if(!f.exists()) {
                            File file = new File(PATH);
//                            createDirIfNotExists("healthouts");
                            createDirIfNotExists("joslin");

                            File outputFile = new File(file, fileName);
                            FileOutputStream fos = new FileOutputStream(outputFile);
                            InputStream is = c.getInputStream();
                            byte[] buffer = new byte[1024];
                            int len1 = 0;
                            while ((len1 = is.read(buffer)) != -1) {
                                fos.write(buffer, 0, len1);
                            }
                            fos.close();
                            is.close();
                            showFile(PATH+fileName, fileMimeType);

                        }else {
                            //show ic_action_attachment
                            showFile(PATH+fileName, fileMimeType);
                        }

                    } catch (Exception e) {
                        e.printStackTrace();

                    }
                }

                public  void showFile(String path, String fileMimeType){
                    //show ic_action_attachment
                    Log.d("---", "----path---"+path);
                    Log.d("---", "----fileMimeType---"+fileMimeType);

                    if(fileMimeType.equals("image/jpeg") || fileMimeType.equals("image/png")){
                        Intent intent = new Intent(mContext, ZoomInZoomOut.class);
                        Bundle myData = new Bundle();
                        myData.putString("imagePath", path);
                        intent.putExtras(myData);
                        mContext.startActivity(intent);
                    }else {
                        Intent intent = new Intent();
                        intent.setAction(Intent.ACTION_VIEW);
                        intent.setData(Uri.parse(path));
                        intent.setType(fileMimeType);
                        PackageManager pm = mContext.getPackageManager();
                        List<ResolveInfo> activities = pm.queryIntentActivities(intent, 0);
                        if (activities.size() > 0) {
                            mContext.startActivity(intent);
                        } else {
                            Toast toast = Toast.makeText(mContext, "Sorry some problem in ic_action_attachment download!", Toast.LENGTH_LONG);
                            toast.getView().setBackgroundColor(mContext.getResources().getColor(R.color.healthoutstheme));
                            toast.show();
                        }
                    }
                }


            });



        }else {
            attatcment.setVisibility(View.GONE);
            healthfile.setVisibility(View.GONE);
        }

        if(feedItem.isAnswerStatus()){
            if(feedItem.isReviewStatus()==false){
                feedListRowHolder.reviewButton.setVisibility(View.VISIBLE);
//                Log.d(">>>", "isReviewStatus" + feedItem.isReviewStatus());
            }else
            {
                feedListRowHolder.reviewButton.setVisibility(View.INVISIBLE);

            }
            feedListRowHolder.dname.setVisibility(View.VISIBLE);
            feedListRowHolder.dImgPath.setVisibility(View.VISIBLE);
            feedListRowHolder.doctorAnswer.setVisibility(View.VISIBLE);
            feedListRowHolder.doctorSubject.setVisibility(View.VISIBLE);
            Picasso.with(mContext).load(new CommonUtil().ConvertToUrlString("http://joslinlive.org/img/"+feedItem.getdImgPath()))


           // Picasso.with(mContext).load(new CommonUtil().ConvertToUrlString("http://healthouts.com/img/"+feedItem.getdImgPath()))
                    .error(R.drawable.ic_launcher)
                    .placeholder(R.drawable.ic_launcher)
                    .into(feedListRowHolder.dImgPath);


            feedListRowHolder.dname.setText(feedItem.getDname());
            feedListRowHolder.doctorSubject.setText(feedItem.getDoctorSubject());
            feedListRowHolder.doctorAnswer.setText(feedItem.getDoctorAnswer());
            // feedListRowHolder.reviewButton.setVisibility(View.VISIBLE);
        }
        else{
            feedListRowHolder.dname.setVisibility(View.GONE);
            feedListRowHolder.dImgPath.setVisibility(View.GONE);
            feedListRowHolder.doctorAnswer.setVisibility(View.GONE);
            feedListRowHolder.doctorSubject.setVisibility(View.GONE);
            feedListRowHolder.reviewButton.setVisibility(View.GONE);
        }


    }

    private void onPdfClick() {
    }


    @Override
    public int getItemCount() {

        return (null != feedItemList ? feedItemList.size() : 0);
    }

    public  interface OnItemClickListener{
        public  void onItemClick(View view, int position);
    }
    public void SetOnItemClickListener(final OnItemClickListener mItemClickListener) {
        this.mItemClickListener = mItemClickListener;
    }

    public class FeedListRowHolderPaidQA  extends RecyclerView.ViewHolder implements View.OnClickListener{

        protected TextView cutomerName;
        protected ImageView customerImg;
        protected TextView cSubject;
        protected TextView cdetails;
        protected  TextView cid;
        protected TextView healthFile;



        protected TextView dname;
        protected ImageView dImgPath;
        protected TextView doctorSubject;
        protected TextView doctorAnswer;
        protected  TextView did;

        protected Button reviewButton;

        public FeedListRowHolderPaidQA(View view) {
            super(view);
            this.customerImg = (ImageView) view.findViewById(R.id.customerImg);
            this.cutomerName=(TextView)view.findViewById(R.id.cutomerName);
            this.cSubject = (TextView) view.findViewById(R.id.cSubject);
            this.cdetails = (TextView) view.findViewById(R.id.cdetails);
            this.healthFile=(TextView)view.findViewById(R.id.healthfile);

            this.dImgPath = (ImageView) view.findViewById(R.id.dImgPath);
            this.dname = (TextView) view.findViewById(R.id.dname);
            this.doctorSubject = (TextView) view.findViewById(R.id.doctorSubject);
            this.doctorAnswer = (TextView) view.findViewById(R.id.doctorAnswer);
            this.reviewButton=(Button)view.findViewById(R.id.reviewButton);



//            view.setOnClickListener(this);
            this.reviewButton.setOnClickListener(this);
        }

        @Override
        public void onClick(View v) {

            if (mItemClickListener != null) {
                mItemClickListener.onItemClick(v, getPosition());
            }
        }

    }


}

/*
package com.healhouts.patient.FragmentsPackage;

*/
/**
 * Created by samsung on 27-05-2015.
 *//*


import android.content.Context;
import android.net.Uri;
import android.os.Environment;
import android.support.v7.widget.RecyclerView;
import android.util.Log;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.PopupWindow;
import android.widget.Spinner;
import android.widget.TextView;
import com.healhouts.patient.common.CommonUtil;
import com.healhouts.patient.R;
import com.squareup.picasso.Picasso;
import java.io.BufferedInputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.List;

*/
/**
 * Created by Sheshakanth on 21-05-2015.
 *//*

public class AdapterPaidQA extends RecyclerView.Adapter<AdapterPaidQA.FeedListRowHolderPaidQA>{
    String TAG=getClass().getName();
    TextView questionId;
    ImageView attatcment;
    TextView healthfile;
//    Button reviewButton;
    LinearLayout linearLayout;
    private List<FeedItemPaidQA> feedItemList;
    String[] ratingValues = {"1", "2","3","4","5"};
    FileInputStream in;
    BufferedInputStream buf;
    private Context mContext;
    OnItemClickListener mItemClickListener;
    public  String URL="url: http://healthouts.com/appSendReview?";
    public AdapterPaidQA(Context context, List<FeedItemPaidQA> feedItemList) {
        this.feedItemList = feedItemList;
        this.mContext = context;
    }
    @Override
    public FeedListRowHolderPaidQA onCreateViewHolder(ViewGroup viewGroup, int viewType) {
        View v = LayoutInflater.from(viewGroup.getContext()).inflate(R.layout.your_paid_feed_list, null);
       // reviewButton=(Button)v.findViewById(R.id.reviewButton);
        attatcment=(ImageView)v.findViewById(R.id.attatcment);
        healthfile=(TextView)v.findViewById(R.id.healthfile);
        FeedListRowHolderPaidQA mh = new FeedListRowHolderPaidQA(v);
        return mh;
    }
    public void onBindViewHolder(final FeedListRowHolderPaidQA feedListRowHolder, final int i) {
        final FeedItemPaidQA feedItem = feedItemList.get(i);
        Picasso.with(mContext).load(new CommonUtil().ConvertToUrlString("http://healthouts.com/img/" + feedItem.getCustomerImg()))
                .error(R.drawable.ic_launcher)
                .placeholder(R.drawable.ic_launcher)
                .into(feedListRowHolder.customerImg);
        feedListRowHolder.cSubject.setText(feedItem.getCsubject());
        feedListRowHolder.cutomerName.setText(feedItem.getCutomerName());
        feedListRowHolder.cdetails.setText(feedItem.getCdetails());
        feedListRowHolder.healthFile.setText(feedItem.getHealthFile());
        if (feedItem.getHealthFile() != null && feedItem.getHealthFile() != "") {
            feedListRowHolder.healthFile.setText(feedItem.getHealthFile());
            Log.d("healthfile is", "is" + feedItem.getHealthFile());
            attatcment.setVisibility(View.VISIBLE);
            healthfile.setVisibility(View.VISIBLE);


        }

        if (feedItem.isAnswerStatus()) {
            if (feedItem.isReviewStatus() == false) {
                feedListRowHolder.reviewButton.setVisibility(View.VISIBLE);
//                Log.d(">>>", "isReviewStatus" + feedItem.isReviewStatus());
            } else {
                feedListRowHolder.reviewButton.setVisibility(View.INVISIBLE);

            }
            feedListRowHolder.dname.setVisibility(View.VISIBLE);
            feedListRowHolder.dImgPath.setVisibility(View.VISIBLE);
            feedListRowHolder.doctorAnswer.setVisibility(View.VISIBLE);
            feedListRowHolder.doctorSubject.setVisibility(View.VISIBLE);
            Picasso.with(mContext).load(new CommonUtil().ConvertToUrlString("http://healthouts.com/img/" + feedItem.getdImgPath()))
                    .error(R.drawable.ic_launcher)
                    .placeholder(R.drawable.ic_launcher)
                    .into(feedListRowHolder.dImgPath);


            feedListRowHolder.dname.setText(feedItem.getDname());
            feedListRowHolder.doctorSubject.setText(feedItem.getDoctorSubject());
            feedListRowHolder.doctorAnswer.setText(feedItem.getDoctorAnswer());
            // feedListRowHolder.reviewButton.setVisibility(View.VISIBLE);
        } else {
            feedListRowHolder.dname.setVisibility(View.GONE);
            feedListRowHolder.dImgPath.setVisibility(View.GONE);
            feedListRowHolder.doctorAnswer.setVisibility(View.GONE);
            feedListRowHolder.doctorSubject.setVisibility(View.GONE);
            feedListRowHolder.reviewButton.setVisibility(View.GONE);
        }
    }

     */
/*   reviewButton.setOnClickListener(new View.OnClickListener() {

            *//*
*/
/*@Override
            public void onClick(View v) {
                LayoutInflater layoutInflater = (LayoutInflater)mContext.getSystemService(mContext.LAYOUT_INFLATER_SERVICE);
                View popupView = layoutInflater.inflate(R.layout.popup, null);
                final PopupWindow popupWindow = new PopupWindow(
                        popupView, LinearLayout.LayoutParams.WRAP_CONTENT, LinearLayout.LayoutParams.WRAP_CONTENT);
                popupWindow.showAtLocation(popupView, Gravity.CENTER, 10, 10);
                popupWindow.setFocusable(true);
                popupWindow.update();
                Button btnDismiss = (Button)popupView.findViewById(R.id.dismiss);
                Button submit = (Button)popupView.findViewById(R.id.submit);
                Spinner popupSpinner = (Spinner)popupView.findViewById(R.id.popupspinner);

                ArrayAdapter<String> adapter =
                        new ArrayAdapter<String>(mContext,
                                android.R.layout.simple_spinner_item, ratingValues);
                adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
                popupSpinner.setAdapter(adapter);
                btnDismiss.setOnClickListener(new Button.OnClickListener(){

                                                  @Override
                                                  public void onClick(View v) {
                                                      popupWindow.dismiss();
                                                  }}

                );

                popupWindow.showAsDropDown(reviewButton, 50, -30);

            }*//*
*/
/*
        });
    }*//*


    private void onPdfClick() {
    }


    @Override
    public int getItemCount() {

        return (null != feedItemList ? feedItemList.size() : 0);
    }

    public  interface OnItemClickListener{
        public  void onItemClick(View view, int position);
    }
    public void SetOnItemClickListener(final OnItemClickListener mItemClickListener) {
        this.mItemClickListener = mItemClickListener;
    }

    public class FeedListRowHolderPaidQA  extends RecyclerView.ViewHolder implements View.OnClickListener{

        protected TextView cutomerName;
        protected ImageView customerImg;
        protected TextView cSubject;
        protected TextView cdetails;
        protected  TextView cid;
        protected TextView healthFile;



        protected TextView dname;
        protected ImageView dImgPath;
        protected TextView doctorSubject;
        protected TextView doctorAnswer;
        protected  TextView did;

        protected Button reviewButton;

        public FeedListRowHolderPaidQA(View view) {
            super(view);
            this.customerImg = (ImageView) view.findViewById(R.id.customerImg);
            this.cutomerName=(TextView)view.findViewById(R.id.cutomerName);
            this.cSubject = (TextView) view.findViewById(R.id.cSubject);
            this.cdetails = (TextView) view.findViewById(R.id.cdetails);
            this.healthFile=(TextView)view.findViewById(R.id.healthfile);

            this.dImgPath = (ImageView) view.findViewById(R.id.dImgPath);
            this.dname = (TextView) view.findViewById(R.id.dname);
            this.doctorSubject = (TextView) view.findViewById(R.id.doctorSubject);
            this.doctorAnswer = (TextView) view.findViewById(R.id.doctorAnswer);
            this.reviewButton=(Button)view.findViewById(R.id.reviewButton);
            view.setOnClickListener(this);
        }

        @Override
        public void onClick(View v) {

            if (mItemClickListener != null) {
                mItemClickListener.onItemClick(v, getPosition());
            }
        }

    }

}*/
