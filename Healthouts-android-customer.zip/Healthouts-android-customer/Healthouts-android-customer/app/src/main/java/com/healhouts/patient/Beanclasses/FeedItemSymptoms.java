package com.healhouts.patient.Beanclasses;

/**
 * Created by samsung on 01-07-2015.
 */
public class FeedItemSymptoms {

    public String getSymptomId() {
        return symptomId;
    }

    public void setSymptomId(String symptomId) {
        this.symptomId = symptomId;
    }

    public String getSymptomState() {
        return symptomState;
    }

    public void setSymptomState(String symptomState) {
        this.symptomState = symptomState;
    }

    public String getSymptom() {
        return symptom;
    }

    public void setSymptom(String symptom) {
        this.symptom = symptom;
    }

    public String getNotes() {
        return notes;
    }

    public void setNotes(String notes) {
        this.notes = notes;
    }

    public String getCustomerId() {
        return customerId;
    }

    public void setCustomerId(String customerId) {
        this.customerId = customerId;
    }

    private  String symptomId;
    private  String symptomState;
    private  String symptom;
    private  String notes;
    private  String customerId;

}
