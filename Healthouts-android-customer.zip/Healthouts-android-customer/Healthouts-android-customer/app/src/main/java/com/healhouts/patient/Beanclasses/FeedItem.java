package com.healhouts.patient.Beanclasses;

/**
 * Created by Venkat Veeravalli on 19-05-2015.
 */
public class FeedItem {
    private String doctorId;
    private  String doctorName;
    private  String doctorcity;
    private String doctorImage;

    private  String customerId;

    private String questionBody;
    private  String answerId;
    private String answerSubject;
    private String answerBody;
    private String ansTime;
    private String feedCount;

    public String getDoctorId() {
        return doctorId;
    }

    public void setDoctorId(String doctorId) {
        this.doctorId = doctorId;
    }

    public String getDoctorName() {
        return doctorName;
    }

    public void setDoctorName(String doctorName) {
        this.doctorName = doctorName;
    }

    public String getDoctorImage() {
        return doctorImage;
    }

    public void setDoctorImage(String doctorImage) {
        this.doctorImage = doctorImage;
    }

    public String getDoctorcity() {
        return doctorcity;
    }

    public void setDoctorcity(String doctorcity) {
        this.doctorcity = doctorcity;
    }

    public String getCustomerId() {
        return customerId;
    }

    public void setCustomerId(String customerId) {
        this.customerId = customerId;
    }

    public String getQuestionBody() {
        return questionBody;
    }

    public void setQuestionBody(String questionBody) {
        this.questionBody = questionBody;
    }

    public String getAnswerId() {
        return answerId;
    }

    public void setAnswerId(String answerId) {
        this.answerId = answerId;
    }

    public String getAnswerSubject() {
        return answerSubject;
    }

    public void setAnswerSubject(String answerSubject) {
        this.answerSubject = answerSubject;
    }

    public String getAnswerBody() {
        return answerBody;
    }

    public void setAnswerBody(String answerBody) {
        this.answerBody = answerBody;
    }

    public String getAnsTime() {
        return ansTime;
    }

    public void setAnsTime(String ansTime) {
        this.ansTime = ansTime;
    }

    public String getFeedCount() {
        return feedCount;
    }

    public void setFeedCount(String feedCount) {
        this.feedCount = feedCount;
    }
}
