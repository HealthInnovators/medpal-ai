package com.healhouts.patient.Activities;

import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.os.Bundle;
import android.support.v7.app.ActionBarActivity;
import android.text.Html;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.RatingBar;
import android.widget.Toast;

import com.healhouts.patient.FragmentsPackage.ServiceHandler;
import com.healhouts.patient.R;
import com.healhouts.patient.common.CommonUtil;
import com.healhouts.patient.common.ServiceCalls;

import org.json.JSONException;
import org.json.JSONObject;

import java.net.URISyntaxException;

/**
 * Created by samsung on 04-06-2015.
 */
public class FeedBack  extends ActionBarActivity {
    Button submit,dismiss;
    EditText feedbackMsg;

    JSONObject jsonObject;
    String TAG = getClass().getName();
    String[] reviews;
    String reviewRating="";
    String chatid;
    String cid;
    String did;
    AlertDialog.Builder builder;
    String flag = "1";
    RatingBar mbar;
    @Override
    protected void onCreate(Bundle savedInstanceState) {

        super.onCreate(savedInstanceState);
        setContentView(R.layout.popup);

        android.support.v7.app.ActionBar actionBar = getSupportActionBar();
        ColorDrawable colorDrawable = new ColorDrawable(Color.parseColor("#993333"));
        actionBar.setBackgroundDrawable(colorDrawable);
        actionBar.setTitle(Html.fromHtml("<font color='#ffffff'>" + "Feedback Form" + "</font>"));
        actionBar.setDisplayHomeAsUpEnabled(true);
        actionBar.setHomeButtonEnabled(true);

        feedbackMsg = (EditText) findViewById(R.id.feedbackMsg);
        submit=(Button)findViewById(R.id.submit);
        dismiss=(Button)findViewById(R.id.dismiss);
        mbar=(RatingBar)findViewById(R.id.popupspinner);


        submit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Toast.makeText(getApplicationContext(),"Please Wait...!!",Toast.LENGTH_LONG).show();
                feedbackMsg=(EditText)findViewById(R.id.feedbackMsg);
                String feed=feedbackMsg.getText().toString();
                ServiceHandler sh = new ServiceHandler();
                String jsonStr = "";
                String queryStr = new CommonUtil().ConvertToUrlString(ServiceCalls.FEEDBACK_URL+"chatId="+chatid+"&doctorId="+did+"&customerId="+cid+"&feedback="+feed+"&reviewRating="+reviewRating);
                Log.d(TAG, "--" + queryStr);
                try {
                    jsonStr = sh.makeServiceCall(queryStr, ServiceHandler.POST);
                    jsonObject=new JSONObject(jsonStr);
                    if(jsonObject.getString("status").equals(flag)){
                        builder = new AlertDialog.Builder(FeedBack.this);
                        builder.setCancelable(true);
                        builder.setMessage("Review has been Done ");
                        builder.setInverseBackgroundForced(true);

                        builder.setNeutralButton("Done", new DialogInterface.OnClickListener() {
                            public void onClick(DialogInterface dialog, int whichButton) {
                                Intent intent = new Intent(getApplicationContext(),AMS.class);
                                startActivity(intent);
                            }
                        });

                        builder.show();

                    }
                } catch (URISyntaxException e) {
                    e.printStackTrace();
                } catch (JSONException e) {
                    e.printStackTrace();
                }
            }
        });

        dismiss.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent ams=new Intent(FeedBack.this,AMS.class);
                startActivity(ams);

            }
        });
        reviews = getResources().getStringArray(R.array.review_array);
        chatid= getIntent().getExtras().getString("chatid");
        cid = getIntent().getExtras().getString("cid");
        did = getIntent().getExtras().getString("did");

        mbar.setOnRatingBarChangeListener(new RatingBar.OnRatingBarChangeListener() {

            public void onRatingChanged(RatingBar ratingBar, float rating, boolean b) {

                int frating = (int) rating;
                reviewRating=String.valueOf(frating);
                Toast.makeText(FeedBack.this, "New Rating:"+frating, Toast.LENGTH_SHORT).show();


            }




        });

        /*Spinner s1 = (Spinner) findViewById(R.id.popupspinner);

        ArrayAdapter<String> adapter = new ArrayAdapter<String>(this,
                android.R.layout.simple_spinner_dropdown_item, reviews);

        s1.setAdapter(adapter);
        s1.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> arg0, View arg1,
                                       int arg2, long arg3) {
                int index = arg0.getSelectedItemPosition();
                Toast.makeText(getBaseContext(),
                        "You have selected item : " + reviews[index].toString(),
                        Toast.LENGTH_SHORT).show();
                reviewRating = reviews[index].toString();
            }
            @Override
            public void onNothingSelected(AdapterView<?> arg0) {
            }
        });
    */}
    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.menu_test, menu);
        return true;
    }
    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()) {
            case android.R.id.home:
                super.onBackPressed();
                break;
            default:
        }
        return super.onOptionsItemSelected(item);
    }
}
