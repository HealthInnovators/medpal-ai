package com.healhouts.patient.common;

import android.content.Context;
import android.content.SharedPreferences;
import android.util.Log;

import com.google.android.gms.gcm.GoogleCloudMessaging;
import com.healhouts.patient.FragmentsPackage.ServiceHandler;
import com.healhouts.patient.GCMService.Config;

import org.json.JSONObject;

import java.net.URI;
import java.net.URL;

/**
 * Created by Venkat Veeravalli on 16-03-2015.
 */
public class CommonUtil {

  //  private String updageRegIdUrl = "http://healthouts.com/updateRegId?";
    private String updageRegIdUrl = "http://joslinlive.org/updateRegId?";

    public static final String REG_ID = "regId";
    private static final String APP_VERSION = "appVersion";

    static String TAG = "CommonUtil";

    SharedPreferences sharedpreferences;
    private static String ctustomerId;
    private static String customerType;
    private static String customerEmail;
    private static String customerPassword;
    private static String customerName;
    private static String customerImage;
    private static String cPreferences;

//    ChatServer xmppServer = new ChatServer();
    GoogleCloudMessaging gcm;
    Context context;
    String regId;
    private boolean token = false;//this is the status for updating device registration id in server



    public URL ConvertToUrl(String urlStr) {
        try {
            URL url = new URL(urlStr);
            URI uri = new URI(url.getProtocol(), url.getUserInfo(),
                    url.getHost(), url.getPort(), url.getPath(),
                    url.getQuery(), url.getRef());
            url = uri.toURL();
            return url;
        } catch (Exception e) {
            e.printStackTrace();
        }
        return null;
    }

    public String ConvertToUrlString(String urlStr) {
        try {
            URL url = new URL(urlStr);
            URI uri = new URI(url.getProtocol(), url.getUserInfo(),
                    url.getHost(), url.getPort(), url.getPath(),
                    url.getQuery(), url.getRef());
            url = uri.toURL();
            return url.toString();
        } catch (Exception e) {
            e.printStackTrace();
        }
        return null;
    }
    public void registerGCMandSaveSession(JSONObject job, Context context, SharedPreferences sharedpreferences){
Log.d("---","---job---"+job.toString());
        String jsonStr = "";

        customerPassword = "customerPasswordKey";
        customerEmail = "customerEmailKey";
        customerType = "customerTypeKey";
        ctustomerId = "customerIdKey";
        customerName = "customerNameKey";
        customerImage = "customerImageKey";
        cPreferences = "custPrefs";


        this.sharedpreferences = sharedpreferences;
        this.context = context;
        try {
            if (gcm == null) {
                gcm = GoogleCloudMessaging.getInstance(context);
                Log.i(TAG, "--gcm1--" + gcm);
                gcm.unregister();
            }
            Log.i(TAG, "--gcm2--" + gcm);
            regId = gcm.register(Config.GOOGLE_PROJECT_ID);
            Log.d(TAG, "registerInBackground - regId: " + regId);
//                            msg = "Device registered, registration ID=" + regId;

            ServiceHandler sh2 = new ServiceHandler();
            Log.d("---", "--job.getString(\"emailId\")--"+job.getString("emailId"));
            updageRegIdUrl = updageRegIdUrl + "regId=" + regId + "&userEmail=" + job.getString("emailId");
            Log.d(TAG, updageRegIdUrl);
            jsonStr = sh2.makeServiceCall(updageRegIdUrl, ServiceHandler.GET);
            Log.d(TAG, "--serverResponse--:" + jsonStr);
            JSONObject json = new JSONObject(jsonStr);

            if (json != null) {
                if (json.get("status").equals("1")) {
                    storeRegistrationId(context, regId);
                    Log.i("josn", job.getString("emailId"));
                    Log.i("josn", job.getString("customerType"));
                    Log.i("josn", job.getString("customerId"));
                    Log.i("josn", job.getString("pass"));
                    SharedPreferences.Editor editor = sharedpreferences.edit();
//						Log.i("Stirng value", customerEmail);
                    editor.putString(ctustomerId, job.getString("customerId"));
                    editor.putString(customerEmail, job.getString("emailId"));
                    editor.putString(customerType, job.getString("customerType"));
                    editor.putString(customerPassword, job.getString("pass"));
                    editor.putString(customerName, job.getString("cName"));
                    editor.putString(customerImage, job.getString("cImage"));
                    editor.commit();
//                    xmppServer.connect("healthouts" + job.getString("customerId"), "healthouts" + job.getString("customerId"));
                }
            }

        }catch (Exception e){
            e.printStackTrace();
        }

    }
    private void storeRegistrationId(Context context, String regId) {
        final SharedPreferences prefs = sharedpreferences;
        SharedPreferences.Editor editor = prefs.edit();
        editor.putString(REG_ID, regId);
        editor.commit();
    }
}
