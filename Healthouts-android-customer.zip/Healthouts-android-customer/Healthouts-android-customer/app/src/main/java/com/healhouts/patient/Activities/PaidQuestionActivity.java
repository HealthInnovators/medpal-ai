package com.healhouts.patient.Activities;

import android.app.AlertDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import android.database.Cursor;
import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.net.Uri;
import android.os.AsyncTask;
import android.os.Bundle;
import android.provider.MediaStore;
import android.support.v7.app.ActionBarActivity;
import android.text.Html;
import android.util.Log;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.WindowManager;
import android.view.inputmethod.InputMethodManager;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;

import com.healhouts.patient.R;
import com.healhouts.patient.common.AndroidMultiPartEntity;
import com.healhouts.patient.common.CommonUtil;
import com.healhouts.patient.common.ServiceCalls;
import com.squareup.picasso.Picasso;

import org.apache.http.HttpEntity;
import org.apache.http.HttpResponse;
import org.apache.http.client.ClientProtocolException;
import org.apache.http.client.HttpClient;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.entity.mime.content.FileBody;
import org.apache.http.entity.mime.content.StringBody;
import org.apache.http.impl.client.DefaultHttpClient;
import org.apache.http.util.EntityUtils;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.File;
import java.io.IOException;
import java.io.UnsupportedEncodingException;


public class PaidQuestionActivity extends ActionBarActivity {

    private static final String TAG = "PaidQuestions";
    Button btnAttachment, button_payment;
    EditText editText2_message, editText_subject;
    ImageView doctorImageView;
    TextView doctorNameView, doctorSpecialityView, doctorFeeView;
    Uri URI = null;
    private static final int SELECT_SINGLE_PICTURE = 101;
    int columnIndex;
    String attachmentFile = "", QsSubject, QsBody, doctorId, doctorName, doctorImg, doctorSpeciality, consultationFee, customerId, customerEmail;
    private Context context;
    private ProgressBar progressBar;
    private TextView txtPercentage;
    long totalSize = 0;
    private String filePath = "";
    AlertDialog.Builder builder;
    SharedPreferences sharedpreferences;
    String resultString = "";
    public static final String IMAGE_TYPE = "image/*";
    File sourceFile;
    int duration = 1000;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_paid_questions2);
        this.getWindow().setSoftInputMode(
                WindowManager.LayoutParams.SOFT_INPUT_ADJUST_PAN);


        android.support.v7.app.ActionBar actionBar = getSupportActionBar();
        ColorDrawable colorDrawable = new ColorDrawable(Color.parseColor("#993333"));
        actionBar.setBackgroundDrawable(colorDrawable);
        actionBar.setTitle(Html.fromHtml("<font color='#ffffff'>" + "Premium Question" + "</font>"));
        actionBar.setDisplayHomeAsUpEnabled(true);
        actionBar.setHomeButtonEnabled(true);
        Bundle bundle = getIntent().getExtras();
        context = getApplicationContext();
        sharedpreferences = context.getSharedPreferences(context.getString(R.string.cPreferences), Context.MODE_PRIVATE);
        customerId = sharedpreferences.getString(context.getString(R.string.customerId), null);
        customerEmail = sharedpreferences.getString(context.getString(R.string.customerEmail), null);
        Log.d("---", "---customerId---" + customerId);
        Log.d("---", "---customerEmail---" + customerEmail);
        doctorId = bundle.getString(getResources().getString(R.string.doctorId));
        doctorName = bundle.getString(getResources().getString(R.string.docotName));
        doctorImg = bundle.getString(getResources().getString(R.string.doctorImgPath));
        doctorSpeciality = bundle.getString(getResources().getString(R.string.speciality));
        consultationFee = bundle.getString(getResources().getString(R.string.consultationFee));


        doctorImageView = (ImageView) findViewById(R.id.docImg);
        doctorNameView = (TextView) findViewById(R.id.doctorName);
        doctorSpecialityView = (TextView) findViewById(R.id.txt_docSpeciality);
        doctorFeeView = (TextView) findViewById(R.id.txt_price);

        doctorNameView.setText(doctorName);
        doctorSpecialityView.setText(doctorSpeciality);
        doctorFeeView.setText(consultationFee);
        Picasso.with(context).load(new CommonUtil().ConvertToUrlString(doctorImg))
                .error(R.drawable.doctorhealthouts)
                .placeholder(R.drawable.doctorhealthouts)
                .into(doctorImageView);
        btnAttachment = (Button) findViewById(R.id.btnAttachment);
        button_payment = (Button) findViewById(R.id.button_payment);
        InputMethodManager imm = (InputMethodManager) getSystemService(Context.INPUT_METHOD_SERVICE);

        editText_subject = (EditText) findViewById(R.id.editText_subject);
        editText2_message = (EditText) findViewById(R.id.editText2_message);
        imm.hideSoftInputFromWindow(editText_subject.getWindowToken(), 0);
        imm.hideSoftInputFromWindow(editText2_message.getWindowToken(), 0);

        progressBar = (ProgressBar) findViewById(R.id.progressBar);
        txtPercentage = (TextView) findViewById(R.id.txtPercentage);
        btnAttachment.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent photoPickerIntent = new Intent();
                photoPickerIntent.setType(IMAGE_TYPE);
                photoPickerIntent.setAction(Intent.ACTION_GET_CONTENT);
                photoPickerIntent.putExtra("return-data", true);
                startActivityForResult(
                        Intent.createChooser(photoPickerIntent, "Complete action using"),
                        SELECT_SINGLE_PICTURE);


            }
        });
        button_payment.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                Toast toast = Toast.makeText(context, "Sit back and Relax!!you will get notified once it was Done", 5000 );
                toast.show();

                QsSubject = editText_subject.getText().toString();
                QsBody = editText2_message.getText().toString();

                if (!QsSubject.equals("") || !QsBody.equals("") || !attachmentFile.equals("") ) {

                    sendQuestionToDoctor();
                } else {
                    Toast toast1 = Toast.makeText(context, "Please enter your question first", Toast.LENGTH_LONG);
                    toast1.getView().setBackgroundColor((getResources().getColor(R.color.error_toast)));
                    toast1.show();
                }
            }
        });


    }

    protected void onActivityResult(int requestCode, int resultCode, Intent data) {

        if (resultCode == RESULT_OK) {
            if (requestCode == SELECT_SINGLE_PICTURE) {

                Uri selectedImage = data.getData();
                String[] filePathColumn = {MediaStore.Images.Media.DATA};
                Cursor cursor = getContentResolver().query(selectedImage, filePathColumn, null, null, null);

                columnIndex = cursor.getColumnIndexOrThrow(MediaStore.Images.Media.DATA);
                cursor.moveToFirst();
                attachmentFile = cursor.getString(columnIndex);
                Log.e("Attachment Path:", "____" + attachmentFile);
                URI = Uri.parse("ic_action_attachment://" + attachmentFile);

                Log.e("Attachment Path:", "" + URI);
                cursor.close();
            }
        }
    }


    public void sendQuestionToDoctor() {
        new AsyncTask<Void, Integer, String>() {

            @Override
            protected void onPreExecute() {
                super.onPreExecute();
                builder = new AlertDialog.Builder(PaidQuestionActivity.this);
                // setting progress bar to zero
                progressBar.setProgress(0);
            }

            @Override
            protected String doInBackground(Void... params) {

                return uploadFile();
            }

            @Override
            protected void onProgressUpdate(Integer... progress) {
//                super.onProgressUpdate(values);

                // Making progress bar visible
                button_payment.setVisibility(View.GONE);
                progressBar.setVisibility(View.VISIBLE);
                txtPercentage.setVisibility(View.VISIBLE);
                // updating progress bar value
                progressBar.setProgress(progress[0]);

                // updating percentage value
                txtPercentage.setText(String.valueOf(progress[0]) + "%");
            }

            private String uploadFile() {

/*
                if (sourceFile == null) {
                    ServiceHandler sh = new ServiceHandler();
                    String queryStr = new CommonUtil().ConvertToUrlString(ServiceCalls.ASK_PAID_QUESION_URL + "?" + "CID=" + customerId + "&cEmail=" + customerEmail + "&qSubject=" + QsSubject + "&qMessage=" + QsBody + "&doctorId=" + doctorId + "&healthFile=" + attachmentFile);
                    Log.d(TAG, "querystr" + queryStr);
                    try {
                        String jsonStr = sh.makeServiceCall(queryStr, ServiceHandler.POST);
                        final JSONObject jsonObject1 = new JSONObject(jsonStr);
                        if (jsonObject1.optString("status").equals("1")) {
                            runOnUiThread(new Runnable() {
                                @Override
                                public void run() {

                                    builder = new AlertDialog.Builder(PaidQuestionActivity.this);
                                    try {
                                        builder.setMessage(jsonObject1.getString("message"));
                                    } catch (JSONException e) {
                                        e.printStackTrace();
                                    }
                                    builder.setPositiveButton("Done", new DialogInterface.OnClickListener() {
                                        @Override
                                        public void onClick(DialogInterface dialog, int which) {
                                            Intent intent = new Intent(context, AMS.class);
                                            startActivity(intent);
                                            dialog.dismiss();
                                        }
                                    });
                                    builder.show();
                                }
                            });

                        } else {
                            Toast toast = Toast.makeText(context, jsonObject1.getString("message"), Toast.LENGTH_LONG);
                            toast.getView().setBackgroundColor(getResources().getColor(R.color.error_toast));
                            toast.show();
                        }

                    } catch (URISyntaxException e) {
                        e.printStackTrace();
                    } catch (JSONException e) {
                        e.printStackTrace();
                    }
                    return null;
                } else {*/
                    String responseString = null;
                    HttpClient httpclient = new DefaultHttpClient();
                    HttpPost httppost = new HttpPost(ServiceCalls.ASK_PAID_QUESION_URL);


                    try {
                        AndroidMultiPartEntity entity = new AndroidMultiPartEntity(
                                new AndroidMultiPartEntity.ProgressListener() {

                                    @Override
                                    public void transferred(long num) {
                                        publishProgress((int) ((num / (float) totalSize) * 100));
                                    }
                                });
                        if (!attachmentFile.equals("")) {
                            Log.d(TAG,"attachewdfile"+attachmentFile);
                            File sourceFile = new File(attachmentFile);
                            Log.d(TAG,"sourcefile"+sourceFile);
                            entity.addPart("healthFile", new FileBody(sourceFile));
                        }
                        entity.addPart("CID", new StringBody(customerId));
                        entity.addPart("cEmail", new StringBody(customerEmail));
                        entity.addPart("qSubject", new StringBody(editText_subject.getText().toString()));
                        entity.addPart("qMessage", new StringBody(editText2_message.getText().toString()));
                        entity.addPart("doctorId", new StringBody(doctorId));
                        totalSize = entity.getContentLength();
                        httppost.setEntity(entity);
                        HttpResponse response = httpclient.execute(httppost);
                        HttpEntity r_entity = response.getEntity();
                        int statusCode = response.getStatusLine().getStatusCode();
                        if (statusCode == 200) {
                            responseString = EntityUtils.toString(r_entity);
                        } else {
                            responseString = "Error occurred! Http Status Code: "
                                    + statusCode;
                        }
                    } catch (UnsupportedEncodingException e) {
                        e.printStackTrace();
                    } catch (ClientProtocolException e) {
                        e.printStackTrace();
                    } catch (IOException e) {
                        e.printStackTrace();
                    }
                    return responseString;

                }




            @Override
            protected void onPostExecute(String resultString) {
                super.onPostExecute(resultString);
                if (resultString != null && !resultString.equals("")) {
                    try {
                        Log.d("---", "---" + resultString);
                        JSONObject jsonObject = new JSONObject(resultString);
                        if (jsonObject.optString("status").equals("1")) {
                            builder.setCancelable(true);
                            builder.setMessage(jsonObject.getString("message"));
                            builder.setInverseBackgroundForced(true);
                            builder.setPositiveButton("Done", new DialogInterface.OnClickListener() {
                                @Override
                                public void onClick(DialogInterface dialog, int which) {
                                    Intent intent = new Intent(context, AMS.class);
                                    startActivity(intent);
                                    dialog.dismiss();
                                }
                            });
                            builder.show();
                            editText_subject.setText("");
                            editText2_message.setText("");
                        } else {
                            Toast toast = Toast.makeText(context, jsonObject.getString("message"), Toast.LENGTH_LONG);
                            toast.getView().setBackgroundColor(getResources().getColor(R.color.error_toast));
                            toast.show();
                        }
                    } catch (JSONException e) {
                        e.printStackTrace();
                    }

                } else {
                    Toast toast = Toast.makeText(context, "Something went Wrong ", Toast.LENGTH_LONG);
                    toast.getView().setBackgroundColor(getResources().getColor(R.color.error_toast));
                    toast.show();
                }
            }
        }.execute();

    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        MenuInflater inflater = getMenuInflater();
        inflater.inflate(R.menu.doctor_actionitems, menu);
        return super.onCreateOptionsMenu(menu);
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()) {
            case android.R.id.home:
                super.onBackPressed();
                return true;
            case R.id.txt_doctorHomeTitle:
                Intent docSpecialities = new Intent(this, AMS.class);
                startActivity(docSpecialities);
                break;
        }
        return super.onOptionsItemSelected(item);
    }
}

