package com.healhouts.patient.Adapters;

/**
 * Created by samsung on 21-05-2015.
 */

import android.content.Context;
import android.support.v7.widget.RecyclerView;
import android.text.Html;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import com.healhouts.patient.Beanclasses.FeedItemDoctor;
import com.healhouts.patient.R;
import com.healhouts.patient.common.CommonUtil;
import com.squareup.picasso.Picasso;

import java.util.List;

public class AdapterDoctor extends RecyclerView.Adapter<AdapterDoctor.FeedListRowHolderDoctor> {

    private static final String TAG = "AdapterDoctor";
    private List<FeedItemDoctor> feedItemList;
    private Context mContext;
    OnItemClickListener mItemClickListener;


    public AdapterDoctor(Context context, List<FeedItemDoctor> feedItemList) {
        this.feedItemList = feedItemList;
        this.mContext = context;
    }

    @Override
    public FeedListRowHolderDoctor onCreateViewHolder(ViewGroup viewGroup, int i) {
        View v = LayoutInflater.from(viewGroup.getContext()).inflate(R.layout.list_row_doctors, null);
        FeedListRowHolderDoctor mh = new FeedListRowHolderDoctor(v);
        return mh;
    }

    @Override
    public void onBindViewHolder(FeedListRowHolderDoctor feedListRowHolder, int i) {
        FeedItemDoctor feedItem = feedItemList.get(i);

        Picasso.with(mContext).load(new CommonUtil().ConvertToUrlString(feedItem.getImgPath()))
                .error(R.drawable.placeholder)
                .placeholder(R.drawable.doctorhealthouts)
                .into(feedListRowHolder.imgPath);

        feedListRowHolder.speciality.setText(Html.fromHtml(feedItem.getSpeciality()));
        feedListRowHolder.city.setText(Html.fromHtml(feedItem.getLocation()));
        feedListRowHolder.dName.setText(Html.fromHtml(feedItem.getdName()));
    }
    public  interface OnItemClickListener{
        public  void onItemClick(View view, int position);



    }
    public void SetOnItemClickListener(final OnItemClickListener mItemClickListener) {
        this.mItemClickListener = mItemClickListener;
    }

    @Override
    public int getItemCount() {
        return (null != feedItemList ? feedItemList.size() : 0);
    }

    public class FeedListRowHolderDoctor  extends RecyclerView.ViewHolder implements View.OnClickListener{

        protected ImageView  imgPath;
        protected TextView speciality;
        protected TextView location;
        protected TextView doctorId;
        protected TextView dName;
        protected TextView city;
        public FeedListRowHolderDoctor(View view) {
            super(view);
            this.imgPath = (ImageView) view.findViewById(R.id.thumbImage);
            this.dName = (TextView) view.findViewById(R.id.dName);
            this.city = (TextView) view.findViewById(R.id.location);
            this.speciality = (TextView) view.findViewById(R.id.speciality);
            view.setOnClickListener(this);
        }

        @Override
        public void onClick(View v) {

            if (mItemClickListener != null) {
                mItemClickListener.onItemClick(v, getPosition());

            }
        }

    }
}