package com.healhouts.patient.FragmentsPackage;

/**
 * Created by samsung on 24-06-2015.
 */

import android.app.AlertDialog;
import android.app.Fragment;
import android.app.ProgressDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.AsyncTask;
import android.os.Bundle;
import android.os.StrictMode;
import android.provider.Settings;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.EditText;

import com.healhouts.patient.R;
import com.healhouts.patient.common.CommonUtil;
import com.healhouts.patient.common.ConnectionDetector;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.net.URISyntaxException;

public class ContactInformation extends Fragment {
    private static final String TAG = "ContactInformation";
    ProgressDialog pDialog;
    AlertDialog.Builder builder;
    JSONObject jsonObj;
    private Context context;
    Boolean isInternetPresent = false;
    ConnectionDetector cd;
    JSONArray jsonArray;
    SharedPreferences userSharedPreferences;
    private String customerId;
    private  String customerEmail;
    private boolean loginStatus = false;
    JSONObject jsonObject;

   /* String url="http://healthouts.com/appCustomerBasicDetails?";
    String url2="http://healthouts.com/appSaveContactInfo?";
*/

    String url="http://joslinlive.org/appCustomerBasicDetails?";
    String url2="http://joslinlive.org/appSaveContactInfo?";



    EditText cStreetAddress1,cStreetAddress2,cState,cCity,cPhone,cZipcode,eRelationship,eState,emergencyContactName,eZipcode,eStreetAddress2,eStreetAddress1,ePhone,eCity;
    Button saveProfile;
    String cStreetAddress1ET,cStreetAddress2ET,cStateET,cCityET,cPhoneET,cZipcodeET,eRelationshipET,eCityET,eStateET,emergencyContactNameET,eZipcodeET,eStreetAddress2ET,eStreetAddress1ET,ePhoneET;
    @Override
    public void onCreate(Bundle savedInstanceState) {
       getActivity().getWindow().setSoftInputMode(
                WindowManager.LayoutParams.SOFT_INPUT_ADJUST_PAN);

        super.onCreate(savedInstanceState);
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        StrictMode.ThreadPolicy policy = new StrictMode.ThreadPolicy.Builder().permitAll().build();
        StrictMode.setThreadPolicy(policy);
        context = getActivity().getApplicationContext();
        cd = new ConnectionDetector(context);
        isInternetPresent = cd.isConnectingToInternet();
        userSharedPreferences = this.getActivity().getSharedPreferences(context.getString(R.string.cPreferences), Context.MODE_PRIVATE);
        customerId = userSharedPreferences.getString(context.getString(R.string.customerId), null);
        customerEmail = userSharedPreferences.getString(getActivity().getResources().getString(R.string.customerEmail), null);

        View view = inflater.inflate(R.layout.contactinfo, null);
        cStreetAddress1=(EditText)view.findViewById(R.id.cStreetAddress1);
        cStreetAddress2=(EditText)view.findViewById(R.id.cStreetAddress2);
        cState=(EditText)view.findViewById(R.id.zipcode);
        cCity=(EditText)view.findViewById(R.id.cCity);
        cZipcode=(EditText)view.findViewById(R.id.cZipcode);
        cPhone=(EditText)view.findViewById(R.id.cPhone);
        emergencyContactName=(EditText)view.findViewById(R.id.emergencyContactName);
        eRelationship=(EditText)view.findViewById(R.id.eRelationship);
        ePhone=(EditText)view.findViewById(R.id.ePhone);
        eStreetAddress1=(EditText)view.findViewById(R.id.eStreetAddress1);
        eStreetAddress2=(EditText)view.findViewById(R.id.eStreetAddress2);
        eState=(EditText)view.findViewById(R.id.eState);
        eZipcode=(EditText)view.findViewById(R.id.eZipcode);
        eCity=(EditText)view.findViewById(R.id.eCity);
        saveProfile = (Button) view.findViewById(R.id.savechanges);
        saveProfile.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                new updateCOntactInfo().execute();

            }
        });


        getContactInformation();




        return view;
    }


    private void getContactInformation() {
        String jsonStr = "";
        ServiceHandler sh = new ServiceHandler();

        String str = "";
        str = str + url;

        try {

            String queryStr = new CommonUtil().ConvertToUrlString(str + "CId=" + customerId + "&CEmail=" + customerEmail);
            Log.d(TAG, "Query string  is" + queryStr);

            if (isInternetPresent) {

                jsonStr = sh.makeServiceCall(queryStr, ServiceHandler.GET);
                try {

                    jsonObject = new JSONObject(jsonStr);
                    jsonObject.optString("cStreetAddress1");
                    jsonObject.optString("cStreetAddress2");
                    jsonObject.optString("cState");
                    jsonObject.optString("cCity");
                    jsonObject.optString("cZipcode");
                    jsonObject.optString("cPhone");
                    jsonObject.optString("emergencyContactName");
                    jsonObject.optString("eRelationship");
                    jsonObject.optString("ePhone");
                    jsonObject.optString("eStreetAddress1");
                    jsonObject.optString("eStreetAddress2");
                    jsonObject.optString("eCity");
                    jsonObject.optString("eZipcode");
                    jsonObject.optString("eState");

                    Log.d(TAG, "cst1" + jsonObject.optString("cStreetAddress1"));
                    Log.d(TAG,"cst2"+jsonObject.optString("cStreetAddress2"));


                    cStreetAddress1.setText(jsonObject.optString("cStreetAddress1"));
                    cStreetAddress2.setText(jsonObject.optString("cStreetAddress2"));
                    cState.setText(jsonObject.optString("cState"));
                    cCity.setText(jsonObject.optString("cCity"));
                    cZipcode.setText(jsonObject.optString("cZipcode"));
                    cPhone.setText(jsonObject.optString("cPhone"));
                    eStreetAddress1.setText(jsonObject.optString("eStreetAddress1"));
                    eStreetAddress2.setText(jsonObject.optString("eStreetAddress2"));
                    emergencyContactName.setText(jsonObject.optString("emergencyContactName"));
                    eRelationship.setText(jsonObject.optString("eRelationship"));
                    ePhone.setText(jsonObject.optString("ePhone"));
                    eCity.setText(jsonObject.optString("eCity"));
                    eZipcode.setText(jsonObject.optString("eZipcode"));
                    eState.setText(jsonObject.optString("eState"));




                    Log.d("My App", jsonObject.toString());

                } catch (Throwable t) {
                    Log.e("My App", "Could not parse malformed JSON: \"" + jsonStr + "\"");
                }

            } else {
                getActivity().runOnUiThread(new Runnable() {
                    public void run() {
                        final AlertDialog.Builder builder = new AlertDialog.Builder(getActivity());
                        builder.setTitle("Connection failure");
                        builder.setMessage("Please check your network connection and try again");
                        builder.setIcon(R.drawable.warn)
                                .setPositiveButton("cancel", new DialogInterface.OnClickListener() {
                                    public void onClick(DialogInterface dialog, int id) {
                                        builder.setCancelable(true);
                                    }
                                })
                                .setNegativeButton("Wi-Fi Settings", new DialogInterface.OnClickListener() {
                                    public void onClick(DialogInterface dialog, int id) {
                                        startActivityForResult(new Intent(Settings.ACTION_WIFI_SETTINGS), 0);

                                    }
                                });
                        builder.show();

                    }
                });

            }

        } catch (URISyntaxException e1) {
            // TODO Auto-generated catch block
            e1.printStackTrace();
        }


    }


    @Override
    public void onActivityCreated(Bundle savedInstanceState) {
        // TODO Auto-generated method stub
        super.onActivityCreated(savedInstanceState);
    }

    private class updateCOntactInfo extends AsyncTask<String,String,String>{
        @Override
        protected String doInBackground(String... params) {
            String jsonStr1 = "";
            ServiceHandler sh = new ServiceHandler();


            cStreetAddress1ET=cStreetAddress1.getText().toString();
            cStreetAddress2ET=cStreetAddress2.getText().toString();
            cStateET=cState.getText().toString();
            cCityET=cCity.getText().toString();
            cZipcodeET=cZipcode.getText().toString();
            cPhoneET=cPhone.getText().toString();
            eRelationshipET=eRelationship.getText().toString();
            emergencyContactNameET=emergencyContactName.getText().toString();
            ePhoneET=ePhone.getText().toString();
            eStreetAddress1ET=eStreetAddress1.getText().toString();
            eStreetAddress2ET=eStreetAddress2.getText().toString();
            eZipcodeET=eZipcode.getText().toString();
            eStateET=eState.getText().toString();
            eCityET=eCity.getText().toString();

            Log.d(TAG,"1"+cStreetAddress1ET);
            Log.d(TAG,"2"+cStreetAddress2ET);
            Log.d(TAG,"3"+cCityET);
            Log.d(TAG,"4"+cStateET);
            Log.d(TAG,"5"+cPhoneET);
            Log.d(TAG,"6"+cZipcodeET);
            Log.d(TAG,"7"+emergencyContactNameET);
            Log.d(TAG,"8"+eRelationshipET);
            Log.d(TAG,"9"+eStreetAddress1ET);
            Log.d(TAG,"10"+eStreetAddress2ET);
            Log.d(TAG,"11"+eCityET);
            Log.d(TAG,"12"+eStateET);
            Log.d(TAG,"13"+eZipcodeET);
            Log.d(TAG,"14"+ePhoneET);


            String str = "";
            str = str + url2;

            try {

                jsonObj=new JSONObject();
                try {

                    jsonObj.put("cStreetAddress1",cStreetAddress1ET);
                    jsonObj.put("cStreetAddress2",cStreetAddress2ET);
                    jsonObj.put("cCity",cCityET);
                    jsonObj.put("cState",cStateET);
                    jsonObj.put("cZipcode",cZipcodeET);
                    jsonObj.put("cPhone",cPhoneET);
                    jsonObj.put("emergencyContactName",emergencyContactNameET);
                    jsonObj.put("eRelationship",eRelationshipET);
                    jsonObj.put("ePhone",ePhoneET);
                    jsonObj.put("eStreetAddress1",eStreetAddress1ET);
                    jsonObj.put("eStreetAddress2",eStreetAddress2ET);
                    jsonObj.put("eState", eStateET);
                    jsonObj.put("eZipcode", eZipcodeET);
                    jsonObj.put("eCity", eCityET);
                    Log.d(TAG, "--jsonobjcet--"+jsonObject);
                } catch (JSONException e) {
                    e.printStackTrace();
                }
                String queryStr1 = new CommonUtil().ConvertToUrlString(str +"CId="+customerId+"&CEmail="+customerEmail+"&contactInfoDetails="+jsonObj);
                Log.d(TAG,"Query string  is"+queryStr1);

                if (isInternetPresent) {

                    jsonStr1 = sh.makeServiceCall(queryStr1, ServiceHandler.POST);

                    String flag="1";
                    Log.d(TAG,"response string---"+jsonStr1);
                    try {
                       final  JSONObject resjsonObj = new JSONObject(jsonStr1);
                        Log.d(TAG,">>>>>>>>>>>>>>"+resjsonObj);
                        if (resjsonObj.getString("status").equals(flag)) {
                            getActivity().runOnUiThread(new Runnable() {
                                public void run() {
                                    builder = new AlertDialog.Builder(getActivity());
                                    builder.setCancelable(true);
                                    try {
                                        builder.setMessage(resjsonObj.getString("message"));
                                    } catch (JSONException e) {
                                        e.printStackTrace();
                                    }
                                    builder.setInverseBackgroundForced(true);
                                    builder.setNeutralButton("Ok", new DialogInterface.OnClickListener() {
                                        public void onClick(DialogInterface dialog, int whichButton) {
                                            dialog.dismiss();
                                        }
                                    });

                                    builder.show();
                                }
                            });
                        }
                    } catch (JSONException e) {
                        e.printStackTrace();
                    }
                    System.out.print(jsonObj);


/*
                    try {

                        JSONObject jsonObject=new JSONObject(jsonStr1);
                        Log.d(TAG,"saved datais"+jsonObject);
                    } catch (JSONException e) {
                        e.printStackTrace();
                    }*/


                } else {
                    getActivity().runOnUiThread(new Runnable() {
                        public void run() {

                            final AlertDialog.Builder builder = new AlertDialog.Builder(getActivity());
                            builder.setTitle("Connection failure");
                            builder.setMessage("Please check your network connection and try again");
                            builder.setIcon(R.drawable.warn)
                                    .setPositiveButton("cancel", new DialogInterface.OnClickListener() {
                                        public void onClick(DialogInterface dialog, int id) {
                                            builder.setCancelable(true);
                                        }
                                    })
                                    .setNegativeButton("Wi-Fi Settings", new DialogInterface.OnClickListener() {
                                        public void onClick(DialogInterface dialog, int id) {
                                            startActivityForResult(new Intent(Settings.ACTION_WIFI_SETTINGS), 0);


                                        }
                                    });
                            builder.show();

                        }
                    });

                }

            } catch (URISyntaxException e1) {
                // TODO Auto-generated catch block
                e1.printStackTrace();
            }


            return null;
        }
    }

}


