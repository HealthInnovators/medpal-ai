package com.healhouts.patient.FragmentsPackage;

import android.app.AlertDialog;
import android.app.Fragment;
import android.app.ProgressDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.content.pm.ResolveInfo;
import android.database.Cursor;
import android.net.Uri;
import android.os.AsyncTask;
import android.os.Bundle;
import android.os.Environment;
import android.provider.MediaStore;
import android.provider.Settings;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.util.Log;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.Toast;

import com.healhouts.patient.Adapters.HealthfilesRecyclerAdapter;
import com.healhouts.patient.Beanclasses.FeedItemHealthFile;
import com.healhouts.patient.R;
import com.healhouts.patient.common.AndroidMultiPartEntity;
import com.healhouts.patient.common.CommonUtil;
import com.healhouts.patient.common.ConnectionDetector;
import com.healhouts.patient.common.ServiceCalls;
import com.healhouts.patient.common.ZoomInZoomOut;

import org.apache.http.HttpEntity;
import org.apache.http.HttpResponse;
import org.apache.http.client.ClientProtocolException;
import org.apache.http.client.HttpClient;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.entity.mime.content.FileBody;
import org.apache.http.entity.mime.content.StringBody;
import org.apache.http.impl.client.DefaultHttpClient;
import org.apache.http.util.EntityUtils;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.UnsupportedEncodingException;
import java.net.HttpURLConnection;
import java.net.URISyntaxException;
import java.net.URL;
import java.util.ArrayList;
import java.util.List;

public class HealthFiles extends Fragment {

    public static final String TAG = "HealthFiles";
    private Context context;
    Boolean isInternetPresent = false;
    ConnectionDetector cd;
    JSONArray jsonArray;
    //    PublicFeedAdapter adapter;
    private List<FeedItemHealthFile> feedItemList = new ArrayList<FeedItemHealthFile>();
    private RecyclerView mRecyclerView;
    LinearLayoutManager mLayoutManager;

    ProgressDialog pDialog;
    AlertDialog.Builder builder;
    private HealthfilesRecyclerAdapter adapter;
    SharedPreferences userSharedPreferences;
    private boolean loginStatus = false;

    private String customerId;
    private String customerEmail;

    Button uploadBtn, saveBtn;
    private static int RESULT_LOAD_IMAGE = 1;
    String attachmentFile = "";


    @Override
    public void onCreate(Bundle savedInstanceState) {
        // TODO Auto-generated method stub
        super.onCreate(savedInstanceState);
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        context = getActivity().getApplicationContext();
        cd = new ConnectionDetector(context);
        isInternetPresent = cd.isConnectingToInternet();

        userSharedPreferences = getActivity().getSharedPreferences(context.getString(R.string.cPreferences), Context.MODE_PRIVATE);

        if (userSharedPreferences.getString(context.getString(R.string.customerId), null) != null) {
            customerId = userSharedPreferences.getString(context.getString(R.string.customerId), null);
            customerEmail = userSharedPreferences.getString(context.getString(R.string.customerEmail), null);
        }
        View fragmentView = inflater.inflate(R.layout.frag3_layout, null);

        mRecyclerView = (RecyclerView) fragmentView.findViewById(R.id.health_files_list);
        mRecyclerView.setHasFixedSize(true);
        mLayoutManager = new LinearLayoutManager(getActivity());
        mRecyclerView.setLayoutManager(mLayoutManager);
        getHealthfile();

        uploadBtn = (Button) fragmentView.findViewById(R.id.uploadBtn);
        saveBtn = (Button) fragmentView.findViewById(R.id.saveBtn);
        uploadBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i = new Intent(Intent.ACTION_PICK, MediaStore.Images.Media.EXTERNAL_CONTENT_URI);
                startActivityForResult(i, RESULT_LOAD_IMAGE);
            }
        });
        saveBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (!attachmentFile.equals("")) {
                    saveHealthFile();
                } else {
                    Toast toast = Toast.makeText(getActivity(), "Sorry..!!Please upload your Healthfile", Toast.LENGTH_LONG);
                    toast.getView().setBackgroundColor(getActivity().getResources().getColor(R.color.healthoutstheme));
                    toast.show();

                }
            }
        });

        return fragmentView;
    }

    @Override
    public void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == RESULT_LOAD_IMAGE && null != data) {
            Uri selectedImage = data.getData();
            String[] filePathColumn = {MediaStore.Images.Media.DATA};
            Cursor cursor = context.getContentResolver().query(selectedImage, filePathColumn, null, null, null);
            cursor.moveToFirst();
            int columnIndex = cursor.getColumnIndex(filePathColumn[0]);
            attachmentFile = cursor.getString(columnIndex);
            Log.d("---", "----picturePath--" + attachmentFile);
            cursor.close();
            uploadBtn.setText(attachmentFile);
            saveBtn.setBackgroundColor(getResources().getColor(R.color.LimeGreen));

        }
    }

    @Override
    public void onActivityCreated(Bundle savedInstanceState) {
        // TODO Auto-generated method stub
        super.onActivityCreated(savedInstanceState);
    }

    public void getHealthfile() {

        new AsyncTask<Void, Void, List<FeedItemHealthFile>>() {
            @Override
            protected void onPreExecute() {
                super.onPreExecute();
                pDialog = new ProgressDialog(getActivity(), ProgressDialog.STYLE_SPINNER);
                pDialog.setMessage("Please wait...");
                pDialog.setCancelable(false);
                pDialog.show();

            }

            @Override
            protected List<FeedItemHealthFile> doInBackground(Void... params) {
                String jsonStr = "";
                ServiceHandler sh = new ServiceHandler();
                String querystr = new CommonUtil().ConvertToUrlString(new ServiceCalls().GET_HEALTHFILE_URL + "CId=" + customerId + "&CEmail=" + customerEmail);
                try {
                    if (isInternetPresent) {
                        jsonStr = sh.makeServiceCall(querystr, ServiceHandler.GET);

                        JSONArray jarr = new JSONArray(jsonStr);
                        for (int i = 0; i < jarr.length(); i++) {
                            JSONObject job = jarr.getJSONObject(i);
                            FeedItemHealthFile feedItem = new FeedItemHealthFile();
                            feedItem.setHeathfileid(job.optString("heathfileid"));
                            feedItem.setHealthfilepath(job.optString("healthfilepath"));
                            feedItemList.add(feedItem);
                        }
                    } else {

                        getActivity().runOnUiThread(new Runnable() {
                            public void run() {

                                final AlertDialog.Builder builder = new AlertDialog.Builder(getActivity());
                                builder.setTitle("Connection failure");
                                builder.setMessage("Please check your network connection and try again");
                                builder.setIcon(R.drawable.warn)
                                        .setPositiveButton("cancel", new DialogInterface.OnClickListener() {
                                            public void onClick(DialogInterface dialog, int id) {
                                                builder.setCancelable(true);
                                            }
                                        })
                                        .setNegativeButton("Wi-Fi Settings", new DialogInterface.OnClickListener() {
                                            public void onClick(DialogInterface dialog, int id) {
                                                startActivityForResult(new Intent(Settings.ACTION_WIFI_SETTINGS), 0);


                                            }
                                        });
                                builder.show();

                            }
                        });

                    }
                } catch (URISyntaxException e) {
                    e.printStackTrace();
                } catch (JSONException e) {
                    e.printStackTrace();
                }

                return feedItemList;
            }


            @Override
            protected void onPostExecute(List<FeedItemHealthFile> list) {
                super.onPostExecute(list);
                if (pDialog.isShowing())
                    pDialog.dismiss();
                if (list.size() > 0) {

                    adapter = new HealthfilesRecyclerAdapter(context, list);
                    mRecyclerView.setAdapter(adapter);

                } else {
                    Toast toast = Toast.makeText(getActivity(), "Your dont have health files to show!", Toast.LENGTH_SHORT);
                    toast.setGravity(Gravity.CENTER_VERTICAL, 0, 0);
                    toast.show();
                }
                if (adapter != null)
                    onClickEventFire();

            }
        }.execute(null, null, null);
    }

    public void onClickEventFire() {

        adapter.SetOnItemClickListener(new HealthfilesRecyclerAdapter.OnItemClickListener() {
            @Override
            public void onItemClick(View view, int position) {
                final FeedItemHealthFile feedItem = feedItemList.get(position);
                if (view.getId() == R.id.btnDelete) {
                    builder = new AlertDialog.Builder(getActivity());
                    builder.setCancelable(true);
                    builder.setMessage("Are you sure want to delete");
                    builder.setInverseBackgroundForced(true);

                    builder.setNegativeButton("Cancle", new DialogInterface.OnClickListener() {
                        public void onClick(DialogInterface dialog, int whichButton) {
                            dialog.dismiss();
                        }
                    });
                    builder.setPositiveButton("Ok", new DialogInterface.OnClickListener() {
                        public void onClick(DialogInterface dialog, int whichButton) {
                            deleteHealthfie(feedItem.getHeathfileid());
                            dialog.dismiss();
                        }
                    });
                    builder.show();
                } else {
                    if (!feedItem.getHealthfilepath().equals("")) {
                      //  String url = "http://healthouts.com/img/" + feedItem.getHealthfilepath();
                        String url = "http://joslinlive.org/img/" + feedItem.getHealthfilepath();
                        downloadPdfContent(url, feedItem.getHealthfilepath());
                    }
                }


            }
        });
    }

    public void deleteHealthfie(final String healthfileId) {
        new AsyncTask<Void, Void, List<FeedItemHealthFile>>() {
            @Override
            protected void onPreExecute() {
                super.onPreExecute();
                pDialog = new ProgressDialog(getActivity(), ProgressDialog.STYLE_SPINNER);
                pDialog.setMessage("Please wait...");
                pDialog.setCancelable(false);
                pDialog.show();
//                builder = new AlertDialog.Builder(getActivity());

            }

            @Override
            protected List<FeedItemHealthFile> doInBackground(Void... params) {
                String jsonStr = "";
                ServiceHandler sh = new ServiceHandler();
                String querystr = new CommonUtil().ConvertToUrlString(new ServiceCalls().DELETE_HEALTHFILE_URL + "CId=" + customerId + "&CEmail=" + customerEmail + "&healthFileId=" + healthfileId);
                try {
                    jsonStr = sh.makeServiceCall(querystr, ServiceHandler.GET);
                    JSONArray jarr = new JSONArray(jsonStr);
                    feedItemList.clear();
                    for (int i = 0; i < jarr.length(); i++) {
                        JSONObject job = jarr.getJSONObject(i);
                        FeedItemHealthFile feedItem = new FeedItemHealthFile();
                        feedItem.setHeathfileid(job.optString("heathfileid"));
                        feedItem.setHealthfilepath(job.optString("healthfilepath"));
                        feedItemList.add(feedItem);
                    }
                } catch (URISyntaxException e) {
                    e.printStackTrace();
                } catch (JSONException e) {
                    e.printStackTrace();
                }


                return feedItemList;
            }

            @Override
            protected void onPostExecute(List<FeedItemHealthFile> list) {
                super.onPostExecute(list);
                if (pDialog.isShowing())
                    pDialog.dismiss();
                Toast toast = Toast.makeText(getActivity(), "File deleted from your list", Toast.LENGTH_SHORT);
                toast.setGravity(Gravity.CENTER_VERTICAL, 0, 0);
                toast.getView().setBackgroundColor(getActivity().getResources().getColor(R.color.LimeGreen));
                toast.show();


                adapter = new HealthfilesRecyclerAdapter(context, list);
                mRecyclerView.setAdapter(adapter);
                onClickEventFire();

            }
        }.execute();
    }

    public void downloadPdfContent(final String urlToDownload, final String filename) {
        new AsyncTask<Void, Void, Void>() {
            @Override
            protected void onPreExecute() {
                super.onPreExecute();

                pDialog = new ProgressDialog(getActivity());
                pDialog.setTitle("Please wait");
                pDialog.setMessage(" You are almost done..!! ");
                pDialog.setCancelable(false);
                pDialog.show();
            }

            @Override
            protected void onPostExecute(Void aVoid) {
                super.onPostExecute(aVoid);
                if (pDialog.isShowing())
                    pDialog.dismiss();
            }

            @Override
            protected Void doInBackground(Void... params) {
                try {


                    String fileName = filename;
                    String fileExtension = android.webkit.MimeTypeMap.getSingleton().getFileExtensionFromUrl(fileName);
                    String fileMimeType = android.webkit.MimeTypeMap.getSingleton().getMimeTypeFromExtension(fileExtension);

                    URL url2 = new URL(urlToDownload);
                    HttpURLConnection c = (HttpURLConnection) url2.openConnection();
                    c.setRequestMethod("GET");
                    c.setDoOutput(true);
                    c.connect();
                    /*String PATH = Environment.getExternalStorageDirectory() + "/healthouts/";*/
                    String PATH = Environment.getExternalStorageDirectory() + "/joslin/";
                    File f = new File(PATH + fileName);
                    if (!f.exists()) {
                        File file = new File(PATH);
                        createDirIfNotExists("patient");
                        File outputFile = new File(file, fileName);
                        FileOutputStream fos = new FileOutputStream(outputFile);
                        InputStream is = c.getInputStream();
                        byte[] buffer = new byte[1024];
                        int len1 = 0;
                        while ((len1 = is.read(buffer)) != -1) {
                            fos.write(buffer, 0, len1);
                        }
                        fos.close();
                        is.close();
                        showFile(PATH + fileName, fileMimeType);

                    } else {
                        //show ic_action_attachment
                        showFile(PATH + fileName, fileMimeType);
                    }
                    pDialog.dismiss();

                } catch (Exception e) {
                    e.printStackTrace();

                }
                return null;
            }
        }.execute(null, null, null);

    }

    public static boolean createDirIfNotExists(String path) {
        boolean ret = true;

        File file = new File(Environment.getExternalStorageDirectory(), path);
        if (!file.exists()) {
            if (!file.mkdirs()) {
                Log.e("TravellerLog :: ", "Problem creating Image folder");
                ret = false;
            }
        }
        return ret;
    }

    public void showFile(String path, String fileMimeType) {
        //show ic_action_attachment
        Log.d("---", "----path---" + path);
        Log.d("---", "----fileMimeType---" + fileMimeType);

        if (fileMimeType.equals("image/jpeg") || fileMimeType.equals("image/png")) {
            Intent intent = new Intent(context, ZoomInZoomOut.class);
            Bundle myData = new Bundle();
            myData.putString("imagePath", path);
            intent.putExtras(myData);
            getActivity().startActivity(intent);
        } else {
            Intent intent = new Intent();
            intent.setAction(Intent.ACTION_VIEW);
            intent.setData(Uri.parse(path));
            intent.setType(fileMimeType);
            PackageManager pm = getActivity().getPackageManager();
            List<ResolveInfo> activities = pm.queryIntentActivities(intent, 0);
            if (activities.size() > 0) {
                getActivity().startActivity(intent);
            } else {
                Toast toast = Toast.makeText(getActivity(), "Sorry some problem in ic_action_attachment download!", Toast.LENGTH_LONG);
                toast.getView().setBackgroundColor(getActivity().getResources().getColor(R.color.error_toast));
                toast.setGravity(Gravity.CENTER_VERTICAL, 0, 0);
                toast.show();
            }
        }
    }

    public void saveHealthFile() {
        new AsyncTask<Void, Integer, String>() {

            @Override
            protected void onPreExecute() {
                super.onPreExecute();
                pDialog = new ProgressDialog(getActivity());
                pDialog.setTitle("Please wait");
                pDialog.setMessage("processing.... ");
                pDialog.setCancelable(false);
                pDialog.show();
                builder = new AlertDialog.Builder(getActivity());
                // setting progress bar to zero

            }

            @Override
            protected String doInBackground(Void... params) {
                return uploadFile();
            }


            private String uploadFile() {

                String responseString = null;

                HttpClient httpclient = new DefaultHttpClient();
                HttpPost httppost = new HttpPost(ServiceCalls.ADD_HEALTHFILE_URL);
                try {
                    AndroidMultiPartEntity entity = new AndroidMultiPartEntity(
                            new AndroidMultiPartEntity.ProgressListener() {

                                @Override
                                public void transferred(long num) {
//                                    publishProgress((int) ((num / (float) totalSize) * 100));
                                }
                            });

                    entity.addPart("CId ", new StringBody(customerId));

                    entity.addPart("CEmail ", new StringBody(customerEmail));

                    if (!attachmentFile.equals("")) {

                        File sourceFile = new File(attachmentFile);
                        entity.addPart("healthFile", new FileBody(sourceFile));
                    } else {
                        Toast toast = Toast.makeText(getActivity(), "Please select the file ", Toast.LENGTH_LONG);
                        toast.getView().setBackgroundColor(getActivity().getResources().getColor(R.color.healthoutstheme));
                        toast.show();

                    }


                    httppost.setEntity(entity);
                    // Making server call
                    HttpResponse response = httpclient.execute(httppost);
                    HttpEntity r_entity = response.getEntity();

                    int statusCode = response.getStatusLine().getStatusCode();
                    if (statusCode == 200) {
                        // Server response
                        responseString = EntityUtils.toString(r_entity);
                    } else {
                        responseString = "ERROR";
                        Log.i(TAG, "Error occurred! Http Status Code: "
                                + statusCode);

                    }
                } catch (UnsupportedEncodingException e) {
                    e.printStackTrace();
                } catch (ClientProtocolException e) {
                    e.printStackTrace();
                } catch (IOException e) {
                    e.printStackTrace();
                }

                return responseString;
            }

            @Override
            protected void onPostExecute(String resultString) {
                super.onPostExecute(resultString);
                saveBtn.setBackgroundResource(android.R.drawable.btn_default);
                uploadBtn.setText("Upload your health ic_action_attachment");
                if (pDialog.isShowing())
                    pDialog.dismiss();
//                Toast toast = Toast.makeText(context, resultString, Toast.LENGTH_LONG);
//                toast.getView().setBackgroundColor(getResources().getColor(R.color.error_toast));
//                toast.show();
                Log.d("---", "-----responseStr----" + resultString);
                if (resultString != null && !resultString.equals("ERROR")) {
                    Toast toast = Toast.makeText(getActivity(), "File added successfully", Toast.LENGTH_SHORT);
                    toast.setGravity(Gravity.CENTER_VERTICAL, 0, 0);
                    toast.getView().setBackgroundColor(getActivity().getResources().getColor(R.color.LimeGreen));
                    toast.show();
                    try {
                        JSONArray jarr = new JSONArray(resultString);
                        feedItemList.clear();
                        for (int i = 0; i < jarr.length(); i++) {
                            JSONObject job = jarr.getJSONObject(i);
                            FeedItemHealthFile feedItem = new FeedItemHealthFile();
                            feedItem.setHeathfileid(job.optString("heathfileid"));
                            feedItem.setHealthfilepath(job.optString("healthfilepath"));
                            feedItemList.add(feedItem);
                        }


                        adapter = new HealthfilesRecyclerAdapter(context, feedItemList);
                        mRecyclerView.setAdapter(adapter);
                        onClickEventFire();
                    } catch (JSONException e) {
                        e.printStackTrace();
                    }

                } else {
                    Toast toast = Toast.makeText(context, "Sorry! Due to some problem your activity failed", Toast.LENGTH_LONG);
                    toast.getView().setBackgroundColor(getResources().getColor(R.color.error_toast));
                    toast.setGravity(Gravity.CENTER_VERTICAL, 0, 0);
                    toast.show();
                }
            }

        }.execute();

    }
}
