package com.healhouts.patient.FragmentsPackage;

import android.app.AlertDialog;
import android.app.Fragment;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.os.AsyncTask;
import android.os.Bundle;
import android.os.StrictMode;
import android.provider.Settings;
import android.support.v4.app.FragmentActivity;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.util.Log;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.widget.Toast;

import com.healhouts.patient.Adapters.MyRecyclerAdapterMedications;
import com.healhouts.patient.Beanclasses.FeedItemMedications;
import com.healhouts.patient.R;
import com.healhouts.patient.common.CommonUtil;
import com.healhouts.patient.common.ConnectionDetector;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.net.URISyntaxException;
import java.util.ArrayList;
import java.util.List;

public class Medications extends Fragment {
    private Context context;
    AlertDialog.Builder builder;
    Boolean isInternetPresent = false;
    ConnectionDetector cd;
    SharedPreferences userSharedPreferences;
    JSONArray jsonArray;
    private boolean loginStatus = false;
    private View v;
    private List<FeedItemMedications> FeedItemMedicationsList = new ArrayList<FeedItemMedications>();
    LinearLayoutManager mLayoutManager;
    private boolean loading = true;
    int firstVisibleItem, visibleItemCount, totalItemCount;
    int count = 0;
    int token = 0;
    private String customerId;
    private String customerEmail;
    private static final String TAG = "Medications";
    ImageView up, down;
    ListView list_item;
    LinearLayout linearLayout;
    RelativeLayout relativeLayout;
    MyRecyclerAdapterMedications adapter;
    Button savechanges;
    EditText medication, notes;
    CheckBox medicineUsage;
    String medicineUsageET, medicationET, notesET;
    String medicationUsage;
    private RecyclerView mRecyclerView;
    //	http://healthouts.com/appGetMedications?CId=193&CEmail=trinadhlikesu@gmail.com

    /*String url="http://healthouts.com/appGetMedications?";
    String url2="http://healthouts.com/appSavemedication?";
*/
    String url = "http://joslinlive.org/appGetMedications?";
    String url2 = "http://joslinlive.org/appSavemedication?";


    @Override
    public void onCreate(Bundle savedInstanceState) {

        getActivity().getWindow().setSoftInputMode(
                WindowManager.LayoutParams.SOFT_INPUT_ADJUST_PAN);
        // TODO Auto-generated method stub
        super.onCreate(savedInstanceState);
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        StrictMode.ThreadPolicy policy = new StrictMode.ThreadPolicy.Builder().permitAll().build();
        StrictMode.setThreadPolicy(policy);
        context = getActivity().getApplicationContext();
        cd = new ConnectionDetector(context);
        isInternetPresent = cd.isConnectingToInternet();
        userSharedPreferences = this.getActivity().getSharedPreferences(context.getString(R.string.cPreferences), Context.MODE_PRIVATE);
        userSharedPreferences = this.getActivity().getSharedPreferences(context.getString(R.string.cPreferences), Context.MODE_PRIVATE);
        customerId = userSharedPreferences.getString(context.getString(R.string.customerId), null);
        customerEmail = userSharedPreferences.getString(getActivity().getResources().getString(R.string.customerEmail), null);

        View view = inflater.inflate(R.layout.medications, container, false);
        medication = (EditText) view.findViewById(R.id.medication);
        notes = (EditText) view.findViewById(R.id.notes);
        medicineUsage = (CheckBox) view.findViewById(R.id.symptomState);

        savechanges = (Button) view.findViewById(R.id.savechanges);
        relativeLayout = (RelativeLayout) view.findViewById(R.id.relativeLayout);
        linearLayout = (LinearLayout) view.findViewById(R.id.linearLayout1);
        mRecyclerView = (RecyclerView) view.findViewById(R.id.recycler_view);
        mRecyclerView.setHasFixedSize(true);
        mLayoutManager = new LinearLayoutManager(getActivity());
        mRecyclerView.setLayoutManager(mLayoutManager);
        RecyclerView.ItemDecoration itemDecoration =
                new DividerItemDecoration(getActivity(), LinearLayoutManager.VERTICAL);
        mRecyclerView.addItemDecoration(itemDecoration);

        mRecyclerView.setLayoutManager(new LinearLayoutManager(getActivity()));
        up = (ImageView) view.findViewById(R.id.up);
        up.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                if (up.isSelected()) {
                    up.setImageResource(R.drawable.down);
                    linearLayout.setVisibility(View.VISIBLE);
                    up.setSelected(false);
                } else {
                    up.setImageResource(R.drawable.up);
                    linearLayout.setVisibility(View.GONE);
                    up.setSelected(true);
                }
            }
        });
        savechanges.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                new CreateMedication().execute();
            }
        });
        yourMedications();
        return view;
    }


    public void yourMedications() {

        new AsyncTask<Void, Void, List<FeedItemMedications>>() {

            @Override
            protected List<FeedItemMedications> doInBackground(Void... params) {
//                ArrayList<HashMap> list = new ArrayList<HashMap>();
                String jsonStr = "";
                ServiceHandler sh = new ServiceHandler();

                String str = "";
                str = str + url;

                try {
                    String queryStr = new CommonUtil().ConvertToUrlString(str + "CId=" + customerId + "&CEmail=" + customerEmail);

                    Log.d(TAG, "querystr" + queryStr);
                    if (isInternetPresent) {

                        jsonStr = sh.makeServiceCall(queryStr, ServiceHandler.GET);
                    } else {
                        getActivity().runOnUiThread(new Runnable() {
                            public void run() {
                                final AlertDialog.Builder builder = new AlertDialog.Builder(getActivity());
                                builder.setTitle("Connection failure");
                                builder.setMessage("Please check your network connection and try again");
                                builder.setCancelable(false);
                                builder.setIcon(R.drawable.warn)
                                        .setPositiveButton("cancel", new DialogInterface.OnClickListener() {
                                            public void onClick(DialogInterface dialog, int id) {
                                                builder.setCancelable(true);
                                            }
                                        })
                                        .setNegativeButton("Wi-Fi Settings", new DialogInterface.OnClickListener() {
                                            public void onClick(DialogInterface dialog, int id) {
                                                startActivityForResult(new Intent(Settings.ACTION_WIFI_SETTINGS), 0);

                                            }
                                        });
                                builder.show();
                            }
                        });
                    }
                } catch (URISyntaxException e1) {
                    // TODO Auto-generated catch block
                    e1.printStackTrace();
                }
                try {
                    jsonArray = new JSONArray(jsonStr);
                    Log.d(TAG, "jsonarray" + jsonArray);
                    FeedItemMedicationsList.clear();
                    for (int i = 0; i < jsonArray.length(); i++) {
                        JSONObject jsonobject = jsonArray.getJSONObject(i);
                        FeedItemMedications item = new FeedItemMedications();
                        item.setMedication(jsonobject.optString("medication"));
                        item.setCustomerId(jsonobject.optString("customerId"));
                        item.setMedicationId(jsonobject.optString("medicationId"));
                        item.setNotes(jsonobject.optString("notes"));
                        item.setMedicineUsage(jsonobject.optString("medicineUsage"));
                        Log.d(TAG, "" + i + "" + jsonobject.optString("medication") + "" + jsonobject.optString("notes"));


                        FeedItemMedicationsList.add(item);
                    }

                } catch (JSONException e) {
                    e.printStackTrace();
                }
                return FeedItemMedicationsList;
            }

            private void showAlertDialog(FragmentActivity activity, String s, String s1, boolean b) {
                AlertDialog alertDialog = new AlertDialog.Builder(context).create();
                alertDialog.setTitle("");
                alertDialog.setMessage("");

                alertDialog.setButton("OK", new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface dialog, int which) {
                    }
                });

                alertDialog.show();
            }

            @Override
            protected void onPostExecute(List<FeedItemMedications> list) {
                if (list.size() == 0) {

                    AlertDialog alertDialog = new AlertDialog.Builder(getActivity()).create();
                    alertDialog.setIcon(R.drawable.ic_report);
                    alertDialog.setTitle("Info");
                    alertDialog.setMessage("You don't have any Medications at Healthouts Doctors");
                    alertDialog.setButton("OK", new DialogInterface.OnClickListener() {
                        public void onClick(DialogInterface dialog, int which) {
                        }
                    });

                    alertDialog.show();
                } else {
                    super.onPostExecute(list);
                    adapter = new MyRecyclerAdapterMedications(getActivity(), FeedItemMedicationsList);
                    adapter.notifyDataSetChanged();
                    mRecyclerView.setAdapter(adapter);
                }

            }
        }.execute(null, null, null);
    }


    @Override
    public void onActivityCreated(Bundle savedInstanceState) {
        // TODO Auto-generated method stub
        super.onActivityCreated(savedInstanceState);
    }


    private class CreateMedication extends AsyncTask<String, String, String> {
        @Override
        protected String doInBackground(String... params) {
            String jsonStr1 = "";
            ServiceHandler sh = new ServiceHandler();

            medicationET = medication.getText().toString();
            notesET = notes.getText().toString();

            if (medicineUsage.isChecked()) {
                medicationUsage = "past";
            } else {
                medicationUsage = "current";
            }


            String str = "";
            str = str + url2;

            String queryStr1 = new CommonUtil().ConvertToUrlString(str + "CId=" + customerId + "&CEmail=" + customerEmail + "&medication=" + medicationET + "&notes=" + notesET + "&medicineUsage=" + medicationUsage);
            Log.d(TAG, "Query string  is" + queryStr1);

            if (isInternetPresent) {

                try {
                    jsonStr1 = sh.makeServiceCall(queryStr1, ServiceHandler.POST);
                    getActivity().runOnUiThread(new Runnable() {
                        public void run() {
                            Toast toast = Toast.makeText(context, "Details saved successfully", Toast.LENGTH_LONG);
                            toast.setGravity(Gravity.CENTER_VERTICAL, 0, 0);
                            TextView tv = new TextView(context);
                            tv.setTextColor(Color.RED);
                            tv.setTextSize(15);
                            toast.getView().setBackgroundColor(Color.parseColor("#FB4C2F"));
                            toast.show();

                            medication.setText("");
                            notes.setText("");
                            medicineUsage.setSelected(false);
                        }
                    });

                    yourMedications();
                } catch (URISyntaxException e) {
                    e.printStackTrace();
                }

            } else {
                getActivity().runOnUiThread(new Runnable() {
                    public void run() {

                        final AlertDialog.Builder builder = new AlertDialog.Builder(getActivity());
                        builder.setTitle("Connection failure");
                        builder.setMessage("Please check your network connection and try again");
                        builder.setIcon(R.drawable.warn)
                                .setPositiveButton("cancel", new DialogInterface.OnClickListener() {
                                    public void onClick(DialogInterface dialog, int id) {
                                        builder.setCancelable(true);
                                    }
                                })
                                .setNegativeButton("Wi-Fi Settings", new DialogInterface.OnClickListener() {
                                    public void onClick(DialogInterface dialog, int id) {
                                        startActivityForResult(new Intent(Settings.ACTION_WIFI_SETTINGS), 0);


                                    }
                                });
                        builder.show();

                    }
                });

            }


            return null;
        }
    }
}
