package com.healhouts.patient.FragmentsPackage;

import android.app.AlertDialog;
import android.app.ProgressDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.os.AsyncTask;
import android.support.v7.widget.RecyclerView;
import android.text.Html;
import android.util.Log;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import com.healhouts.patient.Beanclasses.FeedItemSymptoms;
import com.healhouts.patient.R;
import com.healhouts.patient.common.CommonUtil;

import java.net.URISyntaxException;
import java.util.List;


/**
 * Created by Venkat Veeravalli on 17-06-2015.
 */
public class MyRecyclerAdapterSymptoms extends RecyclerView.Adapter<MyRecyclerAdapterSymptoms.FeedItemRowHolderSymptoms> {

    private static final String TAG = "MyRecyclerAdapterSymptoms";

    private List<FeedItemSymptoms> feedItemList;
    Boolean isInternetPresent = false;
    private Context mContext;
    String notes_update = "";
    int symptomId;
    String status_update = "";
    ProgressDialog pDialog;
    AlertDialog.Builder builder;
    private String customerId;
    private String customerEmail;
    SharedPreferences userSharedPreferences;
    OnItemClickListener mItemClickListener;
/*

    static String URL = "http://healthouts.com/appUpdateSymptom?";
    static String URL2="http://healthouts.com/appDeleteSymptoms?";
*/


    static String URL = "http://joslinlive.org/appUpdateSymptom?";
    static String URL2 = "http://joslinlive.org/appDeleteSymptoms?";

    public MyRecyclerAdapterSymptoms(Context context, List<FeedItemSymptoms> feedItemList) {
        this.feedItemList = feedItemList;
        this.mContext = context;
    }


    @Override
    public FeedItemRowHolderSymptoms onCreateViewHolder(ViewGroup parent, int viewType) {
        userSharedPreferences = this.mContext.getSharedPreferences(mContext.getString(R.string.cPreferences), Context.MODE_PRIVATE);
        userSharedPreferences = this.mContext.getSharedPreferences(mContext.getString(R.string.cPreferences), Context.MODE_PRIVATE);
        customerId = userSharedPreferences.getString(mContext.getString(R.string.customerId), null);
        customerEmail = userSharedPreferences.getString(mContext.getResources().getString(R.string.customerEmail), null);

        View v = LayoutInflater.from(parent.getContext()).inflate(R.layout.symptoms_list, null);
        FeedItemRowHolderSymptoms feedItemRowHolderSymptoms = new FeedItemRowHolderSymptoms(v);

        return feedItemRowHolderSymptoms;
    }


    @Override
    public void onBindViewHolder(final FeedItemRowHolderSymptoms holder, final int position) {

        final FeedItemSymptoms feedItem = feedItemList.get(position);


        holder.symptom.setText(Html.fromHtml(feedItem.getSymptom()));
        holder.notes.setText(Html.fromHtml(feedItem.getNotes()));
        holder.symptomState.setText(Html.fromHtml(feedItem.getSymptomState()));


        if (feedItem.getSymptomState().equals("past")) {
            holder.symptomState.setChecked(true);
        } else
            holder.symptomState.setChecked(false);


//update Button Functionality
        holder.updateButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                notes_update = holder.notes.getText().toString();
                status_update = holder.symptomState.getText().toString();
                // Toast.makeText(mContext,"notes"+notes_update+"status"+status_update,Toast.LENGTH_SHORT).show();
                if (holder.symptomState.isChecked()) {
                    status_update = "past";
                } else {
                    status_update = "current";
                }

                if (!notes_update.equals("") && !status_update.equals("")) {
                    updateSymptom(feedItem, position, holder);
                } else {
                    Toast toast = Toast.makeText(mContext, "Suject and Answer are not empty!", Toast.LENGTH_SHORT);
                    toast.getView().setBackgroundColor(mContext.getResources().getColor(R.color.error_toast));
                    toast.show();
                }
            }
        });

        //delete Button functionality
        holder.deleteButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {


                final AlertDialog.Builder builder = new AlertDialog.Builder(mContext);
                builder.setTitle("Info");
                builder.setMessage("Are you sure want to delete Symptoms");
                builder.setPositiveButton("cancel", new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface dialog, int id) {
                        builder.setCancelable(true);
                    }
                })
                        .setNegativeButton("ok", new DialogInterface.OnClickListener() {
                            public void onClick(DialogInterface dialog, int id) {
                                deleteSymptom(feedItem, position, holder);
                            }
                        });
                builder.show();


            }
        });


    }

    private void deleteSymptom(final FeedItemSymptoms feedItem, final int position, final FeedItemRowHolderSymptoms holder) {

        new AsyncTask<Void, Void, List<FeedItemSymptoms>>() {
            @Override
            protected List<FeedItemSymptoms> doInBackground(Void... params) {

                String jsonStr = "";
                ServiceHandler sh = new ServiceHandler();

                String str = "CId=" + customerId + "&CEmail=" + customerEmail + "&symptomId=" + feedItem.getSymptomId();
                str = URL2 + str;
                String queryStr = new CommonUtil().ConvertToUrlString(str);
                try {
                    jsonStr = sh.makeServiceCall(queryStr, ServiceHandler.POST);

                } catch (URISyntaxException e) {
                    e.printStackTrace();
                }
                return feedItemList;
            }

            @Override
            protected void onCancelled() {
                super.onCancelled();
            }

            @Override
            protected void onPreExecute() {
                super.onPreExecute();
                pDialog = new ProgressDialog(mContext);
                pDialog.setTitle("Please wait");
                pDialog.setMessage("Processing.... ");
                pDialog.setCancelable(true);
                pDialog.show();
                builder = new AlertDialog.Builder(mContext);
            }

            @Override
            protected void onPostExecute(List<FeedItemSymptoms> feedItemSymptoms) {
                super.onPostExecute(feedItemList);

                Log.d("----", "------------------------");
                Toast toast = Toast.makeText(mContext, "Symptom deleted", Toast.LENGTH_LONG);
                toast.setGravity(Gravity.CENTER_VERTICAL, 0, 0);
                TextView tv = new TextView(mContext);
                tv.setTextColor(Color.WHITE);
                tv.setTextSize(15);
                toast.getView().setBackgroundColor(Color.parseColor("#34bf49"));
                toast.show();
                feedItemList.remove(position);
                notifyItemRemoved(position);
                if (pDialog.isShowing())
                    pDialog.dismiss();


            }

        }.execute(null, null, null);
    }


    public void updateSymptom(final FeedItemSymptoms feedItem, final int position, final FeedItemRowHolderSymptoms holder) {

        new AsyncTask<Void, Void, List<FeedItemSymptoms>>() {
            @Override
            protected List<FeedItemSymptoms> doInBackground(Void... params) {

                String jsonStr = "";
                ServiceHandler sh = new ServiceHandler();
//CID=37&cEmail=sheshakanth@seedinvent.com

                String str = "CId=" + customerId + "&CEmail=" + customerEmail + "&symptomState=" + status_update + "&notes=" + notes_update + "&symptomId=" + feedItem.getSymptomId();
                str = URL + str;
                String queryStr = new CommonUtil().ConvertToUrlString(str);
                try {
                    jsonStr = sh.makeServiceCall(queryStr, ServiceHandler.POST);

                } catch (URISyntaxException e) {
                    e.printStackTrace();
                }
                return feedItemList;
            }

            @Override
            protected void onCancelled() {
                super.onCancelled();
            }

            @Override
            protected void onPreExecute() {
                super.onPreExecute();
                pDialog = new ProgressDialog(mContext);
                pDialog.setTitle("Please wait");
                pDialog.setMessage("Processing.... ");
                pDialog.setCancelable(true);
                pDialog.show();
                builder = new AlertDialog.Builder(mContext);
            }

            @Override
            protected void onPostExecute(List<FeedItemSymptoms> feedItemSymptoms) {
                super.onPostExecute(feedItemSymptoms);

                Toast toast = Toast.makeText(mContext, "Details updated successfully", Toast.LENGTH_LONG);
                toast.setGravity(Gravity.CENTER_VERTICAL, 0, 0);
                TextView tv = new TextView(mContext);
                tv.setTextColor(Color.WHITE);
                tv.setTextSize(15);
                toast.getView().setBackgroundColor(Color.parseColor("#34bf49"));
                toast.show();
                if (pDialog.isShowing())
                    pDialog.dismiss();


            }

        }.execute(null, null, null);
    }

    public int getItemCount() {

        return (null != feedItemList ? feedItemList.size() : 0);
    }

    public interface OnItemClickListener {
        public void onItemClick(View view, int position);
    }

    public void SetOnItemClickListener(final OnItemClickListener mItemClickListener) {
        this.mItemClickListener = mItemClickListener;
    }

    public class FeedItemRowHolderSymptoms extends RecyclerView.ViewHolder implements View.OnClickListener {

        public EditText symptom;
        public EditText notes;
        public CheckBox symptomState;
        public Button deleteButton, updateButton;


        public FeedItemRowHolderSymptoms(View view) {
            super(view);
            this.symptom = (EditText) view.findViewById(R.id.allergy);
            this.notes = (EditText) view.findViewById(R.id.notes);
            this.symptomState = (CheckBox) view.findViewById(R.id.symptomState);
            this.updateButton = (Button) view.findViewById(R.id.updateButton);
            this.deleteButton = (Button) view.findViewById(R.id.deleteButton);
            updateButton.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {

                }
            });

            deleteButton.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                }
            });
//        view.setOnClickListener(this);


        }


        @Override
        public void onClick(View v) {

            if (mItemClickListener != null) {
                mItemClickListener.onItemClick(v, getPosition());
            }
        }

    }

}
