package com.healhouts.patient.Activities;

import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.support.v4.view.ViewPager;
import android.support.v7.app.ActionBarActivity;
import android.support.v7.widget.Toolbar;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import com.healhouts.patient.Adapters.ViewPagerPblicFeedAdapter;
import com.healhouts.patient.R;
import com.healhouts.patient.SlidingTabLayout;


public class ViewPagerPublicFeedActivity extends Fragment {

    private Toolbar toolbar;
    private ViewPager pager;
    private ViewPagerPblicFeedAdapter adapter;
    private SlidingTabLayout tabs;
    CharSequence Titles[] = {"Ask Free Question","Public Questions", "My Questions"};
    int NumofTabs = 3;
    @Override
    public View onCreateView(LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View v = inflater.inflate(R.layout.fragment_view_pager_public_feed, container, false);
        // toolbar = (Toolbar) v.findViewById(R.id.tool_bar);
        ActionBarActivity activity = (ActionBarActivity) getActivity();
        // Creating The Toolbar and setting it as the Toolbar for the activity
        // activity.setSupportActionBar(toolbar);

        // Creating The ViewPagerAdapter and Passing Fragment Manager, Titles fot the Tabs and Number Of Tabs.
        adapter = new ViewPagerPblicFeedAdapter(activity.getSupportFragmentManager(), Titles, NumofTabs);


        // Assigning ViewPager View and setting the adapter
        pager = (ViewPager) v.findViewById(R.id.feedPager);
        pager.setAdapter(adapter);

        // Assiging the Sliding Tab Layout View
        tabs = (SlidingTabLayout) v.findViewById(R.id.feedTabs);
        tabs.setDistributeEvenly(true); // To make the Tabs Fixed set this true, This makes the tabs Space Evenly in Available width

        // Setting Custom Color for the Scroll bar indicator of the Tab View
        tabs.setCustomTabColorizer(new SlidingTabLayout.TabColorizer() {
            @Override
            public int getIndicatorColor(int position) {
//                return getResources().getColor(R.color.tabsScrollColor);

                return getResources().getColor(R.color.abc_primary_text_material_dark);

            }
        });

        // Setting the ViewPager For the SlidingTabsLayout
        tabs.setViewPager(pager);


        return v;
    }

}
