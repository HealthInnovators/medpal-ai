package com.healhouts.patient.FragmentsPackage;

/**
 * Created by samsung on 24-06-2015.
 */

import android.app.AlertDialog;
import android.app.Fragment;
import android.app.ProgressDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import android.database.Cursor;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.net.Uri;
import android.os.AsyncTask;
import android.os.Bundle;
import android.os.StrictMode;
import android.provider.MediaStore;
import android.provider.Settings;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.WindowManager;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.Spinner;
import android.widget.Toast;

import com.healhouts.patient.R;
import com.healhouts.patient.common.AndroidMultiPartEntity;
import com.healhouts.patient.common.CommonUtil;
import com.healhouts.patient.common.ConnectionDetector;
import com.healhouts.patient.common.ServiceCalls;
import com.squareup.picasso.Picasso;

import org.apache.http.HttpEntity;
import org.apache.http.HttpResponse;
import org.apache.http.client.ClientProtocolException;
import org.apache.http.client.HttpClient;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.entity.mime.content.FileBody;
import org.apache.http.entity.mime.content.StringBody;
import org.apache.http.impl.client.DefaultHttpClient;
import org.apache.http.util.EntityUtils;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.File;
import java.io.IOException;
import java.io.UnsupportedEncodingException;
import java.net.URISyntaxException;
import java.util.Arrays;

public class AboutMe extends Fragment implements AdapterView.OnItemSelectedListener {

    private Spinner spDate, spMonth, spYear;
    private static final String[] date = {"01", "02", "03", "04", "05", "06", "07", "08", "09",
            "10", "11", "12", "13", "14", "15", "16", "17", "18", "19", "20", "21", "22", "23", "24",
            "25", "26", "27", "28", "29", "30", "31"};
    private static final String[] month = {"January", "February", "March", "April",
            "May", "June", "July", "August", "September",
            "October", "November", "December"};
    private String[] year;
    String TAG = getClass().getName();
    String item = "";
    String bg = "";
    String sex = "";
    ProgressDialog pDialog;
    AlertDialog.Builder builder;
    JSONObject jsonObj;
    private Context context;
    Boolean isInternetPresent = false;
    ConnectionDetector cd;
    JSONArray jsonArray;
    SharedPreferences userSharedPreferences;
    private String customerId;
    private String customerEmail;
    private boolean loginStatus = false;
    JSONObject jsonObject;

    public Button saveProfile;
    EditText name, dob, location, zipcode, info;
    String nameET, dobET, locationET, zipcodeEt, infoET;
    ImageView imgpath;
    Button savechanges, setButton;
    String attachmentFile = "";
    ImageButton imgButtonView;
    private static int RESULT_LOAD_IMAGE = 1;
   // String url = "http://healthouts.com/appCustomerBasicDetails?";
   String url = "http://joslinlive.org/appCustomerBasicDetails?";
    Spinner bloodGroup;
    Spinner genderGroup;
    String[] bloodGroups = new String[]{"O+", "A+", "B+", "AB+", "O-", "A-", "B-", "AB-"};
    String[] genderGroups = new String[]{"Male", "Female"};

    Spinner spinYear;
    Spinner spinMonth;
    Spinner spinDay;
/*
    Button pick;
*/
    LinearLayout linearLayout;
    EditText dateEt;
    /*String finalDate = "";*/
    String mm, dd, yyyy;
    int pos_month, pos_day, pos_year;


    @Override
    public void onCreate(Bundle savedInstanceState) {



        getActivity().getWindow().setSoftInputMode(
                WindowManager.LayoutParams.SOFT_INPUT_ADJUST_PAN);
        // TODO Auto-generated method stub
        super.onCreate(savedInstanceState);
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {

        StrictMode.ThreadPolicy policy = new StrictMode.ThreadPolicy.Builder().permitAll().build();
        StrictMode.setThreadPolicy(policy);
        context = getActivity().getApplicationContext();
        cd = new ConnectionDetector(context);
        isInternetPresent = cd.isConnectingToInternet();
        userSharedPreferences = this.getActivity().getSharedPreferences(context.getString(R.string.cPreferences), Context.MODE_PRIVATE);
        customerId = userSharedPreferences.getString(context.getString(R.string.customerId), null);
        customerEmail = userSharedPreferences.getString(getActivity().getResources().getString(R.string.customerEmail), null);

        View view = inflater.inflate(R.layout.about_me, null);
        final LinearLayout linearLayout = (LinearLayout) view.findViewById(R.id.datelayout);
        bloodGroup = (Spinner) view.findViewById(R.id.bloodGroup);
        genderGroup = (Spinner) view.findViewById(R.id.genderGroup);
        savechanges = (Button) view.findViewById(R.id.savechanges);
        name = (EditText) view.findViewById(R.id.name);
        dob = (EditText) view.findViewById(R.id.dob);

        location = (EditText) view.findViewById(R.id.location);
        zipcode = (EditText) view.findViewById(R.id.zipcode);
        info = (EditText) view.findViewById(R.id.info);
        saveProfile = (Button) view.findViewById(R.id.savechanges);
        setButton = (Button) view.findViewById(R.id.setDate);
        setButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                linearLayout.setVisibility(View.VISIBLE);
            }
        });
        imgButtonView = (ImageButton) view.findViewById(R.id.imagePath);
/*
        pick = (Button) view.findViewById(R.id.pick);
*/
        imgButtonView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View arg0) {
                Intent i = new Intent(Intent.ACTION_PICK, android.provider.MediaStore.Images.Media.EXTERNAL_CONTENT_URI);
                startActivityForResult(i, RESULT_LOAD_IMAGE);
            }
        });

        saveProfile.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                saveMyDetails();

            }
        });





        ArrayAdapter<String> adapter = new ArrayAdapter<String>(getActivity(), android.R.layout.simple_dropdown_item_1line, bloodGroups);
        bloodGroup.setAdapter(adapter);
        bloodGroup.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View arg1,
                                       int arg2, long arg3) {
                bg = parent.getItemAtPosition(arg2).toString();
                Log.d(TAG,"bllodgroup"+bg);
            }

            @Override
            public void onNothingSelected(AdapterView<?> arg0) {
            }
        });

        ArrayAdapter<String> adapter2 = new ArrayAdapter<String>(getActivity(), android.R.layout.simple_dropdown_item_1line, genderGroups);
        genderGroup.setAdapter(adapter2);
        genderGroup.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> arg0, View arg1,
                                       int arg2, long arg3) {
                sex = arg0.getItemAtPosition(arg2).toString();
            }

            @Override
            public void onNothingSelected(AdapterView<?> arg0) {
            }
        });
        getAboutMe();
        return view;
    }

    @Override
    public void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == RESULT_LOAD_IMAGE && null != data) {
            Uri selectedImage = data.getData();
            String[] filePathColumn = {MediaStore.Images.Media.DATA};
            Cursor cursor = context.getContentResolver().query(selectedImage, filePathColumn, null, null, null);
            cursor.moveToFirst();
            int columnIndex = cursor.getColumnIndex(filePathColumn[0]);
            attachmentFile = cursor.getString(columnIndex);
            Log.d("---", "----picturePath--" + attachmentFile);
            Bitmap bmp = BitmapFactory.decodeFile(attachmentFile);
            bmp = Bitmap.createScaledBitmap(bmp, 100, 100, false);

            Log.d(TAG, "is recycled" + bmp.isRecycled());
            imgButtonView.setImageBitmap(bmp);
        }
    }


    public void saveMyDetails() {
        new AsyncTask<Void, Integer, String>() {

            @Override
            protected void onPreExecute() {
                super.onPreExecute();
                pDialog = new ProgressDialog(getActivity());
                pDialog.setTitle("Please wait");
                pDialog.setMessage("processing.... ");
                pDialog.setCancelable(false);
                pDialog.show();
                builder = new AlertDialog.Builder(getActivity());
                // setting progress bar to zero

            }

            @Override
            protected String doInBackground(Void... params) {
                return uploadFile();
            }


            private String uploadFile() {

                String responseString = null;

                HttpClient httpclient = new DefaultHttpClient();
                HttpPost httppost = new HttpPost(ServiceCalls.UPDATE_ABOUTME_URL);
                try {
                    AndroidMultiPartEntity entity = new AndroidMultiPartEntity(
                            new AndroidMultiPartEntity.ProgressListener() {

                                @Override
                                public void transferred(long num) {
//                                    publishProgress((int) ((num / (float) totalSize) * 100));
                                }
                            });

                    entity.addPart("CId ", new StringBody(customerId));

                    entity.addPart("CEmail ", new StringBody(customerEmail));
                    entity.addPart("cName ", new StringBody(name.getText().toString()));
                    entity.addPart("gender", new StringBody(sex));
                    entity.addPart("info", new StringBody(info.getText().toString()));
                    entity.addPart("bloodGroup", new StringBody(bg));

                    entity.addPart("dob", new StringBody(dob.getText().toString()));
                    entity.addPart("city", new StringBody(location.getText().toString()));
                    entity.addPart("zipcode", new StringBody(zipcode.getText().toString()));
                    if (!attachmentFile.equals("")) {
                        File sourceFile = new File(attachmentFile);
                        entity.addPart("profilepImage", new FileBody(sourceFile));
                    }

                    httppost.setEntity(entity);
                    // Making server call
                    HttpResponse response = httpclient.execute(httppost);
                    Log.d(TAG,"response"+response);
                    HttpEntity r_entity = response.getEntity();

                    int statusCode = response.getStatusLine().getStatusCode();
                    if (statusCode == 200) {
                        // Server response
                        responseString = EntityUtils.toString(r_entity);
                    } else {
                        responseString = "Error occurred! Http Status Code: "
                                + statusCode;

                    }
                } catch (UnsupportedEncodingException e) {
                    e.printStackTrace();
                } catch (ClientProtocolException e) {
                    e.printStackTrace();
                } catch (IOException e) {
                    e.printStackTrace();
                }

                return responseString;
            }

            @Override
            protected void onPostExecute(String resultString) {
                super.onPostExecute(resultString);
                if (pDialog.isShowing())
                    pDialog.dismiss();
//                Toast toast = Toast.makeText(context, resultString, Toast.LENGTH_LONG);
//                toast.getView().setBackgroundColor(getResources().getColor(R.color.error_toast));
//                toast.show();
                if (resultString != null && !resultString.equals("")) {
                    try {
                        JSONObject jsonObject = new JSONObject(resultString);
                        if (jsonObject.getString("status").equals("1")) {
                            builder.setCancelable(true);
                            builder.setMessage(jsonObject.getString("message"));
                            builder.setInverseBackgroundForced(true);
                            builder.setPositiveButton("Done", new DialogInterface.OnClickListener() {
                                @Override
                                public void onClick(DialogInterface dialog, int which) {
                                    dialog.dismiss();
                                }
                            });
                            builder.show();

                        } else {
                            Toast toast = Toast.makeText(context, jsonObject.getString("message"), Toast.LENGTH_LONG);
                            toast.getView().setBackgroundColor(getResources().getColor(R.color.error_toast));
                            toast.show();
                        }
                    } catch (JSONException e) {
                        e.printStackTrace();
                    }

                } else {
                    Toast toast = Toast.makeText(context, "Sorry! Due to some problem Message sending failed", Toast.LENGTH_LONG);
                    toast.getView().setBackgroundColor(getResources().getColor(R.color.error_toast));
                    toast.show();
                }
            }

        }.execute();

    }


    private void getAboutMe() {
        String jsonStr = "";
        ServiceHandler sh = new ServiceHandler();

        String str = "";
        str = str + url;

        try {

            String queryStr = new CommonUtil().ConvertToUrlString(str + "CId=" + customerId + "&CEmail=" + customerEmail);
            Log.d(TAG, "Query string  is" + queryStr);

            if (isInternetPresent) {
                jsonStr = sh.makeServiceCall(queryStr, ServiceHandler.GET);
                try {
                    jsonObject = new JSONObject(jsonStr);
                   //Log.d(TAG, "path is" + "http://healthouts.com/img/" + jsonObject.optString("imagePath"));
                  Log.d(TAG, "path is" + "http://joslinlive.org/img/" + jsonObject.optString("imagePath"));
                    if (!jsonObject.optString("imagePath").equals("")) {

//                        Picasso.with(context).load(new CommonUtil().ConvertToUrlString("http://healthouts.com/img/" + jsonObject.optString("imagePath")))
                        Picasso.with(context).load(new CommonUtil().ConvertToUrlString("http://joslinlive.org/img/" + jsonObject.optString("imagePath")))

                                .error(R.drawable.person_image_empty)
                                .placeholder(R.drawable.healthouts)
                                .into(imgButtonView);

                    }
                    jsonObject.optString("name");
                    jsonObject.optString("dob");
                    jsonObject.optString("location");
                    jsonObject.optString("zipcode");
                    jsonObject.optString("info");
                    jsonObject.optString("gender");
                    jsonObject.optString("bloodGroup");
                    Log.d(TAG, "name" + jsonObject.optString("name"));
                    Log.d(TAG, "dob" + jsonObject.optString("dob"));
                    Log.d(TAG,"location"+jsonObject.optString("location"));
                    Log.d(TAG,"zipcode"+jsonObject.optString("zipcode"));
                    Log.d(TAG,"info"+jsonObject.optString("info"));
                    Log.d(TAG,"gender"+jsonObject.optString("gender"));
                    Log.d(TAG, "bg" + jsonObject.optString("bloodGroup"));
                    name.setText(jsonObject.optString("name"));
                    dob.setText(jsonObject.optString("dob"));
                    bloodGroup.setSelection(Arrays.asList(bloodGroups).indexOf(jsonObject.optString("bloodGroup")));
                    location.setText(jsonObject.optString("location"));
                    zipcode.setText(jsonObject.optString("zipcode"));
                    info.setText(jsonObject.optString("info"));
                    for (int j = 0; j <= genderGroups.length; j++) {
                        if (genderGroups[j].equals(jsonObject.optString("gender")))
                            genderGroup.setSelection(j);
                    }
                   /* for (int i = 0; i <= bloodGroups.length; i++) {
                        Arrays.asList(bloodGroups[i].equals(jsonObject.optString("bloodGroup"))).indexOf("")
                        if (bloodGroups[i].equals(jsonObject.optString("bloodGroup")))
                            bloodGroup.setSelection(i);
                    }*/


                } catch (Throwable t) {
                }

            } else {
                getActivity().runOnUiThread(new Runnable() {
                    public void run() {
                        final AlertDialog.Builder builder = new AlertDialog.Builder(getActivity());
                        builder.setTitle("Connection failure");
                        builder.setMessage("Please check your network connection and try again");
                        builder.setIcon(R.drawable.warn)
                                .setPositiveButton("cancel", new DialogInterface.OnClickListener() {
                                    public void onClick(DialogInterface dialog, int id) {
                                        builder.setCancelable(true);
                                    }
                                })
                                .setNegativeButton("Wi-Fi Settings", new DialogInterface.OnClickListener() {
                                    public void onClick(DialogInterface dialog, int id) {
                                        startActivityForResult(new Intent(Settings.ACTION_WIFI_SETTINGS), 0);
                                    }
                                });
                        builder.show();
                    }
                });
            }
        } catch (URISyntaxException e1) {
            // TODO Auto-generated catch block
            e1.printStackTrace();
        }
    }
    @Override
    public void onActivityCreated(Bundle savedInstanceState) {
        // TODO Auto-generated method stub
        super.onActivityCreated(savedInstanceState);
    }
    @Override
    public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
    }
    @Override
    public void onNothingSelected(AdapterView<?> parent) {

    }

}

