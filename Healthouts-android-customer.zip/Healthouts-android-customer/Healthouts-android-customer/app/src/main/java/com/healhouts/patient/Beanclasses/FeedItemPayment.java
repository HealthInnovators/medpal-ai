package com.healhouts.patient.Beanclasses;

/**
 * Created by samsung on 30-06-2015.
 */
public class FeedItemPayment {



        private String payref;
        private String currencyCode;
        private String consultationFee;
        private String payDate;
        private String doctoName;
        private String consultationType;
        private String chatId;


        public String getPayref() {
            return payref;
        }

        public void setPayref(String payref) {
            this.payref = payref;
        }

        public String getCurrencyCode() {
            return currencyCode;
        }

        public void setCurrencyCode(String currencyCode) {
            this.currencyCode = currencyCode;
        }

        public String getConsultationFee() {
            return consultationFee;
        }

        public void setConsultationFee(String consultationFee) {
            this.consultationFee = consultationFee;
        }

        public String getPayDate() {
            return payDate;
        }

        public void setPayDate(String payDate) {
            this.payDate = payDate;
        }

        public String getDoctoName() {
            return doctoName;
        }

        public void setDoctoName(String doctoName) {
            this.doctoName = doctoName;
        }

        public String getConsultationType() {
            return consultationType;
        }

        public void setConsultationType(String consultationType) {
            this.consultationType = consultationType;
        }

        public String getChatId() {
            return chatId;
        }

        public void setChatId(String chatId) {
            this.chatId = chatId;
        }



    }


