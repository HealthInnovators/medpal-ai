package com.healhouts.patient.Adapters;

import android.app.AlertDialog;
import android.app.ProgressDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.os.AsyncTask;
import android.support.v7.widget.RecyclerView;
import android.text.Html;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.inputmethod.InputMethodManager;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import com.healhouts.patient.Beanclasses.FeedItemMedications;
import com.healhouts.patient.FragmentsPackage.ServiceHandler;
import com.healhouts.patient.R;
import com.healhouts.patient.common.CommonUtil;

import java.net.URISyntaxException;
import java.util.List;


/**
 * Created by Venkat Veeravalli on 17-06-2015.
 */
public class MyRecyclerAdapterMedications extends RecyclerView.Adapter<MyRecyclerAdapterMedications.FeedItemRowHolderMedications> {

    private static final String TAG ="MyRecyclerAdapterMedications";

    private List<FeedItemMedications> feedItemList;
    Boolean isInternetPresent = false;
    private Context mContext;
    String notes_update = "";
    int medicationId;
    String status_update = "";
    ProgressDialog pDialog;
    AlertDialog.Builder builder;
    private String customerId;
    private  String customerEmail;
    SharedPreferences userSharedPreferences;
    OnItemClickListener mItemClickListener;

   /* static String URL = "http://healthouts.com/appUpdatemedication?";
    static String URL2="http://healthouts.com/appDeleteMedications?";

*/
    static String URL = "http://joslinlive.org/appUpdatemedication?";
    static String URL2="http://joslinlive.org/appDeleteMedications?";

    public MyRecyclerAdapterMedications(Context context, List<FeedItemMedications> feedItemList) {
        this.feedItemList = feedItemList;
        this.mContext = context;
    }


    @Override
    public FeedItemRowHolderMedications onCreateViewHolder(ViewGroup parent, int viewType) {
        userSharedPreferences = this.mContext.getSharedPreferences(mContext.getString(R.string.cPreferences), Context.MODE_PRIVATE);
        userSharedPreferences = this.mContext.getSharedPreferences(mContext.getString(R.string.cPreferences), Context.MODE_PRIVATE);
        customerId = userSharedPreferences.getString(mContext.getString(R.string.customerId), null);
        customerEmail = userSharedPreferences.getString(mContext.getResources().getString(R.string.customerEmail), null);

        View v = LayoutInflater.from(parent.getContext()).inflate(R.layout.medications_list, null);
        FeedItemRowHolderMedications feedItemRowHolderMedications = new FeedItemRowHolderMedications(v);

        return feedItemRowHolderMedications;
    }


    @Override
    public void onBindViewHolder(final FeedItemRowHolderMedications holder, final int position) {

        final FeedItemMedications feedItem = feedItemList.get(position);


        holder.medication.setText(Html.fromHtml(feedItem.getMedication()));
        holder.notes.setText(Html.fromHtml(feedItem.getNotes()));

        holder.medicineUsage.setText(Html.fromHtml(feedItem.getMedicineUsage()));
        if(feedItem.getMedicineUsage().equalsIgnoreCase("past")){
            holder.medicineUsage.setChecked(true);
        }



//update Button Functionality
        holder.updateButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
//                Toast.makeText(mContext,"clicked",Toast.LENGTH_SHORT).show();
                notes_update = holder.notes.getText().toString();
                status_update = holder.medicineUsage.getText().toString();
//                Toast.makeText(mContext,"notes"+notes_update+"status"+status_update,Toast.LENGTH_SHORT).show();


                if (!notes_update.equals("") && !status_update.equals("")) {
                    updateMedication(feedItem, position, holder);
                } else {
                    Toast toast = Toast.makeText(mContext, "Suject and Answer are not empty!", Toast.LENGTH_SHORT);
                    toast.getView().setBackgroundColor(mContext.getResources().getColor(R.color.error_toast));
                    toast.show();
                }
            }
        });
        
        //delete Button functionality
        holder.deleteButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
//                Toast.makeText(mContext,"clicked",Toast.LENGTH_SHORT).show();
//                updateMedication(feedItem, position, holder);

                final AlertDialog.Builder builder = new AlertDialog.Builder(mContext);
                builder.setTitle("Info");
                builder.setMessage("Are you sure want to delete Medication");
                builder.setPositiveButton("cancel", new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface dialog, int id) {
                        builder.setCancelable(true);
                    }
                })
                        .setNegativeButton("ok", new DialogInterface.OnClickListener() {
                            public void onClick(DialogInterface dialog, int id) {
                                deleteMedication(feedItem, position, holder);
                            }
                        });
                builder.show();


            }
        });


    }

    private void deleteMedication( final FeedItemMedications feedItem, final int position,  final FeedItemRowHolderMedications holder) {

        new AsyncTask<Void, Void, List<FeedItemMedications>>() {
            @Override
            protected List<FeedItemMedications> doInBackground(Void... params) {

                String jsonStr = "";
                ServiceHandler sh = new ServiceHandler();

                String str = "CId="+customerId+"&CEmail="+customerEmail+"&medicationId="+feedItem.getMedicationId();
                str = URL2 + str;
                String queryStr = new CommonUtil().ConvertToUrlString(str);
                try {
                    jsonStr = sh.makeServiceCall(queryStr, ServiceHandler.POST);

                } catch (URISyntaxException e) {
                    e.printStackTrace();
                }
                return feedItemList;
            }

            @Override
            protected void onCancelled() {
                super.onCancelled();
            }

            @Override
            protected void onPreExecute() {
                super.onPreExecute();
                pDialog = new ProgressDialog(mContext);
                pDialog.setTitle("Please wait");
                pDialog.setMessage("Processing.... ");
                pDialog.setCancelable(true);
                pDialog.show();
                builder = new AlertDialog.Builder(mContext);
            }



            @Override
            protected void onPostExecute(List<FeedItemMedications> feedItemMedicationses) {
                super.onPostExecute(feedItemMedicationses);

                Toast toast = Toast.makeText(mContext, "Medication deleted", Toast.LENGTH_LONG);
                toast.setGravity(Gravity.CENTER_VERTICAL,0,0);
                TextView tv=new TextView(mContext);
                tv.setTextColor(Color.WHITE);
                tv.setTextSize(15);
                toast.getView().setBackgroundColor(Color.parseColor("#34bf49"));
                toast.show();
                feedItemList.remove(position);
                notifyItemRemoved(position);
                if (pDialog.isShowing())
                    pDialog.dismiss();

            }
        }.execute(null,null,null);
    }


    public void updateMedication(final FeedItemMedications feedItem, final int position, final FeedItemRowHolderMedications holder) {

        new AsyncTask<Void, Void, List<FeedItemMedications>>() {
            @Override
            protected List<FeedItemMedications> doInBackground(Void... params) {

                String jsonStr = "";
                ServiceHandler sh = new ServiceHandler();
//CID=37&cEmail=sheshakanth@seedinvent.com

                String str = "CId="+customerId+"&CEmail="+customerEmail+"&medicineUsage="+status_update+"&notes="+notes_update+"&medicationId="+feedItem.getMedicationId();
                str = URL + str;
                String queryStr = new CommonUtil().ConvertToUrlString(str);
                try {
                    jsonStr = sh.makeServiceCall(queryStr, ServiceHandler.POST);

                } catch (URISyntaxException e) {
                    e.printStackTrace();
                }
                return feedItemList;
            }

            @Override
            protected void onCancelled() {
                super.onCancelled();
            }

            @Override
            protected void onPreExecute() {
                super.onPreExecute();
                pDialog = new ProgressDialog(mContext);
                pDialog.setTitle("Please wait");
                pDialog.setMessage("Processing.... ");
                pDialog.setCancelable(true);
                pDialog.show();
                builder = new AlertDialog.Builder(mContext);
            }

            @Override
            protected void onPostExecute(List<FeedItemMedications> feedItemMedications) {
                super.onPostExecute(feedItemList);
                Toast toast = Toast.makeText(mContext, "Details updated successfully", Toast.LENGTH_LONG);
                toast.setGravity(Gravity.CENTER_VERTICAL,0,0);
                TextView tv=new TextView(mContext);
                tv.setTextColor(Color.WHITE);
                tv.setTextSize(15);
                toast.getView().setBackgroundColor(Color.parseColor("#34bf49"));
                toast.show();
                if (pDialog.isShowing())
                    pDialog.dismiss();


            }

        }.execute(null,null,null);
    }

    public int getItemCount() {

        return (null != feedItemList ? feedItemList.size() : 0);
    }

    public  interface OnItemClickListener{
        public  void onItemClick(View view, int position);
    }
    public void SetOnItemClickListener(final OnItemClickListener mItemClickListener) {
        this.mItemClickListener = mItemClickListener;
    }
    public class FeedItemRowHolderMedications extends RecyclerView.ViewHolder implements View.OnClickListener{

        public EditText medication;
        public EditText notes;
        public CheckBox medicineUsage;
        public Button deleteButton,updateButton;


        public FeedItemRowHolderMedications(View view) {
            super(view);
            this.medication = (EditText)view.findViewById(R.id.medication);


            InputMethodManager imm = (InputMethodManager) mContext.getSystemService(Context.INPUT_METHOD_SERVICE);

// only will trigger it if no physical keyboard is open
            imm.showSoftInput(this.medication, InputMethodManager.SHOW_IMPLICIT);
            imm.showSoftInput(this.notes, InputMethodManager.SHOW_IMPLICIT);


            this.notes = (EditText)view.findViewById(R.id.notes);
            this.medicineUsage = (CheckBox)view.findViewById(R.id.symptomState);
            this.updateButton = (Button)view.findViewById(R.id.updateButton);
            this.deleteButton = (Button)view.findViewById(R.id.deleteButton);
            updateButton.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {

                }
            });

            deleteButton.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                }
            });
//        view.setOnClickListener(this);


        }


        @Override
        public void onClick(View v) {

            if (mItemClickListener != null) {
                mItemClickListener.onItemClick(v, getPosition());
            }
        }

    }

}
