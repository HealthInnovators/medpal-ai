package com.healhouts.patient.Activities;

import android.app.AlertDialog;
import android.app.ProgressDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.os.AsyncTask;
import android.os.Bundle;
import android.os.StrictMode;
import android.provider.Settings;
import android.support.v7.app.ActionBarActivity;
import android.text.Html;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import com.healhouts.patient.Adapters.CustomListAdapter;
import com.healhouts.patient.Beanclasses.DoctorItems;
import com.healhouts.patient.FragmentsPackage.ServiceHandler;
import com.healhouts.patient.R;
import com.healhouts.patient.common.CommonUtil;
import com.healhouts.patient.common.ConnectionDetector;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.net.URISyntaxException;
import java.util.ArrayList;


public class Test extends ActionBarActivity implements AdapterView.OnItemSelectedListener {
    String sp, price;//speciality
    Spinner spinner_price, spinner_location;
    /* String spinner_item;*/
    String spinner_item_price;
    String spinner_item_location;

    public static String TAG = "Test";
    //    private static String url = "http://healthouts.com/appDocList?";
    private static String url = "http://joslinlive.org/appDocList?";

    //   private static String url2= "http://healthouts.com/appDocFilterList?sp=Dentist&sortby=Price=free";
    // private static String url2 = "http://healthouts.com/appDocFilterList?";
    private static String url2 = "http://joslinlive.org/appDocFilterList?";

    ProgressDialog pDialog;
    ListView lv1;
    CustomListAdapter adapter;
    Boolean isInternetPresent = false;
    ConnectionDetector cd;


    @Override
    protected void onCreate(Bundle savedInstanceState) {


        Bundle myBundle = getIntent().getExtras();
        sp = myBundle.getString("speciality");

        super.onCreate(savedInstanceState);
        Context context = getApplicationContext();
        ConnectionDetector cd = new ConnectionDetector(context);
        isInternetPresent = cd.isConnectingToInternet();
        Log.d(TAG, "present or not" + isInternetPresent);

        setContentView(R.layout.activity_test2);

        StrictMode.ThreadPolicy policy = new StrictMode.ThreadPolicy.Builder().permitAll().build();
        StrictMode.setThreadPolicy(policy);

        lv1 = (ListView) findViewById(R.id.custom_list);


// Create an ArrayAdapter using the string array and a default spinner layout
        spinner_price = (Spinner) findViewById(R.id.price_spinner);
        spinner_price.setOnItemSelectedListener(this);
        ArrayAdapter<CharSequence> adapter = ArrayAdapter.createFromResource(this,
                R.array.price_array, android.R.layout.simple_spinner_item);
// Specify the layout to use when the list of choices appears
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
// Apply the adapter to the spinner
        spinner_price.setAdapter(adapter);

// Create an ArrayAdapter using the string array and a default spinner layout
        spinner_location = (Spinner) findViewById(R.id.location_spinner);
        spinner_location.setOnItemSelectedListener(this);
        ArrayAdapter<CharSequence> adapter1 = ArrayAdapter.createFromResource(this,
                R.array.location_array, android.R.layout.simple_spinner_item);
// Specify the layout to use when the list of choices appears
        adapter1.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
// Apply the adapter to the spinner
        spinner_location.setAdapter(adapter1);
        new GetDoctors().execute();


        //Adding Action bar
        android.support.v7.app.ActionBar actionBar = getSupportActionBar();
        ColorDrawable colorDrawable = new ColorDrawable(Color.parseColor("#993333"));
        actionBar.setBackgroundDrawable(colorDrawable);
        actionBar.setTitle(Html.fromHtml("<font color='#ffffff'>" + sp + "</font>"));
        actionBar.setDisplayHomeAsUpEnabled(true);
        actionBar.setHomeButtonEnabled(true);


        lv1.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> a, View v, int position,
                                    long id) {
                Object o = lv1.getItemAtPosition(position);
                DoctorItems newData = (DoctorItems) o;
                Log.d(TAG, "DoctorItems------>" + newData);
                try {
                    Intent intent = new Intent(Test.this, DoctorPofileActivity.class);
                    Bundle bundle = new Bundle();
                    bundle.putString("doctorId", newData.getDoctorId());
                    bundle.putString("dName", newData.getdName());
                    intent.putExtras(bundle);
                    startActivity(intent);

                } catch (Exception e) {
                    // TODO: handle exception
                    e.printStackTrace();
                }


            }

        });

    }

    public void filter(View view) {

        Toast.makeText(this, "Filter Applied", Toast.LENGTH_LONG).show();
        applyFilter();


    }


    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.menu_test, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()) {


            case R.id.action_search:

                // Toast.makeText(this, "Search selected", Toast.LENGTH_SHORT).show();
                break;

            case android.R.id.home:
                super.onBackPressed();
                break;


            default:

        }


        return super.onOptionsItemSelected(item);
    }

    protected ArrayList<DoctorItems> applyFilter(Void... params) {


        ArrayList<DoctorItems> filterd_list = new ArrayList<DoctorItems>();
        ServiceHandler sh = new ServiceHandler();

        String jsonStr = "";

        try {
            String queryStr = new CommonUtil().ConvertToUrlString(url2 + "sp=" + sp + "&sortby=" + spinner_item_price + "&location=" + spinner_item_location);


            Log.d(TAG, "--" + queryStr);
            if (isInternetPresent == true) {
                jsonStr = sh.makeServiceCall(queryStr, ServiceHandler.GET);

            }


                /*Log.d("log", "---->"+jsonStr);*/
        } catch (URISyntaxException e1) {
            // TODO Auto-generated catch block
            e1.printStackTrace();
        }

//            Log.d("Response: ", "> " + jsonStr);

        if (jsonStr != null) {

            try {

                JSONArray jarr = new JSONArray(jsonStr);

                // Creating ArrayList from JSONArray object

                for (int i = 0; i < jarr.length(); i++) {
                    JSONObject job = (JSONObject) jarr.get(i);

//                        Log.d("log", "--imgPath->" + job.getString("imgPath"));

                    DoctorItems doctorItems = new DoctorItems();
                    doctorItems.setDoctorId(job.getString("doctorId"));
                    doctorItems.setdName(job.getString("dName"));
                    doctorItems.setSpeciality(job.getString("speciality"));
                    doctorItems.setLocation(job.getString("location"));
                    doctorItems.setImgPath(job.getString("imgPath"));

                    filterd_list.add(doctorItems);
//


                }
                adapter = new CustomListAdapter(this, filterd_list);
                if (filterd_list.size() == 0) {
                    String msg = "Sorry..!!search results not found.";
                    Toast toast = Toast.makeText(getApplicationContext(), msg, Toast.LENGTH_SHORT);
                    View view = toast.getView();
                    view.setBackgroundColor(Color.parseColor("#0f9d58"));
                    TextView text = (TextView) view.findViewById(android.R.id.message);
                    toast.show();

                }
                lv1.setAdapter(adapter);
            } catch (JSONException e) {
                e.printStackTrace();
            }

        } else {

            Log.e("ServiceHandler", "Couldn't get any data from the url");
        }

        return filterd_list;

    }

    @Override
    public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {


        switch (parent.getId()) {
            case R.id.price_spinner:
                spinner_price.setOnItemSelectedListener(this);
                spinner_item_price = parent.getItemAtPosition(position).toString();
                //   Toast.makeText(parent.getContext(), "Selected: " + spinner_item_price, Toast.LENGTH_LONG).show();

                break;
            case R.id.location_spinner:
                spinner_location.setOnItemSelectedListener(this);
                spinner_item_location = parent.getItemAtPosition(position).toString();
                // Toast.makeText(parent.getContext(), "Selected: " + spinner_item_location, Toast.LENGTH_LONG).show();
                break;
            default:
                break;
        }


    }

    @Override
    public void onNothingSelected(AdapterView<?> parent) {

    }


    private class GetDoctors extends AsyncTask<Void, Void, ArrayList> {

        @Override
        protected void onPreExecute() {
            super.onPreExecute();
            // Showing progress dialog
            pDialog = new ProgressDialog(Test.this, R.style.MyTheme);
            pDialog.setMessage("Please wait...");
            pDialog.setCancelable(false);
            pDialog.show();

        }

        @Override
        protected void onPostExecute(ArrayList result) {
            if (isInternetPresent == true) {
                if (result.size() != 0) {
                    super.onPostExecute(result);
                    adapter = new CustomListAdapter(Test.this, result);
                    adapter.notifyDataSetChanged();
                    lv1.setAdapter(adapter);
                    // Dismiss the progress dialog
                    if (pDialog.isShowing())
                        pDialog.dismiss();

                } else {

                    final AlertDialog.Builder builder = new AlertDialog.Builder(Test.this);

                    builder.setTitle("Information");
                    builder.setMessage("Joslin don't have any doctors for this Speciality,kindly explore later");
                    builder.setIcon(R.drawable.ic_report)
                            .setPositiveButton("cancel", new DialogInterface.OnClickListener() {
                                public void onClick(DialogInterface dialog, int id) {
                                    builder.setCancelable(true);
                                }
                            });
                    builder.show();
                    pDialog.dismiss();

                }
            } else {
                final AlertDialog.Builder builder = new AlertDialog.Builder(Test.this);

                builder.setTitle("Network Failure");
                builder.setMessage("Please check your Connection and try again");
                builder.setIcon(R.drawable.warn)
                        .setPositiveButton("cancel", new DialogInterface.OnClickListener() {
                            public void onClick(DialogInterface dialog, int id) {
                                builder.setCancelable(true);
                            }
                        })
                        .setNegativeButton("Wi-Fi Settings", new DialogInterface.OnClickListener() {
                            public void onClick(DialogInterface dialog, int id) {
                                startActivityForResult(new Intent(Settings.ACTION_WIFI_SETTINGS), 0);


                            }
                        });
                builder.show();
                pDialog.dismiss();
            }


        }

        @Override
        protected ArrayList doInBackground(Void... params) {

            ArrayList<DoctorItems> list = new ArrayList<DoctorItems>();
            ServiceHandler sh = new ServiceHandler();

            String jsonStr = "";

            try {
                String queryStr = new CommonUtil().ConvertToUrlString(url + "sp=" + sp);
//                Log.d(TAG, "--"+queryStr);
                jsonStr = sh.makeServiceCall(queryStr, ServiceHandler.GET);

                /*Log.d("log", "---->"+jsonStr);*/
            } catch (URISyntaxException e1) {
                // TODO Auto-generated catch block
                e1.printStackTrace();
            }

//            Log.d("Response: ", "> " + jsonStr);

            if (jsonStr != null) {

                try {

                    JSONArray jarr = new JSONArray(jsonStr);

                    // Creating ArrayList from JSONArray object

                    for (int i = 0; i < jarr.length(); i++) {
                        JSONObject job = (JSONObject) jarr.get(i);

//                        Log.d("log", "--imgPath->" + job.getString("imgPath"));

                        DoctorItems doctorItems = new DoctorItems();
                        doctorItems.setDoctorId(job.getString("doctorId"));
                        doctorItems.setdName(job.getString("dName"));
                        doctorItems.setSpeciality(job.getString("speciality"));
                        doctorItems.setLocation(job.getString("location"));
                        doctorItems.setImgPath(job.getString("imgPath"));

                        list.add(doctorItems);


                    }
                } catch (JSONException e) {
                    e.printStackTrace();
                }

            } else {
                Log.e("ServiceHandler", "Couldn't get any data from the url");
            }

            return list;
        }
    }
}





