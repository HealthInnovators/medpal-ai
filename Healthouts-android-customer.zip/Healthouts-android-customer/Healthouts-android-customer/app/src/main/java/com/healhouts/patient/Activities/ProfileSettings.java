package com.healhouts.patient.Activities;

import android.app.ActionBar;
import android.app.FragmentTransaction;
import android.content.Intent;
import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.os.Bundle;
import android.support.v7.app.ActionBarActivity;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.widget.ArrayAdapter;

import com.healhouts.patient.FragmentsPackage.AboutMe;
import com.healhouts.patient.FragmentsPackage.Allergies;
import com.healhouts.patient.FragmentsPackage.ContactInformation;
import com.healhouts.patient.FragmentsPackage.HealthFiles;
import com.healhouts.patient.FragmentsPackage.Immunization;
import com.healhouts.patient.FragmentsPackage.Medications;
import com.healhouts.patient.FragmentsPackage.Procedures;
import com.healhouts.patient.FragmentsPackage.SymptomsConditions;
import com.healhouts.patient.FragmentsPackage.YourPaymentHistory;
import com.healhouts.patient.R;

@SuppressWarnings("ALL")
public class ProfileSettings extends ActionBarActivity {


    // nav drawer title
    private CharSequence mDrawerTitle;

    // used to store app title
    private CharSequence mTitle;

    // slide menu items
    private String[] navMenuTitles;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        final android.support.v7.app.ActionBar actionBar = getSupportActionBar();
        ColorDrawable colorDrawable = new ColorDrawable(Color.parseColor("#993333"));
        actionBar.setBackgroundDrawable(colorDrawable);
        mTitle = mDrawerTitle = getTitle();
        // load slide menu items
        navMenuTitles = getResources().getStringArray(R.array.nav_drawer_items);
        // Specify that a dropdown list should be displayed in the action bar.
        actionBar.setNavigationMode(ActionBar.NAVIGATION_MODE_LIST);
        // Hide the title
        actionBar.setDisplayShowTitleEnabled(false);
        actionBar.setDisplayUseLogoEnabled(true);

        // Specify a SpinnerAdapter to populate the dropdown list.
        ArrayAdapter<String> spinnerMenu = new ArrayAdapter<String>(
                actionBar.getThemedContext(),
                android.R.layout.simple_list_item_activated_1, getResources()
                .getStringArray(R.array.labelMenu));


        actionBar.setListNavigationCallbacks(

                spinnerMenu,

                // Provide a listener to be called when an item is selected.
                new android.support.v7.app.ActionBar.OnNavigationListener() {
                    @Override
                    public boolean onNavigationItemSelected(int i, long l) {
                        FragmentTransaction tx = getFragmentManager()
                                .beginTransaction();

                        switch (i) {
                            case 0:
                                tx.replace(android.R.id.content, new AboutMe());
                                break;
                            case 1:
                                tx.replace(android.R.id.content, new ContactInformation());
                                break;
                            case 2:
                                tx.replace(android.R.id.content, new Medications());
                                break;
                            case 3:
                                tx.replace(android.R.id.content, new Allergies());
                                break;
                            case 4:
                                tx.replace(android.R.id.content, new SymptomsConditions());
                                break;
                            case 5:
                                tx.replace(android.R.id.content, new Procedures());
                                break;
                            case 6:
                                tx.replace(android.R.id.content, new Immunization());
                                break;
                            case 7:
                                tx.replace(android.R.id.content, new HealthFiles());
                                break;
                            case 8:
                                tx.replace(android.R.id.content, new YourPaymentHistory());
                                break;
                            default:
                                break;
                        }

                        tx.commit();

                        return true;
                    }
                });
    }


    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        MenuInflater inflater = getMenuInflater();
        inflater.inflate(R.menu.menu_profilesettings, menu);
        return super.onCreateOptionsMenu(menu);
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()) {
            // Respond to the action baru's Up/Home button
            case R.id.action_home:
                Intent docSpecialities = new Intent(this, AMS.class);
                startActivity(docSpecialities);
                break;


        }
        return super.onOptionsItemSelected(item);
    }


    @Override
    public void setTitle(CharSequence title) {
        mTitle = title;
        android.support.v7.app.ActionBar actionBar = getSupportActionBar();
        actionBar.setTitle(mTitle);
    }
}