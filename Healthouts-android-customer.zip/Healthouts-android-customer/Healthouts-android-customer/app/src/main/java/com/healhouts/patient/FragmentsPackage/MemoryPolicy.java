package com.healhouts.patient.FragmentsPackage;

/**
 * Created by samsung on 07-07-2015.
 */
enum MemoryPolicy {
    NO_CACHE, NO_STORE
}
enum NetworkPolicy {
    NO_CACHE, NO_STORE, OFFLINE
}