package com.healhouts.patient.Beanclasses;

/**
 * Created by samsung on 01-07-2015.
 */
public class FeedItemAllergies {
    private  String allergyId;
    private  String allergyState;
    private  String allergy;
    private  String notes;

    public String getCustomerId() {
        return customerId;
    }

    public void setCustomerId(String customerId) {
        this.customerId = customerId;
    }

    public String getAllergyId() {
        return allergyId;
    }

    public void setAllergyId(String allergyId) {
        this.allergyId = allergyId;
    }

    public String getAllergyState() {
        return allergyState;
    }

    public void setAllergyState(String allergyState) {
        this.allergyState = allergyState;
    }

    public String getAllergy() {
        return allergy;
    }

    public void setAllergy(String allergy) {
        this.allergy = allergy;
    }

    public String getNotes() {
        return notes;
    }

    public void setNotes(String notes) {
        this.notes = notes;
    }

    private String customerId;


}
