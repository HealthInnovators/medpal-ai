package com.healhouts.patient.Activities;

import android.app.Activity;
import android.content.Intent;
import android.graphics.Color;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import com.healhouts.patient.R;

public class AppointmentResultActivity extends Activity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        // TODO Auto-generated method stub
        super.onCreate(savedInstanceState);
        setContentView(R.layout.appointment_result_layout);
        Intent myLocalIntent = getIntent();
        Bundle myBundle = myLocalIntent.getExtras();
        String result = myBundle.getString("result");

        TextView resultView = (TextView) findViewById(R.id.app_result);
        if (result.equals("done")) {
            resultView.setText("Your appointment with doctor booked successfully");
            resultView.setTextColor(Color.parseColor("#993333"));
        } else {
            resultView.setText("Your appointment with doctor Failed");
            resultView.setTextColor(Color.parseColor("#DC4B39"));
        }

        Button resBtn = (Button) findViewById(R.id.res_btn);
        resBtn.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View arg0) {
                // TODO Auto-generated method stub
                Intent intent = new Intent(AppointmentResultActivity.this, AMS.class);
                startActivity(intent);
            }
        });
    }
}
