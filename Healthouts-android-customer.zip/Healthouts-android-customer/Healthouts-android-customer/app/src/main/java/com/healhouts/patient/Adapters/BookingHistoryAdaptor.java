package com.healhouts.patient.Adapters;

import android.support.v4.app.FragmentActivity;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.Filter;
import android.widget.Filterable;
import android.widget.TextView;

import com.healhouts.patient.R;

import java.util.ArrayList;
import java.util.HashMap;

/**
 * Created by Venkat Veeravalli on 16-04-2015.
 */
public class BookingHistoryAdaptor extends BaseAdapter implements Filterable {

    private ArrayList<HashMap> listData;
    ArrayList<HashMap> mStringFilterList;

    private LayoutInflater layoutInflater;
    //    ValueFilter valueFilter;
    public static String TAG = "BookingHistoryAdaptor";

    public BookingHistoryAdaptor(FragmentActivity context, int activity_booking_history_layout, ArrayList list) {
        super();
        this.listData = list;
        this.mStringFilterList = list;
        layoutInflater = LayoutInflater.from(context);
    }

    static class ViewHolder {
        TextView bookingDateView;
        TextView bookingTimeView;
        TextView doctorNameView;
        TextView specialityView;
        TextView cityView;

    }

    @Override
    public int getCount() {
        return listData.size();
    }

    @Override
    public Object getItem(int position) {
        return listData.get(position);
    }

    @Override
    public long getItemId(int position) {
        return position;
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        ViewHolder holder;
        if (convertView == null) {
            convertView = layoutInflater
                    .inflate(R.layout.fragment2, null);
            holder = new ViewHolder();
            holder.bookingDateView = (TextView) convertView.findViewById(R.id.booking_date);
            holder.bookingTimeView = (TextView) convertView.findViewById(R.id.booking_time);
            holder.doctorNameView = (TextView) convertView.findViewById(R.id.booked_doctor);
            holder.specialityView = (TextView) convertView.findViewById(R.id.booking_speciality);
            holder.cityView = (TextView) convertView.findViewById(R.id.booked_city);

            convertView.setTag(holder);
        } else {
            holder = (ViewHolder) convertView.getTag();
        }
        HashMap hm = (HashMap) listData.get(position);
        Log.d("--", "--" + hm.get("appointmentDate").toString());
        holder.bookingDateView.setText(hm.get("appointmentDate").toString());
        holder.bookingTimeView.setText(hm.get("time").toString());
        holder.doctorNameView.setText(hm.get("doctorName").toString());
        holder.specialityView.setText(hm.get("speciality").toString());
        holder.cityView.setText(hm.get("city").toString());
        return convertView;
    }

    @Override
    public Filter getFilter() {
        return null;
    }

}
