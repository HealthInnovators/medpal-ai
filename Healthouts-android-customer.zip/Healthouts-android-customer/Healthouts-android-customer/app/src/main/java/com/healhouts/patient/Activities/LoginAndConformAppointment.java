package com.healhouts.patient.Activities;

import android.app.AlertDialog;
import android.app.ProgressDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageInfo;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.os.AsyncTask;
import android.os.Bundle;
import android.support.v7.app.ActionBarActivity;
import android.text.Html;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.WindowManager;
import android.view.inputmethod.InputMethodManager;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.google.android.gms.gcm.GoogleCloudMessaging;
import com.healhouts.patient.FragmentsPackage.ServiceHandler;
import com.healhouts.patient.GCMService.Config;
import com.healhouts.patient.R;
import com.healhouts.patient.chat.ChatServer;

import org.json.JSONException;
import org.json.JSONObject;

import java.io.IOException;
import java.net.URISyntaxException;


public class LoginAndConformAppointment extends ActionBarActivity {

    AlertDialog.Builder builder;
    private EditText email = null;
    private EditText password = null;
    private Button login;
   // private CheckBox mCbShowPwd;
    ProgressDialog pDialog;
   // private String updageRegIdUrl = "http://healthouts.com/updateRegId?";
  private String updageRegIdUrl = "http://joslinlive.org/updateRegId?";
    public static final String REG_ID = "regId";
    private static final String APP_VERSION = "appVersion";

    static String TAG = "LoginAndConformAppointment";

    SharedPreferences sharedpreferences;
    private static String ctustomerId;
    private static String customerType;
    private static String customerEmail;
    private static String customerPassword;
    private static String customerName;
    private static String customerImage;
    private static String cPreferences;
    ChatServer xmppServer = new ChatServer();
    GoogleCloudMessaging gcm;
    Context context;
    String regId;
    private boolean token = false;//this is the status for updating device registration id in server

    // properties for booking appointment
    String doctorId;
    String dName = "";
    String imgPath = "";
    String speciality = "";
    String location = "";
    String availableDate = "";
    String timePeriod = "";
    String time = "";
    String format = "";
    String doctorTimeId;

    @Override
    protected void onCreate(Bundle savedInstanceState) {

        this.getWindow().setSoftInputMode(
                WindowManager.LayoutParams.SOFT_INPUT_ADJUST_PAN);
        // TODO Auto-generated method stub
        super.onCreate(savedInstanceState);
        setContentView(R.layout.login);
        android.support.v7.app.ActionBar actionBar = getSupportActionBar();
        ColorDrawable colorDrawable = new ColorDrawable(Color.parseColor("#993333"));
        actionBar.setTitle(Html.fromHtml("<font color='#ffffff'>" + "Login" + "</font>"));
        actionBar.setBackgroundDrawable(colorDrawable);
        actionBar.setDisplayHomeAsUpEnabled(true);
        actionBar.setHomeButtonEnabled(true);
//

        /*android.support.v7.app.ActionBar bar = getSupportActionBar();
        bar.setBackgroundDrawable(new ColorDrawable(Color.parseColor("#32c6ff")));
        bar.setDisplayHomeAsUpEnabled(true);
        bar.setHomeButtonEnabled(true);
//       actionBar.hide();
*/
        context = getApplicationContext();

        // these details are come form AvailableTimingsActivity use full to display doctor details
        Intent myLocalIntent = getIntent();
        Bundle myBundle = myLocalIntent.getExtras();
        doctorId = myBundle.getString("doctorId");
        dName = myBundle.getString("dName");
        imgPath = myBundle.getString("imgPath");
        speciality = myBundle.getString("speciality");
        location = myBundle.getString("location");
        availableDate = myBundle.getString("availableDate");
        timePeriod = myBundle.getString("timePeriod");
        time = myBundle.getString("time");
        format = myBundle.getString("format");
        doctorTimeId = myBundle.getString("doctorTimeId");
        InputMethodManager imm = (InputMethodManager)getSystemService(Context.INPUT_METHOD_SERVICE);


//		Toast.makeText(LoginActivity.this, "The email or password that you are entered is incorrect", Toast.LENGTH_LONG).show();
        email = (EditText) findViewById(R.id.edtEmail);

        imm.hideSoftInputFromWindow(email.getWindowToken(), 0);
        password = (EditText) findViewById(R.id.edtPassword);

        imm.hideSoftInputFromWindow(password.getWindowToken(), 0);
        login = (Button) findViewById(R.id.btnLogin);


        /*mCbShowPwd.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {

            public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                // checkbox status is changed from uncheck to checked.
                if (!isChecked) {
                    // show password
                    password.setTransformationMethod(PasswordTransformationMethod.getInstance());
                } else {
                    // hide password
                    password.setTransformationMethod(HideReturnsTransformationMethod.getInstance());
                }
            }
        });*/

        customerPassword = this.getString(R.string.customerPassword);
        customerEmail = this.getString(R.string.customerEmail);
        customerType = this.getString(R.string.customerType);
        ctustomerId = this.getString(R.string.customerId);
        customerName = this.getString(R.string.customerName);
        customerImage = this.getString(R.string.customerImage);
        cPreferences = this.getString(R.string.cPreferences);
        sharedpreferences = getSharedPreferences(cPreferences, Context.MODE_PRIVATE);

    }


    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.menu_login_and_conform_appointment, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()) {

            case R.id.txt_doctorHomeTitle:
                Intent docSpecialities = new Intent(this, AMS.class);
                startActivity(docSpecialities);
                break;
            case R.id.action_search:
                break;

            case android.R.id.home:
                super.onBackPressed();
                break;


            default:

        }


        return super.onOptionsItemSelected(item);
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
    }

    public void login(View view) {

        if (email.getText().toString().equals("") || password.getText().toString().equals("")) {
            Toast.makeText(this, "Login details required", Toast.LENGTH_LONG).show();
        } else {
            new CheckAuthendication().execute();
        }
    }

    public void singUp(View view) {
        Toast.makeText(this, "Sign Up", Toast.LENGTH_LONG).show();
        Intent intent = new Intent(LoginAndConformAppointment.this, RegistrationAndAppointment.class);
        Bundle myData = new Bundle();
        myData.putString("doctorId", doctorId);
        myData.putString("dName", dName);
        myData.putString("speciality", speciality);
        myData.putString("location", location);
        myData.putString("imgPath", imgPath);
        myData.putString("timePeriod", timePeriod);
        myData.putString("time", time);
        myData.putString("format", format);
        myData.putString("availableDate", availableDate);
        myData.putString("doctorTimeId", doctorTimeId);


        intent.putExtras(myData);
        startActivity(intent);
    }

    public void home(View view) {

        Intent i = new Intent(this, AMS.class);
        startActivity(i);
    }


    private class CheckAuthendication extends AsyncTask<Void, Void, JSONObject> {

        @Override
        protected void onPreExecute() {
            // TODO Auto-generated method stub
            super.onPreExecute();
            pDialog = new ProgressDialog(LoginAndConformAppointment.this, R.style.MyTheme);
            pDialog.setMessage("Please wait...");
            pDialog.setCancelable(false);
            pDialog.show();
            builder = new AlertDialog.Builder(LoginAndConformAppointment.this);

        }

        @Override
        protected JSONObject doInBackground(Void... arg0) {
            // TODO Auto-generated method stub
            ServiceHandler sh = new ServiceHandler();
            String jsonStr = "";
            JSONObject job = null;
            try {
                Log.d(TAG, "----email--->" + email.getText());
                Log.d(TAG, "----pass---->" + password.getText());
//                String url ="http://healthouts.com/appLogin?";
          //      String url = "http://healthouts.com/appLoginwithbooking?";
               String url = "http://joslinlive.org/appLoginwithbooking?";
                url = url + "email=" + email.getText().toString() + "&pass=" + password.getText().toString() + "&doctorId=" + doctorId + "&availableDate=" + availableDate + ""
                        + "&timePeriod=" + timePeriod + "&doctorTimeId=" + doctorTimeId;
                Log.d(TAG, "-----url for authendication---->" + url);
                jsonStr = sh.makeServiceCall(url, ServiceHandler.GET);

            } catch (URISyntaxException e) {
                // TODO Auto-generated catch block
                e.printStackTrace();
                Toast.makeText(context, "Network connection is not good", Toast.LENGTH_LONG).show();
            }
            Log.d(TAG, "response string" + jsonStr);
            if (jsonStr != null) {

                try {
                    job = new JSONObject(jsonStr);
                    Log.i("josn", job.getString("status"));

                    if (job.getString("status").equals("1")) {

                        try {
                            if (gcm == null) {
                                gcm = GoogleCloudMessaging.getInstance(context);
                                Log.i(TAG, "--gcm1--" + gcm);
                                gcm.unregister();
                            }
                            Log.i(TAG, "--gcm2--" + gcm);
                            regId = gcm.register(Config.GOOGLE_PROJECT_ID);
                            Log.d(TAG, "registerInBackground - regId: " + regId);
//                            msg = "Device registered, registration ID=" + regId;

                            ServiceHandler sh2 = new ServiceHandler();
                            updageRegIdUrl = updageRegIdUrl + "regId=" + regId + "&userEmail=" + email.getText();
                            Log.d(TAG, updageRegIdUrl);
                            jsonStr = sh2.makeServiceCall(updageRegIdUrl, ServiceHandler.GET);
                            Log.d(TAG, "--serverResponse--:" + jsonStr);
                            JSONObject json = new JSONObject(jsonStr);

                            if (json != null) {
                                if (json.get("status").equals("1")) {
                                    storeRegistrationId(context, regId);
                                    Log.i("josn", job.getString("emailId"));
                                    Log.i("josn", job.getString("customerType"));
                                    Log.i("josn", job.getString("customerId"));
                                    Log.i("josn", job.getString("pass"));
                                    SharedPreferences.Editor editor = sharedpreferences.edit();
//						Log.i("Stirng value", customerEmail);
                                    editor.putString(ctustomerId, job.getString("customerId"));
                                    editor.putString(customerEmail, job.getString("emailId"));
                                    editor.putString(customerType, job.getString("customerType"));
                                    editor.putString(customerPassword, job.getString("pass"));
                                    editor.putString(customerName, job.getString("cName"));
                                    editor.putString(customerImage, job.getString("cImage"));
                                    editor.commit();
                                    xmppServer.connect("joslin" + job.getString("customerId"), "joslin" + job.getString("customerId"));
                                }
                            }

                        } catch (IOException ex) {
                            ex.printStackTrace();
                            job.put("customerType", "NOTVALID");
                            return job;
                        } catch (URISyntaxException e) {
                            e.printStackTrace();
                            job.put("customerType", "NOTVALID");
                            return job;
                        } catch (JSONException e) {
                            e.printStackTrace();
                        }
//                       boolean val =  registerInBackground();


                    } else {
                        job.put("customerType", "NOTVALID");
                        job.put("bookingStatus", job.getString("bookingStatus"));
                        return job;
//                        Toast.makeText(context, "The email or password that you are entered is incorrect", Toast.LENGTH_LONG).show();
                    }

                } catch (JSONException e) {
                    // TODO Auto-generated catch block
                    e.printStackTrace();
                    JSONObject job2 = new JSONObject();
                    try {
                        job2.put("customerType", "NOTVALID");
                    } catch (JSONException e1) {
                        e1.printStackTrace();
                    }

                    return job2;
                } catch (Exception e1) {
                    // TODO Auto-generated catch block
                    e1.printStackTrace();
                }
            }
            return job;
        }

        @Override
        protected void onPostExecute(JSONObject result) {
            // TODO Auto-generated method stub
            super.onPostExecute(result);
            if (pDialog.isShowing())
                pDialog.dismiss();
            Intent intent = null;
            Bundle myData = new Bundle();
            try {
                if (result.getString("customerType").equals("CUSTOMER")) {
                    intent = new Intent(LoginAndConformAppointment.this, AppointmentResultActivity.class);

                    myData.putString("result", "done");
                    intent.putExtras(myData);
                    startActivity(intent);

                } else if (result.getString("customerType").equals("DOCTOR")) {
                    intent = new Intent(LoginAndConformAppointment.this, DoctorHomeActivity.class);
                    //				myData.putString("doctorId", newData.getDoctorId());
//				myData.putString("dName", newData.getdName());
                    intent.putExtras(myData);
//				startActivityForResult(intent, IPC_ID);
                    startActivity(intent);

                } else if (result.getString("customerType").equals("NOTVALID")) {
                    if (result.getString("bookingStatus").equals("bookingFail")) {

                        intent = new Intent(LoginAndConformAppointment.this, AppointmentResultActivity.class);
                        myData.putString("result", "fail");
                        intent.putExtras(myData);
                        startActivity(intent);
                    } else if (result.getString("bookingStatus").equals("loginFail")) {
                        builder.setCancelable(true);
                        builder.setMessage("Authendication failed");
                        builder.setInverseBackgroundForced(true);

                        builder.setNeutralButton("Ok", new DialogInterface.OnClickListener() {
                            public void onClick(DialogInterface dialog, int whichButton) {
                                dialog.dismiss();
                            }
                        });

                        builder.show();
                    }
                    Log.d(TAG, "Authandication failed try again");
                    Toast.makeText(context, "User is not valid try again", Toast.LENGTH_LONG).show();


                }


            } catch (Exception e) {
                // TODO: handle exception
                e.printStackTrace();
            }

            /**
             * Updating parsed JSON data into ListView
             * */


        }


    }

    private boolean registerInBackground() {
        String msg = "";
        String jsonStr = "";
        try {
            if (gcm == null) {
                gcm = GoogleCloudMessaging.getInstance(context);
                gcm.unregister();
            }
            regId = gcm.register(Config.GOOGLE_PROJECT_ID);
            Log.d("RegisterActivity", "registerInBackground - regId: "
                    + regId);
            msg = "Device registered, registration ID=" + regId;

            ServiceHandler sh = new ServiceHandler();
            updageRegIdUrl = updageRegIdUrl + "regId=" + regId + "&userEmail=" + email.getText();
            Log.d(TAG, updageRegIdUrl);
            jsonStr = sh.makeServiceCall(updageRegIdUrl, ServiceHandler.GET);
            Log.d(TAG, "--serverResponse--:" + jsonStr);
            JSONObject json = new JSONObject(jsonStr);

            if (json != null) {
                if (json.get("status").equals("1")) {
                    storeRegistrationId(context, regId);
                    token = true;
                }
            }

        } catch (IOException ex) {
            msg = "Error :" + ex.getMessage();
            Log.d("RegisterActivity", "Error: " + msg);
        } catch (URISyntaxException e) {
            e.printStackTrace();
        } catch (JSONException e) {
            e.printStackTrace();
        }


        return token;
    }

    private static int getAppVersion(Context context) {
        try {
            PackageInfo packageInfo = context.getPackageManager()
                    .getPackageInfo(context.getPackageName(), 0);
            return packageInfo.versionCode;
        } catch (PackageManager.NameNotFoundException e) {
            Log.d("RegisterActivity",
                    "I never expected this! Going down, going down!" + e);
            throw new RuntimeException(e);
        }
    }

    private void storeRegistrationId(Context context, String regId) {
        final SharedPreferences prefs = getSharedPreferences(
                MainActivity.class.getSimpleName(), Context.MODE_PRIVATE);
        int appVersion = getAppVersion(context);
        Log.i(TAG, "Saving regId on app version " + appVersion);
        SharedPreferences.Editor editor = prefs.edit();
        editor.putString(REG_ID, regId);
        editor.putInt(APP_VERSION, appVersion);
        editor.commit();
    }
}
