package com.healhouts.patient.FragmentsPackage;

import android.app.AlertDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.provider.Settings;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.GridView;

import com.healhouts.patient.Activities.FeedListActivityDoctors;
import com.healhouts.patient.Adapters.CustomGrid;
import com.healhouts.patient.R;
import com.healhouts.patient.common.ConnectionDetector;

import java.util.HashMap;


/**
 * Created by sony on 23/02/2015.
 */
public class SpecialitiesTab extends Fragment {
    private Context context;
    Boolean isInternetPresent = false;
    ConnectionDetector cd;

    HashMap hm = new HashMap();

    GridView grid;
    String[] web = {
            "Endocrinology",
            "Cardiovascular",
            "Eye Care",
            "Exercise",
            "Foot Care",
            "Geriatrics",
            "Hypoglycemia",
            "Behavioral Health",
            "Lipids",
            "Nutrition",
            "Pediatrics",
            "Peripheral Neuropathy",
            "Pregnancy",
            "Sexual Function",
            "Weight Management"
    };


    int[] imageId = {
            R.drawable.sp1,
            R.drawable.sp2,
            R.drawable.sp3,
            R.drawable.sp4,
            R.drawable.sp5,
            R.drawable.sp6,
            R.drawable.sp7,
            R.drawable.sp8,
            R.drawable.sp10,
            R.drawable.sp11,
            R.drawable.sp12,
            R.drawable.sp13,
            R.drawable.sp14,
            R.drawable.sp15,
            R.drawable.sp1,


    };

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {


        super.onCreate(savedInstanceState);
        context = getActivity().getApplicationContext();
        cd = new ConnectionDetector(context);
        isInternetPresent = cd.isConnectingToInternet();


        hm.put("0", "Endocrinology");
        hm.put("1", "Cardiovascular");
        hm.put("2", "Eye Care");
        hm.put("3", "Exercise");
        hm.put("4", "Foot Care");
        hm.put("5", "Geriatrics");
        hm.put("6", "Hypoglycemia");
        hm.put("7", "Behavioral Health");
        hm.put("8", "Lipids");
        hm.put("9", "Nutrition");
        hm.put("10", "Pediatrics");
        hm.put("11", "Peripheral Neuropathy");
        hm.put("12", "Pregnancy");
        hm.put("13", "Sexual Function");
        hm.put("14", "Weight Management");

        View fragmentView = inflater.inflate(R.layout.tab1, container, false);
        CustomGrid adapter = new CustomGrid(getActivity(), web, imageId);
        grid = (GridView) fragmentView.findViewById(R.id.grid);
        grid.setAdapter(adapter);
        grid.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view,
                                    int position, long id) {
                String speciality = (String) hm.get(position + "");
                if (isInternetPresent == true) {

                    try {
                        //Intent intent = new Intent(getActivity(), Test.class);
                        Intent intent = new Intent(getActivity(), FeedListActivityDoctors.class);
                        Bundle myData = new Bundle();
                        myData.putString("speciality", speciality);
                        intent.putExtras(myData);
                        startActivity(intent);

                    } catch (Exception e) {
                        // TODO: handle exception
                        e.printStackTrace();
                    }
                } else {
                    getActivity().runOnUiThread(new Runnable() {
                        public void run() {
                            final AlertDialog.Builder builder = new AlertDialog.Builder(getActivity());
                            builder.setTitle("Connection failure");
                            builder.setMessage("Please check your network connection and try again");
                            builder.setIcon(R.drawable.ic_action_warning)
                                    .setPositiveButton("cancel", new DialogInterface.OnClickListener() {
                                        public void onClick(DialogInterface dialog, int id) {
                                            builder.setCancelable(true);
                                        }
                                    })
                                    .setNegativeButton("Wi-Fi Settings", new DialogInterface.OnClickListener() {
                                        public void onClick(DialogInterface dialog, int id) {
                                            startActivityForResult(new Intent(Settings.ACTION_WIFI_SETTINGS), 0);

                                        }
                                    });
                            builder.show();
                        }
                    });

                }

            }
        });
        return fragmentView;
    }


}

