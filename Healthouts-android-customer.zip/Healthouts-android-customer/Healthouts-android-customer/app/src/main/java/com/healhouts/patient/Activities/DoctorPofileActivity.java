package com.healhouts.patient.Activities;

import android.app.DatePickerDialog;
import android.app.Dialog;
import android.app.ProgressDialog;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.ColorDrawable;
import android.os.AsyncTask;
import android.os.Bundle;
import android.support.v4.app.NavUtils;
import android.support.v7.app.ActionBarActivity;
import android.text.Html;
import android.util.Log;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.DatePicker;
import android.widget.ImageView;
import android.widget.RatingBar;
import android.widget.TextView;

import com.healhouts.patient.FragmentsPackage.ServiceHandler;
import com.healhouts.patient.R;
import com.healhouts.patient.chat.EnableChatActivity;
import com.healhouts.patient.common.CommonUtil;
import com.healhouts.patient.common.ServiceCalls;
import com.squareup.picasso.Picasso;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.net.URISyntaxException;
import java.util.Calendar;


public class DoctorPofileActivity extends ActionBarActivity{

    static String TAG = "DoctorPofileActivity";
  //  private String url = "http://healthouts.com/appDocProf";
    /*private String availableUrl = "http://healthouts.com/appDocAvailability";
    private String pushNotifiUrl = "http://healthouts.com/pushNotification?";
*/

    private String url = "http://joslinlive.org/appDocProf";
//    private String availableUrl = "http://joslinlive.org/appDocAvailability";
//    private String pushNotifiUrl = "http://joslinlive.org/pushNotification?";

    String responseStr = "";
    String availableStr = "";
    String doctorId;
    String dName = "", consultationFee;
    String imgPath = "";
    String speciality = "";
    String location = "";
    String doctorEmail = "";
    ServiceHandler sh;
    Dialog cd;
    ProgressDialog pd;
    private String doctorCustomerId;
    Context context;
    SharedPreferences sharedpreferences;

    private String customerId;
    private boolean loginStatus = false;

    private DatePicker datePicker;
    private Calendar calendar;
    private int year, month, day;
    String strDate;

    DatePickerDialog dialog;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        // TODO Auto-generated method stub
        super.onCreate(savedInstanceState);
        setContentView(R.layout.doctor_profile_layout_2);
        final Typeface font = Typeface.createFromAsset(getAssets(), "fonts/MYRIADPRO-REGULAR.OTF");
        context = this;
        Intent myLocalIntent = getIntent();
        Bundle myBundle = myLocalIntent.getExtras();
        doctorId = myBundle.getString("doctorId");
        Log.d(TAG, "--doctorId--" + doctorId);
        dName = myBundle.getString("dName");
        android.support.v7.app.ActionBar actionBar = getSupportActionBar();
        ColorDrawable colorDrawable = new ColorDrawable(Color.parseColor("#993333"));
        actionBar.setBackgroundDrawable(colorDrawable);
        actionBar.setTitle(Html.fromHtml("<font color='#ffffff'>" + dName + "</font>"));
        actionBar.setDisplayHomeAsUpEnabled(true);
        actionBar.setHomeButtonEnabled(true);
        sharedpreferences = context.getSharedPreferences(context.getString(R.string.cPreferences), Context.MODE_PRIVATE);
        Log.d("---", "--sharedpreferences--" + sharedpreferences);
        if (sharedpreferences.getString(context.getString(R.string.customerId), null) != null) {
            customerId = sharedpreferences.getString(context.getString(R.string.customerId), null);
            loginStatus = true;
        }
        Button askPaidQuestion = (Button)findViewById(R.id.btnaskPaidQs);
        askPaidQuestion.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                if(loginStatus) {


                    Intent intent = new Intent(getApplicationContext(), PaidQuestionActivity.class);
                    Bundle bundle = new Bundle();
                    bundle.putString(getResources().getString(R.string.doctorId), doctorId);
                    bundle.putString(getResources().getString(R.string.docotName), dName);
                    bundle.putString(getResources().getString(R.string.doctorImgPath), imgPath);
                    bundle.putString(getResources().getString(R.string.consultationFee), consultationFee);
                    bundle.putString(getResources().getString(R.string.speciality), speciality);
                    intent.putExtras(bundle);

                    startActivity(intent);
                }else{
                    Intent intent = new Intent(getApplicationContext(), LoginActivity.class);
                    Bundle bundle = new Bundle();
                    bundle.putString(getResources().getString(R.string.doctorId), doctorId);
                    bundle.putString(getResources().getString(R.string.docotName), dName);
                    bundle.putString(getResources().getString(R.string.doctorImgPath), imgPath);
                    bundle.putString(getResources().getString(R.string.consultationFee), consultationFee);
                    bundle.putString(getResources().getString(R.string.speciality), speciality);
                    intent.putExtras(bundle);

                    startActivity(intent);
                }
            }
        });

//		 layoutInflater = LayoutInflater.from(this);
        calendar = Calendar.getInstance();
        year = calendar.get(Calendar.YEAR);
        month = calendar.get(Calendar.MONTH);
        day = calendar.get(Calendar.DAY_OF_MONTH);
//	      showDate(year, month+1, day);

        sh = new ServiceHandler();

        new Thread(new Runnable() {


            @Override
            public void run() {
                try {
                    // TODO Auto-generated method stub
                    responseStr = sh.makeServiceCall(url + "?doctorId="
                            + doctorId, ServiceHandler.GET);
                    Log.d(TAG, "---->" + responseStr);
                    if (!responseStr.equals("")) {


                        //set data to view
                        runOnUiThread(new Runnable() {

                            @Override
                            public void run() {
                                // TODO Auto-generated method stub
                                try {
                                    JSONObject content = new JSONObject(responseStr);
                                    JSONArray reviews = content.getJSONArray("reviews");
                                    JSONObject profDetails = content.getJSONObject("profileDetails");


                                    ImageView imgView = (ImageView) findViewById(R.id.imagePath);
                                    imgPath = profDetails.getString("imagePath");
                                    Log.d(TAG,"path of image"+imgPath);


                                    //Picasso.with(context).load("http://i.imgur.com/DvpvklR.png").into(imgView);

                                    Picasso.with(getApplicationContext()).load(new CommonUtil().ConvertToUrlString(imgPath))
                                            .error(R.drawable.placeholder)
                                            .placeholder(R.drawable.doctorhealthouts)
                                            .into(imgView);

                                    Log.d(TAG,"img path is"+imgPath);

                                   /* Log.d(TAG, "--imgPath--" + imgPath);
                                    String finalUrlStr = "";
                                    if (imgPath.equals("")) {
                                        finalUrlStr = "http://healthouts.com/img/doctor1.png";
                                    } else {
                                        finalUrlStr = new CommonUtil().ConvertToUrlString(imgPath);
                                    }

                                    new ImageDownloaderTask(imgView).execute(finalUrlStr);

                                */

                                    TextView nameView = (TextView) findViewById(R.id.profileName);
                                    TextView qualificationView = (TextView) findViewById(R.id.pro_qualification);
                                    TextView specialityView = (TextView) findViewById(R.id.pro_speciality);
                                    TextView cityView = (TextView) findViewById(R.id.pro_city);
                                    RatingBar ratingBar = (RatingBar) findViewById(R.id.pro_rating);
                                    TextView bioView = (TextView) findViewById(R.id.bioText);
                                    TextView topic1View = (TextView) findViewById(R.id.topic1);
                                    TextView topic2View = (TextView) findViewById(R.id.topic2);
                                    TextView topic3View = (TextView) findViewById(R.id.topic3);
                                    TextView topic4View = (TextView) findViewById(R.id.topic4);
                                    TextView topic5View = (TextView) findViewById(R.id.topic5);
                                    TextView experienceView = (TextView) findViewById(R.id.experience);
                                    TextView add1View = (TextView) findViewById(R.id.add1);
                                    TextView add2View = (TextView) findViewById(R.id.add2);
                                    TextView practiceCityView = (TextView) findViewById(R.id.practice_city);
                                    TextView practiceStateView = (TextView) findViewById(R.id.practice_state);
                                    TextView practiceZipView = (TextView) findViewById(R.id.practice_zipcode);
                                    TextView practiceUrlView = (TextView) findViewById(R.id.practice_url);


                                    specialityView.setTypeface(font);
                                    cityView.setTypeface(font);
                                    bioView.setTypeface(font);
                                    topic1View.setTypeface(font);
                                    topic2View.setTypeface(font);
                                    topic3View.setTypeface(font);
                                    topic4View.setTypeface(font);
                                    topic5View.setTypeface(font);
                                    experienceView.setTypeface(font);
                                    add1View.setTypeface(font);
                                    add2View.setTypeface(font);
                                    practiceCityView.setTypeface(font);
                                    practiceStateView.setTypeface(font);
                                    practiceZipView.setTypeface(font);
                                    practiceUrlView.setTypeface(font);



                                    doctorEmail = profDetails.getString("email");
                                    doctorCustomerId = profDetails.getString("customerId");
                                    nameView.setText(profDetails.getString("name"));
                                    qualificationView.setText("-" + profDetails.getString("qualification"));
                                    specialityView.setText(profDetails.getString("specialization"));
                                    speciality = profDetails.getString("specialization");
                                    consultationFee = profDetails.getString("consultationFee");
                                    cityView.setText(profDetails.getString("city"));
                                    location = profDetails.getString("city");
                                    ratingBar.setRating(5);

                                    bioView.setText(profDetails.getString("info"));
                                    topic1View.setText(profDetails.getString("topic1"));
                                    topic2View.setText(profDetails.getString("topic2"));
                                    topic3View.setText(profDetails.getString("topic3"));
                                    topic4View.setText(profDetails.getString("topic4"));
                                    topic5View.setText(profDetails.getString("topic5"));
                                    experienceView.setText(profDetails.getString("experience") + " years of experience");
                                    add1View.setText(profDetails.getString("practiceAddress1"));
                                    add2View.setText(profDetails.getString("practiceAddress2"));
                                    practiceCityView.setText(profDetails.getString("city"));
                                    practiceStateView.setText(profDetails.getString("practicestate"));
                                    practiceZipView.setText(profDetails.getString("zipcode"));
                                    practiceUrlView.setText(profDetails.getString("practiceUrl"));


                                } catch (JSONException e) {
                                    // TODO Auto-generated catch block
                                    e.printStackTrace();
                                }

                            }
                        });
                    }
                } catch (URISyntaxException e) {
                    // TODO Auto-generated catch block
                    e.printStackTrace();
                }

            }
        }).start();


    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        MenuInflater inflater = getMenuInflater();
        inflater.inflate(R.menu.doctor_actionitems, menu);
        return super.onCreateOptionsMenu(menu);
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()) {
            // Respond to the action baru's Up/Home button
            case android.R.id.home:
                NavUtils.navigateUpFromSameTask(this);
                return true;

            case R.id.txt_doctorHomeTitle:
                Intent docSpecialities = new Intent(this, AMS.class);
                startActivity(docSpecialities);
                break;


        }
        return super.onOptionsItemSelected(item);
    }

    int mYear,mMonth, mDay;
    boolean setDatetoken = false;
    @Override
    protected Dialog onCreateDialog(int id) {
        // TODO Auto-generated method stub
        if (id == 999) {
            return new DatePickerDialog(this, myDateListener, year, month, day);
        }
        return null;
    }
    private DatePickerDialog.OnDateSetListener myDateListener = new DatePickerDialog.OnDateSetListener() {
        @Override
        public void onDateSet(DatePicker arg0, int arg1, int arg2, int arg3) {
            // TODO Auto-generated method stub
            // arg1 = year
            // arg2 = month
            // arg3 = day
            showDate(arg1, arg2+1, arg3);
        }
    };
    private void showDate(int year, int month, int day) {
        strDate = new StringBuilder().append(year).append("-").append(month).append("-").append(day).toString();
        setDatetoken=true;
        if(setDatetoken){
            getAvailableTaimings();
        }
/*
        Toast.makeText(getApplicationContext(),"selected date is"+strDate,Toast.LENGTH_SHORT).show();
*/

    }


    @SuppressWarnings("deprecation")
    public void setDate(View view) {
        showDialog(999);
        /*Toast.makeText(this, "Clicked Now", Toast.LENGTH_LONG).show();*/
        setDatetoken = false;
        Calendar c = Calendar.getInstance();
        mYear = c.get(Calendar.YEAR);
        mMonth = c.get(Calendar.MONTH);
        mDay = c.get(Calendar.DAY_OF_MONTH);


        DatePickerDialog.OnDateSetListener myDateListener = new DatePickerDialog.OnDateSetListener() {
            @Override
            public void onDateSet(DatePicker arg0, int arg1, int arg2, int arg3) {
                // TODO Auto-generated method stub
                // arg1 = year
                // arg2 = month
                // arg3 = day
                showDate(arg1, arg2+1, arg3);

            }
        };

    }


    private void getAvailableTaimings() {

        new AsyncTask<Void, Void, Void>() {

            @Override
            protected Void doInBackground(Void... params) {
                try {
                    Log.d("log", "---strDate-->" + strDate);
                    String strUrl = ServiceCalls.availableUrl + "?doctorId="
                            + doctorId + "&strDate=" + strDate;
                    Log.d("---", "--->" + strUrl);
                    availableStr = sh.makeServiceCall(strUrl, ServiceHandler.GET);
                    Log.d("log", "---->" + availableStr);
                    if (!availableStr.equals("")) {
                        JSONObject job = new JSONObject(availableStr);
                        try {
                            Intent intent = new Intent(DoctorPofileActivity.this, AvailableTimingsActivity.class);
                            Bundle myData = new Bundle();
                            myData.putString("doctorId", doctorId);
                            myData.putString("dName", dName);
                            myData.putString("imgPath", imgPath);
                            myData.putString("speciality", speciality);
                            myData.putString("location", location);
                            myData.putString("availableStr", availableStr);
                            intent.putExtras(myData);
//							startActivityForResult(intent, IPC_ID);
                            startActivity(intent);

                        } catch (Exception e) {
                            // TODO: handle exception
                            e.printStackTrace();
                        }


                    }


                } catch (Exception e) {
                    // TODO: handle exception
                }
                return null;
            }
        }.execute(null, null, null);


    }




    public void chatNow(View view) {

/*
        Toast.makeText(this, "Chat Now", Toast.LENGTH_LONG).show();
*/
        try {
            sharedpreferences = getSharedPreferences(context.getString(R.string.dPreferences), Context.MODE_PRIVATE);
            SharedPreferences userSharedPreferences = getSharedPreferences(context.getString(R.string.cPreferences), Context.MODE_PRIVATE);
            ServiceCalls.pushNotifiUrl = ServiceCalls.pushNotifiUrl + "customerId=" + userSharedPreferences.getString(context.getString(R.string.customerId), null) + "&email=" + doctorEmail + "&userName=" + sharedpreferences.getString(context.getString(R.string.doctorEmail), null);

            new AsyncTask<Void, Void, Void>() {
                @Override
                protected Void doInBackground(Void... params) {
                    try {
                        String restult = sh.makeServiceCall(ServiceCalls.pushNotifiUrl, ServiceHandler.POST);
                        Log.d(TAG, "--push notification status from server--" + new JSONObject(restult).getString("status"));
                    } catch (URISyntaxException e) {
                        e.printStackTrace();
                    } catch (JSONException e) {
                        e.printStackTrace();
                    }
                    return null;
                }


            }.execute(null, null, null);


            Intent intent = new Intent(DoctorPofileActivity.this, EnableChatActivity.class);
            Bundle myData = new Bundle();
            Log.i("DoctorProfileActivity", "doctor id --->" + doctorId);
            myData.putString("doctorCustomerId", doctorCustomerId);
            myData.putString("dName", dName);

            intent.putExtras(myData);
            startActivity(intent);

        } catch (Exception e) {
            // TODO: handle exception
            e.printStackTrace();
        }
    }


}
