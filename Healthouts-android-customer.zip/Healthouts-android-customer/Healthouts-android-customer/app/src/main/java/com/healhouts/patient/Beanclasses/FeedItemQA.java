package com.healhouts.patient.Beanclasses;

import org.json.JSONArray;

import java.io.Serializable;

/**
 * Created by Sheshakanth on 21-05-2015.
 */
public class FeedItemQA implements Serializable{
    private String questionBody;
    private String qsDate;
    private String cImage;
    private String questionId;
    private JSONArray ansArray;

    public JSONArray getAnsArray() {
        return ansArray;
    }

    public void setAnsArray(JSONArray ansArray) {
        this.ansArray = ansArray;
    }

    public String getQuestionBody()
    {
        return questionBody;
    }

    public void setQuestionBody(String questionBody)
    {
        this.questionBody = questionBody;
    }
    public String getQsDate()
    {
        return qsDate;
    }

    public void setQsDate(String qsDate) {

        this.qsDate = qsDate;
    }



    public String getcImage() {

        return cImage;
    }

    public void setcImage(String cImage) {

        this.cImage = cImage;
    }
    public String getQuestionId(){
        return   questionId;
    }
    public void setQuestionId(String questionId){
        this.questionId=questionId;
    }


}
