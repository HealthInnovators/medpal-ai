package com.healhouts.patient.Beanclasses;

/**
 * Created by samsung on 21-05-2015.
 */
public class FeedItemDoctor {
    private String docId;
    private String imgPath;
    private  String speciality;
    private String dName;
    private  String location;

    public String getDocId() {

        return docId;
    }

    public void setDocId(String docId) {

        this.docId = docId;
    }

    public String getImgPath()
    {
        return imgPath;
    }

    public void setImgPath(String imgPath) {
        this.imgPath = imgPath;
    }

    public  String getSpeciality(){
        return speciality;
    }

    public void setSpeciality(String speciality) {
        this.speciality = speciality;
    }

    public  String getdName(){
        return dName;
    }

    public void setdName(String dName) {
        this.dName = dName;
    }

    public String getLocation(){
        return location;
    }

    public void setLocation(String location) {
        this.location = location;
    }

}