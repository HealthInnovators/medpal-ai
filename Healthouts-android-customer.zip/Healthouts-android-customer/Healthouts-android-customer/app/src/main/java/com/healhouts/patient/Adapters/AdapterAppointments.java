package com.healhouts.patient.Adapters;

/**
 * Created by samsung on 25-05-2015.
 */

import android.content.Context;
import android.support.v7.widget.RecyclerView;
import android.text.Html;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import com.healhouts.patient.Beanclasses.FeedItemAppointments;
import com.healhouts.patient.R;

import java.util.List;



/**
 * Created by samsung on 23-05-2015.
 */


/**
 * Created by samsung on 21-05-2015.
 */

public class AdapterAppointments extends RecyclerView.Adapter<AdapterAppointments.FeedListRowHolderAppointments> {

    private static final String TAG = "AdapterDoctor";
    private List<FeedItemAppointments> feedItemList;
    private Context mContext;
    OnItemClickListener mItemClickListener;


    public AdapterAppointments(Context context, List<FeedItemAppointments> feedItemList) {
        this.feedItemList = feedItemList;
        this.mContext = context;
    }

    @Override
    public FeedListRowHolderAppointments onCreateViewHolder(ViewGroup viewGroup, int i) {
        View v = LayoutInflater.from(viewGroup.getContext()).inflate(R.layout.fragment2, null);
        FeedListRowHolderAppointments mh = new AdapterAppointments.FeedListRowHolderAppointments(v);
        return mh;
    }

    @Override
    public void onBindViewHolder(FeedListRowHolderAppointments feedListRowHolder, int i) {
        //   FeedItemAppointments feedItemAppointments=feedItemList.get(i);
        FeedItemAppointments feedItem = feedItemList.get(i);

        /*Picasso.with(mContext).load(new CommonUtil().ConvertToUrlString(feedItem.getImgPath()))
                .error(R.drawable.placeholder)
                .placeholder(R.drawable.doctorhealthouts)
                .into(feedListRowHolder.imgPath);
*/
        feedListRowHolder.booking_date.setText(Html.fromHtml(feedItem.getAppointmentDate()));
        feedListRowHolder.booked_city.setText(Html.fromHtml(feedItem.getDoctorCity()));
        feedListRowHolder.booked_doctor.setText(Html.fromHtml(feedItem.getDoctorName()));
        feedListRowHolder.booking_speciality.setText(Html.fromHtml(feedItem.getDoctorSpecialty()));
        feedListRowHolder.booking_time.setText(Html.fromHtml(feedItem.getAppointmentTime()));
    }
    public  interface OnItemClickListener{
        public  void onItemClick(View view, int position);



    }
    public void SetOnItemClickListener(final OnItemClickListener mItemClickListener) {
        this.mItemClickListener = mItemClickListener;
    }

    @Override
    public int getItemCount() {
        return (null != feedItemList ? feedItemList.size() : 0);
    }

    public class FeedListRowHolderAppointments  extends RecyclerView.ViewHolder implements View.OnClickListener{


        protected TextView booked_city;
        protected TextView booking_speciality;
        protected TextView booking_time;
        protected TextView booking_date;
        protected TextView booked_doctor;
        public FeedListRowHolderAppointments(View view) {
            super(view);
            this.booked_city = (TextView) view.findViewById(R.id.booked_city);
            this.booking_speciality = (TextView) view.findViewById(R.id.booking_speciality);
            this.booking_time = (TextView) view.findViewById(R.id.booking_time);
            this.booked_doctor = (TextView) view.findViewById(R.id.booked_doctor);
            this.booking_date = (TextView) view.findViewById(R.id.booking_date);
            view.setOnClickListener(this);
        }

        @Override
        public void onClick(View v) {

            if (mItemClickListener != null) {
                mItemClickListener.onItemClick(v, getPosition());

            }
        }

    }
}