package com.healhouts.patient.common;

/**
 * Created by Venkat on 27-05-2015.
 */
public class ServiceCalls {
/*
    public static final String ASK_PAID_QUESION_URL = "http://healthouts.com/appsendPaidMessageToDoctor";
    public static final String UPDATE_ABOUTME_URL = "http://healthouts.com/appUpdateCustomerAboutme?";
    public static final String GET_HEALTHFILE_URL = "http://healthouts.com/appGetHealthFiles?";
    public static final String DELETE_HEALTHFILE_URL = "http://healthouts.com/appDeleteHealthFile?";
    public static final String ADD_HEALTHFILE_URL = "http://healthouts.com/appAddHealthFiles?";
    public static final String GET_IMMUNIZATION_DETAILS_URL = "http://healthouts.com/appGetImmunizations?";
    public static final String ADD_IMMUNIZATION_URL = "http://healthouts.com/appSaveImmunization?";*/


    /*public static final String DEFAULT_IMG_URL = "http://healthouts.com/img/";
    public static final String APPOINTMENT_CONFIRM_URL = "http://healthouts.com/appConfirmApp";
    public static String pushNotifiUrl = "http://healthouts.com/pushNotification?";
    public static final String availableUrl = "http://healthouts.com/appDocAvailability";
    public static final String FEEDBACK_URL="http://healthouts.com/appSendReview?";
    public static final String DOCTOR_LIST="http://healthouts.com/appDocList?";
    public static final String DOCTOR_FILTER_LIST="http://healthouts.com/appDocFilterList?";
    public static String appLoginwithbooking="http://healthouts.com/appLoginwithbooking?";*/


    public static final String ASK_PAID_QUESION_URL = "http://joslinlive.org/appsendPaidMessageToDoctor";
    public static final String UPDATE_ABOUTME_URL = "http://joslinlive.org/appUpdateCustomerAboutme?";
    public static final String GET_HEALTHFILE_URL = "http://joslinlive.org/appGetHealthFiles?";
    public static final String DELETE_HEALTHFILE_URL = "http://joslinlive.org/appDeleteHealthFile?";
    public static final String ADD_HEALTHFILE_URL = "http://joslinlive.org/appAddHealthFiles?";
    public static final String GET_IMMUNIZATION_DETAILS_URL = "http://joslinlive.org/appGetImmunizations?";
    public static final String ADD_IMMUNIZATION_URL = "http://joslinlive.org/appSaveImmunization?";


    public static final String DEFAULT_IMG_URL = "http://joslinlive.org/img/";
    public static final String APPOINTMENT_CONFIRM_URL = "http://joslinlive.org/appConfirmApp";
    public static String pushNotifiUrl = "http://joslinlive.org/pushNotification?";
    public static final String availableUrl = "http://joslinlive.org/appDocAvailability";
    public static final String FEEDBACK_URL = "http://joslinlive.org/appSendReview?";
    public static final String DOCTOR_LIST = "http://joslinlive.org/appDocList?";
    public static final String DOCTOR_FILTER_LIST = "http://joslinlive.org/appDocFilterList?";
    public static String appLoginwithbooking = "http://joslinlive.org/appLoginwithbooking?";


}

