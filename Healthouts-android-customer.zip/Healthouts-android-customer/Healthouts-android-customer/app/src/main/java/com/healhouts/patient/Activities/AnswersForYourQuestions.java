package com.healhouts.patient.Activities;

import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.os.Bundle;
import android.support.v7.app.ActionBarActivity;
import android.text.Html;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;

import com.healhouts.patient.R;
import com.healhouts.patient.common.CommonUtil;
import com.healhouts.patient.common.ServiceCalls;
import com.squareup.picasso.Picasso;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

public class AnswersForYourQuestions extends ActionBarActivity {
    String TAG=getClass().getName();
    TextView textViewAnsbody;
    TextView textViewAnsHead;
    TextView textViewQs;
    TextView textFeedDocName;
    TextView textAnswered;
    ImageView feedDocImg;

    String ansJsonArray;
    JSONArray jarry;
    String questionBody;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        // TODO Auto-generated method stub
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_answers_yourquestions);
        android.support.v7.app.ActionBar actionBar = getSupportActionBar();
        ColorDrawable colorDrawable = new ColorDrawable(Color.parseColor("#993333"));
        actionBar.setBackgroundDrawable(colorDrawable);
        actionBar.setTitle(Html.fromHtml("<font color='#ffffff'>" + "Answers" + "</font>"));
        actionBar.setDisplayHomeAsUpEnabled(true);
        actionBar.setHomeButtonEnabled(true);
        ansJsonArray = getIntent().getExtras().getString("ansJsonArray");
        questionBody = getIntent().getExtras().getString("questionBody");
        Log.d(TAG,"ans json array"+ansJsonArray);
        feedDocImg=(ImageView)findViewById(R.id.customerImg);
        textFeedDocName=(TextView)findViewById(R.id.textFeedDocName);
        textAnswered=(TextView)findViewById(R.id.textAnswered);
        textViewQs=(TextView)findViewById(R.id.textViewQs);
        textViewAnsHead=(TextView)findViewById(R.id.textViewAnsHead);
        textViewAnsbody=(TextView)findViewById(R.id.textViewAnsbody);
        try {
            jarry = new JSONArray(ansJsonArray.replaceAll("@_@","\n"));
        } catch (JSONException e) {
            e.printStackTrace();
        }
        if(jarry.length() == 0){
//            textViewAnsbody.setText("It seems that Healthouts Doctors Concerned your Question as Emerged One .So Better to meet them ");

            textViewAnsbody.setText("It seems that Joslin Doctors Concerned your Question as Emerged One .So Better to meet them ");
            textViewQs.setText(questionBody);
            textViewAnsHead.setVisibility(View.INVISIBLE);
            feedDocImg.setVisibility(View.INVISIBLE);
            textAnswered.setVisibility(View.INVISIBLE);
            textFeedDocName.setVisibility(View.INVISIBLE);
        }
        for(int i=0;i<=jarry.length();i++){
            try {
                JSONObject jsonObject=jarry.getJSONObject(i);

                Picasso.with(getApplicationContext()).load(new CommonUtil().ConvertToUrlString(ServiceCalls.DEFAULT_IMG_URL+jsonObject.getString("doctorImage")))

//                Picasso.with(getApplicationContext()).load(new CommonUtil().ConvertToUrlString("http://joslinlive.org/img/"+jsonObject.getString("doctorImage")))

                        .error(R.drawable.ic_launcher)
                        .placeholder(R.drawable.ic_launcher)
                        .into(feedDocImg);

                textViewQs.setText(questionBody);
                textViewAnsbody.setText(jsonObject.getString("answerBody"));
                textFeedDocName.setText(jsonObject.getString("doctorName"));
                textViewAnsHead.setText(jsonObject.getString("answerSubject"));
            } catch (JSONException e) {
                e.printStackTrace();
            }


        }

    }
    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.menu_test, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()) {

            case android.R.id.home:
                super.onBackPressed();
                break;


            default:

        }


        return super.onOptionsItemSelected(item);
    }

}