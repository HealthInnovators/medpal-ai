package com.healhouts.patient.Adapters;

import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentManager;
import android.support.v4.app.FragmentStatePagerAdapter;

import com.healhouts.patient.Activities.YourFreeQuestionsFragment;
import com.healhouts.patient.FragmentsPackage.AskQuestionsFragment;
import com.healhouts.patient.FragmentsPackage.PublicQuestionsFragment;

/**
 * Created by Venkat Veeravalli on 12-05-2015.
 */
public class ViewPagerPblicFeedAdapter extends FragmentStatePagerAdapter {
    /* This will store the Titles of the Tab which are going to be passed when the ViewPagerAdapter is going to be created */
    CharSequence Titles[];
    /* This will store the number of Tabs which will be passed when the ViewPagerAdapter will be created*/
    int NumOfTabs;
    public ViewPagerPblicFeedAdapter(FragmentManager fm, CharSequence mTitles[], int noOfTabs) {
        super(fm);
        this.Titles = mTitles;
        this.NumOfTabs = noOfTabs;
    }

    @Override
    public Fragment getItem(int position) {
//        switch (position){
//            case 0:
//                PublicQuestionsFragment tab1 = new PublicQuestionsFragment();
//                return tab1;
//                break;
//            case 1:
//                AskQuestionsFragment layout_doctors_tab = new AskQuestionsFragment();
//                return layout_doctors_tab;
//                break;
//            case 2:
//                YourFreeQuestionsFragment tab3 = new YourFreeQuestionsFragment();
//                return tab3;
//                break;
//            default:
//                PublicQuestionsFragment tab = new PublicQuestionsFragment();
//                return tab;
//                break;
//        }
        if (position == 0) {
            AskQuestionsFragment tab1 = new AskQuestionsFragment();
            return tab1;
        } else if (position == 1) {
            PublicQuestionsFragment tab2 = new PublicQuestionsFragment();
            return tab2;
        } else{
            YourFreeQuestionsFragment tab3 = new YourFreeQuestionsFragment();
            return tab3;
        }
    }

    // This method return the titles for the Tabs in the Tab Strip
    public CharSequence getPageTitle(int position) {
        return Titles[position];
    }
    @Override
    public int getCount() {
        return NumOfTabs;
    }


}
