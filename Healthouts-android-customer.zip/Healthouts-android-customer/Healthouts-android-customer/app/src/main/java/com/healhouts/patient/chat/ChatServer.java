package com.healhouts.patient.chat;

import android.os.Handler;
import android.util.Log;
import android.widget.EditText;
import android.widget.ListView;

import org.jivesoftware.smack.ConnectionConfiguration;
import org.jivesoftware.smack.ConnectionConfiguration.SecurityMode;
import org.jivesoftware.smack.Roster;
import org.jivesoftware.smack.RosterEntry;
import org.jivesoftware.smack.SmackException;
import org.jivesoftware.smack.SmackException.ConnectionException;
import org.jivesoftware.smack.XMPPConnection;
import org.jivesoftware.smack.XMPPException;
import org.jivesoftware.smack.packet.Presence;
import org.jivesoftware.smack.tcp.XMPPTCPConnection;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Collection;

public class ChatServer implements ChatInterface {

    public static final String HOST = "healthouts.com"; //write your host name
    public static final int PORT = 5222;
    public String USERNAME; //username and password with want to login
    public String PASSWORD;
    private static XMPPConnection connection;
    private ConnectionConfiguration connConfig;
    private ArrayList<String> messages = new ArrayList<String>();
    private Handler mHandler = new Handler();

    private EditText recipient;
    private EditText textMessage;
    private ListView listview;

    public ChatServer() {

        // Create a connection
//			connConfig = new ConnectionConfiguration(HOST, PORT);
//			connConfig.setReconnectionAllowed(true);
//			connConfig.setDebuggerEnabled(true);
//			connConfig.setSecurityMode(SecurityMode.disabled);
//			connection = new XMPPTCPConnection(connConfig);
//			try {
//                connection.connect();
//                Log.i("XMPPChatDemoActivity",
//                        "Connected to " + connection.getHost());
//            } catch (XMPPException | SmackException | IOException ex) {
//                Log.e("XMPPChatDemoActivity", "Failed to connect to "
//                        + connection.getHost());
//                Log.e("XMPPChatDemoActivity", ex.toString());
////                setConnection(null);
//            }

    }

    public static XMPPConnection getXmppConnection() {

        Thread t = new Thread(new Runnable() {

            @Override
            public void run() {
                // TODO Auto-generated method stub
                // Create a connection
                Log.i("tag", "------>" + HOST);
                ConnectionConfiguration connConfig = new ConnectionConfiguration(HOST, PORT);
                connConfig.setReconnectionAllowed(true);
                connConfig.setDebuggerEnabled(true);
                connConfig.setSecurityMode(SecurityMode.disabled);
//				connConfig.setCompressionEnabled(true);
//				connConfig.setSASLAuthenticationEnabled(true);
//	            xmppConnection = new XMPPConnection(configuration);
                connection = new XMPPTCPConnection(connConfig);

                try {
                    connection.connect();
                    Log.i("XMPPChatDemoActivity",
                            "Connected to " + connection.getHost());
                    Log.i("XMPPChatDemoActivity",
                            "is connected-------> " + connection.isConnected());

                } catch (XMPPException ex) {
                    Log.e("XMPPChatDemoActivity", "Failed to connect to "
                            + connection.getHost());

                    Log.e("XMPPChatDemoActivity", ex.toString());
//					Log.e("tag", "-----"+((ConnectionException) ex).getFailedAddresses());
//					setConnection(null);
                } catch (SmackException ex) {
                    Log.e("XMPPChatDemoActivity", "Failed to connect to "
                            + connection.getHost());

                    Log.e("XMPPChatDemoActivity", ex.toString());
                    Log.e("tag", "-----" + ((ConnectionException) ex).getFailedAddresses());
//					setConnection(null);
                } catch (IOException ex) {
                    Log.e("XMPPChatDemoActivity", "Failed to connect to "
                            + connection.getHost());

                    Log.e("XMPPChatDemoActivity", ex.toString());
//					Log.e("tag", "-----"+((ConnectionException) ex).getFailedAddresses());
//					setConnection(null);
                }

            }

        });
        t.start();
        return connection;
    }

    public XMPPConnection connect(String username, String password) {

//		final ProgressDialog dialog = ProgressDialog.show(this,
//				"Connecting...", "Please wait...", false);
        USERNAME = username;
        PASSWORD = password;

        Thread t = new Thread(new Runnable() {

            @Override
            public void run() {
                // Create a connection
                Log.i("tag", "------>" + HOST);
                ConnectionConfiguration connConfig = new ConnectionConfiguration(HOST, PORT);
                connConfig.setReconnectionAllowed(true);
                connConfig.setDebuggerEnabled(true);
                connConfig.setSecurityMode(SecurityMode.disabled);
//				connConfig.setCompressionEnabled(true);
//				connConfig.setSASLAuthenticationEnabled(true);
//	            xmppConnection = new XMPPConnection(configuration);
                connection = new XMPPTCPConnection(connConfig);

                try {
                    connection.connect();
                    Log.i("XMPPChatDemoActivity",
                            "Connected to " + connection.getHost());
                    Log.i("XMPPChatDemoActivity",
                            "is connected-------> " + connection.isConnected());

                } catch (XMPPException ex) {
                    Log.e("XMPPChatDemoActivity", "Failed to connect to "
                            + connection.getHost());

                    Log.e("XMPPChatDemoActivity", ex.toString());
//					Log.e("tag", "-----"+((ConnectionException) ex).getFailedAddresses());
//					setConnection(null);
                } catch (SmackException ex) {
                    Log.e("XMPPChatDemoActivity", "Failed to connect to "
                            + connection.getHost());

                    Log.e("XMPPChatDemoActivity", ex.toString());
                    Log.e("tag", "-----" + ((ConnectionException) ex).getFailedAddresses());
//					setConnection(null);
                } catch (IOException ex) {
                    Log.e("XMPPChatDemoActivity", "Failed to connect to "
                            + connection.getHost());

                    Log.e("XMPPChatDemoActivity", ex.toString());
//					Log.e("tag", "-----"+((ConnectionException) ex).getFailedAddresses());
//					setConnection(null);
                }
                try {
                    // SASLAuthentication.supportSASLMechanism("PLAIN", 0);
                    connection.login(USERNAME, PASSWORD);
                    Log.i("XMPPChatDemoActivity",
                            "Logged in as " + connection.getUser());

                    // Set the status to available
                    Presence presence = new Presence(Presence.Type.available);
                    connection.sendPacket(presence);
//					setConnection(connection);

                    Roster roster = connection.getRoster();
                    Collection<RosterEntry> entries = roster.getEntries();
                    Log.i("ChatServer", "roster size----:" + entries.size());
                    for (RosterEntry entry : entries) {
                        Log.d("XMPPChatDemoActivity",
                                "--------------------------------------");
                        Log.d("XMPPChatDemoActivity", "RosterEntry " + entry);
                        Log.d("XMPPChatDemoActivity",
                                "User: " + entry.getUser());
                        Log.d("XMPPChatDemoActivity",
                                "Name: " + entry.getName());
                        Log.d("XMPPChatDemoActivity",
                                "Status: " + entry.getStatus());
                        Log.d("XMPPChatDemoActivity",
                                "Type: " + entry.getType());
                        Presence entryPresence = roster.getPresence(entry
                                .getUser());

                        Log.d("XMPPChatDemoActivity", "Presence Status: "
                                + entryPresence.getStatus());
                        Log.d("XMPPChatDemoActivity", "Presence Type: "
                                + entryPresence.getType());
                        Presence.Type type = entryPresence.getType();
                        if (type == Presence.Type.available)
                            Log.d("XMPPChatDemoActivity", "Presence AVIALABLE");
                        Log.d("XMPPChatDemoActivity", "Presence : "
                                + entryPresence);

                    }
                } catch (XMPPException | SmackException | IOException ex) {
                    Log.e("XMPPChatDemoActivity", "Failed to log in as "
                            + USERNAME);
                    Log.e("XMPPChatDemoActivity", ex.toString());
//					setConnection(null);
                }

//				dialog.dismiss();
            }
        });
        t.start();
//		dialog.show();
        return connection;
    }

    @Override
    public boolean loginToOpenFire(String username, String password)
            throws Exception {
        // TODO Auto-generated method stub
        boolean loginStatus = false;
        try {
            // SASLAuthentication.supportSASLMechanism("PLAIN", 0);
            Log.i("-----", "**************");
            Log.i("openfire", (connection != null) ? "true" : "false");
            Log.i("-----", "**************" + username + password);
            connection.login(username, password);
            Log.i("XMPPChatDemoActivity",
                    "Logged in as " + connection.getUser());
            loginStatus = true;
            // Set the status to available
            Presence presence = new Presence(Presence.Type.available);
            connection.sendPacket(presence);
        } catch (Exception e) {
            // TODO: handle exception
            Log.i("error", "-----------error-------");
//			Log.i("loginerror", e.getMessage().toString());
            e.printStackTrace();
        }
        Log.i("loginStatus", "----->" + loginStatus);
        return loginStatus;
    }


}
