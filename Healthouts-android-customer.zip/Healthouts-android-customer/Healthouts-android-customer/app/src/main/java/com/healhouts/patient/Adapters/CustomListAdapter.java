package com.healhouts.patient.Adapters;

import android.content.Context;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.Filter;
import android.widget.Filterable;
import android.widget.ImageView;
import android.widget.TextView;

import com.healhouts.patient.Beanclasses.DoctorItems;
import com.healhouts.patient.R;
import com.healhouts.patient.common.CommonUtil;
import com.healhouts.patient.common.ImageDownloaderTask;

import java.util.ArrayList;

public class CustomListAdapter extends BaseAdapter implements Filterable {

    private ArrayList<DoctorItems> listData;
    ArrayList<DoctorItems> mStringFilterList;

    private LayoutInflater layoutInflater;
    ValueFilter valueFilter;
    public static String TAG = "CustomListAdapter";

    public CustomListAdapter(Context context, ArrayList<DoctorItems> listData) {
        this.listData = listData;
        this.mStringFilterList = listData;
        layoutInflater = LayoutInflater.from(context);
    }

    @Override
    public int getCount() {
        return listData.size();
    }

    @Override
    public Object getItem(int position) {
        return listData.get(position);
    }

    @Override
    public long getItemId(int position) {
        return position;
    }

    public View getView(int position, View convertView, ViewGroup parent) {
        ViewHolder holder;
        if (convertView == null) {
            convertView = layoutInflater
                    .inflate(R.layout.list_row_layout, null);
            holder = new ViewHolder();
            holder.dNameView = (TextView) convertView.findViewById(R.id.dName);
            holder.specialityView = (TextView) convertView
                    .findViewById(R.id.speciality);
            holder.cityView = (TextView) convertView.findViewById(R.id.location);
            holder.imageView = (ImageView) convertView
                    .findViewById(R.id.thumbImage);
            convertView.setTag(holder);
        } else {
            holder = (ViewHolder) convertView.getTag();
        }

        DoctorItems doctorItem = (DoctorItems) listData.get(position);

        holder.dNameView.setText(doctorItem.getdName());
        holder.specialityView.setText(doctorItem.getSpeciality());
        holder.cityView.setText(doctorItem.getLocation());

        if (holder.imageView != null) {
            Log.d(TAG, "--ImgPath from Adapter--" + doctorItem.getImgPath());
            String finalUrlStr = "";


            if (doctorItem.getImgPath().equals("")) {
                finalUrlStr = "http://joslinlive.org/img/doctor1.png";
                holder.imageView.setImageResource(R.drawable.doctorhealthouts);
            } else {
                finalUrlStr = new CommonUtil().ConvertToUrlString(doctorItem.getImgPath());
                new ImageDownloaderTask(holder.imageView).execute(finalUrlStr);
            }
//            Log.d(TAG, "--finalUrlStr--"+ finalUrlStr);

//			new ImageDownloaderTask(holder.imageView)
//					.execute("http://healthouts.com/img/doctor1.png");
        }

        return convertView;
    }

    static class ViewHolder {
        TextView dNameView;
        TextView specialityView;
        TextView cityView;
        ImageView imageView;
    }

    @Override
    public Filter getFilter() {
        if (valueFilter == null) {
            valueFilter = new ValueFilter();
        }
        return valueFilter;
    }

    private class ValueFilter extends Filter {

        @Override
        protected FilterResults performFiltering(CharSequence constraint) {
            // TODO Auto-generated method stub
            FilterResults results = new FilterResults();
            if (constraint != null && constraint.length() > 0) {
                ArrayList<DoctorItems> filterList = new ArrayList<DoctorItems>();
                for (int i = 0; i < mStringFilterList.size(); i++) {
                    if (mStringFilterList.get(i).getdName().toUpperCase()
                            .contains(constraint.toString().toUpperCase())) {
                        DoctorItems doctorItem = new DoctorItems(
                                mStringFilterList.get(i).getDoctorId(),
                                mStringFilterList.get(i).getdName(),
                                mStringFilterList.get(i).getSpeciality(),
                                mStringFilterList.get(i).getLocation(),
                                mStringFilterList.get(i).getImgPath());
                        filterList.add(doctorItem);

                    }
                }
                results.count = filterList.size();
                results.values = filterList;
            } else {

                results.count = mStringFilterList.size();
                results.values = mStringFilterList;
            }
            return results;
        }

        @Override
        protected void publishResults(CharSequence constraint, FilterResults results) {
            listData = (ArrayList<DoctorItems>) results.values;
            notifyDataSetChanged();

        }

    }
}
