package com.healhouts.patient.FragmentsPackage;

import android.app.ProgressDialog;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.os.StrictMode;
import android.support.v4.app.Fragment;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.VolleyLog;
import com.android.volley.toolbox.JsonArrayRequest;
import com.healhouts.patient.Activities.FeedBack;
import com.healhouts.patient.Activities.SimpleDividerItemDecoration;
import com.healhouts.patient.Adapters.AdapterPaidQA;
import com.healhouts.patient.Beanclasses.FeedItemPaidQA;
import com.healhouts.patient.R;
import com.healhouts.patient.Volley.AppController;
import com.healhouts.patient.common.ConnectionDetector;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.List;
/**
 * Created by sony on 04/03/2015.
 */
public class PaidQuestions extends Fragment {
    private static final String TAG = "YourFreeQuestionsFragment";
    private Context context;
    String customerEmail, customerId;
    Boolean isInternetPresent = false;
    ConnectionDetector cd;
    JSONArray jsonArray;
    List<FeedItemPaidQA> FeedItemPaidQAList = new ArrayList<FeedItemPaidQA>();
    private RecyclerView mRecyclerView;
    LinearLayoutManager mLayoutManager;

    private AdapterPaidQA adapter;
    private boolean loading = true;
    int firstVisibleItem, visibleItemCount, totalItemCount;
    int count = 0;
    int token = 0;
    SharedPreferences sharedpreferences;
    ProgressDialog pDialog;
       String url = "http://joslinlive.org/appGetUserPaidHistory?";
   // String url = "http://healthouts.com/appGetUserPaidHistory?";
    // String url = "http://healthouts.com/appGetUserPaidHistory?CID=5&cEmail=ven.veeravalli@gmail.com";

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        StrictMode.ThreadPolicy policy = new StrictMode.ThreadPolicy.Builder().permitAll().build();
        StrictMode.setThreadPolicy(policy);
        context = getActivity().getApplicationContext();
        cd = new ConnectionDetector(context);
        isInternetPresent = cd.isConnectingToInternet();
        View fragmentView = inflater.inflate(R.layout.activity_paid_feedsqanda_list, container, false);
        mRecyclerView = (RecyclerView) fragmentView.findViewById(R.id.recycler_view);
        mRecyclerView.setHasFixedSize(true);
        mRecyclerView.setHasFixedSize(true);
        mLayoutManager = new LinearLayoutManager(getActivity());
        mRecyclerView.setLayoutManager(mLayoutManager);
        sharedpreferences = context.getSharedPreferences(context.getString(R.string.cPreferences), Context.MODE_PRIVATE);
        customerId = sharedpreferences.getString(context.getString(R.string.customerId), null);
        customerEmail = sharedpreferences.getString(context.getString(R.string.customerEmail), null);

//        mRecyclerView.

        mRecyclerView.setOnScrollListener(new RecyclerView.OnScrollListener() {
            @Override
            public void onScrolled(RecyclerView recyclerView, int dx, int dy) {
                super.onScrolled(recyclerView, dx, dy);
                visibleItemCount = mRecyclerView.getChildCount();
                totalItemCount = mLayoutManager.getItemCount();
                firstVisibleItem = mLayoutManager.findFirstVisibleItemPosition();
                if (loading) {
                    if ((visibleItemCount + firstVisibleItem) >= totalItemCount) {
                        loading = false;
                        Log.v("...", "Last Item Wow !");
                        count = totalItemCount;

                    }
                }
            }


        });
        yourPaidFeedandAns();
        return fragmentView;

    }

    public void yourPaidFeedandAns() {
        final ProgressDialog pDialog = new ProgressDialog(getActivity());
        pDialog.setMessage("Loading...");
        pDialog.show();
        FeedItemPaidQA item = new FeedItemPaidQA();
        JsonArrayRequest req = new JsonArrayRequest(url+"CID="+customerId +"&cEmail="+customerEmail,
                new Response.Listener<JSONArray>() {
                    @Override
                    public void onResponse(JSONArray response) {
                        for (int i = 0; i < response.length(); i++) {
                            JSONObject jsonobject = null;
                            try {
                                JSONObject jsonObject = response.getJSONObject(i);
                                String chatType=jsonObject.getString("chatType");
                                if(chatType.equals("question")||chatType.equals("answer")){
                                    FeedItemPaidQA item = new FeedItemPaidQA();
                                    Log.d(TAG, "q" + chatType.equals("question"));
                                    if(jsonObject.getString("healthFile")!=null&&jsonObject.getString("healthFile")!="") {
                                        item.setHealthFile(jsonObject.getString("healthFile"));
                                        Log.d(TAG,"healthFile"+jsonObject.getString("healthFile"));

                                    }
                                    item.setCsubject(jsonObject.getString("csubject"));
                                    item.setCdetails(jsonObject.getString("cdetails"));
                                    item.setCustomerImg(jsonObject.getString("customerImg"));
                                    item.setCutomerName(jsonObject.getString("cutomerName"));
                                    item.setCid(Integer.valueOf(jsonObject.getString("cid")));
                                    item.setChatid(Integer.valueOf(jsonObject.getString("chatid")));
                                    if(chatType.equals("answer")){
//
                                        //Log.d(TAG,"is it answer"+chatType.equals("answer"));
                                        item.setAnswerStatus(true);
                                        item.setDname(jsonObject.getString("dname"));
                                        item.setdImgPath(jsonObject.getString("dImgPath"));
                                        item.setDoctorSubject(jsonObject.getString("doctorSubject").replace("@_@","\n"));
                                        item.setDoctorAnswer(jsonObject.getString("doctorAnswer").replace("@_@","\n"));
                                        item.setReviewStatus(Boolean.valueOf(jsonObject.getString("reviewStatus")));
                                        item.setDid(Integer.parseInt(jsonObject.getString("did")));
                                    }
                                    FeedItemPaidQAList.add(item);
                                    adapter = new AdapterPaidQA(getActivity(), FeedItemPaidQAList);                            mRecyclerView.addItemDecoration(new SimpleDividerItemDecoration(getResources()));
                                    mRecyclerView.setAdapter(adapter);
                                    mLayoutManager.scrollToPositionWithOffset(count, 0);
                                    loading=true;

                                    adapter.SetOnItemClickListener(new AdapterPaidQA.OnItemClickListener() {
                                        @Override
                                        public void onItemClick(View view, int position) {
                                            Log.d("---", "----position---"+position);
                                            FeedItemPaidQA feedItem = FeedItemPaidQAList.get(position);

                                            if(feedItem.isReviewStatus()==false){


                                                Intent intent = new Intent(context, FeedBack.class);
                                                Bundle myData = new Bundle();
                                                myData.putString("chatid", String.valueOf(feedItem.getChatid()));
                                                myData.putString("did", String.valueOf(feedItem.getDid()));
                                                myData.putString("cid", String.valueOf(feedItem.getCid()));
                                                intent.putExtras(myData);
                                                startActivity(intent);
                                            }

                                        }
                                    });
                                }

                            } catch (JSONException e) {
                                e.printStackTrace();
                            }
                        }
                        pDialog.hide();
                    }
                }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                VolleyLog.d(TAG, "Error: " + error.getMessage());
                pDialog.hide();
            }
        });

        AppController.getInstance(context.getApplicationContext()).addToRequestQueue(req);

    }
}