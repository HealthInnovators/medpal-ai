package com.healhouts.patient.Activities;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.os.Bundle;
import android.support.v4.app.NavUtils;
import android.support.v7.app.AppCompatActivity;
import android.text.Html;
import android.util.Log;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.widget.Toast;

import com.healhouts.patient.R;

import org.json.JSONException;
import org.json.JSONObject;

public class AvailableTimingsActivity extends AppCompatActivity {

    String availableStr = "";
    String doctorId;
    String dName = "";
    String imgPath = "";
    String speciality = "";
    String location = "";
    String availableDate = "";
    String timePeriod[] = {"", "10:00", "10:30", "11:00", "11:30", "12:00", "12:30", "05:00", "05:30", "06:00", "06:30", "07:00", "07:30", "08:00", "08:30"};
    int sdk = android.os.Build.VERSION.SDK_INT;
    JSONObject job;
    String doctorTimeId;
    SharedPreferences userSharedPreferences;
    private Context context;
    private String customerId;
    private boolean loginStatus = false;
    String TAG=getClass().getName();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        // TODO Auto-generated method stub
        super.onCreate(savedInstanceState);
        setContentView(R.layout.timings_layout);
//        getActionBar().setDisplayHomeAsUpEnabled(true);
        android.support.v7.app.ActionBar actionBar = getSupportActionBar();
        ColorDrawable colorDrawable = new ColorDrawable(Color.parseColor("#993333"));
        actionBar.setBackgroundDrawable(colorDrawable);

        actionBar.setDisplayHomeAsUpEnabled(true);
        actionBar.setHomeButtonEnabled(true);
        actionBar.setTitle(Html.fromHtml("<font color='#ffffff'>" + "Available Timings" + "</font>"));
        Intent myLocalIntent = getIntent();
        Bundle myBundle = myLocalIntent.getExtras();
        doctorId = myBundle.getString("doctorId");
        dName = myBundle.getString("dName");
        imgPath = myBundle.getString("imgPath");
        speciality = myBundle.getString("speciality");
        location = myBundle.getString("location");
        availableStr = myBundle.getString("availableStr");

//		Log.d("log", "-------}"+availableStr);

        //set data into layout

        TextView dNameView = (TextView) findViewById(R.id.timeDName);
        dNameView.setText(dName);
        TextView specialityView = (TextView) findViewById(R.id.time_speciality);
        specialityView.setText(speciality);
        TextView locationView = (TextView) findViewById(R.id.time_city);
        locationView.setText(location);
        TextView availableTimeView1 = (TextView) findViewById(R.id.available_time_1);
        TextView timePeriodView1 = (TextView) findViewById(R.id.time_period_1);


        TextView availableTimeView2 = (TextView) findViewById(R.id.available_time_2);
        TextView timePeriodView2 = (TextView) findViewById(R.id.time_period_2);

        TextView availableTimeView3 = (TextView) findViewById(R.id.available_time_3);
        TextView timePeriodView3 = (TextView) findViewById(R.id.time_period_3);

        TextView availableTimeView4 = (TextView) findViewById(R.id.available_time_4);
        TextView timePeriodView4 = (TextView) findViewById(R.id.time_period_4);

        TextView availableTimeView5 = (TextView) findViewById(R.id.available_time_5);
        TextView timePeriodView5 = (TextView) findViewById(R.id.time_period_5);

        TextView availableTimeView6 = (TextView) findViewById(R.id.available_time_6);
        TextView timePeriodView6 = (TextView) findViewById(R.id.time_period_6);

        TextView availableTimeView7 = (TextView) findViewById(R.id.available_time_7);
        TextView timePeriodView7 = (TextView) findViewById(R.id.time_period_7);

        TextView availableTimeView8 = (TextView) findViewById(R.id.available_time_8);
        TextView timePeriodView8 = (TextView) findViewById(R.id.time_period_8);

        TextView availableTimeView9 = (TextView) findViewById(R.id.available_time_9);
        TextView timePeriodView9 = (TextView) findViewById(R.id.time_period_9);

        TextView availableTimeView10 = (TextView) findViewById(R.id.available_time_10);
        TextView timePeriodView10 = (TextView) findViewById(R.id.time_period_10);

        TextView availableTimeView11 = (TextView) findViewById(R.id.available_time_11);
        TextView timePeriodView11 = (TextView) findViewById(R.id.time_period_11);

        TextView availableTimeView12 = (TextView) findViewById(R.id.available_time_12);
        TextView timePeriodView12 = (TextView) findViewById(R.id.time_period_12);

        TextView availableTimeView13 = (TextView) findViewById(R.id.available_time_13);
        TextView timePeriodView13 = (TextView) findViewById(R.id.time_period_13);

        TextView availableTimeView14 = (TextView) findViewById(R.id.available_time_14);
        TextView timePeriodView14 = (TextView) findViewById(R.id.time_period_14);

        try {

            job = new JSONObject(availableStr);

            availableDate = job.getString("date");
            doctorTimeId = job.getString("doctorTimeId");

            RelativeLayout rl_1 = (RelativeLayout) findViewById(R.id.relativeTime_1);
            rl_1.setOnClickListener(new View.OnClickListener() {

                public void onClick(View arg0) {
                    // TODO Auto-generated method stub
                    try {
                        if (job.getBoolean("tp1") == true) {
                            forwardControl("1", timePeriod[1], "AM");
                        } else {
                            Toast.makeText(getApplicationContext(), "No available", Toast.LENGTH_LONG).show();
                        }
                    } catch (JSONException e) {
                        // TODO Auto-generated catch block
                        e.printStackTrace();
                    }


                }

            });

            availableTimeView1.setText(timePeriod[1]);
            if (job.getBoolean("tp1") == true) {
                getActiveDetails(rl_1);
            } else {
                getInativeDetails(rl_1);
            }

            RelativeLayout rl_2 = (RelativeLayout) findViewById(R.id.relativeTime_2);
            availableTimeView2.setText(timePeriod[2]);
            if (job.getBoolean("tp2") == true) {
                getActiveDetails(rl_2);
            } else {
                getInativeDetails(rl_2);
            }
            rl_2.setOnClickListener(new View.OnClickListener() {

                public void onClick(View arg0) {
                    // TODO Auto-generated method stub

                    try {
                        if (job.getBoolean("tp2") == true) {
                            forwardControl("2", timePeriod[2], "AM");
                        } else {
                            Toast.makeText(getApplicationContext(), "No available", Toast.LENGTH_LONG).show();
                        }
                    } catch (JSONException e) {
                        // TODO Auto-generated catch block
                        e.printStackTrace();
                    }

                }

            });

            RelativeLayout rl_3 = (RelativeLayout) findViewById(R.id.relativeTime_3);
            availableTimeView3.setText(timePeriod[3]);
            if (job.getBoolean("tp3") == true) {
                getActiveDetails(rl_3);
            } else {
                getInativeDetails(rl_3);
            }
            rl_3.setOnClickListener(new View.OnClickListener() {

                public void onClick(View arg0) {
                    // TODO Auto-generated method stub

                    try {
                        if (job.getBoolean("tp3") == true) {
                            forwardControl("3", timePeriod[3], "AM");
                        } else {
                            Toast.makeText(getApplicationContext(), "No available", Toast.LENGTH_LONG).show();
                        }
                    } catch (JSONException e) {
                        // TODO Auto-generated catch block
                        e.printStackTrace();
                    }

                }

            });

            RelativeLayout rl_4 = (RelativeLayout) findViewById(R.id.relativeTime_4);
            availableTimeView4.setText(timePeriod[4]);
            if (job.getBoolean("tp4") == true) {
                getActiveDetails(rl_4);
            } else {
                getInativeDetails(rl_4);
            }
            rl_4.setOnClickListener(new View.OnClickListener() {

                public void onClick(View arg0) {
                    // TODO Auto-generated method stub

                    try {
                        if (job.getBoolean("tp4") == true) {
                            forwardControl("4", timePeriod[4], "AM");
                        } else {
                            Toast.makeText(getApplicationContext(), "No available", Toast.LENGTH_LONG).show();
                        }
                    } catch (JSONException e) {
                        // TODO Auto-generated catch block
                        e.printStackTrace();
                    }

                }

            });

            RelativeLayout rl_5 = (RelativeLayout) findViewById(R.id.relativeTime_5);
            availableTimeView5.setText(timePeriod[5]);
            if (job.getBoolean("tp5") == true) {
                getActiveDetails(rl_5);
            } else {
                getInativeDetails(rl_5);
            }
            rl_5.setOnClickListener(new View.OnClickListener() {

                public void onClick(View arg0) {
                    // TODO Auto-generated method stub

                    try {
                        if (job.getBoolean("tp5") == true) {
                            forwardControl("5", timePeriod[5], "PM");
                        } else {
                            Toast.makeText(getApplicationContext(), "No available", Toast.LENGTH_LONG).show();
                        }
                    } catch (JSONException e) {
                        // TODO Auto-generated catch block
                        e.printStackTrace();
                    }

                }

            });

            RelativeLayout rl_6 = (RelativeLayout) findViewById(R.id.relativeTime_6);
            availableTimeView6.setText(timePeriod[6]);
            if (job.getBoolean("tp6") == true) {
                getActiveDetails(rl_6);
            } else {
                getInativeDetails(rl_6);
            }
            rl_6.setOnClickListener(new View.OnClickListener() {

                public void onClick(View arg0) {
                    // TODO Auto-generated method stub

                    try {
                        if (job.getBoolean("tp6") == true) {
                            forwardControl("6", timePeriod[6], "PM");
                        } else {
                            Toast.makeText(getApplicationContext(), "No available", Toast.LENGTH_LONG).show();
                        }
                    } catch (JSONException e) {
                        // TODO Auto-generated catch block
                        e.printStackTrace();
                    }

                }

            });

            RelativeLayout rl_7 = (RelativeLayout) findViewById(R.id.relativeTime_7);
            availableTimeView7.setText(timePeriod[7]);
            if (job.getBoolean("tp7") == true) {
                getActiveDetails(rl_7);
            } else {
                getInativeDetails(rl_7);
            }
            rl_7.setOnClickListener(new View.OnClickListener() {

                public void onClick(View arg0) {
                    // TODO Auto-generated method stub

                    try {
                        if (job.getBoolean("tp7") == true) {
                            forwardControl("7", timePeriod[7], "PM");
                        } else {
                            Toast.makeText(getApplicationContext(), "No available", Toast.LENGTH_LONG).show();
                        }
                    } catch (JSONException e) {
                        // TODO Auto-generated catch block
                        e.printStackTrace();
                    }

                }

            });

            RelativeLayout rl_8 = (RelativeLayout) findViewById(R.id.relativeTime_8);
            availableTimeView8.setText(timePeriod[8]);
            if (job.getBoolean("tp8") == true) {
                getActiveDetails(rl_8);
            } else {
                getInativeDetails(rl_8);
            }
            rl_8.setOnClickListener(new View.OnClickListener() {

                public void onClick(View arg0) {
                    // TODO Auto-generated method stub

                    try {
                        if (job.getBoolean("tp8") == true) {
                            forwardControl("8", timePeriod[8], "PM");
                        } else {
                            Toast.makeText(getApplicationContext(), "No available", Toast.LENGTH_LONG).show();
                        }
                    } catch (JSONException e) {
                        // TODO Auto-generated catch block
                        e.printStackTrace();
                    }

                }

            });
            RelativeLayout rl_9 = (RelativeLayout) findViewById(R.id.relativeTime_9);
            availableTimeView9.setText(timePeriod[9]);
            if (job.getBoolean("tp9") == true) {
                getActiveDetails(rl_9);
            } else {
                getInativeDetails(rl_9);
            }
            rl_9.setOnClickListener(new View.OnClickListener() {

                public void onClick(View arg0) {
                    // TODO Auto-generated method stub

                    try {
                        if (job.getBoolean("tp9") == true) {
                            forwardControl("9", timePeriod[9], "PM");
                        } else {
                            Toast.makeText(getApplicationContext(), "No available", Toast.LENGTH_LONG).show();
                        }
                    } catch (JSONException e) {
                        // TODO Auto-generated catch block
                        e.printStackTrace();
                    }

                }

            });

            RelativeLayout rl_10 = (RelativeLayout) findViewById(R.id.relativeTime_10);
            availableTimeView10.setText(timePeriod[10]);
            if (job.getBoolean("tp10") == true) {
                getActiveDetails(rl_10);
            } else {
                getInativeDetails(rl_10);
            }
            rl_10.setOnClickListener(new View.OnClickListener() {

                public void onClick(View arg0) {
                    // TODO Auto-generated method stub

                    try {
                        if (job.getBoolean("tp10") == true) {
                            forwardControl("10", timePeriod[10], "PM");
                        } else {
                            Toast.makeText(getApplicationContext(), "No available", Toast.LENGTH_LONG).show();
                        }
                    } catch (JSONException e) {
                        // TODO Auto-generated catch block
                        e.printStackTrace();
                    }

                }

            });

            RelativeLayout rl_11 = (RelativeLayout) findViewById(R.id.relativeTime_11);
            availableTimeView11.setText(timePeriod[11]);
            if (job.getBoolean("tp11") == true) {
                getActiveDetails(rl_11);
            } else {
                getInativeDetails(rl_11);
            }
            rl_11.setOnClickListener(new View.OnClickListener() {

                public void onClick(View arg0) {
                    // TODO Auto-generated method stub

                    try {
                        if (job.getBoolean("tp11") == true) {
                            forwardControl("11", timePeriod[11], "PM");
                        } else {
                            Toast.makeText(getApplicationContext(), "No available", Toast.LENGTH_LONG).show();
                        }
                    } catch (JSONException e) {
                        // TODO Auto-generated catch block
                        e.printStackTrace();
                    }

                }

            });
            RelativeLayout rl_12 = (RelativeLayout) findViewById(R.id.relativeTime_12);
            availableTimeView12.setText(timePeriod[12]);
            if (job.getBoolean("tp12") == true) {
                getActiveDetails(rl_12);
            } else {
                getInativeDetails(rl_12);
            }
            rl_12.setOnClickListener(new View.OnClickListener() {

                public void onClick(View arg0) {
                    // TODO Auto-generated method stub

                    try {
                        if (job.getBoolean("tp12") == true) {
                            forwardControl("12", timePeriod[12], "PM");
                        } else {
                            Toast.makeText(getApplicationContext(), "No available", Toast.LENGTH_LONG).show();
                        }
                    } catch (JSONException e) {
                        // TODO Auto-generated catch block
                        e.printStackTrace();
                    }

                }

            });

            RelativeLayout rl_13 = (RelativeLayout) findViewById(R.id.relativeTime_13);
            availableTimeView13.setText(timePeriod[13]);
            if (job.getBoolean("tp13") == true) {
                getActiveDetails(rl_13);
            } else {
                getInativeDetails(rl_13);
            }
            rl_13.setOnClickListener(new View.OnClickListener() {

                public void onClick(View arg0) {
                    // TODO Auto-generated method stub

                    try {
                        if (job.getBoolean("tp13") == true) {
                            forwardControl("13", timePeriod[13], "AM");
                        } else {
                            Toast.makeText(getApplicationContext(), "No available", Toast.LENGTH_LONG).show();
                        }
                    } catch (JSONException e) {
                        // TODO Auto-generated catch block
                        e.printStackTrace();
                    }

                }

            });

            RelativeLayout rl_14 = (RelativeLayout) findViewById(R.id.relativeTime_14);
            availableTimeView14.setText(timePeriod[14]);
            if (job.getBoolean("tp14") == true) {
                getActiveDetails(rl_14);
            } else {
                getInativeDetails(rl_14);
            }
            rl_14.setOnClickListener(new View.OnClickListener() {

                public void onClick(View arg0) {
                    // TODO Auto-generated method stub

                    try {
                        if (job.getBoolean("tp14") == true) {
                            forwardControl("14", timePeriod[14], "AM");
                        } else {
                            Toast.makeText(getApplicationContext(), "No available", Toast.LENGTH_LONG).show();
                        }
                    } catch (JSONException e) {
                        // TODO Auto-generated catch block
                        e.printStackTrace();
                    }

                }

            });

        } catch (JSONException j) {
            // TODO: handle exception
            System.out.println(j.getMessage());
        } catch (Exception e) {
            // TODO: handle exception
            e.printStackTrace();
        }

    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        MenuInflater inflater = getMenuInflater();
        inflater.inflate(R.menu.doctor_actionitems, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()) {
            // Respond to the action baru's Up/Home button
            case android.R.id.home:
                NavUtils.navigateUpFromSameTask(this);
                return true;

            case R.id.txt_doctorHomeTitle:
                Intent docSpecialities = new Intent(this, AMS.class);
                startActivity(docSpecialities);
                break;


        }
        return super.onOptionsItemSelected(item);
    }

    public void getActiveDetails(RelativeLayout layout) {
        layout.setBackgroundDrawable(getResources().getDrawable(R.drawable.customborder));
//		if(sdk < android.os.Build.VERSION_CODES.JELLY_BEAN) {
//		    layout.setBackgroundDrawable( getResources().getDrawable(R.drawable.customborder) );
//		} else {
//		    layout.setBackgroundDrawable( getResources().getDrawable(R.drawable.customborder));
//		}
    }

    public void getInativeDetails(RelativeLayout layout) {
        layout.setBackgroundDrawable(getResources().getDrawable(R.drawable.customborder_inactive));
//		if(sdk < android.os.Build.VERSION_CODES.JELLY_BEAN) {
//			
//		    layout.setBackgroundDrawable( getResources().getDrawable(R.drawable.customborder_inactive) );
//		} else {
//		    layout.setBackgroundDrawable( getResources().getDrawable(R.drawable.customborder_inactive));
//		}
    }

//	public void myfun(View v){
//		
//		Toast.makeText(this, "Venkat", Toast.LENGTH_LONG).show();
//	}

    public void forwardControl(String timePeriod, String time, String format) {

        try {
            context = this.getApplicationContext();
            userSharedPreferences = this.getSharedPreferences(context.getString(R.string.cPreferences), Context.MODE_PRIVATE);
            Log.d(TAG, "--userSharedPreferenc--" + userSharedPreferences);
            if (userSharedPreferences.getString(context.getString(R.string.customerId), null) != null) {
                customerId = userSharedPreferences.getString(context.getString(R.string.customerId), null);
                loginStatus = true;
            }
            if(loginStatus){
               Intent intent = new Intent(AvailableTimingsActivity.this, AppointmentConfirmActivity.class);
                Bundle myData = new Bundle();
                myData.putString("doctorId", doctorId);
                myData.putString("dName", dName);
                myData.putString("speciality", speciality);
                myData.putString("location", location);
                myData.putString("imgPath", imgPath);
                myData.putString("timePeriod", timePeriod);
                myData.putString("time", time);
                myData.putString("format", format);
                myData.putString("availableDate", availableDate);
                myData.putString("doctorTimeId", doctorTimeId);
                Log.d(TAG,"img path in availa"+imgPath);
                Log.d(TAG,"my data in avail"+myData);


                intent.putExtras(myData);
//			startActivityForResult(intent, IPC_ID);
                startActivity(intent);

            }else {
                Intent intent = new Intent(AvailableTimingsActivity.this, LoginAndConformAppointment.class);
                Bundle myData = new Bundle();
                myData.putString("doctorId", doctorId);
                myData.putString("dName", dName);
                myData.putString("speciality", speciality);
                myData.putString("location", location);
                myData.putString("imgPath", imgPath);
                myData.putString("timePeriod", timePeriod);
                myData.putString("time", time);
                myData.putString("format", format);
                myData.putString("availableDate", availableDate);
                myData.putString("doctorTimeId", doctorTimeId);


                intent.putExtras(myData);
//			startActivityForResult(intent, IPC_ID);
                startActivity(intent);


            }



        } catch (Exception e) {
            // TODO: handle exception
            e.printStackTrace();
        }
    }


}
