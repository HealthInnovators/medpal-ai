package com.healhouts.patient.FragmentsPackage;

import android.app.ProgressDialog;
import android.content.Intent;
import android.os.AsyncTask;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.support.v4.view.MenuItemCompat;
import android.text.Editable;
import android.text.TextWatcher;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.SearchView;

import com.healhouts.patient.Activities.DoctorPofileActivity;
import com.healhouts.patient.Adapters.CustomListAdapter;
import com.healhouts.patient.Beanclasses.DoctorItems;
import com.healhouts.patient.R;
import com.healhouts.patient.common.ImageDownloaderTask;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.net.URISyntaxException;
import java.util.ArrayList;


/**
 * Created by sony on 23/02/2015.
 */
public class DoctorsTab extends Fragment implements
        android.widget.SearchView.OnQueryTextListener {

    public static String TAG = "Fragment2";
    //    private static String url = "http://healthouts.com/doctors";
   // private static String url = "http://healthouts.com/appdocListByName?str=";
    private static String url = "http://joslinlive.org/appdocListByName?str=";
    ProgressDialog pDialog;
    ListView lv1;
    SearchView search_view;
    EditText autoSerachView;
    CustomListAdapter adapter;


    @Override
    public View onCreateView(LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.layout_doctors_tab, container, false);
        lv1 = (ListView) view.findViewById(R.id.custom_list);
        autoSerachView = (EditText) view.findViewById(R.id.editText_autoSearch);
        autoSerachView.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {

            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {

            }

            @Override
            public void afterTextChanged(Editable s) {
                if (autoSerachView.getText().length() >=1){

                    new GetDoctors().execute();

                }

            }
        });



        /*search_view.setQueryHint("find Your Doctors...");*/
/*
        search_view.setQueryHint(Html.fromHtml("<font color = #ffffff>" + getResources().getString(R.string.action_search) + "</font>"));
*/

/*
        search_view.setBackgroundDrawable(getResources().getDrawable(R.drawable.action_search));
*/
//        search_view.setBackgroundColor(Color.parseColor("#0f9d58"));

        new GetDoctors().execute();

/*
        search_view.setOnQueryTextListener(this);
*/


//        new GetDoctors().execute();


        lv1.setOnItemClickListener(new AdapterView.OnItemClickListener() {

            @Override
            public void onItemClick(AdapterView<?> a, View v, int position,
                                    long id) {
                ImageView imageView = (ImageView) getView().findViewById(R.id.thumbImage);
//                new ImageDownloaderTask(imageView).cancel(true);
                new ImageDownloaderTask(imageView);
                Object o = lv1.getItemAtPosition(position);
                DoctorItems newData = (DoctorItems) o;
                try {
                    Intent intent = new Intent(getActivity(), DoctorPofileActivity.class);
                    Bundle myData = new Bundle();
                    myData.putString("doctorId", newData.getDoctorId());
                    myData.putString("dName", newData.getdName());
                    intent.putExtras(myData);
//					startActivityForResult(intent, IPC_ID);
                    startActivity(intent);

                } catch (Exception e) {
                    // TODO: handle exception
                    e.printStackTrace();
                }


//				Toast.makeText(
//						MainActivity.this,
//						"Selected :" + " " + newData.getdName() + "\n Id :"
//								+ newData.getDoctorId(), Toast.LENGTH_LONG)
//						.show();
            }

        });
        return view;
    }


    private class GetDoctors extends AsyncTask<Void, Void, ArrayList> {

        @Override
        protected void onPreExecute() {
            super.onPreExecute();
            // Showing progress dialog
//            pDialog = new ProgressDialog(getActivity());
//            pDialog.setMessage("Please hold on...Listing Doctors Profile");
//            pDialog.setCancelable(true);
//            pDialog.show();

        }


        public boolean onCreateOptionsMenu(Menu menu) {

            // Only show items in the action bar relevant to this screen
            // if the drawer is not showing. Otherwise, let the drawer
            // decide what to show in the action bar.
            MenuInflater inflater = new MenuInflater(getActivity());
            inflater.inflate(R.menu.main, menu);

            MenuItem searchItem = menu.findItem(R.id.action_search);
            if (searchItem != null) {
                android.support.v7.widget.SearchView searchView = (android.support.v7.widget.SearchView) MenuItemCompat.getActionView(searchItem);
                searchView.setOnQueryTextListener((android.support.v7.widget.SearchView.OnQueryTextListener) getActivity());


            }


            return true;
        }


        @Override
        protected ArrayList doInBackground(Void... arg0) {
            ArrayList<DoctorItems> list = new ArrayList<DoctorItems>();
            // Creating service handler class instance
            ServiceHandler sh = new ServiceHandler();

            // Making a request to url and getting response
            String jsonStr = "";

            try {
                jsonStr = sh.makeServiceCall(url + autoSerachView.getText(), ServiceHandler.GET);
            } catch (URISyntaxException e1) {
                // TODO Auto-generated catch block
                e1.printStackTrace();
            }

            Log.d("Response: ", "> " + jsonStr);

            if (jsonStr != null) {

                try {

                    JSONArray jarr = new JSONArray(jsonStr);

                    // Creating ArrayList from JSONArray object
                    for (int i = 0; i < jarr.length(); i++) {
//
                        JSONObject job = (JSONObject) jarr.get(i);


                        DoctorItems doctorItems = new DoctorItems();
                        doctorItems.setDoctorId(job.getString("doctorId"));
                        doctorItems.setdName(job.getString("dName"));
                        doctorItems.setSpeciality(job.getString("speciality"));
                        doctorItems.setLocation(job.getString("location"));
                        doctorItems.setImgPath(job.getString("imgPath"));


                        list.add(doctorItems);


                    }
                } catch (JSONException e) {
                    Log.e(TAG, "--Couldn't get any data from the url(Error String)");
                    e.printStackTrace();
                }

            } else {
                Log.e("ServiceHandler", "Couldn't get any data from the url");
            }

            return list;
        }

        @Override
        protected void onPostExecute(ArrayList result) {
            super.onPostExecute(result);
            adapter = new CustomListAdapter(getActivity(), result);
            lv1.setAdapter(adapter);


            // Dismiss the progress dialog
//            if (pDialog.isShowing())
//                pDialog.dismiss();
            /**
             * Updating parsed JSON data into ListView
             * */

        }
    }

    public boolean onQueryTextChange(String newText) {
        adapter.getFilter().filter(newText);
        //  Toast.makeText(getActivity(), "submit: " + newText, Toast.LENGTH_SHORT).show();
        return false;

    }


    public boolean onQueryTextSubmit(String arg0) {
        //Toast.makeText(getActivity(), "submit: " + arg0, Toast.LENGTH_SHORT).show();
        // TODO Auto-generated method stub
        return false;
    }


}