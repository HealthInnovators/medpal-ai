package com.healhouts.patient.Beanclasses;

/**
 * Created by samsung on 27-05-2015.
 */
public class FeedItemPaidQA {

    private String csubject;
    private String cdetails;
    private String chatType;
    private String dname;

    public int getChatid() {
        return chatid;
    }

    public void setChatid(int chatid) {
        this.chatid = chatid;
    }

    private int chatid;
    private String dImgPath;
    private String cutomerName;
    private String customerImg;
    private String healthFile;
    private boolean reviewStatus;
    private Integer did;
    private Integer cid;
    private  String doctorSubject;
    private  String doctorAnswer;

    private  boolean answerStatus =false;

    public String getCsubject() {
        return csubject;
    }
    public void setCsubject(String csubject) {
        this.csubject = csubject;
    }
    public String getCdetails() {
        return cdetails;
    }
    public void setCdetails(String cdetails) {
        this.cdetails = cdetails;
    }
    public String getChatType() {
        return chatType;
    }
    public void setChatType(String chatType) {
        this.chatType = chatType;
    }
    public String getDname() {
        return dname;
    }
    public void setDname(String dname) {
        this.dname = dname;
    }
    public String getdImgPath() {
        return dImgPath;
    }
    public void setdImgPath(String dImgPath) {
        this.dImgPath = dImgPath;
    }
    public String getCutomerName() {
        return cutomerName;
    }
    public void setCutomerName(String cutomerName) {
        this.cutomerName = cutomerName;
    }
    public String getCustomerImg() {
        return customerImg;
    }
    public void setCustomerImg(String customerImg) {
        this.customerImg = customerImg;
    }
    public boolean isReviewStatus() {
        return reviewStatus;
    }
    public void setReviewStatus(boolean reviewStatus) {
        this.reviewStatus = reviewStatus;
    }
    public Integer getDid() {
        return did;
    }
    public void setDid(Integer did) {
        this.did = did;
    }
    public Integer getCid() {
        return cid;
    }
    public void setCid(Integer cid) {
        this.cid = cid;
    }
    public boolean isAnswerStatus() {
        return answerStatus;
    }
    public void setAnswerStatus(boolean answerStatus) {
        this.answerStatus = answerStatus;
    }
    public String getDoctorSubject() {
        return doctorSubject;
    }
    public void setDoctorSubject(String doctorSubject) {
        this.doctorSubject = doctorSubject;
    }
    public String getDoctorAnswer() {
        return doctorAnswer;
    }
    public void setDoctorAnswer(String doctorAnswer) {
        this.doctorAnswer = doctorAnswer;
    }

    public String getHealthFile() {
        return healthFile;
    }

    public void setHealthFile(String healthFile) {
        this.healthFile = healthFile;
    }
}
