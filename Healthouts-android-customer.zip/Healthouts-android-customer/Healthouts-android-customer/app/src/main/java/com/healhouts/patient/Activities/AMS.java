package com.healhouts.patient.Activities;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentManager;
import android.support.v4.view.MenuItemCompat;
import android.support.v4.widget.DrawerLayout;
import android.support.v7.app.ActionBar;
import android.support.v7.app.ActionBarActivity;
import android.support.v7.widget.SearchView;
import android.support.v7.widget.Toolbar;
import android.text.Html;
import android.util.Log;
import android.view.Gravity;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;

import com.healhouts.patient.FragmentsPackage.AboutUs;
import com.healhouts.patient.FragmentsPackage.AppointmentHistory;
import com.healhouts.patient.FragmentsPackage.PaidQuestions;
import com.healhouts.patient.R;
import com.healhouts.patient.TheNavigationDrawer.NavigationDrawerFragment;


public class AMS extends ActionBarActivity implements NavigationDrawerFragment.NavigationDrawerCallbacks,
        SearchView.OnQueryTextListener {
    private static final String TAG = "AMS";
    SharedPreferences userSharedPreferences;
    private boolean loginStatus = false;
    Context context;


    /**
     * Fragment managing the behaviors, interactions and presentation of the navigation drawer.
     */
    private NavigationDrawerFragment mNavigationDrawerFragment;
    private DrawerLayout mDrawerLayout;

    /**
     * Used to store the last screen title. For use in {@link #restoreActionBar()}.
     */
    private CharSequence mTitle;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_ams);

        context = getApplicationContext();
        userSharedPreferences = context.getSharedPreferences(context.getString(R.string.cPreferences), Context.MODE_PRIVATE);

        if (userSharedPreferences.getString(context.getString(R.string.customerId), null) != null)
            loginStatus = true;
        mTitle = getTitle();
        Toolbar mToolbar = (Toolbar) findViewById(R.id.tool_bar);
//        mToolbar.setTitle(Html.fromHtml("<font color='#ffffff' font-size: 1.5em > Healthouts</font>"));
        mToolbar.setTitle(Html.fromHtml("<font color='#ffffff' font-size: 1.5em > Joslin</font>"));


        setSupportActionBar(mToolbar);
        mDrawerLayout = (DrawerLayout) findViewById(R.id.drawer_layout);
        mNavigationDrawerFragment = (NavigationDrawerFragment) getSupportFragmentManager().findFragmentById(R.id.navigation_drawer);
        mNavigationDrawerFragment.setUp(R.id.navigation_drawer, mDrawerLayout, mToolbar);

    }

    @Override
    public void onNavigationDrawerItemSelected(int position) {
        onSectionAttached(position);
        Fragment fragment = null;
        Intent intent = null;

        if (loginStatus) {
            Log.d(TAG, "login stat" + loginStatus);
            switch (position) {

                case 0:
                    fragment = new ViewPagerActivity();
                    FragmentManager fragmentManager = getSupportFragmentManager();
                    fragmentManager.beginTransaction()
                            .replace(R.id.container, fragment)
                            .commit(); 
                    break;
                case 1:
                    fragment = new AppointmentHistory();
                    fragmentManager = getSupportFragmentManager();
                    fragmentManager.beginTransaction()
                            .replace(R.id.container, fragment)
                            .commit();
                    //appointments
                    break;
                case 2:
                    fragment = new ViewPagerPublicFeedActivity();
                    fragmentManager = getSupportFragmentManager();
                    fragmentManager.beginTransaction()
                            .replace(R.id.container, fragment)
                            .commit();
                    //free Questions/Public Feed
                    break;
                case 3:
                    fragment = new PaidQuestions();
                    fragmentManager = getSupportFragmentManager();
                    fragmentManager.beginTransaction()
                            .replace(R.id.container, fragment)
                            .commit();
                    //paid Questions
                    break;
                case 4:
                    intent = new Intent(context, ProfileSettings.class);
                    startActivity(intent);
                    //paid Questions
                    break;

                case 5:
                    fragment = new AboutUs();
                    fragmentManager = getSupportFragmentManager();
                    fragmentManager.beginTransaction()
                            .replace(R.id.container, fragment)
                            .commit();
                    //about us
                    break;

                default:
                    break;
            }
        } else {

            switch (position) {

                case 0:
                    fragment = new ViewPagerActivity();
                    FragmentManager fragmentManager = getSupportFragmentManager();
                    fragmentManager = getSupportFragmentManager();
                    fragmentManager.beginTransaction()
                            .replace(R.id.container, fragment)
                            .commit();
                    //search/ask
                    break;
                case 1:
                    fragment = new AppointmentHistory();
                    fragmentManager = getSupportFragmentManager();
                    fragmentManager.beginTransaction()
                            .replace(R.id.container, fragment)
                            .commit();
                    //appointments
                    break;
                case 2:
                    fragment = new ViewPagerPublicFeedActivity();
                    fragmentManager = getSupportFragmentManager();
                    fragmentManager.beginTransaction()
                            .replace(R.id.container, fragment)
                            .commit();
                    //free Questions/Public Feed
                    break;
//                case 3:
//                    fragment= new PaidQuestions();
//                    //paid Questions
//                    break;

                case 3:
                    fragment = new AboutUs();
                    fragmentManager = getSupportFragmentManager();
                    fragmentManager.beginTransaction()
                            .replace(R.id.container, fragment)
                            .commit();
                    //about us
                    break;


                default:
                    break;
            }

        }
        // update the main content by replacing fragments
/*
        FragmentManager fragmentManager = getSupportFragmentManager();
        fragmentManager.beginTransaction()
                .replace(R.id.container,fragment)
                .commit();
*/

        // update the main content by replacing fragments
        /*FragmentManager fragmentManager = getSupportFragmentManager();
        fragmentManager.beginTransaction()
                .replace(R.id.container, fragment)
                .commit();*/
    }

    public void onSectionAttached(int number) {
        if (loginStatus) {
            switch (number) {
                case 0:

                    mTitle = getString(R.string.title_section1);
                    //search/ask
                    break;
                case 1:
                    mTitle = getString(R.string.title_section2);
                    //appointments
                    break;
                case 2:
                    mTitle = getString(R.string.title_section3);
                    //Free Questions
                    break;
                case 3:
                    mTitle = getString(R.string.title_section4);
                    //Paid Questions
                    break;
                case 4:
                    mTitle = getString(R.string.title_section5);
                    //About Us
                    break;

                case 5:
                    mTitle = getString(R.string.title_section6);
                    //About Us
                    break;


            }
        } else {
            switch (number) {
                case 0:

                    mTitle = getString(R.string.title_section1);
                    //find doctors
                    break;
                case 1:
                    mTitle = getString(R.string.title_section2);
                    //appointments
                    break;
                case 2:
                    mTitle = getString(R.string.title_section3);
                    //Public Feed
                    break;
                case 3:
                    mTitle = getString(R.string.title_section6);
                    //Paid Questions
                    break;
//                case 4:
//                    mTitle = getString(R.string.title_section5);
//                    //About Us
//                    break;


            }
        }
    }

    public void restoreActionBar() {
        final ActionBar actionBar = getSupportActionBar();
        actionBar.setDisplayShowTitleEnabled(true);
        actionBar.setTitle(mTitle);
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        if (!mNavigationDrawerFragment.isDrawerOpen()) {
            // Only show items in the action bar relevant to this screen
            // if the drawer is not showing. Otherwise, let the drawer
            // decide what to show in the action bar.
            MenuInflater inflater = new MenuInflater(this);
            inflater.inflate(R.menu.main, menu);

            MenuItem searchItem = menu.findItem(R.id.action_search);
            if (searchItem != null) {
                SearchView searchView = (SearchView) MenuItemCompat.getActionView(searchItem);
                searchView.setOnQueryTextListener(this);
            }
            restoreActionBar();
            return true;
        }


        return super.onCreateOptionsMenu(menu);
    }

    @Override
    public void onBackPressed() {
        if (mDrawerLayout.isDrawerOpen(Gravity.START)) {
            mDrawerLayout.closeDrawers();
            return;
        }
        super.onBackPressed();
    }

    @Override
    public boolean onQueryTextSubmit(String s) {
        //  Toast.makeText(this, "submit: " + s, Toast.LENGTH_SHORT).show();
        return false;
    }

    @Override
    public boolean onQueryTextChange(String s) {
//        Toast.makeText(this, "text: " + s, Toast.LENGTH_SHORT).show();
        return false;
    }

}
