package com.healhouts.patient.FragmentsPackage;

import android.annotation.TargetApi;
import android.app.AlertDialog;
import android.app.Fragment;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.os.AsyncTask;
import android.os.Build;
import android.os.Bundle;
import android.provider.Settings;
import android.support.v4.app.FragmentActivity;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.util.Log;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.widget.Toast;

import com.healhouts.patient.Adapters.ImmunizationRecyclerAdapter;
import com.healhouts.patient.Beanclasses.FeedItemImmunization;
import com.healhouts.patient.R;
import com.healhouts.patient.common.CommonUtil;
import com.healhouts.patient.common.ConnectionDetector;
import com.healhouts.patient.common.ServiceCalls;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.net.URISyntaxException;
import java.util.ArrayList;
import java.util.List;

public class Immunization extends Fragment {

    private Context context;
    AlertDialog.Builder builder;
    Boolean isInternetPresent = false;
    ConnectionDetector cd;
    SharedPreferences userSharedPreferences;
    JSONArray jsonArray;
    private boolean loginStatus = false;
    private String customerId;
    private  String customerEmail;
    private static final String TAG ="Immunization" ;
    private List<FeedItemImmunization> FeedItemImmunzList = new ArrayList<FeedItemImmunization>();
    LinearLayoutManager mLayoutManager;

    ImageView imUP,imDown;
    ListView list_item;
    LinearLayout linearLayout;
    RelativeLayout relativeLayout;
    ImmunizationRecyclerAdapter adapter;
    Button saveImmunizChanges;
    EditText immunizName,immunizNotes,immunizDate;
    String immunizNameET,immunizNotesET,immunizDateET;
    private RecyclerView mRecyclerView;
    Toast toast;
	
	@Override
	public void onCreate(Bundle savedInstanceState) {

        getActivity().getWindow().setSoftInputMode(
                WindowManager.LayoutParams.SOFT_INPUT_ADJUST_PAN);
		// TODO Auto-generated method stub
		super.onCreate(savedInstanceState);
	}

	@Override
	public View onCreateView(LayoutInflater inflater, ViewGroup container,
			Bundle savedInstanceState) {
        context = getActivity().getApplicationContext();
        cd = new ConnectionDetector(context);
        isInternetPresent = cd.isConnectingToInternet();

        userSharedPreferences = this.getActivity().getSharedPreferences(context.getString(R.string.cPreferences), Context.MODE_PRIVATE);
        customerId = userSharedPreferences.getString(context.getString(R.string.customerId), null);
        customerEmail = userSharedPreferences.getString(getActivity().getResources().getString(R.string.customerEmail), null);
		View view = inflater.inflate(R.layout.immunization_layout, null);


        immunizName=(EditText)view.findViewById(R.id.immunizName);
        immunizNotes=(EditText)view.findViewById(R.id.immunizNotes);
        immunizDate=(EditText)view.findViewById(R.id.immunizDate);

        saveImmunizChanges=(Button)view.findViewById(R.id.saveImmunizChanges);
        relativeLayout=(RelativeLayout)view.findViewById(R.id.immunzRL);
        linearLayout=(LinearLayout)view.findViewById(R.id.immunzLL);

        mRecyclerView = (RecyclerView) view.findViewById(R.id.recycler_view_immuniz);
        mRecyclerView.setHasFixedSize(true);
        mLayoutManager = new LinearLayoutManager(getActivity());
        mRecyclerView.setLayoutManager(mLayoutManager);
        RecyclerView.ItemDecoration itemDecoration =
                new DividerItemDecoration(getActivity(), LinearLayoutManager.VERTICAL);
        mRecyclerView.addItemDecoration(itemDecoration);

        imUP=(ImageView)view.findViewById(R.id.imUP);
        imUP.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                if (imUP.isSelected()) {
                    imUP.setImageResource(R.drawable.down);
                    linearLayout.setVisibility(View.VISIBLE);
                    imUP.setSelected(false);
                } else {
                    imUP.setImageResource(R.drawable.up);
                    linearLayout.setVisibility(View.GONE);
                    imUP.setSelected(true);
                }
            }
        });
        getImmunization();
        saveImmunizChanges.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                new CreateImmunization().execute();
            }
        });
		return view;
	}

	
	@Override
	public void onActivityCreated(Bundle savedInstanceState) {
		// TODO Auto-generated method stub
		super.onActivityCreated(savedInstanceState);
	}
    public void getImmunization() {

        new AsyncTask<Void, Void, List<FeedItemImmunization>>() {

            @Override
            protected List<FeedItemImmunization> doInBackground(Void... params) {
//                ArrayList<HashMap> list = new ArrayList<HashMap>();
                String jsonStr = "";
                ServiceHandler sh = new ServiceHandler();

                String str = "";
                str = str + ServiceCalls.GET_IMMUNIZATION_DETAILS_URL;

                try {
                    String queryStr = new CommonUtil().ConvertToUrlString(str + "CId=" + customerId + "&CEmail=" + customerEmail);
                    Log.d(TAG, "querystr" + queryStr);
                    if (isInternetPresent) {

                        jsonStr = sh.makeServiceCall(queryStr, ServiceHandler.GET);
                    } else {
                        getActivity().runOnUiThread(new Runnable() {
                            public void run() {
                                final AlertDialog.Builder builder = new AlertDialog.Builder(getActivity());
                                builder.setTitle("Connection failure");
                                builder.setMessage("Please check your network connection and try again");
                                builder.setIcon(R.drawable.warn)
                                        .setPositiveButton("cancel", new DialogInterface.OnClickListener() {
                                            public void onClick(DialogInterface dialog, int id) {
                                                builder.setCancelable(true);
                                            }
                                        })
                                        .setNegativeButton("Wi-Fi Settings", new DialogInterface.OnClickListener() {
                                            public void onClick(DialogInterface dialog, int id) {
                                                startActivityForResult(new Intent(Settings.ACTION_WIFI_SETTINGS), 0);

                                            }
                                        });
                                builder.show();
                            }
                        });
                    }
                } catch (URISyntaxException e1) {
                    // TODO Auto-generated catch block
                    e1.printStackTrace();
                }
                try {
                    jsonArray = new JSONArray(jsonStr);
                    Log.d(TAG, "jsonarray" + jsonArray);
                    FeedItemImmunzList.clear();
                    for (int i = 0; i < jsonArray.length(); i++) {
                        JSONObject jsonobject = jsonArray.getJSONObject(i);
                        FeedItemImmunization item = new FeedItemImmunization();


                        item.setImmunizationName(jsonobject.optString("immunization"));
                        item.setCustomerId(jsonobject.optString("customerId"));
                        item.setImmunizationId(jsonobject.optString("immunizationId"));
                        item.setNotes(jsonobject.optString("notes"));
                        item.setImmunizationDate(jsonobject.optString("immunizationDate"));
                        //Log.d(TAG,""+i+""+jsonobject.optString("medication")+""+jsonobject.optString("notes"));


                        FeedItemImmunzList.add(item);
                    }

                } catch (JSONException e) {
                    e.printStackTrace();
                }
                return FeedItemImmunzList;
            }

            private void showAlertDialog(FragmentActivity activity, String s, String s1, boolean b) {
                AlertDialog alertDialog = new AlertDialog.Builder(context).create();
                alertDialog.setTitle("");
                alertDialog.setMessage("");

                alertDialog.setButton("OK", new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface dialog, int which) {
                    }
                });

                alertDialog.show();
            }

            @Override
            protected void onPostExecute(List<FeedItemImmunization> list) {
                Log.d("---", "---list size----" + list.size());
                if (list.size() == 0) {

                    AlertDialog alertDialog = new AlertDialog.Builder(getActivity()).create();
                    alertDialog.setIcon(R.drawable.ic_report);
                    alertDialog.setTitle("Info");
                    alertDialog.setMessage("You don't have any Immunizations at Joslin Doctors");
                    alertDialog.setButton("OK", new DialogInterface.OnClickListener() {
                        public void onClick(DialogInterface dialog, int which) {
                        }
                    });

                    alertDialog.show();
                } else {
                    super.onPostExecute(list);
                    adapter = new ImmunizationRecyclerAdapter(getActivity(), FeedItemImmunzList);
                    adapter.notifyDataSetChanged();
                    mRecyclerView.setAdapter(adapter);
                }

            }
        }.execute(null, null, null);


    }
    private class CreateImmunization extends AsyncTask<String,String ,String> {
        @TargetApi(Build.VERSION_CODES.LOLLIPOP)
        @Override
        protected String doInBackground(String... params) {
            String jsonStr1 = "";
            ServiceHandler sh = new ServiceHandler();


            immunizNameET = immunizName.getText().toString();
            immunizNotesET = immunizNotes.getText().toString();

            immunizDateET = immunizDate.getText().toString();


            String str = "";
            str = str + ServiceCalls.ADD_IMMUNIZATION_URL;

            String queryStr1 = new CommonUtil().ConvertToUrlString(str + "CId=" + customerId + "&CEmail=" + customerEmail + "&immunization=" + immunizNameET + "&notes=" + immunizNotesET + "&immunizationDate=" + immunizDateET);
            Log.d(TAG, "Query string  is" + queryStr1);

            if (isInternetPresent) {

                try {
                    jsonStr1 = sh.makeServiceCall(queryStr1, ServiceHandler.POST);
//                    getToast();

                    getActivity().runOnUiThread(new Runnable() {
                        public void run() {
                            toast = Toast.makeText(context, "Details saved successfully", Toast.LENGTH_LONG);
                            toast.setGravity(Gravity.CENTER_VERTICAL,0,0);
                            TextView tv=new TextView(context);
                            tv.setTextColor(Color.RED);
                            tv.setTextSize(15);
                            toast.getView().setBackgroundColor(Color.parseColor("#34bf49"));
                            toast.show();

                            immunizName.setText("");
                            immunizNotes.setText("");
                            immunizDate.setText("");
                        }
                    });

                    getImmunization();

                    Log.d(TAG, "after post" + jsonStr1);
                } catch (URISyntaxException e) {
                    e.printStackTrace();
                }

            } else {
                getActivity().runOnUiThread(new Runnable() {
                    public void run() {

                        final AlertDialog.Builder builder = new AlertDialog.Builder(getActivity());
                        builder.setTitle("Connection failure");
                        builder.setMessage("Please check your network connection and try again");
                        builder.setIcon(R.drawable.warn)
                                .setPositiveButton("cancel", new DialogInterface.OnClickListener() {
                                    public void onClick(DialogInterface dialog, int id) {
                                        builder.setCancelable(true);
                                    }
                                })
                                .setNegativeButton("Wi-Fi Settings", new DialogInterface.OnClickListener() {
                                    public void onClick(DialogInterface dialog, int id) {
                                        startActivityForResult(new Intent(Settings.ACTION_WIFI_SETTINGS), 0);


                                    }
                                });
                        builder.show();

                    }
                });

            }


            return null;
        }


    }



    }
