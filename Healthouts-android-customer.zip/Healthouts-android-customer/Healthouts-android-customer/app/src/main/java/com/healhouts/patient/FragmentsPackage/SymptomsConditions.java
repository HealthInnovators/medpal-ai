package com.healhouts.patient.FragmentsPackage;

import android.app.AlertDialog;
import android.app.Fragment;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.os.AsyncTask;
import android.os.Bundle;
import android.os.StrictMode;
import android.provider.Settings;
import android.support.v4.app.FragmentActivity;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.util.Log;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.widget.Toast;

import com.healhouts.patient.Beanclasses.FeedItemSymptoms;
import com.healhouts.patient.R;
import com.healhouts.patient.common.CommonUtil;
import com.healhouts.patient.common.ConnectionDetector;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.net.URISyntaxException;
import java.util.ArrayList;
import java.util.List;

public class SymptomsConditions extends Fragment {
	private Context context;
	AlertDialog.Builder builder;
	Boolean isInternetPresent = false;
	ConnectionDetector cd;
	SharedPreferences userSharedPreferences;
	JSONArray jsonArray;
	private boolean loginStatus = false;
	private View v;
	private List<FeedItemSymptoms> FeedItemSymptomsList = new ArrayList<FeedItemSymptoms>();
	LinearLayoutManager mLayoutManager;
	private boolean loading = true;
	int firstVisibleItem, visibleItemCount, totalItemCount;
	int count = 0;
	int token = 0;
	private String customerId;
	private  String customerEmail;
	private static final String TAG ="SymptomsConditions" ;
	ImageView up,down;
	ListView list_item;
	LinearLayout linearLayout;
	RelativeLayout relativeLayout;
	MyRecyclerAdapterSymptoms adapter;
	Button savechanges;
	EditText symptom,notes;
	CheckBox symptomState;
	String symptomET,notesET;
	String symptom_State;
	private RecyclerView mRecyclerView;
	//	http://healthouts.com/appGetMedications?CId=193&CEmail=trinadhlikesu@gmail.com
	/*
	String url="http://healthouts.com/appGetSymptoms?";
	String url2="http://healthouts.com/appSaveSymptom?";
	*/
	String url="http://joslinlive.org/appGetSymptoms?";
	String url2="http://joslinlive.org/appSaveSymptom?";



	@Override
	public void onCreate(Bundle savedInstanceState) {
		getActivity().getWindow().setSoftInputMode(
				WindowManager.LayoutParams.SOFT_INPUT_ADJUST_PAN);
		// TODO Auto-generated method stub
		super.onCreate(savedInstanceState);
	}

	@Override
	public View onCreateView(LayoutInflater inflater, ViewGroup container,
							 Bundle savedInstanceState) {
		StrictMode.ThreadPolicy policy = new StrictMode.ThreadPolicy.Builder().permitAll().build();
		StrictMode.setThreadPolicy(policy);
		context = getActivity().getApplicationContext();
		cd = new ConnectionDetector(context);
		isInternetPresent = cd.isConnectingToInternet();
		userSharedPreferences = this.getActivity().getSharedPreferences(context.getString(R.string.cPreferences), Context.MODE_PRIVATE);
		userSharedPreferences = this.getActivity().getSharedPreferences(context.getString(R.string.cPreferences), Context.MODE_PRIVATE);
		customerId = userSharedPreferences.getString(context.getString(R.string.customerId), null);
		customerEmail = userSharedPreferences.getString(getActivity().getResources().getString(R.string.customerEmail), null);

		View view = inflater.inflate(R.layout.symptoms, container,false);
		symptom=(EditText)view.findViewById(R.id.allergy);
		notes=(EditText)view.findViewById(R.id.notes);
		symptomState=(CheckBox)view.findViewById(R.id.symptomState);

		savechanges=(Button)view.findViewById(R.id.savechanges);
		relativeLayout=(RelativeLayout)view.findViewById(R.id.relativeLayout);
		linearLayout=(LinearLayout)view.findViewById(R.id.linearLayout1);
		mRecyclerView = (RecyclerView) view.findViewById(R.id.recycler_view);
		mRecyclerView.setHasFixedSize(true);
		mLayoutManager = new LinearLayoutManager(getActivity());
		mRecyclerView.setLayoutManager(mLayoutManager);
		RecyclerView.ItemDecoration itemDecoration =
				new DividerItemDecoration(getActivity(), LinearLayoutManager.VERTICAL);
		mRecyclerView.addItemDecoration(itemDecoration);

		mRecyclerView.setLayoutManager(new LinearLayoutManager(getActivity()));
		up=(ImageView)view.findViewById(R.id.up);
		up.setOnClickListener(new View.OnClickListener() {
			public void onClick(View v) {
				if (up.isSelected()) {
					up.setImageResource(R.drawable.down);
					linearLayout.setVisibility(View.VISIBLE);
					up.setSelected(false);
				} else {
					up.setImageResource(R.drawable.up);
					linearLayout.setVisibility(View.GONE);
					up.setSelected(true);
				}
			}
		});
		savechanges.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View v) {
				new CreateSymptom().execute();
			}
		});
		yourSymptoms();
		return view;
	}


	public void yourSymptoms() {

		new AsyncTask<Void, Void, List<FeedItemSymptoms>>() {

			@Override
			protected List<FeedItemSymptoms> doInBackground(Void... params) {
//                ArrayList<HashMap> list = new ArrayList<HashMap>();
				String jsonStr = "";
				ServiceHandler sh = new ServiceHandler();

				String str = "";
				str = str + url;

				try {
					String queryStr = new CommonUtil().ConvertToUrlString(str +"&CId="+customerId+"&CEmail="+customerEmail);
					Log.d(TAG,"querystr"+queryStr);
					if (isInternetPresent) {

						jsonStr = sh.makeServiceCall(queryStr, ServiceHandler.GET);
					} else {
						getActivity().runOnUiThread(new Runnable() {
							public void run() {
								final AlertDialog.Builder builder = new AlertDialog.Builder(getActivity());
								builder.setTitle("Connection failure");
								builder.setMessage("Please check your network connection and try again");
								builder.setIcon(R.drawable.warn)
										.setPositiveButton("cancel", new DialogInterface.OnClickListener() {
											public void onClick(DialogInterface dialog, int id) {
												builder.setCancelable(true);
											}
										})
										.setNegativeButton("Wi-Fi Settings", new DialogInterface.OnClickListener() {
											public void onClick(DialogInterface dialog, int id) {
												startActivityForResult(new Intent(Settings.ACTION_WIFI_SETTINGS), 0);

											}
										});
								builder.show();
							}
						});
					}
				} catch (URISyntaxException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
				try {
					jsonArray = new JSONArray(jsonStr);
					Log.d(TAG,"jsonarray"+jsonArray);
					FeedItemSymptomsList.clear();
					for (int i = 0; i < jsonArray.length(); i++) {
						JSONObject jsonobject = jsonArray.getJSONObject(i);
						FeedItemSymptoms item = new FeedItemSymptoms();
						item.setSymptom(jsonobject.optString("symptom"));
						item.setCustomerId(jsonobject.optString("customerId"));
						item.setSymptomId(jsonobject.optString("symptomId"));
						item.setNotes(jsonobject.optString("notes"));
						item.setSymptomState(jsonobject.optString("symptomState"));
						//Log.d(TAG,""+i+""+jsonobject.optString("medication")+""+jsonobject.optString("notes"));


						FeedItemSymptomsList.add(item);
					}

				} catch (JSONException e) {
					e.printStackTrace();
				}
				return FeedItemSymptomsList;
			}
			private void showAlertDialog(FragmentActivity activity, String s, String s1, boolean b) {
				AlertDialog alertDialog = new AlertDialog.Builder(context).create();
				alertDialog.setTitle("");
				alertDialog.setMessage("");

				alertDialog.setButton("OK", new DialogInterface.OnClickListener() {
					public void onClick(DialogInterface dialog, int which) {
					}
				});

				alertDialog.show();
			}
			@Override
			protected void onPostExecute(List<FeedItemSymptoms> list) {
				Log.d("---","---list size----"+list.size());
				if (list.size() == 0) {

					AlertDialog alertDialog = new AlertDialog.Builder(getActivity()).create();
					alertDialog.setIcon(R.drawable.ic_report);
					alertDialog.setTitle("Info");
					alertDialog.setMessage("You don't have any Symptoms list at joslin Doctors");
					alertDialog.setButton("OK", new DialogInterface.OnClickListener() {
						public void onClick(DialogInterface dialog, int which) {
						}
					});

					alertDialog.show();
				} else {
					super.onPostExecute(list);
					adapter = new MyRecyclerAdapterSymptoms(getActivity(), FeedItemSymptomsList);
					adapter.notifyDataSetChanged();
					mRecyclerView.setAdapter(adapter);
				}

			}
		}.execute(null, null, null);
	}


	@Override
	public void onActivityCreated(Bundle savedInstanceState) {
		// TODO Auto-generated method stub
		super.onActivityCreated(savedInstanceState);
	}


	private class CreateSymptom  extends AsyncTask<String,String ,String>{
		@Override
		protected String doInBackground(String... params) {
			String jsonStr1 = "";
			ServiceHandler sh = new ServiceHandler();

			symptomET=symptom.getText().toString();
			notesET=notes.getText().toString();

			if(symptomState.isChecked()){
				symptom_State="past";
			}else{
				symptom_State="current";
			}


			String str = "";
			str = str + url2;

			String queryStr1 = new CommonUtil().ConvertToUrlString(str +"CId="+customerId+"&CEmail="+customerEmail+"&symptom="+symptomET+"&notes="+notesET+"&symptomState="+symptom_State);
			Log.d(TAG,"Query string  is"+queryStr1);

			if (isInternetPresent) {

				try {
					jsonStr1 = sh.makeServiceCall(queryStr1, ServiceHandler.POST);

                    getActivity().runOnUiThread(new Runnable() {
                        public void run() {
                            Toast toast = Toast.makeText(context, "Details saved successfully", Toast.LENGTH_LONG);
                            toast.setGravity(Gravity.CENTER_VERTICAL,0,0);
                            TextView tv=new TextView(context);
                            tv.setTextColor(Color.RED);
                            tv.setTextSize(15);
                            toast.getView().setBackgroundColor(Color.parseColor("#34bf49"));
                            toast.show();

                            symptom.setText("");
                            notes.setText("");
                            symptomState.setChecked(false);
                        }
                    });
                    yourSymptoms();

				} catch (URISyntaxException e) {
					e.printStackTrace();
				}

			} else {
				getActivity().runOnUiThread(new Runnable() {
					public void run() {

						final AlertDialog.Builder builder = new AlertDialog.Builder(getActivity());
						builder.setTitle("Connection failure");
						builder.setMessage("Please check your network connection and try again");
						builder.setIcon(R.drawable.warn)
								.setPositiveButton("cancel", new DialogInterface.OnClickListener() {
									public void onClick(DialogInterface dialog, int id) {
										builder.setCancelable(true);
									}
								})
								.setNegativeButton("Wi-Fi Settings", new DialogInterface.OnClickListener() {
									public void onClick(DialogInterface dialog, int id) {
										startActivityForResult(new Intent(Settings.ACTION_WIFI_SETTINGS), 0);


									}
								});
						builder.show();

					}
				});

			}



			return null;
		}
	}
}

