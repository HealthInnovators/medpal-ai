package com.healhouts.patient.Activities;

import android.app.Activity;
import android.app.ProgressDialog;
import android.content.Intent;
import android.os.AsyncTask;
import android.os.Bundle;
import android.util.Log;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.widget.AdapterView;
import android.widget.AdapterView.OnItemClickListener;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.SearchView;

import com.healhouts.patient.Adapters.CustomListAdapter;
import com.healhouts.patient.Beanclasses.DoctorItems;
import com.healhouts.patient.FragmentsPackage.ServiceHandler;
import com.healhouts.patient.R;
import com.healhouts.patient.common.ImageDownloaderTask;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.net.URISyntaxException;
import java.util.ArrayList;

public class MainActivity extends Activity implements
        android.widget.SearchView.OnQueryTextListener {

    public static String TAG = "MainActivity";
/*
    private static String url = "http://healthouts.com/doctors";
*/

    private static String url = "http://joslinlive.org/doctors";
    ProgressDialog pDialog;
    ListView lv1;
    SearchView search_view;
    CustomListAdapter adapter;


    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main2);

        lv1 = (ListView) findViewById(R.id.custom_list);
        search_view = (SearchView) findViewById(R.id.search_view);
        new GetDoctors().execute();
        search_view.setOnQueryTextListener(this);

        lv1.setOnItemClickListener(new OnItemClickListener() {

            @Override
            public void onItemClick(AdapterView<?> a, View v, int position,
                                    long id) {
                ImageView imageView = (ImageView) findViewById(R.id.thumbImage);
//                new ImageDownloaderTask(imageView).cancel(true);
                new ImageDownloaderTask(imageView);
                Object o = lv1.getItemAtPosition(position);
                DoctorItems newData = (DoctorItems) o;
                try {
                    Intent intent = new Intent(MainActivity.this, DoctorPofileActivity.class);
                    Bundle myData = new Bundle();
                    myData.putString("doctorId", newData.getDoctorId());
                    myData.putString("dName", newData.getdName());
                    intent.putExtras(myData);
//					startActivityForResult(intent, IPC_ID);
                    startActivity(intent);

                } catch (Exception e) {
                    // TODO: handle exception
                    e.printStackTrace();
                }


//				Toast.makeText(
//						MainActivity.this,
//						"Selected :" + " " + newData.getdName() + "\n Id :"
//								+ newData.getDoctorId(), Toast.LENGTH_LONG)
//						.show();
            }

        });
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        MenuInflater inflater = getMenuInflater();
        inflater.inflate(R.menu.main_mainactivity_actions, menu);
        return super.onCreateOptionsMenu(menu);
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()) {
            case R.id.action_reload:
                new GetDoctors().execute();
                return true;
            default:
                return super.onOptionsItemSelected(item);
        }
    }

    private class GetDoctors extends AsyncTask<Void, Void, ArrayList> {

        @Override
        protected void onPreExecute() {
            super.onPreExecute();
            // Showing progress dialog
            pDialog = new ProgressDialog(MainActivity.this, R.style.MyTheme);
            pDialog.setMessage("Please wait...");
            pDialog.setCancelable(false);
            pDialog.show();

        }

        @Override
        protected ArrayList doInBackground(Void... arg0) {
            ArrayList<DoctorItems> list = new ArrayList<DoctorItems>();
            // Creating service handler class instance
            ServiceHandler sh = new ServiceHandler();

            // Making a request to url and getting response
            String jsonStr = "";

            try {
                jsonStr = sh.makeServiceCall(url, ServiceHandler.GET);
            } catch (URISyntaxException e1) {
                // TODO Auto-generated catch block
                e1.printStackTrace();
            }

            Log.d("Response: ", "> " + jsonStr);

            if (jsonStr != null) {

                try {

                    JSONArray jarr = new JSONArray(jsonStr);

                    // Creating ArrayList from JSONArray object

                    for (int i = 0; i < jarr.length(); i++) {
                        JSONObject job = (JSONObject) jarr.get(i);

//						Log.d(TAG, "--imgPath->" + job.getString("imgPath"));
                        // NewsItem newsItem = new NewsItem();
                        // newsItem.setHeadline(job.getString("dName"));
                        // newsItem.setReporterName(job.getString("speciality"));
                        // newsItem.setDate(job.getString("location"));
                        // newsItem.setUrl(job.getString("imgPath"));

                        DoctorItems doctorItems = new DoctorItems();
                        doctorItems.setDoctorId(job.getString("doctorId"));
                        doctorItems.setdName(job.getString("dName"));
                        doctorItems.setSpeciality(job.getString("speciality"));
                        doctorItems.setLocation(job.getString("location"));
                        doctorItems.setImgPath(job.getString("imgPath"));

                        list.add(doctorItems);

                    }
                } catch (JSONException e) {
                    Log.e(TAG, "--Couldn't get any data from the url(Error String)");
                    e.printStackTrace();
                }

            } else {
                Log.e("ServiceHandler", "Couldn't get any data from the url");
            }

            return list;
        }


    }

    @Override
    public boolean onQueryTextChange(String newText) {
        adapter.getFilter().filter(newText);
        return false;
    }

    @Override
    public boolean onQueryTextSubmit(String arg0) {
        // TODO Auto-generated method stub
        return false;
    }
}
