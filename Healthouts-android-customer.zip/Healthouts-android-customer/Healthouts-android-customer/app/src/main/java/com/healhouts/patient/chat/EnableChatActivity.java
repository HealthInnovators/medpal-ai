package com.healhouts.patient.chat;

import android.app.Activity;
import android.app.ProgressDialog;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.database.DataSetObserver;
import android.graphics.Bitmap;
import android.os.Bundle;
import android.os.Environment;
import android.os.Handler;
import android.provider.MediaStore;
import android.text.Editable;
import android.text.TextWatcher;
import android.util.Log;
import android.view.KeyEvent;
import android.view.View;
import android.widget.AbsListView;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.ListView;

import com.healhouts.patient.R;

import org.jivesoftware.smack.ConnectionConfiguration;
import org.jivesoftware.smack.ConnectionConfiguration.SecurityMode;
import org.jivesoftware.smack.PacketListener;
import org.jivesoftware.smack.Roster;
import org.jivesoftware.smack.RosterEntry;
import org.jivesoftware.smack.SmackException;
import org.jivesoftware.smack.SmackException.ConnectionException;
import org.jivesoftware.smack.SmackException.NotConnectedException;
import org.jivesoftware.smack.XMPPConnection;
import org.jivesoftware.smack.XMPPException;
import org.jivesoftware.smack.filter.MessageTypeFilter;
import org.jivesoftware.smack.filter.PacketFilter;
import org.jivesoftware.smack.packet.Message;
import org.jivesoftware.smack.packet.Packet;
import org.jivesoftware.smack.packet.Presence;
import org.jivesoftware.smack.tcp.XMPPTCPConnection;
import org.jivesoftware.smack.util.StringUtils;
import org.jivesoftware.smackx.filetransfer.FileTransfer;
import org.jivesoftware.smackx.filetransfer.FileTransferListener;
import org.jivesoftware.smackx.filetransfer.FileTransferManager;
import org.jivesoftware.smackx.filetransfer.FileTransferRequest;
import org.jivesoftware.smackx.filetransfer.IncomingFileTransfer;
import org.jivesoftware.smackx.filetransfer.OutgoingFileTransfer;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.OutputStream;
import java.util.ArrayList;
import java.util.Collection;

public class EnableChatActivity extends Activity {
    public static final String TAG = "EnableChatActivity";
    public static final String HOST = "healthouts.com";
    public static final int PORT = 5222;
//    public static final int PORT = 7777;

    //	public static final String SERVICE = "gmail.com";
    public String USERNAME;
    public String PASSWORD;

    private XMPPConnection connection;
    private ArrayList<String> messages = new ArrayList<String>();
    private Handler mHandler = new Handler();
    private ChatArrayAdapter chatArrayAdapter;
    private ListView listView;

    private EditText recipient;
    private EditText textMessage;
    public ImageView send;
//    private ListView listview;

    private static String cPreferences;
    private static String customerId;
    private static String customerName;
    String doctorCustomerId;
    String dName;
    SharedPreferences sharedpreferences;
    private static String server = "healthouts.com";
    private static String name = "healthouts";

    private boolean side = true;
    String msgToken;
    String to;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        // TODO Auto-generated method stub
        super.onCreate(savedInstanceState);
        setContentView(R.layout.chatwindow);

        Intent myLocalIntent = getIntent();
        Bundle myBundle = myLocalIntent.getExtras();
//		doctorCustomerId = myBundle.getString("doctorCustomerId");
        doctorCustomerId = "37";
//		dName = myBundle.getString("dName");
        dName = "Venkat Veeravalli";

        cPreferences = this.getString(R.string.cPreferences);
        customerId = this.getString(R.string.customerId);
        customerName = this.getString(R.string.customerName);
        sharedpreferences = getSharedPreferences(cPreferences, Context.MODE_PRIVATE);

//        customerId = sharedpreferences.getString(customerId, null);
        customerId = "5";
//        customerName = sharedpreferences.getString(customerName, null);
        customerName = "V.Venkat";
        Log.i("EnableChatActivity", "preferece-----customerId---->" + customerId);
        USERNAME = name + customerId;
        PASSWORD = name + customerId;

        to = "healthouts" + doctorCustomerId + "@" + server;
//		ChatServer xmppServer = new ChatServer();
//		connection = ChatServer.getXmppConnection();
//		connection = xmppServer.connect(name+customerId, name+customerId);
//		setConnection(connection);
        recipient = (EditText) this.findViewById(R.id.toET);
        recipient.setText("Dr." + dName);
        textMessage = (EditText) this.findViewById(R.id.chatET);
        listView = (ListView) this.findViewById(R.id.listMessages);
        send = (ImageView) this.findViewById(R.id.sendBtn);

        chatArrayAdapter = new ChatArrayAdapter(getApplicationContext(), R.layout.activity_chat_singlemessage);

        listView.setAdapter(chatArrayAdapter);


        textMessage.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {
            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
            }

            @Override
            public void afterTextChanged(Editable s) {
                if (textMessage.getText().toString().length() > 0) {
//                    Toast.makeText(getApplicationContext(), "afterTextChanged", Toast.LENGTH_SHORT).show();
                    send.setImageResource(R.drawable.ic_chat_send_active);
                } else if (textMessage.getText().toString().length() == 0) {
                    int id = getResources().getIdentifier("android:drawable/ic_menu_camera", null, null);
                    send.setImageResource(id);
                }
            }
        });

        textMessage.setOnKeyListener(new View.OnKeyListener() {

            public boolean onKey(View v, int keyCode, KeyEvent event) {

                if ((event.getAction() == KeyEvent.ACTION_DOWN) && (keyCode == KeyEvent.KEYCODE_ENTER)) {
                    return setListAdapter(textMessage.getText().toString(), true);
                }
                return false;
            }
        });


        // Set a listener to send a chat text message

        send.setOnClickListener(new View.OnClickListener() {
            public void onClick(View view) {
//						String to = recipient.getText().toString();
//                String to = "healthouts" + doctorCustomerId + "@" + server;
                String text = textMessage.getText().toString();
                if (text.length() > 0) {

                    Log.i("XMPPChatDemoActivity", "Sending text " + text + " to " + to);
                    Message msg = new Message(to, Message.Type.chat);
                    msg.setBody(text);
//                setListAdapter(text);
                    if (connection != null) {
                        try {
                            Log.i("EnableChatActivity", "------>" + connection.getUser());
                            connection.sendPacket(msg);
                        } catch (NotConnectedException e) {
                            // TODO Auto-generated catch block
                            e.printStackTrace();
                        } catch (SmackException e) {
                            e.printStackTrace();
                        }

                        setListAdapter(text, true);
                    }
                } else if (text.length() == 0) {
                    open();
                }
            }
        });


        connect();

        listView.setTranscriptMode(AbsListView.TRANSCRIPT_MODE_ALWAYS_SCROLL);
        listView.setAdapter(chatArrayAdapter);

        //to scroll the list view to bottom on data change
        chatArrayAdapter.registerDataSetObserver(new DataSetObserver() {
            @Override
            public void onChanged() {
                super.onChanged();
                listView.setSelection(chatArrayAdapter.getCount() - 1);
            }
        });

    }

    public void open() {
        Intent intent = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
        startActivityForResult(intent, 0);
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        Bitmap bp = (Bitmap) data.getExtras().get("data");


        Log.d(TAG, "--------->" + bp.toString());

        sendFile(bp);
//        imgFavorite.setImageBitmap(bp);
    }

    public void sendFile(Bitmap bp) {
        Log.i("XMPPChatDemoActivity", "Sending File  to " + to);
        OutputStream stream = null;
        try {
            stream = new FileOutputStream(Environment.getExternalStorageDirectory().getAbsoluteFile() + "/DCIM/Camera/VENKAT.jpg");
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        }
        bp.compress(Bitmap.CompressFormat.JPEG, 100, stream);
        if (connection != null) {
            try {
                Log.i("EnableChatActivity", "------>" + connection.getUser());


                //====================ic_action_attachment transfer code=======================================================

                FileTransferManager manager = new FileTransferManager(connection);
                OutgoingFileTransfer transfer = manager.createOutgoingFileTransfer(to + "/Smack");
                File file = new File(Environment.getExternalStorageDirectory().getAbsoluteFile() + "/DCIM/Camera/VENKAT.jpg");
                transfer.sendFile(file, "test_file");
                Log.e(TAG, "--sending status1--" + transfer.getStatus());
                while (!transfer.isDone()) {
                    if (transfer.getStatus().equals(FileTransfer.Status.error)) {
                        Log.e(TAG, "ERROR!!! " + transfer.getError());
//                        System.out.println("ERROR!!! " + transfer.getError());
                    } else if (transfer.getStatus().equals(FileTransfer.Status.cancelled)
                            || transfer.getStatus().equals(FileTransfer.Status.refused)) {
                        Log.e(TAG, "Cancelled!!! " + transfer.getError());
//                        System.out.println("Cancelled!!! " + transfer.getError());
                    }
                    try {
                        Thread.sleep(1000L);
                    } catch (InterruptedException e) {
                        e.printStackTrace();
                    }
                }
                Log.e(TAG, "--sending status2--" + transfer.getStatus());
                if (transfer.getStatus().equals(FileTransfer.Status.refused) || transfer.getStatus().equals(FileTransfer.Status.error)
                        || transfer.getStatus().equals(FileTransfer.Status.cancelled)) {
                    Log.e(TAG, "refused cancelled error " + transfer.getError());
//                    System.out.println("refused cancelled error " + transfer.getError());
                } else {
                    Log.i(TAG, "---ic_action_attachment transfer success---");
//                    System.out.println("Success");
                }


                //===============================================================================================


            } catch (NotConnectedException e) {
                // TODO Auto-generated catch block
                e.printStackTrace();
            } catch (SmackException e) {
                e.printStackTrace();
            }

//            setListAdapter(text, true);
        }
    }

    /**
     * Called by Settings dialog when a connection is establised with the XMPP
     * server
     *
     * @param connection
     */
    public void setConnection(XMPPConnection connection) {
        this.connection = connection;
        if (connection != null) {


            FileTransferManager manager = new FileTransferManager(connection);
            manager.addFileTransferListener(new FileTransferListener() {
                public void fileTransferRequest(final FileTransferRequest request) {
                    new Thread() {
                        @Override
                        public void run() {
                            IncomingFileTransfer transfer = request.accept();
                            File mf = Environment.getExternalStorageDirectory();
                            File file = new File(mf.getAbsoluteFile() + "/DCIM/Camera/" + transfer.getFileName());
                            try {
                                transfer.recieveFile(file);
                                while (!transfer.isDone()) {
                                    try {
                                        Thread.sleep(1000L);
                                    } catch (Exception e) {
                                        Log.e("", e.getMessage());
                                    }
                                    if (transfer.getStatus().equals(FileTransfer.Status.error)) {
                                        Log.e("ERROR!!! ", transfer.getError() + "");
                                    }
                                    if (transfer.getException() != null) {
                                        transfer.getException().printStackTrace();
                                    }
                                }
                            } catch (Exception e) {
                                Log.e("", e.getMessage());
                            }
                        }

                        ;
                    }.start();
                }
            });


            // Add a packet listener to get messages sent to us
            PacketFilter filter = new MessageTypeFilter(Message.Type.chat);
            connection.addPacketListener(new PacketListener() {
                @Override
                public void processPacket(Packet packet) {
                    Message message = (Message) packet;
                    if (message.getBody() != null) {
                        String fromName = StringUtils.parseBareAddress(message
                                .getFrom());
                        Log.i("EnableChatActivity", "Text Recieved " + message.getBody()
                                + " from " + fromName);
//						messages.up(fromName + ":");
//						messages.up("Dr."+dName+ ":");
//						messages.up(message.getBody());
                        msgToken = message.getBody();
                        // Add the incoming message to the list view
                        mHandler.post(new Runnable() {
                            public void run() {
                                setListAdapter(msgToken, false);
                            }
                        });
                    }
                }
            }, filter);
        }

    }

    private boolean setListAdapter(String msg, boolean side) {

        chatArrayAdapter.add(new ChatMessage(side, msg));
        textMessage.setText("");


        return true;
//		ArrayAdapter<String> adapter = new ArrayAdapter<String>(this,
//				R.layout.listitem, messages);
//		listview.setAdapter(adapter);
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        try {
            if (connection != null)
                connection.disconnect();
        } catch (Exception e) {

        }
    }

    public void connect() {

        final ProgressDialog dialog = ProgressDialog.show(this,
                "Connecting...", "Please wait...", false);

        Thread t = new Thread(new Runnable() {

            @Override
            public void run() {
                // Create a connection
                Log.i("tag", "------>" + HOST);
                ConnectionConfiguration connConfig = new ConnectionConfiguration(HOST, PORT);
                connConfig.setReconnectionAllowed(true);
                connConfig.setDebuggerEnabled(true);

                connConfig.setSecurityMode(SecurityMode.disabled);
//				connConfig.setCompressionEnabled(true);
//				connConfig.setSASLAuthenticationEnabled(true);
//	            xmppConnection = new XMPPConnection(configuration);
                XMPPConnection connection = new XMPPTCPConnection(connConfig);

                try {
                    connection.connect();
                    Log.i("XMPPChatDemoActivity",
                            "Connected to " + connection.getHost());
                    Log.i("XMPPChatDemoActivity",
                            "is connected-------> " + connection.isConnected());

                } catch (XMPPException | SmackException | IOException ex) {
                    Log.e("XMPPChatDemoActivity", "Failed to connect to "
                            + connection.getHost());

                    Log.e("XMPPChatDemoActivity", ex.toString());
                    Log.e("tag", "-----" + ((ConnectionException) ex).getFailedAddresses());
                    setConnection(null);
                }
                try {
                    Log.d(TAG, "--USERNAME---" + USERNAME);
                    Log.d(TAG, "--PASSWORD---" + PASSWORD);
                    // SASLAuthentication.supportSASLMechanism("PLAIN", 0);
                    connection.login(USERNAME, PASSWORD);
                    Log.i("XMPPChatDemoActivity",
                            "Logged in as " + connection.getUser());

                    // Set the status to available
                    Presence presence = new Presence(Presence.Type.available);
                    connection.sendPacket(presence);
                    setConnection(connection);

                    Roster roster = connection.getRoster();
                    Collection<RosterEntry> entries = roster.getEntries();
                    for (RosterEntry entry : entries) {
                        Log.d("XMPPChatDemoActivity",
                                "--------------------------------------");
                        Log.d("XMPPChatDemoActivity", "RosterEntry " + entry);
                        Log.d("XMPPChatDemoActivity",
                                "User: " + entry.getUser());
                        Log.d("XMPPChatDemoActivity",
                                "Name: " + entry.getName());
                        Log.d("XMPPChatDemoActivity",
                                "Status: " + entry.getStatus());
                        Log.d("XMPPChatDemoActivity",
                                "Type: " + entry.getType());
                        Presence entryPresence = roster.getPresence(entry
                                .getUser());

                        Log.d("XMPPChatDemoActivity", "Presence Status: "
                                + entryPresence.getStatus());
                        Log.d("XMPPChatDemoActivity", "Presence Type: "
                                + entryPresence.getType());
                        Presence.Type type = entryPresence.getType();
                        if (type == Presence.Type.available)
                            Log.d("XMPPChatDemoActivity", "Presence AVIALABLE");
                        Log.d("XMPPChatDemoActivity", "Presence : "
                                + entryPresence);

                    }
                } catch (XMPPException | SmackException | IOException ex) {
                    Log.e("XMPPChatDemoActivity", "Failed to log in as "
                            + USERNAME);
                    Log.e("XMPPChatDemoActivity", ex.toString());
                    setConnection(null);
                }

                dialog.dismiss();
            }
        });
        t.start();
        dialog.show();
    }
}
