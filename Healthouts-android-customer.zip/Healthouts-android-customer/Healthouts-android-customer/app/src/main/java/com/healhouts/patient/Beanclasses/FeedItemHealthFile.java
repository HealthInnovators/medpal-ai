package com.healhouts.patient.Beanclasses;

/**
 * Created by venkat veeravalli on 30-06-2015.
 */
public class FeedItemHealthFile {
    private String heathfileid;
    private String healthfilepath;

    public String getHeathfileid() {
        return heathfileid;
    }

    public void setHeathfileid(String heathfileid) {
        this.heathfileid = heathfileid;
    }

    public String getHealthfilepath() {
        return healthfilepath;
    }

    public void setHealthfilepath(String healthfilepath) {
        this.healthfilepath = healthfilepath;
    }
}
