package com.healhouts.patient.FragmentsPackage;

import android.app.AlertDialog;
import android.app.ProgressDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.os.StrictMode;
import android.provider.Settings;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentActivity;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.VolleyLog;
import com.android.volley.toolbox.JsonArrayRequest;
import com.android.volley.toolbox.Volley;
import com.healhouts.patient.Activities.AMS;
import com.healhouts.patient.Activities.SimpleDividerItemDecoration;
import com.healhouts.patient.Adapters.AdapterAppointments;
import com.healhouts.patient.Beanclasses.FeedItemAppointments;
import com.healhouts.patient.R;
import com.healhouts.patient.Volley.AppController;
import com.healhouts.patient.common.ConnectionDetector;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by samsung on 23-05-2015.
 */
public class AppointmentHistory extends Fragment {
    private static final String TAG = "AppointmentHistory";
    private Context context;
    Boolean isInternetPresent = false;
    ConnectionDetector cd;
    SharedPreferences userSharedPreferences;
    JSONArray jsonArray;
    private String customerId;
    private boolean loginStatus = false;
    private View v;
    public List<FeedItemAppointments> FeedItemAppList = new ArrayList<FeedItemAppointments>();
    private RecyclerView mRecyclerView;
    LinearLayoutManager mLayoutManager;
    private AdapterAppointments adapter;
    private boolean loading = true;
    int firstVisibleItem, visibleItemCount, totalItemCount;
    int count = 0;
    int token = 0;
    TextView appointmentswologin;
 //   String url = "http://healthouts.com/appBookedAppointments?";
    String url = "http://joslinlive.org/appBookedAppointments?";


    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        StrictMode.ThreadPolicy policy = new StrictMode.ThreadPolicy.Builder().permitAll().build();
        StrictMode.setThreadPolicy(policy);
        context = getActivity().getApplicationContext();
        cd = new ConnectionDetector(context);
        isInternetPresent = cd.isConnectingToInternet();
        View fragmentView = inflater.inflate(R.layout.activity_feeds_list_appointments, container, false);
        mRecyclerView = (RecyclerView) fragmentView.findViewById(R.id.recycler_view);
        mRecyclerView.setHasFixedSize(true);
        mLayoutManager = new LinearLayoutManager(getActivity());
        mRecyclerView.setLayoutManager(mLayoutManager);
        /*RecyclerView.ItemDecoration itemDecoration =
                new DividerItemDecoration(getActivity(), LinearLayoutManager.VERTICAL);
        mRecyclerView.addItemDecoration(itemDecoration);
        */userSharedPreferences = this.getActivity().getSharedPreferences(context.getString(R.string.cPreferences), Context.MODE_PRIVATE);
        Log.d(TAG, "--userSharedPreferenc--" + userSharedPreferences);
        if (userSharedPreferences.getString(context.getString(R.string.customerId), null) != null) {
            customerId = userSharedPreferences.getString(context.getString(R.string.customerId), null);
            loginStatus = true;
        }
        if (loginStatus) {

            v = inflater.inflate(R.layout.activity_booking_history_layout, container, false);
        } else{

            final AlertDialog.Builder builder = new AlertDialog.Builder(getActivity());
            builder.setMessage("You dont have any appointments at Joslin doctors..!!");
            builder.setPositiveButton("Done", new DialogInterface.OnClickListener() {
                @Override
                public void onClick(DialogInterface dialog, int which) {
                    Intent intent = new Intent(context, AMS.class);
                    startActivity(intent);
                    dialog.dismiss();
                }
            });
            builder.show();


        }
        mRecyclerView.setOnScrollListener(new RecyclerView.OnScrollListener() {
            @Override
            public void onScrolled(RecyclerView recyclerView, int dx, int dy) {
                super.onScrolled(recyclerView, dx, dy);
                visibleItemCount = mRecyclerView.getChildCount();
                totalItemCount = mLayoutManager.getItemCount();
                firstVisibleItem = mLayoutManager.findFirstVisibleItemPosition();
                if (loading) {
                    if ((visibleItemCount + firstVisibleItem) >= totalItemCount) {
                        loading = false;
                        Log.v("...", "Last Item Wow !");
                        count = totalItemCount;

                    }
                }
            }


        });
        yourAppointments();
        Volley.newRequestQueue(context);
        return fragmentView;

    }

    private void yourAppointments() {
        if(isInternetPresent) {
            final ProgressDialog pDialog = new ProgressDialog(getActivity());
            pDialog.setMessage("Loading...");
            pDialog.show();
            FeedItemAppointments item = new FeedItemAppointments();


            JsonArrayRequest req = new JsonArrayRequest(url + "customerId=" + customerId,
                    new Response.Listener<JSONArray>() {
                        @Override
                        public void onResponse(JSONArray response) {
                            for (int i = 0; i < response.length(); i++) {
                                JSONObject jsonobject = null;
                                FeedItemAppointments item = new FeedItemAppointments();

                                try {
                                    jsonobject = response.getJSONObject(i);
                                    item.setDoctorName(jsonobject.getString("doctorName"));
                                    item.setAppointmentDate(jsonobject.getString("appointmentDate"));
                                    item.setDoctorSpecialty(jsonobject.getString("doctorSpecialty"));
                                    item.setAppointmentTime(jsonobject.getString("appointmentTime"));
                                    item.setDoctorCity(jsonobject.getString("doctorCity"));

                                } catch (JSONException e) {
                                    e.printStackTrace();
                                }
//used volley
                                FeedItemAppList.add(item);
                                adapter = new AdapterAppointments(getActivity(), FeedItemAppList);
                                mRecyclerView.addItemDecoration(new SimpleDividerItemDecoration(getResources()));
                                mRecyclerView.setAdapter(adapter);
                            }
                            pDialog.hide();
                        }
                    }, new Response.ErrorListener() {
                @Override
                public void onErrorResponse(VolleyError error) {
                    VolleyLog.d(TAG, "Error: " + error.getMessage());
                    pDialog.hide();
                }
            });

            AppController.getInstance(context.getApplicationContext()).addToRequestQueue(req);
        }else{
            getActivity().runOnUiThread(new Runnable() {
                public void run() {
                    final AlertDialog.Builder builder = new AlertDialog.Builder(getActivity());
                    builder.setTitle("Connection failure");
                    builder.setMessage("Please check your network connection and try again");
                    builder.setIcon(R.drawable.warn)
                            .setPositiveButton("cancel", new DialogInterface.OnClickListener() {
                                public void onClick(DialogInterface dialog, int id) {
                                    builder.setCancelable(false);
                                }
                            })
                            .setNegativeButton("Wi-Fi Settings", new DialogInterface.OnClickListener() {
                                public void onClick(DialogInterface dialog, int id) {
                                    startActivityForResult(new Intent(Settings.ACTION_WIFI_SETTINGS), 0);

                                }
                            });
                    builder.show();
                }
            });

        }
    }
/*

    public void yourAppointments() {

        new AsyncTask<Void, Void, List<FeedItemAppointments>>() {

            @Override
            protected List<FeedItemAppointments> doInBackground(Void... params) {
//                ArrayList<HashMap> list = new ArrayList<HashMap>();
                String jsonStr = "";
                ServiceHandler sh = new ServiceHandler();

                String str = "";
                str = str + url;

                try {
                    String queryStr = new CommonUtil().ConvertToUrlString(str + "customerId=" + customerId);
                    if (isInternetPresent) {

                        jsonStr = sh.makeServiceCall(queryStr, ServiceHandler.GET);
                    } else {
                        getActivity().runOnUiThread(new Runnable() {
                            public void run() {
                                final AlertDialog.Builder builder = new AlertDialog.Builder(getActivity());
                                builder.setTitle("Connection failure");
                                builder.setMessage("Please check your network connection and try again");
                                builder.setIcon(R.drawable.warn)
                                        .setPositiveButton("cancel", new DialogInterface.OnClickListener() {
                                            public void onClick(DialogInterface dialog, int id) {
                                                builder.setCancelable(true);
                                            }
                                        })
                                        .setNegativeButton("Wi-Fi Settings", new DialogInterface.OnClickListener() {
                                            public void onClick(DialogInterface dialog, int id) {
                                                startActivityForResult(new Intent(Settings.ACTION_WIFI_SETTINGS), 0);

                                            }
                                        });
                                builder.show();
                            }
                        });
                    }
                } catch (URISyntaxException e1) {
                    // TODO Auto-generated catch block
                    e1.printStackTrace();
                }
                try {
                    jsonArray = new JSONArray(jsonStr);
                    for (int i = 0; i < jsonArray.length(); i++) {
                        JSONObject jsonobject = jsonArray.getJSONObject(i);
                        FeedItemAppointments item = new FeedItemAppointments();
                        item.setDoctorName(jsonobject.getString("doctorName"));
                        item.setAppointmentDate(jsonobject.getString("appointmentDate"));
                        item.setDoctorSpecialty(jsonobject.getString("doctorSpecialty"));
                        item.setAppointmentTime(jsonobject.getString("appointmentTime"));
                        item.setDoctorCity(jsonobject.getString("doctorCity"));

                        FeedItemAppList.add(item);
                    }
                } catch (JSONException e) {
                    e.printStackTrace();
                }
                return FeedItemAppList;
            }

        }.execute(null, null, null);
    }
*/

    private void showAlertDialog(FragmentActivity activity, String s, String s1, boolean b) {
        AlertDialog alertDialog = new AlertDialog.Builder(context).create();
        alertDialog.setTitle("");
        alertDialog.setMessage("");

        alertDialog.setButton("OK", new DialogInterface.OnClickListener() {
            public void onClick(DialogInterface dialog, int which) {
            }
        });

        alertDialog.show();
    }

    /*protected void onPostExecute(List<FeedItemAppointments> list) {
        if (list.size() == 0) {
            AlertDialog alertDialog = new AlertDialog.Builder(getActivity()).create();
            alertDialog.setIcon(R.drawable.ic_report);
            alertDialog.setTitle("Info");
            alertDialog.setMessage("You don't have any Appointments at healthouts Doctors");
            alertDialog.setButton("OK", new DialogInterface.OnClickListener() {
                public void onClick(DialogInterface dialog, int which) {
                }
            });

            alertDialog.show();
        } else {

            adapter = new AdapterAppointments(getActivity(), FeedItemAppList);
            mRecyclerView.addItemDecoration(new SimpleDividerItemDecoration(getResources()));

            mRecyclerView.setAdapter(adapter);
        }

    }*/
}
