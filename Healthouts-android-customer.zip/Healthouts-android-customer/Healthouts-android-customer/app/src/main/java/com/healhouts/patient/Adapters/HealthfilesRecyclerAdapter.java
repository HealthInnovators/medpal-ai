package com.healhouts.patient.Adapters;

import android.content.Context;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.TextView;

import com.healhouts.patient.Beanclasses.FeedItemHealthFile;
import com.healhouts.patient.R;

import java.util.List;

/**
 * Created by Venkat Veeravalli on 30-06-2015.
 */
public class HealthfilesRecyclerAdapter extends RecyclerView.Adapter<HealthfilesRecyclerAdapter.FeedListRowHolder> {


    private List<FeedItemHealthFile> feedItemList;
    private Context mContext;

    OnItemClickListener mItemClickListener;

    public HealthfilesRecyclerAdapter(Context context, List<FeedItemHealthFile> feedItemList) {
        this.feedItemList = feedItemList;
        this.mContext = context;
    }



    @Override
    public FeedListRowHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.healthfiles_list_layout, null);

        FeedListRowHolder rowHolder = new FeedListRowHolder(view);
        return rowHolder;
    }

    @Override
    public void onBindViewHolder(FeedListRowHolder holder, int position) {
        FeedItemHealthFile feedItem = feedItemList.get(position);
        holder.healthfileView.setText(feedItem.getHealthfilepath());

    }

    @Override
    public int getItemCount() {
        return (null != feedItemList ? feedItemList.size() : 0);
    }
    public  interface OnItemClickListener{
        public  void onItemClick(View view, int position);
    }
    public void SetOnItemClickListener(final OnItemClickListener mItemClickListener) {
        this.mItemClickListener = mItemClickListener;
    }

    public class FeedListRowHolder extends RecyclerView.ViewHolder implements View.OnClickListener{
        protected TextView healthfileView;
        protected Button buttonView;



        public FeedListRowHolder(View view) {
            super(view);
            this.healthfileView =(TextView)view.findViewById(R.id.healthfileName);
            this.buttonView = (Button)view.findViewById(R.id.btnDelete);
            view.setOnClickListener(this);
            buttonView.setOnClickListener(this);
        }

        @Override
        public void onClick(View v) {
            if (mItemClickListener != null) {
                mItemClickListener.onItemClick(v, getPosition());
            }
        }
    }
}
