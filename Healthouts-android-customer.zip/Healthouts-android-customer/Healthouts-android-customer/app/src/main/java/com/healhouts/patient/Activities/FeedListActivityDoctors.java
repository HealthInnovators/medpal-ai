package com.healhouts.patient.Activities;

import android.app.AlertDialog;
import android.app.ProgressDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.os.AsyncTask;
import android.os.Bundle;
import android.os.StrictMode;
import android.support.v4.app.FragmentActivity;
import android.support.v7.app.ActionBarActivity;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.text.Html;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.Window;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.LinearLayout;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import com.healhouts.patient.Adapters.AdapterDoctor;
import com.healhouts.patient.Beanclasses.FeedItemDoctor;
import com.healhouts.patient.FragmentsPackage.ServiceHandler;
import com.healhouts.patient.R;
import com.healhouts.patient.common.CommonUtil;
import com.healhouts.patient.common.ConnectionDetector;
import com.healhouts.patient.common.ServiceCalls;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.net.URISyntaxException;
import java.util.ArrayList;
import java.util.List;

public class FeedListActivityDoctors extends ActionBarActivity implements AdapterView.OnItemSelectedListener {
    private static final String TAG = "FeedListActivityDoctors";
    private List<FeedItemDoctor> feedItemList = new ArrayList<FeedItemDoctor>();

    JSONArray jsonArray;
    LinearLayout linearLayout1;
    String sp;
    Spinner spinner_price, spinner_location;
    String spinner_item_price;
    String spinner_item_location;
    private RecyclerView mRecyclerView;
    private AdapterDoctor adapter;


//    private static String url = "http://joslinlive.org/appDocList?";
//    private static String url2 = "http://joslinlive.org/appDocFilterList?";

    boolean isInternetPresent = false;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        requestWindowFeature(Window.FEATURE_INDETERMINATE_PROGRESS);
        super.onCreate(savedInstanceState);
        Bundle myBundle = getIntent().getExtras();
        sp = myBundle.getString("speciality");
        //Log.d(TAG, "clicked at" + sp);
        android.support.v7.app.ActionBar actionBar = getSupportActionBar();
        ColorDrawable colorDrawable = new ColorDrawable(Color.parseColor("#993333"));
        actionBar.setBackgroundDrawable(colorDrawable);
        actionBar.setTitle(Html.fromHtml("<font color='#ffffff' font-weight:bold>" + sp + "</font>"));
        actionBar.setDisplayHomeAsUpEnabled(true);
        actionBar.setHomeButtonEnabled(true);


        Context context = this.getApplicationContext();
        ConnectionDetector cd = new ConnectionDetector(context);
        isInternetPresent = cd.isConnectingToInternet();
        // Log.d(TAG, "present or not" + isInternetPresent);

        setContentView(R.layout.activity_feeds_list_doctor);
        linearLayout1=(LinearLayout)findViewById(R.id.linearLayout1);

        StrictMode.ThreadPolicy policy = new StrictMode.ThreadPolicy.Builder().permitAll().build();
        StrictMode.setThreadPolicy(policy);
        spinner_price = (Spinner) findViewById(R.id.price_spinner);
        spinner_price.setOnItemSelectedListener(this);
        ArrayAdapter<CharSequence> adapter = ArrayAdapter.createFromResource(this,
                R.array.price_array, android.R.layout.simple_list_item_1);
// Specify the layout to use when the list of choices appears
        adapter.setDropDownViewResource(android.R.layout.simple_list_item_activated_1);
// Apply the adapter to the spinner
        spinner_price.setAdapter(adapter);


        // Create an ArrayAdapter using the string array and a default spinner layout
        spinner_location = (Spinner) findViewById(R.id.location_spinner);
        spinner_location.setOnItemSelectedListener(this);
        ArrayAdapter<CharSequence> adapter1 = ArrayAdapter.createFromResource(this,
                R.array.location_array, android.R.layout.simple_list_item_1);
        adapter1.setDropDownViewResource(android.R.layout.simple_list_item_activated_1);
        spinner_location.setAdapter(adapter1);


        mRecyclerView = (RecyclerView) findViewById(R.id.recycler_view);

        mRecyclerView.setLayoutManager(new LinearLayoutManager(this));
        yourDoctors();

    }

    public void filter(View view) {
        applyFilter();
        linearLayout1.setVisibility(View.GONE);
    }


    public void applyFilter() {

        new AsyncTask<Void, Void, List<FeedItemDoctor>>() {




            @Override
            protected List<FeedItemDoctor> doInBackground(Void... params) {
                String jsonStr = "";
                ServiceHandler sh = new ServiceHandler();
                try {
                    String queryStr = new CommonUtil().ConvertToUrlString(ServiceCalls.DOCTOR_FILTER_LIST + "sp=" + sp + "&sortby=" + spinner_item_price + "&location=" + spinner_item_location);
                    //   Log.d(TAG, "--"+queryStr);
                    jsonStr = sh.makeServiceCall(queryStr, ServiceHandler.GET);
                } catch (URISyntaxException e1) {
                    // TODO Auto-generated catch block
                    e1.printStackTrace();
                }
                try {
                    if (feedItemList.size() > 0) {
                        feedItemList.clear();
                    }
                    JSONArray jarr = new JSONArray(jsonStr);
                    for (int i = 0; i < jarr.length(); i++) {
                        JSONObject jsonobject = (JSONObject) jarr.get(i);
                        FeedItemDoctor item = new FeedItemDoctor();
                        Log.d("---", "---jsonObject---" + jsonobject.toString());
                        item.setDocId(jsonobject.getString("doctorId"));
                        item.setdName(jsonobject.getString("dName"));
                        item.setLocation(jsonobject.getString("location"));
                        item.setSpeciality(jsonobject.getString("speciality"));
                        item.setImgPath(jsonobject.getString("imgPath"));

                        feedItemList.add(item);
                    }
                } catch (JSONException e) {
                    e.printStackTrace();
                }
                return feedItemList;
            }

            private void showAlertDialog(FragmentActivity activity, String s, String s1, boolean b) {
                AlertDialog alertDialog = new AlertDialog.Builder(getApplicationContext()).create();
                alertDialog.setTitle("");
                alertDialog.setMessage("");

                alertDialog.setButton("OK", new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface dialog, int which) {
                    }
                });

                alertDialog.show();
            }

            @Override
            protected void onPostExecute(List<FeedItemDoctor> list) {

                if (list.size() == 0) {
                    String msg = "joslin Don't have any doctors for your Search Criteria.Kindly explore later";
                    Toast toast = Toast.makeText(getApplicationContext(), msg, Toast.LENGTH_SHORT);
                    View view = toast.getView();
                    view.setBackgroundColor(Color.parseColor("#FF5722"));
                    TextView text = (TextView) view.findViewById(android.R.id.message);

                    toast.show();
                } else {
                    super.onPostExecute(list);

                }
                adapter = new AdapterDoctor(getApplicationContext(), feedItemList);
                mRecyclerView.setHasFixedSize(true);
                mRecyclerView.setAdapter(adapter);
                adapter.SetOnItemClickListener(new AdapterDoctor.OnItemClickListener() {
                    public void onItemClick(View view, int position) {
                        Log.d("---", "----position---" + position);
                        FeedItemDoctor feedItem = feedItemList.get(position);

                        Intent intent = new Intent(getApplicationContext(), DoctorPofileActivity.class);
                        Bundle bundle = new Bundle();
                        bundle.putString("doctorId", feedItem.getDocId());
                        bundle.putString("dName", feedItem.getdName());
                        intent.putExtras(bundle);
                        startActivity(intent);
                    }
                });
//adapter.notifyDataSetChanged();
            }

        }.execute(null, null, null);
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.menu_feeddoctorslist, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()) {
            case android.R.id.home:
                super.onBackPressed();
                return true;

            case R.id.filter:
                showFilter();
                break;
            default:

        }
        return super.onOptionsItemSelected(item);
    }

    private void showFilter() {
        linearLayout1.setVisibility(View.VISIBLE);
    }


    public void yourDoctors() {
        new AsyncTask<Void, Void, List<FeedItemDoctor>>() {
            @Override
            protected List<FeedItemDoctor> doInBackground(Void... params) {
                String jsonStr = "";
                ServiceHandler sh = new ServiceHandler();
                try {
                    String queryStr = new CommonUtil().ConvertToUrlString(ServiceCalls.DOCTOR_LIST + "sp=" + sp);
                    //Log.d(TAG, "--"+queryStr);
                    jsonStr = sh.makeServiceCall(queryStr, ServiceHandler.GET);

                    //   Log.d("log", "---->"+jsonStr);
                } catch (URISyntaxException e1) {
                    // TODO Auto-generated catch block
                    e1.printStackTrace();
                }
                try {
                    JSONArray jarr = new JSONArray(jsonStr);
                    for (int i = 0; i < jarr.length(); i++) {
                        JSONObject jsonobject = (JSONObject) jarr.get(i);
                        FeedItemDoctor item = new FeedItemDoctor();
                        item.setDocId(jsonobject.getString("doctorId"));
                        item.setdName(jsonobject.getString("dName"));
                        item.setLocation(jsonobject.getString("location"));
                        item.setSpeciality(jsonobject.getString("speciality"));
                        item.setImgPath(jsonobject.getString("imgPath"));

                        feedItemList.add(item);
                    }
                } catch (JSONException e) {
                    e.printStackTrace();
                }
                return feedItemList;
            }

            private void showAlertDialog(FragmentActivity activity, String s, String s1, boolean b) {
                AlertDialog alertDialog = new AlertDialog.Builder(getApplicationContext()).create();
                alertDialog.setTitle("");
                alertDialog.setMessage("");

                alertDialog.setButton("OK", new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface dialog, int which) {
                    }
                });
                alertDialog.show();
            }

            @Override
            protected void onPostExecute(List<FeedItemDoctor> list) {
                if (list.size() == 0) {
                    Toast.makeText(getApplicationContext(), "Joslin don't have any doctors for this Speciality,kindly explore later", Toast.LENGTH_LONG).show();
                    final AlertDialog.Builder builder = new AlertDialog.Builder(FeedListActivityDoctors.this);

                    builder.setTitle("Information");
                    builder.setMessage("joslin don't have any doctors for this Speciality,kindly explore later");
                    builder.setIcon(R.drawable.ic_report)
                            .setPositiveButton("cancel", new DialogInterface.OnClickListener() {
                                public void onClick(DialogInterface dialog, int id) {
                                    builder.setCancelable(true);
                                }
                            });
                    builder.show();

                } else {
                    super.onPostExecute(list);
                    adapter = new AdapterDoctor(getApplicationContext(), feedItemList);
                    adapter.SetOnItemClickListener(new AdapterDoctor.OnItemClickListener() {
                        public void onItemClick(View view, int position) {
                            Log.d("---", "----position---" + position);
                            FeedItemDoctor feedItem = feedItemList.get(position);
                            Intent intent = new Intent(getApplicationContext(), DoctorPofileActivity.class);
                            Bundle bundle = new Bundle();
                            bundle.putString("doctorId", feedItem.getDocId());
                            bundle.putString("dName", feedItem.getdName());
                            intent.putExtras(bundle);
                            startActivity(intent);
                        }
                    });
                    mRecyclerView.setAdapter(adapter);
                }
            }
        }.execute(null, null, null);
    }

    @Override
    public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {

        switch (parent.getId()) {
            case R.id.price_spinner:
                spinner_price.setOnItemSelectedListener(this);
                spinner_item_price = parent.getItemAtPosition(position).toString();
                //   Toast.makeText(parent.getContext(), "Selected: " + spinner_item_price, Toast.LENGTH_LONG).show();

                break;
            case R.id.location_spinner:
                spinner_location.setOnItemSelectedListener(this);
                spinner_item_location = parent.getItemAtPosition(position).toString();
                break;
            default:
                break;
        }
    }

    @Override
    public void onNothingSelected(AdapterView<?> parent) {

    }
}