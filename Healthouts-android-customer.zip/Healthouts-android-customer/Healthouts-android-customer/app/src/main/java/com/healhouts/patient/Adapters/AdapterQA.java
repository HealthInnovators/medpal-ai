package com.healhouts.patient.Adapters;

import android.content.Context;
import android.support.v7.widget.RecyclerView;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import com.healhouts.patient.Beanclasses.FeedItemQA;
import com.healhouts.patient.R;
import com.healhouts.patient.common.CommonUtil;
import com.squareup.picasso.Picasso;

import java.util.List;

/**
 * Created by Sheshakanth on 21-05-2015.
 */
public class AdapterQA extends RecyclerView.Adapter<AdapterQA.FeedListRowHolderQA>{
    private static final String TAG = "AdapterQA";
    TextView questionId;


    private List<FeedItemQA> feedItemList;

    private Context mContext;
    OnItemClickListener mItemClickListener;
    public AdapterQA(Context context, List<FeedItemQA> feedItemList) {
        this.feedItemList = feedItemList;
        this.mContext = context;
    }

    @Override
    public FeedListRowHolderQA onCreateViewHolder(ViewGroup viewGroup, int viewType) {
        View v = LayoutInflater.from(viewGroup.getContext()).inflate(R.layout.your_feed_list, null);
        TextView questionId=(TextView)v.findViewById(R.id.questionId);

        FeedListRowHolderQA mh = new FeedListRowHolderQA(v);
//        mh.questionBody.setOnClickListener(AdapterQA.this);
//        mh.questionId.setOnClickListener(AdapterQA.this);
        mh.questionBody.setTag(mh);
        return mh;
    }

    @Override
    public void onBindViewHolder(FeedListRowHolderQA feedListRowHolder, int i) {
        FeedItemQA feedItem = feedItemList.get(i);

        Log.d("---", "--image path---" + feedItem.getcImage());
        Log.d("---", "--question body---" + feedItem.getQuestionBody());
        Log.d("---", "--date---" + feedItem.getQsDate());
        Log.d("---", "--date---" + feedItem.getQuestionId());


/*
        Log.d(TAG,"image "+"http://joslinlive.org/img/"+feedItem.getcImage());
*/

      Picasso.with(mContext).load(new CommonUtil().ConvertToUrlString("http://joslinlive.org/img/"+feedItem.getcImage()))
    //    Picasso.with(mContext).load(new CommonUtil().ConvertToUrlString("http://healthouts.com/img/"+feedItem.getcImage()))

                .error(R.drawable.ic_launcher)
                .placeholder(R.drawable.ic_launcher)
                .into(feedListRowHolder.cImage);

        feedListRowHolder.questionBody.setText(feedItem.getQuestionBody());
        feedListRowHolder.qsDate.setText(feedItem.getQsDate());
        feedListRowHolder.questionId.setText(feedItem.getQuestionId());
    }
    @Override
    public int getItemCount() {

        return (null != feedItemList ? feedItemList.size() : 0);
    }

    public  interface OnItemClickListener{
        public  void onItemClick(View view, int position);
    }
    public void SetOnItemClickListener(final OnItemClickListener mItemClickListener) {
        this.mItemClickListener = mItemClickListener;
    }

            public class FeedListRowHolderQA  extends RecyclerView.ViewHolder implements View.OnClickListener{

                protected ImageView cImage;
                protected TextView qsDate;
                protected TextView questionBody;
                protected TextView questionId;



                public FeedListRowHolderQA(View view) {
                    super(view);
                    this.cImage = (ImageView) view.findViewById(R.id.cImage);
                    this.qsDate = (TextView) view.findViewById(R.id.qsDate);
                    this.questionBody = (TextView) view.findViewById(R.id.cdetails);
                    this.questionId = (TextView) view.findViewById(R.id.questionId);
                    view.setOnClickListener(this);
                }

                @Override
                public void onClick(View v) {

                    if (mItemClickListener != null) {
                        mItemClickListener.onItemClick(v, getPosition());
                    }
                }

            }
}
