//
//  UpdateAboutMeViewController.swift
//  Healthouts
//
//  Created by Y.Bharath Kumar Reddy on 23/06/15.
//  Copyright (c) 2015 Y.Bharath Kumar Reddy. All rights reserved.
//

import UIKit

protocol AboutMeDelegate{
    func showImagePicker(imagePicker:UIImagePickerController)
    
}

class UpdateAboutMeViewController: UIViewController,HorizontalBaseDelegate,UITextFieldDelegate,UITextViewDelegate {

    //outlets from the storyboard
    @IBOutlet weak var changeDpButton: UIButton!
    @IBOutlet weak var saveButton: UIButton!
    @IBOutlet weak var dateOfBirthTextField: UITextField!
    @IBOutlet weak var aboutMeTextView: UITextView!
    @IBOutlet weak var nameTextField: UITextField!
    @IBOutlet weak var doctorImageView: UIImageView!
    @IBOutlet weak var femaleButton: DownStateButton!
    @IBOutlet weak var maleButton: DownStateButton!
    @IBOutlet weak var contentView: UIView!
    @IBOutlet weak var scrollView: UIScrollView!
    
    //required variables
    var selectedTextView:UITextView!
    var selectedTextField:UITextField!
    var delegate:AboutMeDelegate?
    var imageCache = [String:UIImage]()
    var imagePicker = UIImagePickerController()
    var actInd : UIActivityIndicatorView = UIActivityIndicatorView(frame: CGRectMake(0,0, 50, 50)) as UIActivityIndicatorView
    
    override func viewDidLoad() {
        super.viewDidLoad()

        changeDpButton.setTitle("", forState: UIControlState.Normal)
        contentView.backgroundColor = UIColor.clearColor()
        
        //set the left and right constraints of content view of the table view
        var leftConstraint = NSLayoutConstraint(item: self.contentView, attribute: NSLayoutAttribute.Leading, relatedBy: NSLayoutRelation.Equal, toItem: self.view, attribute: NSLayoutAttribute.Left, multiplier: 1, constant: 0)
        self.view.addConstraint(leftConstraint)
        
        var rightConstraint = NSLayoutConstraint(item: self.contentView, attribute: NSLayoutAttribute.Trailing, relatedBy: NSLayoutRelation.Equal, toItem: self.view, attribute: NSLayoutAttribute.Right, multiplier: 1, constant: 0)
        self.view.addConstraint(rightConstraint)
        
        //from here on
        //populate all the fields in the about me screen like name,gender,aboutme etc using the doctorCompleteprofile
        
        saveButton.layer.cornerRadius = 5
        
        aboutMeTextView.layer.borderColor = UIColor.lightGrayColor().CGColor
        aboutMeTextView.layer.borderWidth = 1
        aboutMeTextView.layer.cornerRadius = 5
        aboutMeTextView.text = doctorCompleteProfile.objectForKey("info") as! String
        
        nameTextField.text = doctorCompleteProfile.objectForKey("name") as! String
        
        dateOfBirthTextField.text = doctorCompleteProfile.objectForKey("dob") as! String
        if(doctorCompleteProfile.objectForKey("gender") as! String == "Male"){
            maleButton.selected = true
        }else{
            femaleButton.selected = true
        }
        
        maleButton.myAlternateButton = [femaleButton]
        femaleButton.myAlternateButton = [maleButton]
        
        
        //set the doctor image view and its properties..
        var userInfo = NSUserDefaults.standardUserDefaults().objectForKey("userInfo") as! NSDictionary
        var docName = userInfo.objectForKey("cImage") as! String
        docName = docName.stringByReplacingOccurrencesOfString(" ", withString: "%20")
        var imgPath = "http://healthouts.com/img/" + docName
        var imgUrl = NSURL(string: imgPath)
        
        SDWebImageDownloader.sharedDownloader().downloadImageWithURL(imgUrl, options: nil, progress: { (receivedSize:Int, expectedSize:Int) -> Void in
            
            }) { (image, data, error, finished) -> Void in
                self.doctorImageView.image = image
        }
        doctorImageView.layer.cornerRadius = 50
        doctorImageView.layer.masksToBounds = true
        
        
        //set the textfield and textview delegates
        nameTextField.delegate = self
        dateOfBirthTextField.delegate = self
        
    }
    
    override func viewWillAppear(animated: Bool) {
        super.viewWillAppear(true)
        
        //add the keyboard notifications
        NSNotificationCenter.defaultCenter().addObserver(self, selector: "keyboardWillBeShown:", name: UIKeyboardWillShowNotification, object: nil)
        NSNotificationCenter.defaultCenter().addObserver(self, selector: "keyboardWillBeHidden:", name: UIKeyboardWillHideNotification, object: nil)
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    
    //save the details
    @IBAction func saveButtonPressed(sender: AnyObject) {
        
        //resign the responsers
        if(selectedTextField != nil){
            selectedTextField.resignFirstResponder()
        }
        if(selectedTextView != nil){
            selectedTextView.resignFirstResponder()
        }
        
        //start the activity indicator
        actInd.center = CGPointMake(self.view.center.x, self.view.center.y - 64)
        actInd.hidesWhenStopped = true
        actInd.activityIndicatorViewStyle = UIActivityIndicatorViewStyle.White
        actInd.backgroundColor = UIColor.blackColor()
        actInd.layer.cornerRadius = 5
        view.addSubview(actInd)
        actInd.startAnimating()
        
        //prepare the parameters to be sent with the url
        var userInfo = NSUserDefaults.standardUserDefaults().objectForKey("userInfo")?.mutableCopy() as? NSDictionary
        var customerId = userInfo?.objectForKey("customerId") as! Int
        var customerEmail = userInfo?.objectForKey("emailId") as! String
        var gender = ""
        if(maleButton.selected == true){
            gender = "Male"
        }else{
            gender = "Female"
        }
        
        
        //executed when the profile image is not dummy image..
        if(doctorImageView.image != UIImage(named: "dummydp")){
            
            //use net to uplaod the image
            let net = Net()
            var imageData = NetData(jpegImage: doctorImageView.image!, compressionQuanlity: 1.0, filename: "myFile")
            net.POST("http://healthouts.com/appUpdateDoctorProfileInfo?", params: ["CID":customerId,"cEmail":customerEmail,"name":nameTextField.text,"dob":dateOfBirthTextField.text,"gender":gender,"aboutme":aboutMeTextView.text,"profilepImage":imageData], successHandler: { (response) -> () in
                dispatch_async(dispatch_get_main_queue(), {
                    self.actInd.stopAnimating()
                    let result:NSDictionary? = response.jsonDict(error: nil)
                   
                    if result != nil{
                        if(result!.objectForKey("status") as! String == "1"){
                            if let imgPath = result?.objectForKey("profileImgPath") as? String{
                                userInfo?.setValue(imgPath, forKey: "cImage")
                                NSUserDefaults.standardUserDefaults().setObject(userInfo, forKey: "userInfo")
                            }
                            
                        }
                        
                        self.addAlert(result?.objectForKey("message") as! String)
                    }
                })
            }, failureHandler: { (error) -> () in
                dispatch_async(dispatch_get_main_queue(), {
                    self.actInd.stopAnimating()
                self.addAlert(error.localizedDescription)
                })
            })
            
            
            
            
        }else{
            //executed when profile image is dummy image
           
            //use the SRWebclient to call the service url
            SRWebClient.POST("http://healthouts.com/appUpdateDoctorProfileInfo?")
                .data(["CID":customerId,"cEmail":customerEmail,"name":nameTextField.text,"dob":dateOfBirthTextField.text,"gender":gender,"aboutme":aboutMeTextView.text])
                .send({ (response:AnyObject!, status:Int) -> Void in
                
                    self.actInd.stopAnimating()
                    var err: NSError?
                    var data = (response as! String).dataUsingEncoding(NSUTF8StringEncoding, allowLossyConversion: true)
                    if let jsonResult = NSJSONSerialization.JSONObjectWithData(data!, options: NSJSONReadingOptions.MutableContainers, error: &err) as? NSDictionary {
                        dispatch_async(dispatch_get_main_queue(), {
                        
                            self.addAlert(jsonResult["message"] as! String)
                        
                        })
                    }else{
                        self.addAlert((err?.localizedDescription)!)
                    }
                }, failure: { (error) -> Void in
                    dispatch_async(dispatch_get_main_queue(), {
                        
                        self.addAlert(error.localizedDescription)
                        
                        
                    })
            })
        }
        
    }



    //show the options when the profile image is pressed
    @IBAction func changeDpButtonPressed(sender: AnyObject) {
        
        let optionMenu = UIAlertController(title: nil, message: "Choose Option", preferredStyle: UIAlertControllerStyle.ActionSheet)
        
        
        let selectImageAction = UIAlertAction(title: "Choose Image", style: .Default, handler: {
            (alert: UIAlertAction!) -> Void in
            if UIImagePickerController.isSourceTypeAvailable(UIImagePickerControllerSourceType.SavedPhotosAlbum){
                
                self.imagePicker.sourceType = UIImagePickerControllerSourceType.SavedPhotosAlbum;
                self.imagePicker.allowsEditing = false
                self.delegate?.showImagePicker(self.imagePicker)
                
            }
        })
        
        /*
        let selectFileAction = UIAlertAction(title: "Take Photo", style: .Default, handler: {
            (alert: UIAlertAction!) -> Void in
            self.imagePicker.sourceType = UIImagePickerControllerSourceType.Camera;
            self.imagePicker.allowsEditing = false
            self.delegate?.showImagePicker(self.imagePicker)
        })
        */
        
        let cancelAction = UIAlertAction(title: "Cancel", style: .Cancel, handler: {
            (alert: UIAlertAction!) -> Void in
            
        })
        
        
        
        optionMenu.addAction(selectImageAction)
        //optionMenu.addAction(selectFileAction)
        optionMenu.addAction(cancelAction)
        
        
        
        self.presentViewController(optionMenu, animated: true, completion: nil)
    }
    
    //set the doctor dp
    func setDoctorDp(image: UIImage) {
        self.doctorImageView.image = image
    }
    
    
    //textfield and textview delegate methods
    func textFieldShouldBeginEditing(textField: UITextField) -> Bool {
        
        self.selectedTextField = textField
        return true
    }
    
    func textViewShouldBeginEditing(textView: UITextView) -> Bool {
        self.selectedTextView = textView
        return true
    }
    
    
    func textFieldShouldReturn(textField: UITextField) -> Bool {
        textField.resignFirstResponder()
        return true
    }
    
    //keyboard notification functions
    func keyboardWillBeHidden(notification:NSNotification){
        var contentInsets = UIEdgeInsetsZero
        self.scrollView.contentInset = contentInsets
        self.scrollView.scrollIndicatorInsets = contentInsets
    }
    
    func keyboardWillBeShown(notification:NSNotification){
        if let userInfo = notification.userInfo {
            if let keyboardSize = (userInfo[UIKeyboardFrameBeginUserInfoKey] as? NSValue)?.CGRectValue() {
                //self.bottomConstraint.constant = -keyboardSize.height
                var contentInsets = UIEdgeInsetsMake(0, 0, keyboardSize.height, 0)
                self.scrollView.contentInset = contentInsets
                self.scrollView.scrollIndicatorInsets = contentInsets
                var rect = self.contentView.frame
                rect.size.height -= keyboardSize.height
                if (!aboutMeTextView.isFirstResponder() && !CGRectContainsPoint(rect, self.selectedTextField.frame.origin)) {
                    var scrollPoint = CGPointMake(0.0, self.selectedTextField.frame.origin.y - (keyboardSize.height - self.selectedTextField.frame.size.height))
                    self.scrollView.setContentOffset(scrollPoint, animated: false)
                }else{
                    var scrollPoint = CGPointMake(0.0, self.aboutMeTextView.frame.origin.y - (keyboardSize.height - self.aboutMeTextView.frame.size.height) + 60)
                    self.scrollView.setContentOffset(scrollPoint, animated: false)
                }
            }
        }
    }
    
    
    override func viewWillDisappear(animated: Bool) {
        super.viewWillDisappear(true)
        
        //remove all notifications before the view disappears
        NSNotificationCenter.defaultCenter().removeObserver(self)
    }
    
    //function to add alert
    func addAlert(message:String){
        var alert = UIAlertController(title: "Alert", message: message, preferredStyle: UIAlertControllerStyle.Alert)
        alert.addAction(UIAlertAction(title: "ok", style: UIAlertActionStyle.Default, handler: nil))
        self.presentViewController(alert, animated: true, completion: nil)
    }

}
