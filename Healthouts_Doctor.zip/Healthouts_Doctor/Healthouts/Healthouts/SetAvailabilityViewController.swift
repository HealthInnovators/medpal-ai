//
//  SetAvailabilityViewController.swift
//  Healthouts
//
//  Created by Y.Bharath Kumar Reddy on 22/06/15.
//  Copyright (c) 2015 Y.Bharath Kumar Reddy. All rights reserved.
//

import UIKit

class SetAvailabilityViewController: UIViewController,UICollectionViewDelegate,UICollectionViewDataSource{

    //outlets from the storyBoard
    @IBOutlet weak var datePicker: UIDatePicker!
    @IBOutlet weak var contentView: UIView!
    @IBOutlet weak var scrollView: UIScrollView!
    @IBOutlet weak var collectionView: UICollectionView!
    
    //required variables..
    var timingsArray = ["10:00","10:30","11:00","11:30","12:00","12:30","05:00","05:30","06:00","06:30","07:00","07:30","08:00","08:30"]
    var data:NSDictionary = [:]
    var actInd : UIActivityIndicatorView = UIActivityIndicatorView(frame: CGRectMake(0,0, 50, 50)) as UIActivityIndicatorView
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        //set the left and right constraint of the content view of scroll view
        var leftConstraint = NSLayoutConstraint(item: self.contentView, attribute: NSLayoutAttribute.Leading, relatedBy: NSLayoutRelation.Equal, toItem: self.view, attribute: NSLayoutAttribute.Left, multiplier: 1, constant: 0)
        self.view.addConstraint(leftConstraint)
        
        var rightConstraint = NSLayoutConstraint(item: self.contentView, attribute: NSLayoutAttribute.Trailing, relatedBy: NSLayoutRelation.Equal, toItem: self.view, attribute: NSLayoutAttribute.Right, multiplier: 1, constant: 0)
        self.view.addConstraint(rightConstraint)
        
        //set the date picker mode
        datePicker.datePickerMode = UIDatePickerMode.Date
        
        //register the timings collection cell using its identifier
        var nib = UINib(nibName: "TimingsCollectionViewCell", bundle: nil)
        collectionView.registerNib(nib, forCellWithReuseIdentifier: "TimingsCell")
        
    }
    

    //call the getData function every time the view appears
    //the getData func calls the timings availability service url
    override func viewWillAppear(animated: Bool) {
        super.viewWillAppear(true)
        getData()
        
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    //call the getData every time the date is changed
    //the getData func calls the timings availability service url
    @IBAction func dateChanged(sender: AnyObject) {
        getData()
    }

    
    //function to get the timings availability by calling the api
    func getData(){
        
        //start the activity indicator
        actInd.center = CGPointMake(self.view.center.x, self.view.center.y - 64)
        actInd.hidesWhenStopped = true
        actInd.activityIndicatorViewStyle = UIActivityIndicatorViewStyle.White
        actInd.backgroundColor = UIColor.blackColor()
        actInd.layer.cornerRadius = 5
        view.addSubview(actInd)
        actInd.startAnimating()
        
        //get the parameters needed to be sent to the service url
        var userInfo = NSUserDefaults.standardUserDefaults().objectForKey("userInfo")
        var doctorId = userInfo?.objectForKey("doctorId") as! Int
        var dateformatter = NSDateFormatter()
        dateformatter.dateFormat = "yyyy-MM-dd"
        var dateString = dateformatter.stringFromDate(datePicker.date)
        
        //call the url using SRWebClient
        SRWebClient.POST("http://healthouts.com/appDocAvailability?")
            .data(["doctorId":doctorId,"strDate":dateString])
            .send({ (response:AnyObject!, status:Int) -> Void in
                //handle the successful response
                self.actInd.stopAnimating()
                var err: NSError?
                var data = (response as! String).dataUsingEncoding(NSUTF8StringEncoding, allowLossyConversion: true)
                
                //convert the response json object into NSDictionary
                //and populate the timings collection view
                if let jsonResult = NSJSONSerialization.JSONObjectWithData(data!, options: NSJSONReadingOptions.MutableContainers, error: &err) as? NSDictionary {
                   
                    self.view.hidden = false
                    self.data = jsonResult
                    self.collectionView.reloadData()
                    
                    
                }else{
                    self.view.hidden = false
                }
                
            }, failure: { (error) -> Void in
                
                //handle failure by showing an alert
                self.view.hidden = true
                self.actInd.stopAnimating()
                var alert = UIAlertController(title: "Alert", message: error.localizedDescription, preferredStyle: UIAlertControllerStyle.Alert)
                alert.addAction(UIAlertAction(title: "ok", style: UIAlertActionStyle.Default, handler: nil))
                self.presentViewController(alert, animated: true, completion: nil)
            })
        
        
        
    }
    
    //collection view count
    func collectionView(collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        return timingsArray.count
    }
    
    //populate the collection view
    func collectionView(collectionView: UICollectionView, cellForItemAtIndexPath indexPath: NSIndexPath) -> UICollectionViewCell {
        //instantiate the cell with its identifier
        var identifier = "TimingsCell"
        var cell = collectionView.dequeueReusableCellWithReuseIdentifier(identifier, forIndexPath: indexPath) as! TimingsCollectionViewCell
        
        //populate the cell
        cell.timeLabel.textColor = UIColor.blackColor()
        cell.stateLabel.textColor = UIColor.blackColor()
        cell.timeLabel.text = timingsArray[indexPath.row]
        if(indexPath.row < 4){
            cell.stateLabel.text = "AM"
        }else{
            cell.stateLabel.text = "PM"
        }
        
        var timeslot = "tp" + "\(indexPath.row + 1)"
        
        if let bool = data["\(timeslot)"] as? NSObject{
            if(bool == 1){
                cell.availabilityImageView.image = UIImage(named: "blue_availability")
            }else{
                cell.availabilityImageView.image = UIImage(named: "red_availability")
            }
        }
        
        //return the cell
        return cell
    }
    
    
    
    //handle the selections in the timings collection view
    func collectionView(collectionView: UICollectionView, didSelectItemAtIndexPath indexPath: NSIndexPath) {
        if(data.count != 0){
            
            //start the activity indicator
            actInd.center = CGPointMake(self.view.center.x, self.view.center.y - 64)
            actInd.hidesWhenStopped = true
            actInd.activityIndicatorViewStyle = UIActivityIndicatorViewStyle.White
            actInd.backgroundColor = UIColor.blackColor()
            actInd.layer.cornerRadius = 5
            view.addSubview(actInd)
            actInd.startAnimating()
        
            //prepare the parameters to be sent with the service url
            var timeslot = "tp" + "\(indexPath.row + 1)"
            
            var userInfo = NSUserDefaults.standardUserDefaults().objectForKey("userInfo") as? NSDictionary
            var customerId = userInfo?.objectForKey("customerId") as! Int
            var customerEmail = userInfo?.objectForKey("emailId") as! String
            
            var dateformatter = NSDateFormatter()
            var toChange = "false"
            dateformatter.dateFormat = "yyyy-MM-dd"
            var dateString = dateformatter.stringFromDate(datePicker.date)
       
        
            if let bool = data["\(timeslot)"] as? NSObject{
                if(bool == 1){
                    toChange = "false"
                }else{
                    toChange = "true"
                }
            }
        
            var doctorTimeId = data["doctorTimeId"] as! Int
            
            //call the service url using SRWebClient
            //pass the parameters
            SRWebClient.POST("http://healthouts.com/appChangeAvailability?")
                .data(["CID":customerId,"cEmail":customerEmail,"givenDate":dateString,"tp":indexPath.row + 1,"toChange":toChange,"doctorTimeId":doctorTimeId])
                .send({ (response:AnyObject!, status:Int) -> Void in
                    //handle succesful response
                    self.actInd.stopAnimating()
                    dispatch_async(dispatch_get_main_queue(), {
                        
                        if(response as! String == "true"){
                            if(toChange == "true"){
                                (collectionView.cellForItemAtIndexPath(indexPath) as! TimingsCollectionViewCell).availabilityImageView.image = UIImage(named: "blue_availability")
                            }else{
                                (collectionView.cellForItemAtIndexPath(indexPath) as! TimingsCollectionViewCell).availabilityImageView.image = UIImage(named: "red_availability")
                            }
                            
                        }else{
                            self.addAlert("The availability could not be changed")
                        }
                        self.getData()
                    })
            
                }, failure: { (error) -> Void in
                    
                    //handle failure in calling the service url
                    dispatch_async(dispatch_get_main_queue(), {
            
                        self.actInd.stopAnimating()
                        self.addAlert(error.localizedDescription)
            
                
                    })
                })
        }
    }
    
    //function to add an alert
    func addAlert(message:String){
        var alert = UIAlertController(title: "Alert", message: message, preferredStyle: UIAlertControllerStyle.Alert)
        alert.addAction(UIAlertAction(title: "ok", style: UIAlertActionStyle.Default, handler: nil))
        self.presentViewController(alert, animated: true, completion: nil)
    }
}
