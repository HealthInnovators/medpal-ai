//
//  HorizontalScrollBaseViewController.swift
//  Healthouts
//
//  Created by Y.Bharath Kumar Reddy on 22/06/15.
//  Copyright (c) 2015 Y.Bharath Kumar Reddy. All rights reserved.


import UIKit

//protocol declaration
protocol HorizontalBaseDelegate {
    func setDoctorDp(image:UIImage)
}

class HorizontalScrollBaseViewController: UIViewController,AboutMeDelegate,UIImagePickerControllerDelegate,UINavigationControllerDelegate {
    
    //outlets from storyboard
    @IBOutlet weak var navigationMenuLabel: UILabel!

    //required variables
    var delegate:HorizontalBaseDelegate?
    var pageMenu : CAPSPageMenu?
    var count = 0
    var doctorDetails = NSDictionary()
    var actInd : UIActivityIndicatorView = UIActivityIndicatorView(frame: CGRectMake(0,0, 50, 50)) as UIActivityIndicatorView
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        //page menu is what controls the horizontal scrolling in the profile settings and set availability screens
        pageMenu?.menuItemWidthBasedOnTitleTextWidth = true
        
        //array to store the controllers that must be added to the page menu(horizontal scrolling)
        var controllerArray : [UIViewController] = []
        
        //count = 0 means that the present sceen is the set availability timings screen
        if(count == 0){
            navigationMenuLabel.text = "Appointments"
            
            /*  
                instantiate the view controllers with their correnponding identifiers
                set the title of the screen
                append it to the controller array
            */
            var controller1 : MyAppointmentsViewController = self.storyboard?.instantiateViewControllerWithIdentifier("MyAppointments") as! MyAppointmentsViewController
            controller1.title = "Appointments"
            controllerArray.append(controller1)
        
            var controller2 : SetAvailabilityViewController = self.storyboard?.instantiateViewControllerWithIdentifier("SetAvailability") as! SetAvailabilityViewController
            controller2.title = "Set Availability"
            controllerArray.append(controller2)
            
            
            
            // Customize menu
            var parameters: [CAPSPageMenuOption] = [
            .ScrollMenuBackgroundColor(UIColor(red: 0/255.0, green: 147/255.0, blue: 59/255.0, alpha: 1)),
            .ViewBackgroundColor(UIColor.whiteColor()),
            .SelectionIndicatorColor(UIColor.whiteColor()),
            .BottomMenuHairlineColor(UIColor(red: 70.0/255.0, green: 70.0/255.0, blue: 80.0/255.0, alpha: 1.0)),
            .MenuHeight(44.0),
            .CenterMenuItems(true)
            ]
        
            // Initialize scroll menu and add it as subview
            pageMenu = CAPSPageMenu(viewControllers: controllerArray, frame: CGRectMake(0.0, 64, self.view.frame.width, self.view.frame.height - 64), pageMenuOptions: parameters)
        
            self.view.addSubview(pageMenu!.view)
            
        }else{
            //count is not 0 so the sceen to be presented is the profile settings screen..
            getDoctorData()
            
            
        }

    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    //horizontal scrolling to the left
    func didTapGoToLeft() {
        var currentIndex = pageMenu!.currentPageIndex
    
        if currentIndex > 0 {
            pageMenu!.moveToPage(currentIndex - 1)
        }
    }
    
    //horizontal scrolling to the right
    func didTapGoToRight() {
        var currentIndex = pageMenu!.currentPageIndex
        if currentIndex < pageMenu!.controllerArray.count {
            pageMenu!.moveToPage(currentIndex + 1)
        }
    }

    //show the side menu on pressing side menu button
    @IBAction func showMenuPressed(sender: AnyObject) {
        self.view.endEditing(true)
        self.frostedViewController.view.endEditing(true)
        self.frostedViewController.presentMenuViewController()
    }
    
    //get the doctor data to be shown in the profile settings screen
    func getDoctorData(){
        self.navigationMenuLabel.text = "Profile Settings"
        
        //start activity indicator
        actInd.center = self.view.center
        actInd.hidesWhenStopped = true
        actInd.activityIndicatorViewStyle = UIActivityIndicatorViewStyle.White
        actInd.backgroundColor = UIColor.blackColor()
        actInd.layer.cornerRadius = 5
        view.addSubview(actInd)
        actInd.startAnimating()
        
        //prepare the parameters to be sent with the url
        var userInfo = NSUserDefaults.standardUserDefaults().objectForKey("userInfo") as? NSDictionary
        var customerId = userInfo?.objectForKey("customerId") as! Int
        var customerEmail = userInfo?.objectForKey("emailId") as! String
        
        //call the SRWebClient with the url
        SRWebClient.GET("http://healthouts.com/appDoctorAllDetails?CID=\(customerId)&cEmail=\(customerEmail)",
            success:{(response:AnyObject!, status:Int) -> Void in
                //process success response
                
                self.actInd.stopAnimating()
                var err: NSError?
                var data = (response as! String).dataUsingEncoding(NSUTF8StringEncoding, allowLossyConversion: true)
                if let jsonResult = NSJSONSerialization.JSONObjectWithData(data!, options: NSJSONReadingOptions.MutableContainers, error: &err) as? NSDictionary {
                    dispatch_async(dispatch_get_main_queue(), {
                        
                        //assign the returned result to the doctorCompleteProfile
                        doctorCompleteProfile = jsonResult
                        
                        //an array to store the profile settings view controllers
                        var controllerArray : [UIViewController] = []
                        
                        /*
                            do the following fo each controller
                            1.instantiate the controller with its identifier
                            2.initialize the properties or variable for ech controller
                            3.append the controller to the controller array
                        */
                        var controller1 : UpdateAboutMeViewController = self.storyboard?.instantiateViewControllerWithIdentifier("AboutMe") as! UpdateAboutMeViewController
                        controller1.delegate = self
                        self.delegate = controller1
                        controller1.title = "ABOUT ME"
                        controllerArray.append(controller1)
                        
                        var controller2 : UpdateSpecializationViewController = self.storyboard?.instantiateViewControllerWithIdentifier("Specialization") as! UpdateSpecializationViewController
                        controller2.title = "EDUCATION/SPECIALIZATION"
                        controllerArray.append(controller2)
                        
                        var controller3 : UpdatePracticeLocationViewController = self.storyboard?.instantiateViewControllerWithIdentifier("PracticeLocation") as! UpdatePracticeLocationViewController
                        controller3.title = "PRACTICE LOCATION"
                        controllerArray.append(controller3)
                        
                        var controller4 : UpdateKnownForViewController = self.storyboard?.instantiateViewControllerWithIdentifier("KnownFor") as! UpdateKnownForViewController
                        controller4.title = "KNOWN FOR"
                        controllerArray.append(controller4)
                        
                        var controller5 : PaymentHistoryViewController = self.storyboard?.instantiateViewControllerWithIdentifier("PaymentHistory") as! PaymentHistoryViewController
                        controller5.title = "PAYMENT HISTORY"
                        controllerArray.append(controller5)
                        
                        //customise the page menu
                        var parameters: [CAPSPageMenuOption] = [
                            .ScrollMenuBackgroundColor(UIColor(red: 0/255.0, green: 147/255.0, blue: 59/255.0, alpha: 1)),
                            .ViewBackgroundColor(UIColor.whiteColor()),
                            .SelectionIndicatorColor(UIColor.whiteColor()),
                            .BottomMenuHairlineColor(UIColor(red: 70.0/255.0, green: 70.0/255.0, blue: 80.0/255.0, alpha: 1.0)),
                            .MenuHeight(44.0),
                            .CenterMenuItems(true)
                        ]
                        
                        // Initialize scroll menu add it as subview
                        self.pageMenu = CAPSPageMenu(viewControllers: controllerArray, frame: CGRectMake(0.0, 64, self.view.frame.width, self.view.frame.height - 64), pageMenuOptions: parameters)
                        
                        self.view.addSubview(self.pageMenu!.view)
                    
                        
                    })
                    
                }else{
                    
                    //show alent when parsing error occured
                    self.actInd.stopAnimating()
                    var alert = UIAlertController(title: "Alert", message: err!.localizedDescription, preferredStyle: UIAlertControllerStyle.Alert)
                    alert.addAction(UIAlertAction(title: "Ok", style: UIAlertActionStyle.Default, handler: nil))
                    self.presentViewController(alert, animated: true, completion: nil)

                }
                
                
            }, failure:{(error:NSError!) -> Void in
                //handle failure response by adding an alert
                dispatch_async(dispatch_get_main_queue(), {
                
                    self.actInd.stopAnimating()
                    var alert = UIAlertController(title: "Alert", message: error.localizedDescription, preferredStyle: UIAlertControllerStyle.Alert)
                    alert.addAction(UIAlertAction(title: "Ok", style: UIAlertActionStyle.Default, handler: nil))
                    self.presentViewController(alert, animated: true, completion: nil)
                    
                })
        })

    }
    
    
    //these are the AboutMeDelegate and UIImagePickerControllerDelegate methods
    //these are used to select and change the user image in the about me screnn
    func showImagePicker(imagePicker:UIImagePickerController){
        imagePicker.delegate = self
        self.presentViewController(imagePicker, animated: true) { () -> Void in
            
        }
    }
    
    func imagePickerController(picker: UIImagePickerController, didFinishPickingImage image: UIImage!, editingInfo: [NSObject : AnyObject]!) {
        self.delegate?.setDoctorDp(image)
        self.dismissViewControllerAnimated(true, completion: { () -> Void in
            
        })
        
    }
    
    func imagePickerControllerDidCancel(picker: UIImagePickerController) {
        self.dismissViewControllerAnimated(true, completion: { () -> Void in
            
        })
    }
}
