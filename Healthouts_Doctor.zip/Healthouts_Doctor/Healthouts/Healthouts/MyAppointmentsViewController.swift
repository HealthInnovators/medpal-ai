
//
//  MyAppointmentsViewController.swift
//  Healthouts
//
//  Created by Y.Bharath Kumar Reddy on 21/06/15.
//  Copyright (c) 2015 Y.Bharath Kumar Reddy. All rights reserved.
//

import UIKit

class MyAppointmentsViewController: UIViewController,UITableViewDelegate,UITableViewDataSource {

    //required outlets
    @IBOutlet weak var tableView: UITableView!
   
    //required variables
    var tableData = []
    var actInd : UIActivityIndicatorView = UIActivityIndicatorView(frame: CGRectMake(0,0, 50, 50)) as UIActivityIndicatorView
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        //register the custom cell
        var nib1 = UINib(nibName: "AppointmentsTableViewCell", bundle: nil)
        tableView.registerNib(nib1, forCellReuseIdentifier: "AppointmentsCell")
        self.tableView.hidden = true
        
    }

    override func viewWillAppear(animated: Bool) {
        super.viewWillAppear(true)
        
        //get the data..
        getData()
    }
    
    //call the service url
    func getData(){
        actInd.center = CGPointMake(self.view.center.x, self.view.center.y - 64)
        actInd.hidesWhenStopped = true
        actInd.activityIndicatorViewStyle = UIActivityIndicatorViewStyle.White
        actInd.backgroundColor = UIColor.blackColor()
        actInd.layer.cornerRadius = 5
        view.addSubview(actInd)
        actInd.startAnimating()
        
        var userInfo = NSUserDefaults.standardUserDefaults().objectForKey("userInfo") as? NSDictionary
        var customerId = userInfo?.objectForKey("customerId") as! Int
        var customerEmail = userInfo?.objectForKey("emailId") as! String
        
        SRWebClient.POST("http://healthouts.com/appDocAppointments?")
            .data(["CID":customerId,"cEmail":customerEmail])
            .send({ (response:AnyObject!, status:Int) -> Void in
                self.actInd.stopAnimating()
                var err: NSError?
                var data = (response as! String).dataUsingEncoding(NSUTF8StringEncoding, allowLossyConversion: true)
                if let jsonResult = NSJSONSerialization.JSONObjectWithData(data!, options: NSJSONReadingOptions.MutableContainers, error: &err) as? NSMutableArray {
                    dispatch_async(dispatch_get_main_queue(), {
                        
                        self.tableData = jsonResult
                        self.tableView.hidden = false
                        self.tableView.reloadData()
                        
                    })
                   
                }else{
                    self.addAlert((err?.localizedDescription)!)
                }
                    
                
            }, failure: { (error) -> Void in
                dispatch_async(dispatch_get_main_queue(), {
                    
                    self.actInd.stopAnimating()
                    self.addAlert(error.localizedDescription)
                    
                        
                })
                    
        })
    }
    
    //add alert view
    func addAlert(message:String){
        var alert = UIAlertController(title: "Alert", message: message, preferredStyle: UIAlertControllerStyle.Alert)
        alert.addAction(UIAlertAction(title: "ok", style: UIAlertActionStyle.Default, handler: nil))
        self.presentViewController(alert, animated: true, completion: nil)
    }
    
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    //populate the table view
    func tableView(tableView: UITableView, cellForRowAtIndexPath indexPath: NSIndexPath) -> UITableViewCell {
        
        var identifier = "AppointmentsCell"
        var cell  = tableView.dequeueReusableCellWithIdentifier(identifier) as! AppointmentsTableViewCell
        
        
        var appointmentInfo = tableData[tableData.count - indexPath.row - 1] as! NSDictionary
        
        if let customerName = appointmentInfo.objectForKey("customerName") as? String{
            cell.nameLabel.text = customerName
        }else{
            cell.nameLabel.text = ""
        }
        if let customerCity = appointmentInfo.objectForKey("customerCity") as? String{
            cell.placeLabel.text = customerCity
        }else{
            cell.placeLabel.text = ""
        }
        if let customerEmail = appointmentInfo.objectForKey("customerEmail") as? String{
            cell.emailLabel.text = customerEmail
        }else if let customerPhone = appointmentInfo.objectForKey("customerPhone") as? String{
            cell.emailLabel.text = customerPhone
        }else{
           cell.emailLabel.text = ""
        }
        
        var date = appointmentInfo["appointmentDate"] as! String
        var time = appointmentInfo["appointmentTime"] as! String
        cell.dateTimeLabel.text = date + " " + time
        
        cell.nameLabel.textColor = UIColor(red: 0, green: 147/255, blue: 59/255, alpha: 1)
        cell.bgView.backgroundColor = UIColor.whiteColor()
        cell.selectionStyle = UITableViewCellSelectionStyle.None
        
        return cell
        
    }
    
    //number of tableview cells
    func tableView(tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return tableData.count
    }

}
