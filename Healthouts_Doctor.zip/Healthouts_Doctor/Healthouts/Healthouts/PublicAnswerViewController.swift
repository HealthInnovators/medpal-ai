//
//  PublicAnswerViewController.swift
//  Healthouts
//
//  Created by Y.Bharath Kumar Reddy on 07/07/15.
//  Copyright (c) 2015 Y.Bharath Kumar Reddy. All rights reserved.
//

import UIKit

class PublicAnswerViewController: UIViewController,UITextFieldDelegate,UITextViewDelegate {

    //required outlets..
    @IBOutlet weak var answerTextView: UITextView!
    @IBOutlet weak var summaryTextField: UITextField!
    @IBOutlet weak var contentView: UIView!
    @IBOutlet weak var scrollView: UIScrollView!
    
    //required variables..
    var actInd : UIActivityIndicatorView = UIActivityIndicatorView(frame: CGRectMake(0,0, 50, 50)) as UIActivityIndicatorView
    var questionId = 0
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        //set the left and right constraints of the scroll view..
        var leftConstraint = NSLayoutConstraint(item: self.contentView, attribute: NSLayoutAttribute.Leading, relatedBy: NSLayoutRelation.Equal, toItem: self.view, attribute: NSLayoutAttribute.Left, multiplier: 1, constant: 0)
        self.view.addConstraint(leftConstraint)
        
        var rightConstraint = NSLayoutConstraint(item: self.contentView, attribute: NSLayoutAttribute.Trailing, relatedBy: NSLayoutRelation.Equal, toItem: self.view, attribute: NSLayoutAttribute.Right, multiplier: 1, constant: 0)
        self.view.addConstraint(rightConstraint)
        
        //add the keyboard notifications..
        NSNotificationCenter.defaultCenter().addObserver(self, selector: "keyboardWillBeShown:", name: UIKeyboardWillShowNotification, object: nil)
        NSNotificationCenter.defaultCenter().addObserver(self, selector: "keyboardWillBeHidden:", name: UIKeyboardWillHideNotification, object: nil)
        
        //set the text field delegate..
        summaryTextField.delegate = self
        answerTextView.delegate = self
        
        //set the answer text view properties..
        answerTextView.textColor = UIColor.lightGrayColor()
        answerTextView.layer.borderColor = UIColor(red: 0, green: 147/255, blue: 59/255, alpha: 0.86).CGColor
        answerTextView.layer.borderWidth = 1
        answerTextView.layer.cornerRadius = 5
        
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    
    //send the answer..
    @IBAction func sendButtonPressed(sender: AnyObject) {
        
        //resign the first responder
        summaryTextField.resignFirstResponder()
        answerTextView.resignFirstResponder()
        
        //start the activity indicator
        actInd.center = self.view.center
        actInd.hidesWhenStopped = true
        actInd.activityIndicatorViewStyle = UIActivityIndicatorViewStyle.White
        actInd.backgroundColor = UIColor.blackColor()
        actInd.layer.cornerRadius = 5
        view.addSubview(actInd)
        actInd.startAnimating()
        
        //prepare the parameters to be sent
        var userInfo = NSUserDefaults.standardUserDefaults().objectForKey("userInfo") as? NSDictionary
        var customerId = userInfo?.objectForKey("customerId") as! Int
        var customerEmail = userInfo?.objectForKey("emailId") as! String
        
        //input validation
        if(summaryTextField.text == "" && answerTextView.text == "Enter your brief answer"){
            self.actInd.stopAnimating()
            var alert = UIAlertController(title: "Alert", message: "Kindly fill in atleast one of the fields", preferredStyle: UIAlertControllerStyle.Alert)
            alert.addAction(UIAlertAction(title: "ok", style: UIAlertActionStyle.Default, handler: nil))
            self.presentViewController(alert, animated: true, completion: nil)
        }else{
            
            //if input validation succeeds,call the service url with the parameters using SRWebClient
            SRWebClient.POST("http://healthouts.com/appSendFreeAnswer?")
                .data(["CID":customerId,"cEmail":customerEmail,"questionId":self.questionId,"summary":summaryTextField.text,"details":answerTextView.text])
                .send({ (response:AnyObject!, status:Int) -> Void in
                    self.actInd.stopAnimating()
                    var err: NSError?
                    var data = (response as! String).dataUsingEncoding(NSUTF8StringEncoding, allowLossyConversion: true)
                    if let jsonResult = NSJSONSerialization.JSONObjectWithData(data!, options: NSJSONReadingOptions.MutableContainers, error: &err) as? NSDictionary {
                        dispatch_async(dispatch_get_main_queue(), {
                            if(jsonResult.objectForKey("status") as! String == "1"){
                                self.addSuccessAlert(jsonResult.objectForKey("message") as! String)
                            }else{
                                self.addFailureAlert(jsonResult.objectForKey("message") as! String)
                            }
                            
                        })
                    }else{
                        self.addFailureAlert((err?.localizedDescription)!)
                        
                    }
                }, failure: { (error) -> Void in
                    dispatch_async(dispatch_get_main_queue(), {
                            
                        self.actInd.stopAnimating()
                        self.addFailureAlert("Kindly Make sure you are connected to the internet")
                            
                    })
                })
        }
    }
    
    
    //functions to add alerts
    func addSuccessAlert(message:String){
        var alert = UIAlertController(title: "Alert", message: message, preferredStyle: UIAlertControllerStyle.Alert)
        alert.addAction(UIAlertAction(title: "ok", style: UIAlertActionStyle.Default, handler: { (action:UIAlertAction!) -> Void in
            //delete the cell containing the current question as it has been answered
            var previousViewController = self.navigationController?.viewControllers[0] as! PublicQuestionsViewController
            var selectedIndex = previousViewController.selectedIndex
            previousViewController.tableData.removeObjectAtIndex(selectedIndex.row)
            previousViewController.tableView.reloadData()
            self.navigationController?.popViewControllerAnimated(true)
            
        }))
        self.presentViewController(alert, animated: true, completion: nil)
    }
    
    func addFailureAlert(message:String){
        var alert = UIAlertController(title: "Alert", message: message, preferredStyle: UIAlertControllerStyle.Alert)
        alert.addAction(UIAlertAction(title: "ok", style: UIAlertActionStyle.Default, handler: nil))
        self.presentViewController(alert, animated: true, completion: nil)
    }
    
    //keyboard notification functions..
    func keyboardWillBeHidden(notification:NSNotification){
        var contentInsets = UIEdgeInsetsZero
        self.scrollView.contentInset = contentInsets
        self.scrollView.scrollIndicatorInsets = contentInsets
    }
    
    func keyboardWillBeShown(notification:NSNotification){
        if let userInfo = notification.userInfo {
            if let keyboardSize = (userInfo[UIKeyboardFrameBeginUserInfoKey] as? NSValue)?.CGRectValue() {
                //self.bottomConstraint.constant = -keyboardSize.height
                var contentInsets = UIEdgeInsetsMake(0, 0, keyboardSize.height, 0)
                self.scrollView.contentInset = contentInsets
                self.scrollView.scrollIndicatorInsets = contentInsets
                var rect = self.contentView.frame
                rect.size.height -= keyboardSize.height
                /*if (!answerTextView.isFirstResponder() && !CGRectContainsPoint(rect, self.summaryTextField.frame.origin)) {
                    var scrollPoint = CGPointMake(0.0, self.summaryTextField.frame.origin.y - (keyboardSize.height - self.summaryTextField.frame.size.height))
                    self.scrollView.setContentOffset(scrollPoint, animated: false)
                }else{
                    var scrollPoint = CGPointMake(0.0, self.answerTextView.frame.origin.y - (keyboardSize.height - self.answerTextView.frame.size.height) + 64)
                    self.scrollView.setContentOffset(scrollPoint, animated: false)
                }*/
            }
        }
    }
    
    //textview and textfield delegate methods
    func textViewDidBeginEditing(textView: UITextView) {
        if(textView.text == "Enter your brief answer"){
            textView.text = ""
            textView.textColor = UIColor.blackColor()
        }
    }
    
    func textViewDidEndEditing(textView: UITextView) {
        if(textView.text == ""){
            textView.text = "Enter your brief answer"
            textView.textColor = UIColor.lightGrayColor()
        }
    }

    func textFieldShouldReturn(textField: UITextField) -> Bool {
        textField.resignFirstResponder()
        return true
    }
    
    //pop the present view
    @IBAction func backButtonPressed(sender: AnyObject) {
        self.navigationController?.popViewControllerAnimated(true)
    }
}
