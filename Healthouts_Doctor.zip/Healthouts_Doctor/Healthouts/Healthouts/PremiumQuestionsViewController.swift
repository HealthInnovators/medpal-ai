//
//  PremiumQuestionsViewController.swift
//  Healthouts
//
//  Created by Y.Bharath Kumar Reddy on 01/07/15.
//  Copyright (c) 2015 Y.Bharath Kumar Reddy. All rights reserved.
//

import UIKit

class PremiumQuestionsViewController: UIViewController,UITableViewDataSource,UITableViewDelegate,PaidQuestionCellDelegate {

    //required outlets
    @IBOutlet weak var navBarView: UIView!
    @IBOutlet weak var tableView: UITableView!
    
    //reuqired variables
    var myRowHeightEstimateCache = [String:CGFloat]()
    var actInd : UIActivityIndicatorView = UIActivityIndicatorView(frame: CGRectMake(0,0, 50, 50)) as UIActivityIndicatorView
    var tableData:NSMutableArray = []
    var selectedAttachmentName = ""
    var imageCache = [String:UIImage]()
    var selectedIndex = NSIndexPath()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        
        
        //set the nav bar view properties
        navBarView.layer.shadowColor = UIColor.blackColor().CGColor
        navBarView.layer.shadowOffset = CGSizeMake(0.5, 0.5)
        navBarView.layer.shadowRadius = 3.0
        navBarView.layer.shadowOpacity = 1.0
        
        //register the paid question cell
        var nib1 = UINib(nibName: "PaidQuestionTableViewCell", bundle: nil)
        tableView.registerNib(nib1, forCellReuseIdentifier: "PaidQuestionCell")
        
        self.tableView.hidden = true
    }

    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    

    override func viewWillAppear(animated: Bool) {
        super.viewWillAppear(true)
        
        getData()
    }
    
    
    //get the premium questions
    func getData(){
        //start the activity indicator
        actInd.center = self.view.center
        actInd.hidesWhenStopped = true
        actInd.activityIndicatorViewStyle = UIActivityIndicatorViewStyle.White
        actInd.backgroundColor = UIColor.blackColor()
        actInd.layer.cornerRadius = 5
        view.addSubview(actInd)
        actInd.startAnimating()
        
        //prepare the parameters to be sent
        var userInfo = NSUserDefaults.standardUserDefaults().objectForKey("userInfo") as? NSDictionary
        var customerId = userInfo?.objectForKey("customerId") as! Int
        var customerEmail = userInfo?.objectForKey("emailId") as! String
        
        //call the service url with parameters using SRWebClient
        SRWebClient.POST("http://healthouts.com/appGetDoctorPaidQuestions?")
            .data(["CID":customerId,"cEmail":customerEmail])
            .send({ (response:AnyObject!, status:Int) -> Void in
                self.actInd.stopAnimating()
                var err: NSError?
                var data = (response as! String).dataUsingEncoding(NSUTF8StringEncoding, allowLossyConversion: true)
                if let jsonResult = NSJSONSerialization.JSONObjectWithData(data!, options: NSJSONReadingOptions.MutableContainers, error: &err) as? NSMutableArray {
                    dispatch_async(dispatch_get_main_queue(), {
                    
                        self.tableData = jsonResult
                        self.tableView.hidden = false
                        self.tableView.reloadData()
                        
                    })
                  
                }else{
                    self.addAlert((err?.localizedDescription)!)
                }
                
                }, failure: { (error) -> Void in
                    dispatch_async(dispatch_get_main_queue(), {
                    
                        self.actInd.stopAnimating()
                        self.addAlert(error.localizedDescription)
                        
                    })
            })
    }
    
    //function to add alert
    func addAlert(message:String){
        var alert = UIAlertController(title: "Alert", message: message, preferredStyle: UIAlertControllerStyle.Alert)
        alert.addAction(UIAlertAction(title: "ok", style: UIAlertActionStyle.Default, handler: nil))
        self.presentViewController(alert, animated: true, completion: nil)
    }
    
    //number of cells
    func tableView(tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return tableData.count - 1
    }
    
    //populate the table view
    func tableView(tableView: UITableView, cellForRowAtIndexPath indexPath: NSIndexPath) -> UITableViewCell {
        var identifier = "PaidQuestionCell"
        var cell  = tableView.dequeueReusableCellWithIdentifier(identifier) as! PaidQuestionTableViewCell
        
        var questionData:NSDictionary = tableData[indexPath.row] as! NSDictionary
        
        cell.selectionStyle = UITableViewCellSelectionStyle.None
        cell.userNameLabel.text = questionData.objectForKey("customerName") as? String
        cell.questionSubjectLabel.text = questionData.objectForKey("csubject") as? String
        cell.questionBodyLabel.text = questionData.objectForKey("cdetails") as? String
    
        if let healthFile = questionData.objectForKey("cHealthfile") as? String{
            if(healthFile != ""){
                cell.attachmentsButton.setTitle(healthFile, forState: UIControlState.Normal)
            }else{
                cell.attachmentsButton.setTitle("No Attachments", forState: UIControlState.Normal)
            }
        }else{
            cell.attachmentsButton.setTitle("No Attachments", forState: UIControlState.Normal)
        }
        
        cell.containerView.layer.cornerRadius = 5
        cell.containerView.layer.zPosition = 5
        
        cell.userImageView.layer.cornerRadius = 30
        cell.userImageView.layer.masksToBounds = true
        cell.answerButton.layer.cornerRadius = 5
        
        if let userName = questionData.objectForKey("cImage") as? String{
            
            var userImgName = userName.stringByReplacingOccurrencesOfString(" ", withString: "%20")
            var imgPath = "http://healthouts.com/img/" + userImgName
            var imgUrl = NSURL(string: imgPath)
            
            if let img = imageCache[imgPath]{
                cell.userImageView.image = img
            }else{
                SDWebImageDownloader.sharedDownloader().downloadImageWithURL(imgUrl, options: nil, progress: { (receivedSize:Int, expectedSize:Int) -> Void in
                
                    }) { (image, data, error, finished) -> Void in
                        if(error == nil){
                            cell.userImageView.image = image
                            self.imageCache[imgPath] = image
                        }else{
                            cell.userImageView.image = UIImage(named: "dummydp")
                        }
                    }
                }
            
        }else{
            cell.userImageView.image = UIImage(named: "dummydp")
        }
        
            
        cell.delegate = self
            
        return cell
    }
    
    
    //estimated height 
    //return if height is present myRowHeightEstimateCache
    func tableView(tableView: UITableView, estimatedHeightForRowAtIndexPath indexPath: NSIndexPath) -> CGFloat {
        
            if let height = myRowHeightEstimateCache["\(indexPath.row)"]
            {
                return height
            }
            else
            {
                return 300
            }
    }
    
    //height of the row
    func tableView(tableView: UITableView, heightForRowAtIndexPath indexPath: NSIndexPath) -> CGFloat {
        return UITableViewAutomaticDimension
    }
    
    //store the cells height in myRowHeightEstimateCache
    func tableView(tableView: UITableView, didEndDisplayingCell cell: UITableViewCell, forRowAtIndexPath indexPath: NSIndexPath) {
        myRowHeightEstimateCache["\(indexPath.row)"] = CGRectGetHeight(cell.frame)
    }
    
    
    //show attachment if present
    func showAttachment(attachmentName: String) {
        if(attachmentName == "No Attachments"){
            
        }else{
            self.saveImage(attachmentName)
            self.selectedAttachmentName = attachmentName
            performSegueWithIdentifier("ShowAttachment", sender: self)
        }
    }
    
    //take to premium answer view controller..
    func answerNow(button: UIButton) {
        var buttonFrame = button.convertRect(button.bounds, toView: self.tableView)
        var indexPath = self.tableView.indexPathForRowAtPoint(buttonFrame.origin)
        selectedIndex = indexPath!
        self.performSegueWithIdentifier("AnswerNow", sender: self)
    }
    
    //pass data before performing segue
    override func prepareForSegue(segue: UIStoryboardSegue, sender: AnyObject?) {
        if(segue.identifier == "AnswerNow"){
            var destViewController = segue.destinationViewController as! PremiumAnswerViewController
            var selectedQuestion = self.tableData.objectAtIndex(selectedIndex.row) as! NSDictionary
            destViewController.chatId = selectedQuestion.objectForKey("chatid") as! Int
        }else if(segue.identifier == "ShowAttachment"){
            var destViewController = segue.destinationViewController as! ShowAttachmentViewController
            destViewController.attachmentName = self.selectedAttachmentName
        }
    }
    
    //show menu
    @IBAction func showMenu(sender: AnyObject) {
        self.view.endEditing(true)
        self.frostedViewController.view.endEditing(true)
        self.frostedViewController.presentMenuViewController()
    }
    
    //save the image/file to documents
    func saveImage(fileName: String) {
        var imgPath = "http://healthouts.com/img/\(fileName)"
        var imgUrl = NSURL(string: imgPath)
        
        //use the SDWebImageDownloader
        SDWebImageDownloader.sharedDownloader().downloadImageWithURL(imgUrl, options: nil, progress: { (receivedSize:Int, expectedSize:Int) -> Void in
            
            }) { (image, data, error, finished) -> Void in
                if(error != nil){
                    
                }else{
                    
                    //if the image is downloaded successfully
                    //save it to the documents directory
                    let fileManager = NSFileManager.defaultManager()
                    
                    var paths = NSSearchPathForDirectoriesInDomains(.DocumentDirectory, .UserDomainMask, true)[0] as! String
                    
                    var filePathToWrite = "\(paths)/\(fileName)"
                    
                    var imageData: NSData = UIImagePNGRepresentation(image)
                    
                    fileManager.createFileAtPath(filePathToWrite, contents: imageData, attributes: nil)
                }
        }
    }
}





