//
//  LoginViewController.swift
//  Healthouts
//
//  Created by Y.Bharath Kumar Reddy on 21/06/15.
//  Copyright (c) 2015 Y.Bharath Kumar Reddy. All rights reserved.
//

import UIKit

class LoginViewController: UIViewController,UITextFieldDelegate {

    //required outlets..
    @IBOutlet weak var infoLabel: UILabel!
    @IBOutlet weak var loginButton: UIButton!
    @IBOutlet weak var passwordTextField: UITextField!
    @IBOutlet weak var usernameTextField: UITextField!
    @IBOutlet weak var navBarView: UIView!
    @IBOutlet weak var contentView: UIView!
    @IBOutlet weak var scrollView: UIScrollView!
    @IBOutlet weak var signupButton: UIButton!
    
    //required variables..
    var actInd : UIActivityIndicatorView = UIActivityIndicatorView(frame: CGRectMake(0,0, 50, 50)) as UIActivityIndicatorView
    override func viewDidLoad() {
        super.viewDidLoad()

        //info label is for showing alerts like wrong credentials when logged in is pressed etc..
        infoLabel.text = ""
        
        //set the nav bar properties like shadow etc
        navBarView.layer.shadowColor = UIColor.blackColor().CGColor
        navBarView.layer.shadowOffset = CGSizeMake(0.5, 0.5)
        navBarView.layer.shadowRadius = 3.0
        navBarView.layer.shadowOpacity = 1.0
        
        //set the left and right constraints of the scroll view
        var leftConstraint = NSLayoutConstraint(item: self.contentView, attribute: NSLayoutAttribute.Leading, relatedBy: NSLayoutRelation.Equal, toItem: self.view, attribute: NSLayoutAttribute.Left, multiplier: 1, constant: 0)
        self.view.addConstraint(leftConstraint)
        var rightConstraint = NSLayoutConstraint(item: self.contentView, attribute: NSLayoutAttribute.Trailing, relatedBy: NSLayoutRelation.Equal, toItem: self.view, attribute: NSLayoutAttribute.Right, multiplier: 1, constant: 0)
        self.view.addConstraint(rightConstraint)
        
        //add keyboard notification
        NSNotificationCenter.defaultCenter().addObserver(self, selector: "keyboardWillBeShown:", name: UIKeyboardWillShowNotification, object: nil)
        NSNotificationCenter.defaultCenter().addObserver(self, selector: "keyboardWillBeHidden:", name: UIKeyboardWillHideNotification, object: nil)
        
        //set the textfield delegate
        passwordTextField.delegate = self
        usernameTextField.delegate = self
        
        //set the corner radius for the buttons
        loginButton.layer.cornerRadius = 5
        signupButton.layer.cornerRadius = 5
        
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    override func viewWillDisappear(animated: Bool) {
        super.viewWillDisappear(true)
        
        //remove all notifications
        NSNotificationCenter.defaultCenter().removeObserver(self)
    }
    
    
    //keyboard notification functions to move the scroll view up and down on showing or hiding the keyboard
    func keyboardWillBeHidden(notification:NSNotification){
        var contentInsets = UIEdgeInsetsZero
        self.scrollView.contentInset = contentInsets
        self.scrollView.scrollIndicatorInsets = contentInsets
    }
    
    func keyboardWillBeShown(notification:NSNotification){
        if let userInfo = notification.userInfo {
            if let keyboardSize = (userInfo[UIKeyboardFrameBeginUserInfoKey] as? NSValue)?.CGRectValue() {
                //self.bottomConstraint.constant = -keyboardSize.height
                var contentInsets = UIEdgeInsetsMake(0, 0, keyboardSize.height, 0)
                self.scrollView.contentInset = contentInsets
                self.scrollView.scrollIndicatorInsets = contentInsets
                var rect = self.contentView.frame
                rect.size.height -= keyboardSize.height
                if (!CGRectContainsPoint(rect, self.usernameTextField.frame.origin)) {
                    var scrollPoint = CGPointMake(0.0, self.usernameTextField.frame.origin.y - (keyboardSize.height - self.usernameTextField.frame.size.height))
                    self.scrollView.setContentOffset(scrollPoint, animated: false)
                }
            }
        }
    }
    
    //text field delegate methods..
    func textFieldShouldReturn(textField: UITextField) -> Bool {
        textField.resignFirstResponder()
        return true
    }
    
    func textFieldShouldBeginEditing(textField: UITextField) -> Bool {
        infoLabel.text = ""
        return true
        
    }
    
    
    //call the login service url..
    @IBAction func loginButtonPressed(sender: AnyObject) {
        usernameTextField.resignFirstResponder()
        passwordTextField.resignFirstResponder()
        
        infoLabel.text = ""
        actInd.center = self.view.center
        actInd.hidesWhenStopped = true
        actInd.activityIndicatorViewStyle = UIActivityIndicatorViewStyle.White
        actInd.backgroundColor = UIColor.blackColor()
        actInd.layer.cornerRadius = 5
        view.addSubview(actInd)
        actInd.startAnimating()
        
        //check if both textfields are filled
        if(usernameTextField.text == "" || passwordTextField.text == ""){
            
            infoLabel.text = "Please Fill in all the fields"
            actInd.stopAnimating()
            
        }else{
            
        SRWebClient.GET("http://healthouts.com/appLogin?email=\(usernameTextField.text)&pass=\(passwordTextField.text)",
            success:{(response:AnyObject!, status:Int) -> Void in
                //process success response
                
                self.actInd.stopAnimating()
                var err: NSError?
                var data = (response as! String).dataUsingEncoding(NSUTF8StringEncoding, allowLossyConversion: true)
                if let jsonResult = NSJSONSerialization.JSONObjectWithData(data!, options: NSJSONReadingOptions.MutableContainers, error: &err) as? NSDictionary {
                    
                    dispatch_async(dispatch_get_main_queue(), {
                    
                        if(jsonResult["status"] as! String == "1" && jsonResult["customerType"] as! String == "DOCTOR"){
                      
                            NSUserDefaults.standardUserDefaults().setBool(true, forKey: "isLoggedIn")
                            NSUserDefaults.standardUserDefaults().setObject(jsonResult, forKey: "userInfo")
                            self.performSegueWithIdentifier("LoginSuccess", sender: self)
                            
                        
                        }else{
                            self.infoLabel.text = "invalid login parameters"
                        }
                    })
                    
                }else{
                        self.infoLabel.text = "There was an error parsing the data"
                }
                
                
            }, failure:{(error:NSError!) -> Void in
                //process failure response
                dispatch_async(dispatch_get_main_queue(), {
                    self.actInd.stopAnimating()   
                    self.infoLabel.text = error.localizedDescription
                    
                })
        })
        }
    }
    
}
