//
//  PublicQuestionsViewController.swift
//  Healthouts
//
//  Created by Y.Bharath Kumar Reddy on 01/07/15.
//  Copyright (c) 2015 Y.Bharath Kumar Reddy. All rights reserved.
//

import UIKit

class PublicQuestionsViewController: UIViewController,UITableViewDelegate,UITableViewDataSource,PublicQuestionCellDelegate {

    //required outlets
    @IBOutlet weak var tableView: UITableView!
   
    //required variables
    var count = 0
    var myRowHeightEstimateCache = [String:CGFloat]()
    var actInd : UIActivityIndicatorView = UIActivityIndicatorView(frame: CGRectMake(0,0, 50, 50)) as UIActivityIndicatorView
    var tableData:NSMutableArray = []
    var selectedIndex = NSIndexPath()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        //register the public questions cell
        var nib1 = UINib(nibName: "PublicQuestionTableViewCell", bundle: nil)
        tableView.registerNib(nib1, forCellReuseIdentifier: "PublicQuestionCell")
        
        self.tableView.hidden = true
        
        //get the data
        getData()
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    override func viewWillAppear(animated: Bool) {
        super.viewWillAppear(true)

    }
    
    //function to get the data
    func getData(){
        //start the activity indicator
        actInd.center = self.view.center
        actInd.hidesWhenStopped = true
        actInd.activityIndicatorViewStyle = UIActivityIndicatorViewStyle.White
        actInd.backgroundColor = UIColor.blackColor()
        actInd.layer.cornerRadius = 5
        view.addSubview(actInd)
        actInd.startAnimating()
        
        //prepsre the parameters to be sent with the url
        var userInfo = NSUserDefaults.standardUserDefaults().objectForKey("userInfo") as? NSDictionary
        var customerId = userInfo?.objectForKey("customerId") as! Int
        var customerEmail = userInfo?.objectForKey("emailId") as! String
        
        //call the service url with the parameters using srwebclient
        SRWebClient.POST("http://healthouts.com/appGetPublicQuestion?")
            .data(["count":count,"CID":customerId,"cEmail":customerEmail])
            .send({ (response:AnyObject!, status:Int) -> Void in
                self.actInd.stopAnimating()
                var err: NSError?
                var data = (response as! String).dataUsingEncoding(NSUTF8StringEncoding, allowLossyConversion: true)
                if let jsonResult = NSJSONSerialization.JSONObjectWithData(data!, options: NSJSONReadingOptions.MutableContainers, error: &err) as? NSMutableArray {
                    
                    dispatch_async(dispatch_get_main_queue(), {
                        self.tableData.removeLastObject()
                        self.tableData.addObjectsFromArray(jsonResult as [AnyObject])
                        self.tableView.hidden = false
                        self.tableView.reloadData()
                        
                    })
                
                }else{
                    self.tableView.hidden = true
                    self.addAlert((err?.localizedDescription)!)
                }
                
            }, failure: { (error) -> Void in
                dispatch_async(dispatch_get_main_queue(), {
                    
                    self.actInd.stopAnimating()
                    self.addAlert(error.localizedDescription)
                        
                })
            })
    }
    
    //function to add alert
    func addAlert(message:String){
        var alert = UIAlertController(title: "Alert", message: message, preferredStyle: UIAlertControllerStyle.Alert)
        alert.addAction(UIAlertAction(title: "ok", style: UIAlertActionStyle.Default, handler: nil))
        self.presentViewController(alert, animated: true, completion: nil)
    }
    
    //populate the tableview..
    func tableView(tableView: UITableView, cellForRowAtIndexPath indexPath: NSIndexPath) -> UITableViewCell {
        var identifier = "PublicQuestionCell"
        var cell:PublicQuestionTableViewCell  = tableView.dequeueReusableCellWithIdentifier(identifier) as! PublicQuestionTableViewCell
        
        cell.containerView.layer.cornerRadius = 5
        cell.containerView.layer.zPosition = 5
        cell.selectionStyle = UITableViewCellSelectionStyle.None
        
        var questionInfo:NSDictionary = tableData[indexPath.row] as! NSDictionary
        
        cell.questionLabel.text = questionInfo.objectForKey("question") as? String
        cell.timeLabel.text = questionInfo.objectForKey("time") as? String
        cell.answerNowButton.layer.cornerRadius = 5
        cell.delegate = self
        
        self.count = questionInfo.objectForKey("count") as! Int
        
        //reload data when last cell is reached
        if(indexPath.row == self.tableData.count-2 && count != -1){
            getData()
        }
        
        return cell
    }
    
    //number of cells
    func tableView(tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        
        return tableData.count - 1
    }
    
    //cache the cell's height
    func tableView(tableView: UITableView, didEndDisplayingCell cell: UITableViewCell, forRowAtIndexPath indexPath: NSIndexPath) {
        myRowHeightEstimateCache["\(indexPath.row)"] = CGRectGetHeight(cell.frame)
    }

    //return the height from cache if exists else return 150
    func tableView(tableView: UITableView, estimatedHeightForRowAtIndexPath indexPath: NSIndexPath) -> CGFloat {
        
        if let height = myRowHeightEstimateCache["\(indexPath.row)"]
        {
            return height
        }
        else
        {
            return 150
        }
    }
    
    //return height
    func tableView(tableView: UITableView, heightForRowAtIndexPath indexPath: NSIndexPath) -> CGFloat {
        return UITableViewAutomaticDimension
    }
    
    //take the user to the answer screen
    func answerNow(button: UIButton) {
    
        var buttonFrame = button.convertRect(button.bounds, toView: self.tableView)
        var indexPath = self.tableView.indexPathForRowAtPoint(buttonFrame.origin)
        self.selectedIndex = indexPath!
        self.performSegueWithIdentifier("AnswerNow", sender: self)
        
    }
    
    //pass the data before performing the segue
    override func prepareForSegue(segue: UIStoryboardSegue, sender: AnyObject?) {
        if(segue.identifier == "AnswerNow"){
            var destViewController = segue.destinationViewController as! PublicAnswerViewController
            var selectedQuestion = self.tableData.objectAtIndex(selectedIndex.row) as! NSDictionary
            destViewController.questionId = selectedQuestion.objectForKey("questionId") as! Int
        }
    }
    
    //show the menu on pressing side menu button
    @IBAction func showMenuPressed(sender: AnyObject) {
        self.view.endEditing(true)
        self.frostedViewController.view.endEditing(true)
        self.frostedViewController.presentMenuViewController()
    }
}
