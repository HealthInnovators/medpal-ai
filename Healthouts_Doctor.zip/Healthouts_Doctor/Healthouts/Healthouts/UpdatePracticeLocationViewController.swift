//
//  UpdatePracticeLocationViewController.swift
//  Healthouts
//
//  Created by Y.Bharath Kumar Reddy on 23/06/15.
//  Copyright (c) 2015 Y.Bharath Kumar Reddy. All rights reserved.
//

import UIKit

class UpdatePracticeLocationViewController: UIViewController,UITextFieldDelegate {

    //outlets from the storyboard
    @IBOutlet weak var contentView: UIView!
    @IBOutlet weak var scrollView: UIScrollView!
    @IBOutlet weak var clinicNameTextField: UITextField!
    @IBOutlet weak var address1TextField: UITextField!
    @IBOutlet weak var address2TextField: UITextField!
    @IBOutlet weak var cityTextField: UITextField!
    @IBOutlet weak var stateTextField: UITextField!
    @IBOutlet weak var zipcodeTextField: UITextField!
    @IBOutlet weak var contactNumberTextField: UITextField!
    @IBOutlet weak var faxTextField: UITextField!
    @IBOutlet weak var experienceTextField: UITextField!
    @IBOutlet weak var consultationFeeTextField: UITextField!
    @IBOutlet weak var websiteTextField: UITextField!
    
    //required variables
    var selectedTextView:UITextView!
    var selectedTextField:UITextField!
    var actInd : UIActivityIndicatorView = UIActivityIndicatorView(frame: CGRectMake(0,0, 50, 50)) as UIActivityIndicatorView
    
    override func viewDidLoad() {
        super.viewDidLoad()

        //set the textfield and textview delegates
        clinicNameTextField.delegate = self
        address1TextField.delegate = self
        address2TextField.delegate = self
        cityTextField.delegate = self
        stateTextField.delegate = self
        zipcodeTextField.delegate = self
        contactNumberTextField.delegate = self
        faxTextField.delegate = self
        experienceTextField.delegate = self
        consultationFeeTextField.delegate = self
        websiteTextField.delegate = self
        
        contentView.backgroundColor = UIColor.clearColor()
        
        //populate the textfields like clinicName,address etc using the doctorCompleteProfile
        clinicNameTextField.text = doctorCompleteProfile.objectForKey("clinicName") as! String
        address1TextField.text = doctorCompleteProfile.objectForKey("practiceAddress1") as! String
        address2TextField.text = doctorCompleteProfile.objectForKey("practiceAddress2") as! String
        cityTextField.text = doctorCompleteProfile.objectForKey("city") as! String
        stateTextField.text = doctorCompleteProfile.objectForKey("practicestate") as! String
        zipcodeTextField.text = doctorCompleteProfile.objectForKey("zipcode") as! String
        contactNumberTextField.text = doctorCompleteProfile.objectForKey("contact") as! String
        faxTextField.text = doctorCompleteProfile.objectForKey("fax") as! String
        experienceTextField.text = String(doctorCompleteProfile.objectForKey("experience") as! Int)
        consultationFeeTextField.text = String(doctorCompleteProfile.objectForKey("price") as! Int)
        websiteTextField.text = doctorCompleteProfile.objectForKey("practiceUrl") as! String
        
        //set the left and right constraints of the content view of the scroll view
        var leftConstraint = NSLayoutConstraint(item: self.contentView, attribute: NSLayoutAttribute.Leading, relatedBy: NSLayoutRelation.Equal, toItem: self.view, attribute: NSLayoutAttribute.Left, multiplier: 1, constant: 0)
        self.view.addConstraint(leftConstraint)
        
        var rightConstraint = NSLayoutConstraint(item: self.contentView, attribute: NSLayoutAttribute.Trailing, relatedBy: NSLayoutRelation.Equal, toItem: self.view, attribute: NSLayoutAttribute.Right, multiplier: 1, constant: 0)
        self.view.addConstraint(rightConstraint)
    }

    
    override func viewWillAppear(animated: Bool) {
        super.viewWillAppear(true)
        
        //add the keyboard notifications
        NSNotificationCenter.defaultCenter().addObserver(self, selector: "keyboardWillBeShown:", name: UIKeyboardWillShowNotification, object: nil)
        NSNotificationCenter.defaultCenter().addObserver(self, selector: "keyboardWillBeHidden:", name: UIKeyboardWillHideNotification, object: nil)
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    

    //call the service url to save the details
    @IBAction func savePracticeDetailsPressed(sender: AnyObject) {
        //resign the first responders
        if(selectedTextField != nil){
            selectedTextField.resignFirstResponder()
        }
        if(selectedTextView != nil){
            selectedTextView.resignFirstResponder()
        }
        
        //start the activity indicator
        actInd.center = CGPointMake(self.view.center.x, self.view.center.y - 64)
        actInd.hidesWhenStopped = true
        actInd.activityIndicatorViewStyle = UIActivityIndicatorViewStyle.White
        actInd.backgroundColor = UIColor.blackColor()
        actInd.layer.cornerRadius = 5
        view.addSubview(actInd)
        actInd.startAnimating()
        
        //prepare the parameters to be sent with the url
        var userInfo = NSUserDefaults.standardUserDefaults().objectForKey("userInfo")
        var customerId = userInfo?.objectForKey("customerId") as! Int
        var customerEmail = userInfo?.objectForKey("emailId") as! String
        
        //call the SRWebClient with the required url and parameters
        SRWebClient.POST("http://healthouts.com/appSavePracticeDetails?")
            .data(["CID":customerId,"cEmail":customerEmail,"JSONObj":["clinicName":clinicNameTextField.text,"practiceAddress1":address1TextField.text,"practiceAddress2":address2TextField.text,"city":cityTextField.text,"practicestate":stateTextField.text,"zipcode":zipcodeTextField.text,"contact":contactNumberTextField.text,"fax":faxTextField.text,"practiceUrl":websiteTextField.text,"experience":experienceTextField.text,"price":consultationFeeTextField.text]])
            .send({ (response:AnyObject!, status:Int) -> Void in
                self.actInd.stopAnimating()
                var err: NSError?
                var data = (response as! String).dataUsingEncoding(NSUTF8StringEncoding, allowLossyConversion: true)
                if let jsonResult = NSJSONSerialization.JSONObjectWithData(data!, options: NSJSONReadingOptions.MutableContainers, error: &err) as? NSDictionary {
                    
                    dispatch_async(dispatch_get_main_queue(), {
                        
                        self.addAlert(jsonResult["message"] as! String)
                        
                    })
                }else{
                    self.addAlert(err!.localizedDescription)
                }
            }, failure: { (error) -> Void in
                dispatch_async(dispatch_get_main_queue(), {
                        
                    self.addAlert(error.localizedDescription)
                        
                })
                    
            })
    }
    
    //textfield and text view delegate methods
    func textFieldShouldBeginEditing(textField: UITextField) -> Bool {
        self.selectedTextField = textField
        return true
    }
    
    func textFieldShouldReturn(textField: UITextField) -> Bool {
        textField.resignFirstResponder()
        return true
    }
    
    func textViewShouldBeginEditing(textView: UITextView) -> Bool {
        self.selectedTextView = textView
        return true
    }
    
    //add the keyboard notifications
    func keyboardWillBeHidden(notification:NSNotification){
        var contentInsets = UIEdgeInsetsZero
        self.scrollView.contentInset = contentInsets
        self.scrollView.scrollIndicatorInsets = contentInsets
    }
    
    func keyboardWillBeShown(notification:NSNotification){
        if let userInfo = notification.userInfo {
            if let keyboardSize = (userInfo[UIKeyboardFrameBeginUserInfoKey] as? NSValue)?.CGRectValue() {
                //self.bottomConstraint.constant = -keyboardSize.height
                var contentInsets = UIEdgeInsetsMake(0, 0, keyboardSize.height, 0)
                self.scrollView.contentInset = contentInsets
                self.scrollView.scrollIndicatorInsets = contentInsets
                var rect = self.contentView.frame
                rect.size.height -= keyboardSize.height
                if (!CGRectContainsPoint(rect, self.selectedTextField.frame.origin)) {
                    var scrollPoint = CGPointMake(0.0, self.selectedTextField.frame.origin.y - (keyboardSize.height - self.selectedTextField.frame.size.height))
                    self.scrollView.setContentOffset(scrollPoint, animated: false)
                }
            }
        }
    }
    
    
    
    override func viewWillDisappear(animated: Bool) {
        super.viewWillDisappear(true)
        
        //remove all the notifications before the view disappears
        NSNotificationCenter.defaultCenter().removeObserver(self)
    }
    
    //function to add alert
    func addAlert(message:String){
        var alert = UIAlertController(title: "Alert", message: message, preferredStyle: UIAlertControllerStyle.Alert)
        alert.addAction(UIAlertAction(title: "ok", style: UIAlertActionStyle.Default, handler: nil))
        self.presentViewController(alert, animated: true, completion: nil)
    }

}
