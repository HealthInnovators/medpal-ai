//
//  MenuViewController.swift
//  Healthouts
//
//  Created by Y.Bharath Kumar Reddy on 21/06/15.
//  Copyright (c) 2015 Y.Bharath Kumar Reddy. All rights reserved.
//

import UIKit

class MenuViewController: UIViewController,UITableViewDelegate,UITableViewDataSource {

    //required outlets..
    @IBOutlet weak var profileImageView: UIImageView!
    @IBOutlet weak var nameLabel: UILabel!
    @IBOutlet weak var tableView: UITableView!
    
    //required variables..
    var imageCache = [String:UIImage]()
    var menuItems = ["Appointments","Premium Questions","Public Questions","Clinical Cases","Profile Settings","Logout"]
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        //set the properties to make the image in side menu into circular shape
        profileImageView.layer.cornerRadius = 60
        profileImageView.layer.masksToBounds = true
        
    }

    
    override func viewWillAppear(animated: Bool) {
        super.viewWillAppear(true)
        
        //the logged in  user's details are stored as an NSDictionary in the NSUserDefaults() with the key "userInfo"
        //get the image path from the user details
        var userInfo = NSUserDefaults.standardUserDefaults().objectForKey("userInfo") as! NSDictionary
        var docName = userInfo.objectForKey("cImage") as! String
        docName = docName.stringByReplacingOccurrencesOfString(" ", withString: "%20")
        var imgPath = "http://healthouts.com/img/" + docName
        var imgUrl = NSURL(string: imgPath)
        
        //load the image into the side menu
        SDWebImageDownloader.sharedDownloader().downloadImageWithURL(imgUrl, options: nil, progress: { (receivedSize:Int, expectedSize:Int) -> Void in
            
            }) { (image, data, error, finished) -> Void in
                if(error != nil){
                    println(error)
                    self.profileImageView.image = UIImage(named: "dummydp")
                }else{
                    self.profileImageView.image = image
                }
        }
        
        
        //set the user's name in the side menu under the image
        if let userData = NSUserDefaults.standardUserDefaults().objectForKey("userInfo") as? NSDictionary{
            
            if(userData["cName"] as? String != ""){
                nameLabel.text = userData["cName"] as? String
            }else{
                nameLabel.text = ""
            }
        }
        
        //reload the table view in the side menu
        self.tableView.reloadData()
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    //populate the table view with the values in the menuItems Array
    func tableView(tableView: UITableView, cellForRowAtIndexPath indexPath: NSIndexPath) -> UITableViewCell {
        var cell = tableView.dequeueReusableCellWithIdentifier("SideCell") as! UITableViewCell
        cell.textLabel?.text = menuItems[indexPath.row]
        return cell
    }
    
    //number of items in the table view
    func tableView(tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return menuItems.count
    }

    //handle selections in the table view
    /*
    For each selection do the following
    1.Instantiate the corresponding view controller with its identifier
    2.If required assign a navigation controller to it
    3.now make it or its navigation Controller(if assigned any) the contentViewController of the frostedViewController
    4.Call the self.frostedViewController.hideMenuViewController()
    */
    func tableView(tableView: UITableView, didSelectRowAtIndexPath indexPath: NSIndexPath) {
        if(indexPath.row == 0){
            
            var navController = self.storyboard?.instantiateViewControllerWithIdentifier("contentController") as? UINavigationController
            var destViewController = self.storyboard?.instantiateViewControllerWithIdentifier("ScrollBase") as! HorizontalScrollBaseViewController
            navController?.viewControllers = [destViewController]
            destViewController.count = 0
            self.frostedViewController.contentViewController = navController
            self.frostedViewController.hideMenuViewController()
            
        }else if(indexPath.row == 1){
            
            var navController = self.storyboard?.instantiateViewControllerWithIdentifier("contentController") as? UINavigationController
            var destViewController = self.storyboard?.instantiateViewControllerWithIdentifier("PaidQuestions") as! PremiumQuestionsViewController
            navController?.viewControllers = [destViewController]
            self.frostedViewController.contentViewController = navController
            self.frostedViewController.hideMenuViewController()
            
            
        }else if(indexPath.row == 2){
            
            var navController = self.storyboard?.instantiateViewControllerWithIdentifier("contentController") as? UINavigationController
            var destViewController = self.storyboard?.instantiateViewControllerWithIdentifier("PublicQuestions") as! PublicQuestionsViewController
            navController?.viewControllers = [destViewController]
            self.frostedViewController.contentViewController = navController
            self.frostedViewController.hideMenuViewController()
            
        }else if(indexPath.row == 4){
            
            var navController = self.storyboard?.instantiateViewControllerWithIdentifier("contentController") as? UINavigationController
            var destViewController = self.storyboard?.instantiateViewControllerWithIdentifier("ScrollBase") as! HorizontalScrollBaseViewController
            navController?.viewControllers = [destViewController]
            destViewController.count = 1
            self.frostedViewController.contentViewController = navController
            self.frostedViewController.hideMenuViewController()
        }
    }
}
