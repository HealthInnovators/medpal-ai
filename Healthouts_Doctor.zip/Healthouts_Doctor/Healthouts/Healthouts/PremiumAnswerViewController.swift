//
//  PremiumAnswerViewController.swift
//  Healthouts
//
//  Created by Y.Bharath Kumar Reddy on 02/07/15.
//  Copyright (c) 2015 Y.Bharath Kumar Reddy. All rights reserved.
//

import UIKit

class PremiumAnswerViewController: UIViewController,UITextViewDelegate,UITextFieldDelegate {

    //required outlets
    @IBOutlet weak var answerTextView: UITextView!
    @IBOutlet weak var summaryTextField: UITextField!
    @IBOutlet weak var contentView: UIView!
    @IBOutlet weak var scrollView: UIScrollView!
    
    //required variables
    var actInd : UIActivityIndicatorView = UIActivityIndicatorView(frame: CGRectMake(0,0, 50, 50)) as UIActivityIndicatorView
    var chatId = 0
    
    override func viewDidLoad() {
        super.viewDidLoad()

        //set the left and right constraints for the content view of the scrollview
        var leftConstraint = NSLayoutConstraint(item: self.contentView, attribute: NSLayoutAttribute.Leading, relatedBy: NSLayoutRelation.Equal, toItem: self.view, attribute: NSLayoutAttribute.Left, multiplier: 1, constant: 0)
        self.view.addConstraint(leftConstraint)
        
        var rightConstraint = NSLayoutConstraint(item: self.contentView, attribute: NSLayoutAttribute.Trailing, relatedBy: NSLayoutRelation.Equal, toItem: self.view, attribute: NSLayoutAttribute.Right, multiplier: 1, constant: 0)
        self.view.addConstraint(rightConstraint)
        
        //add the keyboard notifications
        NSNotificationCenter.defaultCenter().addObserver(self, selector: "keyboardWillBeShown:", name: UIKeyboardWillShowNotification, object: nil)
        NSNotificationCenter.defaultCenter().addObserver(self, selector: "keyboardWillBeHidden:", name: UIKeyboardWillHideNotification, object: nil)
        
        //set the texfields and textviews delegate
        summaryTextField.delegate = self
        answerTextView.delegate = self
        
        //set the properties of answer text View
        answerTextView.textColor = UIColor.lightGrayColor()
        answerTextView.layer.borderColor = UIColor(red: 0, green: 147/255, blue: 59/255, alpha: 0.86).CGColor
        answerTextView.layer.borderWidth = 1
        answerTextView.layer.cornerRadius = 5
       
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    @IBAction func backButtonPressed(sender: AnyObject) {
        self.navigationController?.popViewControllerAnimated(true)
    }

    //keyboard notifications..
    func keyboardWillBeHidden(notification:NSNotification){
        var contentInsets = UIEdgeInsetsZero
        self.scrollView.contentInset = contentInsets
        self.scrollView.scrollIndicatorInsets = contentInsets
    }
    
    func keyboardWillBeShown(notification:NSNotification){
        if let userInfo = notification.userInfo {
            if let keyboardSize = (userInfo[UIKeyboardFrameBeginUserInfoKey] as? NSValue)?.CGRectValue() {
                var contentInsets = UIEdgeInsetsMake(0, 0, keyboardSize.height, 0)
                self.scrollView.contentInset = contentInsets
                self.scrollView.scrollIndicatorInsets = contentInsets
                var rect = self.contentView.frame
                rect.size.height -= keyboardSize.height
                /*if (!answerTextView.isFirstResponder() && !CGRectContainsPoint(rect, self.summaryTextField.frame.origin)) {
                    var scrollPoint = CGPointMake(0.0, self.summaryTextField.frame.origin.y - (keyboardSize.height - self.summaryTextField.frame.size.height))
                    self.scrollView.setContentOffset(scrollPoint, animated: false)
                }else{
                    var scrollPoint = CGPointMake(0.0, self.answerTextView.frame.origin.y - (keyboardSize.height - self.answerTextView.frame.size.height) + 64)
                    self.scrollView.setContentOffset(scrollPoint, animated: false)
                }*/
            }
        }
    }
    
    //textview and textfield delegates
    func textViewDidBeginEditing(textView: UITextView) {
        if(textView.text == "Enter your brief answer"){
            textView.text = ""
            textView.textColor = UIColor.blackColor()
        }
        
    }
    
    func textViewDidEndEditing(textView: UITextView) {
        if(textView.text == ""){
            textView.text = "Enter your brief answer"
            textView.textColor = UIColor.lightGrayColor()
        }
        
    }
    
    
    func textFieldShouldReturn(textField: UITextField) -> Bool {
        textField.resignFirstResponder()
        return true
    }
    
    //send the premium answer
    @IBAction func sendButtonPressed(sender: AnyObject) {
        summaryTextField.resignFirstResponder()
        answerTextView.resignFirstResponder()
        
        actInd.center = self.view.center
        actInd.hidesWhenStopped = true
        actInd.activityIndicatorViewStyle = UIActivityIndicatorViewStyle.White
        actInd.backgroundColor = UIColor.blackColor()
        actInd.layer.cornerRadius = 5
        view.addSubview(actInd)
        actInd.startAnimating()
        
        var userInfo = NSUserDefaults.standardUserDefaults().objectForKey("userInfo") as? NSDictionary
        var customerId = userInfo?.objectForKey("customerId") as! Int
        var customerEmail = userInfo?.objectForKey("emailId") as! String
        
        if(summaryTextField.text == "" && answerTextView.text == "Enter your brief answer" ){
            self.actInd.stopAnimating()
            var alert = UIAlertController(title: "Alert", message: "Kindly fill in atleast one of the fields", preferredStyle: UIAlertControllerStyle.Alert)
            alert.addAction(UIAlertAction(title: "ok", style: UIAlertActionStyle.Default, handler: nil))
            self.presentViewController(alert, animated: true, completion: nil)
        }else{
            SRWebClient.POST("http://healthouts.com/appSendAnswerToPremiumQuestion?")
                .data(["CID":customerId,"cEmail":customerEmail,"chatId":self.chatId,"summary":summaryTextField.text,"details":answerTextView.text])
                .send({ (response:AnyObject!, status:Int) -> Void in
                    self.actInd.stopAnimating()
                    var err: NSError?
                    var data = (response as! String).dataUsingEncoding(NSUTF8StringEncoding, allowLossyConversion: true)
                    if let jsonResult = NSJSONSerialization.JSONObjectWithData(data!, options: NSJSONReadingOptions.MutableContainers, error: &err) as? NSDictionary {
                        dispatch_async(dispatch_get_main_queue(), {
                        
                            if(jsonResult.objectForKey("status") as! String == "1"){
                                self.addSuccessAlert(jsonResult.objectForKey("message") as! String)
                            }else{
                                self.addFailureAlert(jsonResult.objectForKey("message") as! String)
                            }
                        })
                    }else{
                        self.addFailureAlert("there seems to be a parse error")
                    }
            }, failure: { (error) -> Void in
                dispatch_async(dispatch_get_main_queue(), {
                    
                    self.actInd.stopAnimating()
                    self.addFailureAlert("Kindly Make sure you are connected to the internet")
                    
                })
            })
        }
    }
    
    
    override func touchesBegan(touches: Set<NSObject>, withEvent event: UIEvent) {
        summaryTextField.resignFirstResponder()
        answerTextView.resignFirstResponder()
    }
    
    //alert functions
    func addSuccessAlert(message:String){
        var alert = UIAlertController(title: "Alert", message: message, preferredStyle: UIAlertControllerStyle.Alert)
        alert.addAction(UIAlertAction(title: "ok", style: UIAlertActionStyle.Default, handler: { (action:UIAlertAction!) -> Void in
            self.navigationController?.popViewControllerAnimated(true)
        }))
        self.presentViewController(alert, animated: true, completion: nil)
    }
    
    func addFailureAlert(message:String){
        var alert = UIAlertController(title: "Alert", message: message, preferredStyle: UIAlertControllerStyle.Alert)
        alert.addAction(UIAlertAction(title: "ok", style: UIAlertActionStyle.Default, handler: nil))
        self.presentViewController(alert, animated: true, completion: nil)
    }
}
