//
//  UpdateKnownForViewController.swift
//  Healthouts
//
//  Created by Y.Bharath Kumar Reddy on 23/06/15.
//  Copyright (c) 2015 Y.Bharath Kumar Reddy. All rights reserved.
//

import UIKit

class UpdateKnownForViewController: UIViewController,UITextFieldDelegate {

    //outlets from the story board
    @IBOutlet weak var contentView: UIView!
    @IBOutlet weak var scrollView: UIScrollView!
    @IBOutlet weak var topic1TextField: UITextField!
    @IBOutlet weak var topic2TextField: UITextField!
    @IBOutlet weak var topic3TextField: UITextField!
    @IBOutlet weak var topic4TextField: UITextField!
    @IBOutlet weak var topic5TextField: UITextField!
    
    //required variables
    var selectedTextView:UITextView!
    var selectedTextField:UITextField!
    var actInd : UIActivityIndicatorView = UIActivityIndicatorView(frame: CGRectMake(0,0, 50, 50)) as UIActivityIndicatorView
    
    override func viewDidLoad() {
        super.viewDidLoad()

        //set the textfield and textview delegates
        topic1TextField.delegate = self
        topic2TextField.delegate = self
        topic3TextField.delegate = self
        topic4TextField.delegate = self
        topic5TextField.delegate = self
        
        contentView.backgroundColor = UIColor.clearColor()
        
        //populate the textfields like clinicName,address etc using the doctorCompleteProfile
        topic1TextField.text = doctorCompleteProfile.objectForKey("topic1") as! String
        topic2TextField.text = doctorCompleteProfile.objectForKey("topic2") as! String
        topic3TextField.text = doctorCompleteProfile.objectForKey("topic3") as! String
        topic4TextField.text = doctorCompleteProfile.objectForKey("topic4") as! String
        topic5TextField.text = doctorCompleteProfile.objectForKey("topic5") as! String
        
        //set the left and right constraints of the content view of the scroll view
        var leftConstraint = NSLayoutConstraint(item: self.contentView, attribute: NSLayoutAttribute.Leading, relatedBy: NSLayoutRelation.Equal, toItem: self.view, attribute: NSLayoutAttribute.Left, multiplier: 1, constant: 0)
        self.view.addConstraint(leftConstraint)
        
        var rightConstraint = NSLayoutConstraint(item: self.contentView, attribute: NSLayoutAttribute.Trailing, relatedBy: NSLayoutRelation.Equal, toItem: self.view, attribute: NSLayoutAttribute.Right, multiplier: 1, constant: 0)
        self.view.addConstraint(rightConstraint)
        
    }

    override func viewWillAppear(animated: Bool) {
        super.viewWillAppear(true)
        
         //add the keyboard notifications
        NSNotificationCenter.defaultCenter().addObserver(self, selector: "keyboardWillBeShown:", name: UIKeyboardWillShowNotification, object: nil)
        NSNotificationCenter.defaultCenter().addObserver(self, selector: "keyboardWillBeHidden:", name: UIKeyboardWillHideNotification, object: nil)
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    //call the service url to save the details
    @IBAction func saveButtonPressed(sender: AnyObject) {
        //resign the first responders
        if(selectedTextField != nil){
            selectedTextField.resignFirstResponder()
        }
        if(selectedTextView != nil){
            selectedTextView.resignFirstResponder()
        }
        
        //start the activity indicator
        actInd.center = CGPointMake(self.view.center.x, self.view.center.y - 64)
        actInd.hidesWhenStopped = true
        actInd.activityIndicatorViewStyle = UIActivityIndicatorViewStyle.White
        actInd.backgroundColor = UIColor.blackColor()
        actInd.layer.cornerRadius = 5
        view.addSubview(actInd)
        actInd.startAnimating()
        
        //prepare the parameters to be sent with the url
        var userInfo = NSUserDefaults.standardUserDefaults().objectForKey("userInfo") as? NSDictionary
        var customerId = userInfo?.objectForKey("customerId") as! Int
        var customerEmail = userInfo?.objectForKey("emailId") as! String
        
        //call the SRWebClient with the required url and parameters
        SRWebClient.POST("http://healthouts.com/appSaveKnwonfor?")
            .data(["CID":customerId,"cEmail":customerEmail,"JSONObj":["topic1":topic1TextField.text,"topic2":topic2TextField.text,"topic3":topic3TextField.text,"topic4":topic4TextField.text,"topic5":topic5TextField.text]])
            .send({ (response:AnyObject!, status:Int) -> Void in
                self.actInd.stopAnimating()
                var err: NSError?
                var data = (response as! String).dataUsingEncoding(NSUTF8StringEncoding, allowLossyConversion: true)
                if let jsonResult = NSJSONSerialization.JSONObjectWithData(data!, options: NSJSONReadingOptions.MutableContainers, error: &err) as? NSDictionary {
                    
                    dispatch_async(dispatch_get_main_queue(), {
                    
                        self.addAlert(jsonResult["message"] as! String)
                        
                    })
                }else{
                    self.addAlert("parsing error.kindly try again")
                }
                }, failure: { (error) -> Void in
                    dispatch_async(dispatch_get_main_queue(), {
                    
                        self.addAlert(error.localizedDescription)
                        
                    })
                    
            })
    }
    
    //textfield and text view delegate methods
    func textFieldShouldBeginEditing(textField: UITextField) -> Bool {
        
        self.selectedTextField = textField
        return true
    }
    
    func textViewShouldBeginEditing(textView: UITextView) -> Bool {
        self.selectedTextView = textView
        return true
    }
    
    func textFieldShouldReturn(textField: UITextField) -> Bool {
        textField.resignFirstResponder()
        return true
    }
    
    //add the keyboard notifications
    func keyboardWillBeHidden(notification:NSNotification){
        var contentInsets = UIEdgeInsetsZero
        self.scrollView.contentInset = contentInsets
        self.scrollView.scrollIndicatorInsets = contentInsets
    }
    
    func keyboardWillBeShown(notification:NSNotification){
        if let userInfo = notification.userInfo {
            if let keyboardSize = (userInfo[UIKeyboardFrameBeginUserInfoKey] as? NSValue)?.CGRectValue() {
                //self.bottomConstraint.constant = -keyboardSize.height
                var contentInsets = UIEdgeInsetsMake(0, 0, keyboardSize.height, 0)
                self.scrollView.contentInset = contentInsets
                self.scrollView.scrollIndicatorInsets = contentInsets
                var rect = self.contentView.frame
                rect.size.height -= keyboardSize.height
                if (!CGRectContainsPoint(rect, self.selectedTextField.frame.origin)) {
                    var scrollPoint = CGPointMake(0.0, self.selectedTextField.frame.origin.y - (keyboardSize.height - self.selectedTextField.frame.size.height))
                    self.scrollView.setContentOffset(scrollPoint, animated: false)
                }
            }
        }
    }

    
    override func viewWillDisappear(animated: Bool) {
        super.viewWillDisappear(true)
        
        //remove all the notifications
        NSNotificationCenter.defaultCenter().removeObserver(self)
    }
    
    //function to add alert
    func addAlert(message:String){
        var alert = UIAlertController(title: "Alert", message: message, preferredStyle: UIAlertControllerStyle.Alert)
        alert.addAction(UIAlertAction(title: "ok", style: UIAlertActionStyle.Default, handler: nil))
        self.presentViewController(alert, animated: true, completion: nil)
    }
}
