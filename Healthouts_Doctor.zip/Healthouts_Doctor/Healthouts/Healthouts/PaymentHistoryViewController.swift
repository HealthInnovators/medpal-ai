//
//  PaymentHistoryViewController.swift
//  Healthouts
//
//  Created by Y.Bharath Kumar Reddy on 23/06/15.
//  Copyright (c) 2015 Y.Bharath Kumar Reddy. All rights reserved.
//

import UIKit

class PaymentHistoryViewController: UIViewController,UITableViewDataSource,UITableViewDelegate {

    //outlets from the storyboard
    @IBOutlet weak var tableView: UITableView!
    
    //required variables
    var tableData = []
    var actInd : UIActivityIndicatorView = UIActivityIndicatorView(frame: CGRectMake(0,0, 50, 50)) as UIActivityIndicatorView
    var myMutableString = NSMutableAttributedString()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        //register the custom cell
        var nib1 = UINib(nibName: "PaymentHistoryTableViewCell", bundle: nil)
        tableView.registerNib(nib1, forCellReuseIdentifier: "PaymentHistoryCell")

    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    override func viewWillAppear(animated: Bool) {
        super.viewWillAppear(true)
        
        //function to get the payment data
        getData()
    }

    //call the payment history service url
    func getData(){
        
        //start the activity indicator
        actInd.center = CGPointMake(self.view.center.x, self.view.center.y - 64)
        actInd.hidesWhenStopped = true
        actInd.activityIndicatorViewStyle = UIActivityIndicatorViewStyle.White
        actInd.backgroundColor = UIColor.blackColor()
        actInd.layer.cornerRadius = 5
        view.addSubview(actInd)
        actInd.startAnimating()
        
        //prepare the parameters to be sent with the url
        var userInfo = NSUserDefaults.standardUserDefaults().objectForKey("userInfo") as? NSDictionary
        var customerId = userInfo?.objectForKey("customerId") as! Int
        var customerEmail = userInfo?.objectForKey("emailId") as! String
        
        //call the SRWebClient with the service url and parameters
        SRWebClient.POST("http://healthouts.com/appDoctorPayHistory?")
            .data(["CID":customerId,"cEmail":customerEmail])
            .send({ (response:AnyObject!, status:Int) -> Void in
                self.actInd.stopAnimating()
                var err: NSError?
                var data = (response as! String).dataUsingEncoding(NSUTF8StringEncoding, allowLossyConversion: true)
                if let jsonResult = NSJSONSerialization.JSONObjectWithData(data!, options: NSJSONReadingOptions.MutableContainers, error: &err) as? NSMutableArray {
                    dispatch_async(dispatch_get_main_queue(), {
                    
                        self.tableData = jsonResult
                        self.tableView.hidden = false
                        self.tableView.reloadData()
                        
                    })
                   
                }else{
                    var alert = UIAlertController(title: "Alert", message: err?.localizedDescription, preferredStyle: UIAlertControllerStyle.Alert)
                    alert.addAction(UIAlertAction(title: "ok", style: UIAlertActionStyle.Default, handler: nil))
                    self.presentViewController(alert, animated: true, completion: nil)
                }
                
            }, failure: { (error) -> Void in
                dispatch_async(dispatch_get_main_queue(), {
                    
                    self.actInd.stopAnimating()
                    var alert = UIAlertController(title: "Alert", message: "Please make sure you are connected to the internet", preferredStyle: UIAlertControllerStyle.Alert)
                    alert.addAction(UIAlertAction(title: "ok", style: UIAlertActionStyle.Default, handler: nil))
                    self.presentViewController(alert, animated: true, completion: nil)
                        
                })
            })
    }
    
    //number of cells in the tableview
    func tableView(tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return tableData.count - 1
    }
    
    //populate the tableview
    //initialise the name,transaction id,fee etc of each cell
    func tableView(tableView: UITableView, cellForRowAtIndexPath indexPath: NSIndexPath) -> UITableViewCell {
        
        var identifier = "PaymentHistoryCell"
        var cell  = tableView.dequeueReusableCellWithIdentifier(identifier) as! PaymentHistoryTableViewCell
        
        cell.selectionStyle = UITableViewCellSelectionStyle.None
        cell.containerView.layer.cornerRadius = 10
        
        var paymentData:NSDictionary = tableData[indexPath.row] as! NSDictionary
        
        var text = "Transaction Id : " +  (paymentData.objectForKey("payref") as! String)
        myMutableString = NSMutableAttributedString(string: text, attributes: [NSFontAttributeName : UIFont(name: "HelveticaNeue", size: 15)!])
        myMutableString.addAttribute(NSFontAttributeName, value: UIFont(name: "HelveticaNeue-Bold", size: 15)!, range: NSRange(location: 0, length: 16))
        cell.idLabel.attributedText = myMutableString
        
        text = "Name : " +  (paymentData.objectForKey("customerName") as! String)
        myMutableString = NSMutableAttributedString(string: text, attributes: [NSFontAttributeName : UIFont(name: "HelveticaNeue", size: 15)!])
        myMutableString.addAttribute(NSFontAttributeName, value: UIFont(name: "HelveticaNeue-Bold", size: 15)!, range: NSRange(location: 0, length: 5))
        cell.nameLabel.attributedText = myMutableString
        
        var fee = paymentData.objectForKey("consultationFee") as! CGFloat
        var feestring = "\(fee)"
        var currency = paymentData.objectForKey("currencyCode") as! String

        text = "Fee : " + feestring + " " + currency
        myMutableString = NSMutableAttributedString(string: text, attributes: [NSFontAttributeName : UIFont(name: "HelveticaNeue", size: 15)!])
        myMutableString.addAttribute(NSFontAttributeName, value: UIFont(name: "HelveticaNeue-Bold", size: 15)!, range: NSRange(location: 0, length: 4))
        cell.feeLabel.attributedText = myMutableString
        
        text = "Date : " +  (paymentData.objectForKey("payDate") as! String)
        myMutableString = NSMutableAttributedString(string: text, attributes: [NSFontAttributeName : UIFont(name: "HelveticaNeue", size: 15)!])
        myMutableString.addAttribute(NSFontAttributeName, value: UIFont(name: "HelveticaNeue-Bold", size: 15)!, range: NSRange(location: 0, length: 5))
        cell.dateLabel.attributedText = myMutableString
        
        if let type = paymentData.objectForKey("consultationType") as? String{
            text = "Type : " +  (paymentData.objectForKey("consultationType") as! String)
            myMutableString = NSMutableAttributedString(string: text, attributes: [NSFontAttributeName : UIFont(name: "HelveticaNeue", size: 15)!])
            myMutableString.addAttribute(NSFontAttributeName, value: UIFont(name: "HelveticaNeue-Bold", size: 15)!, range: NSRange(location: 0, length: 5))
            cell.typeLabel.attributedText = myMutableString
        }else{
            cell.typeLabel.text = "Type :"
        }

        return cell
    }
   

}
