//
//  RootViewController.swift
//  Healthouts
//
//  Created by Y.Bharath Kumar Reddy on 21/06/15.
//  Copyright (c) 2015 Y.Bharath Kumar Reddy. All rights reserved.
//

import UIKit

class RootViewController: REFrostedViewController {

    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    override func awakeFromNib() {
        //instantiate the content view controller for the side navigation container
        self.contentViewController = self.storyboard?.instantiateViewControllerWithIdentifier("contentController") as? UINavigationController
        
        //instantiate menu view controller for the side navigation container
        self.menuViewController = self.storyboard?.instantiateViewControllerWithIdentifier("menuController") as? MenuViewController
        
        //set some properties like the size of side menu etc
        self.limitMenuViewSize  = true
        self.menuViewSize = CGSizeMake(275, UIScreen.mainScreen().bounds.size.height)
    }

}
