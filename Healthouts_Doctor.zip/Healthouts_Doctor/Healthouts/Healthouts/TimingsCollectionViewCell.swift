//
//  TimingsCollectionViewCell.swift
//  Healthouts
//
//  Created by Y.Bharath Kumar Reddy on 28/06/15.
//  Copyright (c) 2015 Y.Bharath Kumar Reddy. All rights reserved.
//

import UIKit

class TimingsCollectionViewCell: UICollectionViewCell {
    @IBOutlet weak var timeLabel: UILabel!
    @IBOutlet weak var stateLabel: UILabel!
    @IBOutlet weak var availabilityImageView: UIImageView!
    
}
