//
//  PaidQuestionTableViewCell.swift
//  Healthouts
//
//  Created by Y.Bharath Kumar Reddy on 01/07/15.
//  Copyright (c) 2015 Y.Bharath Kumar Reddy. All rights reserved.
//

import UIKit

protocol PaidQuestionCellDelegate{
    func showAttachment(attachmentName:String)
    func answerNow(button:UIButton)
}

class PaidQuestionTableViewCell: UITableViewCell {

    @IBOutlet weak var containerView: UIView!
    @IBOutlet weak var attachmentsButton: UIButton!
    @IBOutlet weak var questionBodyLabel: UILabel!
    @IBOutlet weak var questionSubjectLabel: UILabel!
    @IBOutlet weak var userNameLabel: UILabel!
    @IBOutlet weak var userImageView: UIImageView!
    @IBOutlet weak var answerButton: UIButton!
    @IBOutlet weak var bottomSpaceConstraint: NSLayoutConstraint!
    
    //delegate to respond to buttons in the cell
    var delegate:PaidQuestionCellDelegate?
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }

    @IBAction func attachmentButtonPressed(sender: AnyObject) {
        self.delegate?.showAttachment((sender as! UIButton).titleForState(UIControlState.Normal)!)
    }
    @IBAction func answerNowPressed(sender: AnyObject) {
        self.delegate?.answerNow(sender as! UIButton)
    }
}

