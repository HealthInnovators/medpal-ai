//
//  UpdateSpecializationViewController.swift
//  Healthouts
//
//  Created by Y.Bharath Kumar Reddy on 23/06/15.
//  Copyright (c) 2015 Y.Bharath Kumar Reddy. All rights reserved.
//

import UIKit

class UpdateSpecializationViewController: UIViewController,UIPickerViewDataSource,UIPickerViewDelegate,UITextFieldDelegate {

    //outlets from the storyboard
    @IBOutlet weak var practiceTextField: UITextField!
    @IBOutlet weak var scrollView: UIScrollView!
    @IBOutlet weak var contentView: UIView!
    @IBOutlet weak var universityTextField: UITextField!
    @IBOutlet weak var degreeTextField: UITextField!
    @IBOutlet weak var licenseTextField: UITextField!
    @IBOutlet weak var speciality1TextField: UITextField!
    @IBOutlet weak var speciality2TextField: UITextField!
    @IBOutlet weak var speciality3TextField: UITextField!
    @IBOutlet weak var speciality4TextField: UITextField!
    @IBOutlet weak var speciality5TextField: UITextField!
    @IBOutlet weak var saveButton: UIButton!
    
    //required variables
    var selectedTextView:UITextView!
    var selectedTextField:UITextField!
    var practicePickerView:UIPickerView!
    var specialitiesArray = ["General Physician","OB-Gynecologist","Dermatologist","Dentist","ENT","Eye Doctor","Cardiologist","Pediatrician","Orthopedician","Cancer Specialist","Endocrinologist","General Surgeon","Psychiatrist"]
    var textFieldArr:NSArray = []
    var actInd : UIActivityIndicatorView = UIActivityIndicatorView(frame: CGRectMake(0,0, 50, 50)) as UIActivityIndicatorView
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        //set the textfield and text view delegates
        practiceTextField.delegate = self
        universityTextField.delegate = self
        degreeTextField.delegate = self
        licenseTextField.delegate = self
        speciality1TextField.delegate = self
        speciality2TextField.delegate = self
        speciality3TextField.delegate = self
        speciality4TextField.delegate = self
        speciality5TextField.delegate = self
        
        //initialise the picker view to select the speciality and set it as the inputView of the practiceTextField
        practicePickerView = UIPickerView(frame: CGRectMake(0, 0, self.view.frame.size.width, 100))
        practicePickerView.delegate = self
        practicePickerView.dataSource = self
        practiceTextField.inputView = practicePickerView
        
        //make a view with a done button and make it the inputAccessory view of the practiceTextField
        var view = UIView(frame: CGRectMake(0, 0, self.view.frame.size.width, 40))
        var button = UIButton(frame: CGRectMake(0, 0, self.view.frame.size.width, 40))
        button.setTitle("Done", forState: UIControlState.Normal)
        button.backgroundColor = UIColor.blackColor()
        button.addTarget(self, action: "specialitySelected", forControlEvents: UIControlEvents.TouchUpInside)
        view.addSubview(button)
        practiceTextField.inputAccessoryView = view
        
        
        contentView.backgroundColor = UIColor.clearColor()
        
        //initialise the textfields
        practiceTextField.text = doctorCompleteProfile.objectForKey("specialization") as! String
        universityTextField.text = doctorCompleteProfile.objectForKey("universityName") as! String
        degreeTextField.text = doctorCompleteProfile.objectForKey("qualification") as! String
        licenseTextField.text = doctorCompleteProfile.objectForKey("doctorLicenceNumber") as! String
        
        textFieldArr = [speciality1TextField,speciality2TextField,speciality3TextField,speciality4TextField,speciality5TextField]
        var additionalSpecialitiesString = doctorCompleteProfile.objectForKey("additionalSpecialty") as! String
        let additionalSpecialitiesArray = additionalSpecialitiesString.componentsSeparatedByString(",")
        
        var i = 0
        for(i = 0;i < additionalSpecialitiesArray.count-1 ;i++){
            (textFieldArr[i] as! UITextField).text = additionalSpecialitiesArray[i]
        }
        
        
        //set the left and right constraints of the content view in the scroll view
        var leftConstraint = NSLayoutConstraint(item: self.contentView, attribute: NSLayoutAttribute.Leading, relatedBy: NSLayoutRelation.Equal, toItem: self.view, attribute: NSLayoutAttribute.Left, multiplier: 1, constant: 0)
        self.view.addConstraint(leftConstraint)
        
        var rightConstraint = NSLayoutConstraint(item: self.contentView, attribute: NSLayoutAttribute.Trailing, relatedBy: NSLayoutRelation.Equal, toItem: self.view, attribute: NSLayoutAttribute.Right, multiplier: 1, constant: 0)
        self.view.addConstraint(rightConstraint)
        
        saveButton.layer.cornerRadius = 5
        
    }

    override func viewWillAppear(animated: Bool) {
        super.viewWillAppear(true)
        
        //add the keyboard notifications
        NSNotificationCenter.defaultCenter().addObserver(self, selector: "keyboardWillBeShown:", name: UIKeyboardWillShowNotification, object: nil)
        NSNotificationCenter.defaultCenter().addObserver(self, selector: "keyboardWillBeHidden:", name: UIKeyboardWillHideNotification, object: nil)
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    //call the service url
    @IBAction func saveButtonPressed(sender: AnyObject) {
        
        //resign the first responders
        if(selectedTextField != nil){
            selectedTextField.resignFirstResponder()
        }
        if(selectedTextView != nil){
            selectedTextView.resignFirstResponder()
        }
        
        //start the activity indicator
        actInd.center = CGPointMake(self.view.center.x, self.view.center.y - 64)
        actInd.hidesWhenStopped = true
        actInd.activityIndicatorViewStyle = UIActivityIndicatorViewStyle.White
        actInd.backgroundColor = UIColor.blackColor()
        actInd.layer.cornerRadius = 5
        view.addSubview(actInd)
        actInd.startAnimating()
        
        //prepare the parameters to be sent with the url
        var speciality = practiceTextField.text
        var userInfo = NSUserDefaults.standardUserDefaults().objectForKey("userInfo") as? NSDictionary
        var customerId = userInfo?.objectForKey("customerId") as! Int
        var customerEmail = userInfo?.objectForKey("emailId") as! String
        
        var additionalSpeciality = ""
        var i = 0
        for(i=0;i<5;i++){
            additionalSpeciality = additionalSpeciality + (textFieldArr[i] as! UITextField).text + ","
        }
        
        //call the SRWebClient with the required url and parameters
        SRWebClient.POST("http://healthouts.com/appSaveEducationDetails?")
            .data(["CID":customerId,"cEmail":customerEmail,"JSONObj":["doctorSpecialization":speciality,"doctorQualification":degreeTextField.text,"universityName":universityTextField.text,"doctorLicenceNumber":licenseTextField.text,"additionalSpecialty":additionalSpeciality]])
            .send({ (response:AnyObject!, status:Int) -> Void in
                self.actInd.stopAnimating()
                var err: NSError?
                var data = (response as! String).dataUsingEncoding(NSUTF8StringEncoding, allowLossyConversion: true)
                if let jsonResult = NSJSONSerialization.JSONObjectWithData(data!, options: NSJSONReadingOptions.MutableContainers, error: &err) as? NSDictionary {
                    
                    dispatch_async(dispatch_get_main_queue(), {
                    
                        self.addAlert(jsonResult["message"] as! String)
                        
                    })
                }else{
                    self.addAlert((err?.localizedDescription)!)
                }
            }, failure: { (error) -> Void in
                dispatch_async(dispatch_get_main_queue(), {
                        
                    self.addAlert(error.localizedDescription)
                    
                })
        })
    }

    
    //textfield and textview delegate methods
    func textFieldShouldReturn(textField: UITextField) -> Bool {
        textField.resignFirstResponder()
        return true
    }
    
    func textViewShouldBeginEditing(textView: UITextView) -> Bool {
        self.selectedTextView = textView
        return true
    }
    
    func textFieldShouldBeginEditing(textField: UITextField) -> Bool {
        self.selectedTextField = textField
        return true
    }
    
    //speciality picker view delegate and datasource methods
    func pickerView(pickerView: UIPickerView, numberOfRowsInComponent component: Int) -> Int {
        return specialitiesArray.count
    }
    
    func pickerView(pickerView: UIPickerView, titleForRow row: Int, forComponent component: Int) -> String! {
        return specialitiesArray[row]
    }
    
    func numberOfComponentsInPickerView(pickerView: UIPickerView) -> Int{
        return 1
    }

    //keyboard notification functions
    func keyboardWillBeHidden(notification:NSNotification){
        var contentInsets = UIEdgeInsetsZero
        self.scrollView.contentInset = contentInsets
        self.scrollView.scrollIndicatorInsets = contentInsets
    }
    
    func keyboardWillBeShown(notification:NSNotification){
        if let userInfo = notification.userInfo {
            if let keyboardSize = (userInfo[UIKeyboardFrameBeginUserInfoKey] as? NSValue)?.CGRectValue() {
                //self.bottomConstraint.constant = -keyboardSize.height
                var contentInsets = UIEdgeInsetsMake(0, 0, keyboardSize.height, 0)
                self.scrollView.contentInset = contentInsets
                self.scrollView.scrollIndicatorInsets = contentInsets
                var rect = self.contentView.frame
                rect.size.height -= keyboardSize.height
                if (!CGRectContainsPoint(rect, self.selectedTextField.frame.origin)) {
                    var scrollPoint = CGPointMake(0.0, self.selectedTextField.frame.origin.y - (keyboardSize.height - self.selectedTextField.frame.size.height))
                    self.scrollView.setContentOffset(scrollPoint, animated: false)
                }
            }
        }
    }
    
    override func viewWillDisappear(animated: Bool) {
        super.viewWillDisappear(true)
        //remove the notifications before the view disappears
        NSNotificationCenter.defaultCenter().removeObserver(self)
    }
    
    //dismiss the picker view once the speciality is selected
    func specialitySelected(){
        practiceTextField.text = specialitiesArray[practicePickerView.selectedRowInComponent(0)]
        self.view.endEditing(true)
    }
 
    //function to add alert
    func addAlert(message:String){
        var alert = UIAlertController(title: "Alert", message: message, preferredStyle: UIAlertControllerStyle.Alert)
        alert.addAction(UIAlertAction(title: "ok", style: UIAlertActionStyle.Default, handler: nil))
        self.presentViewController(alert, animated: true, completion: nil)
    }
}
