//
//  ShowAttachmentViewController.swift
//  Healthouts
//
//  Created by Y.Bharath Kumar Reddy on 02/07/15.
//  Copyright (c) 2015 Y.Bharath Kumar Reddy. All rights reserved.
//

import UIKit

class ShowAttachmentViewController: UIViewController,UIWebViewDelegate {

    //required outlets
    @IBOutlet weak var webView: UIWebView!
    
    //required variables..
    var attachmentName = ""
    var actInd : UIActivityIndicatorView = UIActivityIndicatorView(frame: CGRectMake(0,0, 50, 50)) as UIActivityIndicatorView
    
    override func viewDidLoad() {
        super.viewDidLoad()
        //load the webview with the attchment's url
        webView.delegate = self
        attachmentName = attachmentName.stringByReplacingOccurrencesOfString(" ", withString: "%20")
        var urlString = "http://healthouts.com/img/" + attachmentName
        var url = NSURL(string: urlString)!
        var request = NSURLRequest(URL: url)
        webView.loadRequest(request)
        
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    //webview delegate methods to start and stop the activity indicator
    func webViewDidStartLoad(webView: UIWebView) {
        actInd.center = self.view.center
        actInd.hidesWhenStopped = true
        actInd.activityIndicatorViewStyle = UIActivityIndicatorViewStyle.White
        actInd.backgroundColor = UIColor.blackColor()
        actInd.layer.cornerRadius = 10
        view.addSubview(actInd)
        actInd.startAnimating()
        
    }
    
    func webViewDidFinishLoad(webView: UIWebView) {
        actInd.stopAnimating()
    }
    
    //handle the back button
    @IBAction func backButtonPressed(sender: AnyObject) {
        self.navigationController?.popViewControllerAnimated(true)
    }


}
