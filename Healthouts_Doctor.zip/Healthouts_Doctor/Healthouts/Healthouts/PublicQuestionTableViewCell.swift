//
//  PublicQuestionTableViewCell.swift
//  Healthouts
//
//  Created by Y.Bharath Kumar Reddy on 07/07/15.
//  Copyright (c) 2015 Y.Bharath Kumar Reddy. All rights reserved.
//

import UIKit

protocol PublicQuestionCellDelegate{
    func answerNow(button:UIButton)
}

class PublicQuestionTableViewCell: UITableViewCell {

    @IBOutlet weak var containerView: UIView!
    @IBOutlet weak var questionLabel: UILabel!
    @IBOutlet weak var timeLabel: UILabel!
    @IBOutlet weak var answerNowButton: UIButton!
    
    //delegate to respond to buttons in the cell
    var delegate:PublicQuestionCellDelegate?
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)
        // Configure the view for the selected state
    }

    
    @IBAction func answerButtonPressed(sender: AnyObject) {
        self.delegate?.answerNow(sender as! UIButton)
    }
    
    
   
}
